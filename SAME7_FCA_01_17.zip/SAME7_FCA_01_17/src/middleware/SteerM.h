#ifndef __STEERM_H
#define __STEERM_H

#include "bsp.h"
#include "global_type.h"

void SetGB_Angle(uint16_t PitchData, float EulerPitch);//, float WatchAng);

#endif /* __STEERM_H */
