#include "SteerM.h"

static int16_t GB_PWM = 400;

void SetGB_Angle(uint16_t PitchData, float EulerPitch)//, float WatchAng)
{
//	int16_t Data = (int16_t)((PitchData - 400) * 0.14f + 128.0f);
	GB_PWM = (GB_PWM > PitchData + 6) ? (GB_PWM - 6) : ((GB_PWM < PitchData - 6) ? (GB_PWM + 6) : GB_PWM);
	int16_t Data = (GB_PWM - 400) / 10 + 160;
	if(EulerPitch > 90) EulerPitch = 90;
	if(EulerPitch < -90) EulerPitch = -90;
	Data += (int16_t)((EulerPitch * 16) / 9);
//	Data += (int16_t)((WatchAng * 16) / 9);
	write(Steer_getID(), &Data, 1);
}
