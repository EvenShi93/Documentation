#ifndef _PRESSUREM_H_
#define _PRESSUREM_H_

#include "bsp.h"

void pressureM_task(void);
float get_pressure(void);

#endif 
