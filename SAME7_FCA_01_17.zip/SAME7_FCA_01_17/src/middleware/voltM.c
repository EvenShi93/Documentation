#include "voltM.h"

#define SAMPLE_NUM 300

uint8_t WriteVoltParamFlag = 0;
static uint8_t VoltCaliSta = 0;
static uint32_t VoltCalProg = 0;
static int32_t RawDataSum[2] = {0};
static int16_t RawDataAvg[2] = {0};

short voltValueRaw[1] = {0};
//float VoltMod = 0.00772470703125f;

float Volt_k = 0.00944475f, Volt_b = 0.0f;

float get_volt(void)
{
	float temp;
	read(volt_getID(), voltValueRaw, 2);
//	temp = (float)(voltValueRaw - voltOffset) * 3.3f * 4.333f/4096.0f;
	temp = (float)(voltValueRaw[0]) * Volt_k + Volt_b;
//	temp = (float)(voltValueRaw - voltOffset) * 3.3f * 9.588f/4096.0f;
	return temp;
}

uint8_t VoltCalibrate(uint8_t Flag)//1->H,2->L
{
//	if(VoltCalProg < 400)
//	{
//		read(volt_getID(), voltValueRaw, 2);
//		if(VoltCalProg == 0)
//			VoltMod = 12.5f / voltValueRaw[0];
//		VoltMod = (12.5f / voltValueRaw[0]) * 0.9f + VoltMod * 0.1f;
//		VoltCalProg ++;
//	}
//	return (VoltCalProg / 4);

	if(VoltCalProg < SAMPLE_NUM)
	{
		read(volt_getID(), voltValueRaw, 2);
		if(VoltCalProg == 0)
		{
			VoltCaliSta |= Flag;
			RawDataSum[Flag - 1] = 0;
		}
		RawDataSum[Flag - 1] += voltValueRaw[0];
		VoltCalProg ++;
		if(VoltCalProg == SAMPLE_NUM)
		{
			RawDataAvg[Flag - 1] = RawDataSum[Flag - 1] / SAMPLE_NUM;
			if(VoltCaliSta == 0x3)
			{
				Volt_k = 2.2f / ((float)(RawDataAvg[0] - RawDataAvg[1]));
				Volt_b = 12.0f - Volt_k * RawDataAvg[0];

				WriteVoltParamFlag = 1;
			}
		}
	}
	return (VoltCalProg / (SAMPLE_NUM / 100));
}

void InitVoltCal(void)
{
	VoltCalProg = 0;
}

void GetVoltCalParam(float *fData)
{
	fData[0] = Volt_k;
	fData[1] = Volt_b;
}

void SetVoltCalParam(float k, float b)
{
	Volt_k = k;
	Volt_b = b;
}
