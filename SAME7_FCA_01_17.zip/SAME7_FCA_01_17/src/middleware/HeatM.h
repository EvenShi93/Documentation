#ifndef __HEATM_H
#define __HEATM_H

#include "bsp.h"

void OpenHeater(void);
void CloseHeater(void);

#endif /* __HEATM_H */
