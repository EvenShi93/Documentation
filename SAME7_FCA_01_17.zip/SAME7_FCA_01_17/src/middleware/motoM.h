#ifndef _MOTOM_H_
#define _MOTOM_H_

#include "bsp.h"

#define Moto_PwmMax 1900
#define Moto_PwmMin 1200

#define ESCBUS_MSG_ID_CONFIG_BASIC 0
#define	ESCBUS_MSG_ID_CONFIG_FULL 1
#define	ESCBUS_MSG_ID_RUN 2
#define	ESCBUS_MSG_ID_TUNE 3
#define	ESCBUS_MSG_ID_DO_CMD 4

#define ToneTypMsk_1  0x0001
#define ToneTypMsk_2  0x0002
#define ToneTypMsk_3  0x0004
#define ToneTypMsk_4  0x0008
#define ToneTypMsk_5  0x0010
#define ToneTypMsk_6  0x0020
#define ToneTypMsk_7  0x0040
#define ToneTypMsk_8  0x0080
#define ToneTypMsk_9  0x0100
#define ToneTypMsk_10 0x0200
#define ToneTypMsk_11 0x0400
#define ToneTypMsk_12 0x0800
#define ToneTypMsk_13 0x1000
#define ToneTypMsk_14 0x2000
#define ToneTypMsk_15 0x4000
//#define ToneTypMsk_16 0x8000

typedef enum
{
	rfLink = 0,
	rfLost = 1,
	User_1 = 2,
	GPSReady = 3,
	EEPROMErr = 4,
	MPU6500Err = 5,
	IST8307Err = 6,
	MS56xxErr = 7,
	FlowCamera = 8,
	UBLOXM8Err = 9,
	AccCalDataErr = 10,
	MagCalOK = 11,
	Startup = 12,
	Shutdown = 13,
	Default = 14
}ToneCmd;

void motoM_run_set(float moto1,float moto2,float moto3,float moto4);
void Send_ESC_Tone(uint16_t ferq, uint16_t len, uint8_t pwr);

#endif 
