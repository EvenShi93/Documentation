#include "switchM.h"
#include "motoM.h"

uint8_t GetSwitchLevel(void)
{
	uint8_t SwitchLevel;
	read(switch_getID(), &SwitchLevel, 1);
	return SwitchLevel;
}
