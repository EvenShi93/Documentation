#include "rfM.h"
#include "global_type.h"
#include "maths.h"
#include "FlowAlgorithm.h"

/* ---------------------- ESC版本号 ---------------------- */
uint16_t ESC_Version = 1;//default:V0.0.1
/* ---------------------- Drone S/N ---------------------- */
uint8_t DroneSN[16] = {'Y','U','1','6','-','-','x','x','x','x','#','#','#','*','?','?'};
/* ----------------------- 系统参数 ---------------------- */
FCA_SystemParam DroneSysParam = {//设置默认值 
	.Distance = 40,
	.Height = 10,
	.LoseGPS_ACT = 1,
	.GoHomeHeight = 200,
	.OutDoorDist = 600,
	.OutDoorHeight = 60,
	.OutDoorSpeeed = 400
};

extern uint8_t flyEnable;
static unsigned char recPackageFlag = 0;
static unsigned int rfLostCount = 1000;//默认是掉信号
unsigned char rfRelinkClose = 0;

#if defined(CTRL_RF)
#define CHTOPWM1024(ch) (unsigned short)((unsigned int)(ch) * 2400 / 1023)
#define CHTOPWM2048(ch) (unsigned short)((unsigned int)(ch) * 2400 / 2047)
#define CHTOPWM4096(ch) (unsigned short)((unsigned int)(ch) * 2400 / 4095)

YUNEEC_RF_STR recRFPackage = {0};

#elif defined(CTRL_A9)

YUNEEC_A9_STR recA9Package = {0};
static RF_GPS_DATA rfData_GPSInfo;
static rfGPS_DATA rfGPSInfo;

PACKET_TYPE recPackageType = PACKET_TYPE_CHANNELDATA12;
Calibration_Type CalCmd = 0;
FCA_SysParamSet SetSystemParam = {0};
uint8_t SysParamChanged = 0;

uint8_t AppsGetInfoFlag = 0;
extern void StartMagCalibrate(void);
extern uint8_t MagCalibrateSta(void);
#endif

REMOTE_DATA remoteData;

void rfM_task(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

/* --------------------接收机接收-------------------- */
#if defined(CTRL_RF)
	recPackageFlag = read(rf_st10_getID(), &recRFPackage, 0);
#elif defined(CTRL_A9)
	ioctrl(AppsA9_getID(), CMD_GET_REC_FLAG, &recPackageFlag);
#endif

	OS_EXIT_CRITICAL();

	if(recPackageFlag == 1)
	{
#if defined(CTRL_A9)
		ioctrl(AppsA9_getID(), CMD_GET_PKG_TYPE, &recPackageType);
		if(recPackageType == PACKET_TYPE_CHANNELDATA12)//不带GPS的数据包
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, &recA9Package);
#endif
			//使用新数据
			OS_ENTER_CRITICAL();
#if defined(CTRL_RF)
			if(recRFPackage.status[1] < 50)//未掉信号
#elif defined(CTRL_A9)
			if(1)//if(recA9Package.status[1] < 50)//未掉信号
#endif
			{
				for(unsigned char i = 0; i < 12; i ++)
				{
#if defined(CTRL_RF)
					unsigned int j = i * 3 / 2;
					if(i % 2 == 0)//偶数
					{
						remoteData.RemoteD[i] = \
							CHTOPWM4096(((unsigned short)(recRFPackage.channel[j]) << 4) | ((unsigned short)(recRFPackage.channel[j + 1] & 0xf0) >> 4));
					}
					else
					{
						remoteData.RemoteD[i] = \
							CHTOPWM4096(((unsigned short)(recRFPackage.channel[j] & 0x0f) << 8) | ((unsigned short)(recRFPackage.channel[j + 1])));
					}
#elif defined(CTRL_A9)
					remoteData.RemoteD[i] = ((unsigned short *)recA9Package.channel)[i];
#endif
				}
				rfLostCount = 0;
			}
#if defined(CTRL_RF)
			else
			{
				rfLostCount ++; 
				if(rfLostCount >= 2000)
				{
					rfLostCount = 2000;
				}
			}
#endif /* defined(CTRL_RF) */
			OS_EXIT_CRITICAL();

			rfRelinkClose = 1;
#if defined(CTRL_A9)
		}
		else if(recPackageType == PACKET_TYPE_CHANNELDATA12_GPS)//带GPS的数据包
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, &rfData_GPSInfo);
			if(rfData_GPSInfo.status[1] < 50)//未掉信号
			{
				for(unsigned char i = 0; i < 12; i ++)
				{
					remoteData.RemoteD[i] = ((unsigned short *)rfData_GPSInfo.channel)[i];
				}
				rfLostCount = 0;
			}
			else
			{
				rfLostCount ++; 
				if(rfLostCount >= 2000)
				{
					rfLostCount = 2000;
				}
			}
			rfGPSInfo.lat = rfData_GPSInfo.lat * 0.0000001;
			rfGPSInfo.lon = rfData_GPSInfo.lon * 0.0000001;
			rfGPSInfo.alt = rfData_GPSInfo.alt * 0.001f;
			rfGPSInfo.speed = rfData_GPSInfo.speed * 0.1f;
			rfGPSInfo.accurancy = rfData_GPSInfo.accurancy * 0.001;
			rfGPSInfo.heading = rfData_GPSInfo.heading;
			rfGPSInfo.fixType = rfData_GPSInfo.fixType;
			rfRelinkClose = 1;
		}
		else if(recPackageType == PACKET_TYPE_File_Ready)
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, NULL);
			if(flyEnable == 0)
			{
				__set_FAULTMASK(1);
				NVIC_SystemReset();//系统复位
			}
		}
		else if(recPackageType == PACKET_TYPE_Calibration_Set)
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, &CalCmd);
			if(CalCmd == 1 && MagCalibrateSta() == 0) StartMagCalibrate();//magCalibrationFlag = 1;
//			else if(CalCmd == 2) accCalibrationFlag = 1;
		}
		else if(recPackageType == PACKET_TYPE_Version_Chk)
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, NULL);
			AppsGetInfoFlag |= 0x01;//需要发送版本包
		}
		else if(recPackageType == PACKET_TYPE_Parameter_Set)
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, &SetSystemParam);
			for(uint8_t Index = 0; Index < SetSystemParam.ParNum; Index ++)//写入参数
				((int16_t *)&DroneSysParam)[Index + SetSystemParam.ParOffset] = SetSystemParam.ParData[Index];
			SysParamChanged = 1;//系统参数改变，需要写入EEPROM
			AppsGetInfoFlag |= 0x04;//需要发送写入参数的应答包
		}
		else if(recPackageType == PACKET_TYPE_ALLParameter_Chk)
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, NULL);
			AppsGetInfoFlag |= 0x02;//需要发送参数列表包
		}
		else
		{
			ioctrl(AppsA9_getID(), CMD_GET_PKG_DATA, NULL);
//			__nop();
		}
#endif
	}
	else
	{
		//使用原数据
#if defined(CTRL_A9)
		if(MagCalibrateSta() == 1) rfLostCount = 0;//recPackageType == PACKET_TYPE_Calibration_Set && 
		else
#endif
		rfLostCount ++;
		if(rfLostCount >= 2000)
		{
			 rfLostCount = 2000;
		}
	}
}

static YUNEEC_SND_STR YuneecSendData = {
	.h1 = 0x55,
	.h2 = 0x55
};

#if defined(CTRL_RF)
void rf_relink(void)
{
//	YuneecSendData.h1 = 0x55;
//	YuneecSendData.h2 = 0x55;
	YuneecSendData.length = 8;
	YuneecSendData.type = PACKET_TYPE_BINDCMD;
	YuneecSendData.buffer[0] = 0;
	YuneecSendData.buffer[1] = 0;
	YuneecSendData.buffer[2] = 'B';
	YuneecSendData.buffer[3] = 'I';
	YuneecSendData.buffer[4] = 'N';
	YuneecSendData.buffer[5] = 'D';
	YuneecSendData.buffer[6] = crcRfCal((unsigned char *)&YuneecSendData.length, 8);
	write(rf_st10_getID(),(unsigned char* )&YuneecSendData, 11);
}
#endif
//返回标准格式大数据包
void rf_send_remote_data(rfFeedBackData *Data)
{
	YUNEEC_FEEDBACK_STR *feedback_data = (YUNEEC_FEEDBACK_STR *)&YuneecSendData;
//	feedback_data->h1 = 0x55;
//	feedback_data->h2 = 0x55;
	feedback_data->length = sizeof(YUNEEC_FEEDBACK_STR) - 3;
	feedback_data->type = PACKET_TYPE_TELEMETRYDATA;
	feedback_data->t = (_Get_Secnds() & 0x00FF);//0;
	feedback_data->lat = Data->gpsData->lat;
	feedback_data->lon = Data->gpsData->lon;
	feedback_data->alt = Data->alt;
	feedback_data->vx = Data->gpsData->velN / 10;
	feedback_data->vy = Data->gpsData->velE / 10;
	feedback_data->vz = Data->gpsData->velD / 10;
    if(Data->LockFlag == 1)
		feedback_data->nsat = 0x80| Data->gpsData->numSV;
    else
		feedback_data->nsat = 0x0| Data->gpsData->numSV;
	if(Data->voltage > 12.6f) Data->voltage = 12.6f;
	feedback_data->voltage = (uint8_t)(Data->voltage * 71) - 640;//(Data->voltage * 10) - 50;
#if defined(CTRL_RF)
	feedback_data->current = 5;
#elif defined(CTRL_A9)
	feedback_data->current = Data->TakeOffSta;//5;
#endif
	feedback_data->roll = Data->eur->Rool * 100;
	feedback_data->pitch = Data->eur->Pitch * 100;
	feedback_data->yaw = Data->eur->Yaw * 100;
	feedback_data->imuStatus = Data->IMU_Sta;
#if defined(CTRL_RF)
	feedback_data->baroMagGpsStatus = 0x7f;
#elif defined(CTRL_A9)
	feedback_data->baroMagGpsStatus = Data->DeviceInit;
#endif
	feedback_data->flightMode = Data->flightMode;
#if defined(CTRL_RF)
	feedback_data->vehicleType = 4;
#elif defined(CTRL_A9)
	feedback_data->vehicleType = Data->ElectricQuantity;
#endif
	feedback_data->errorFlags = Data->errorFlags;
	feedback_data->gpsAccH = (uint8_t)(Data->GPSaccV);
	feedback_data->motorStatus = Data->motorStatus;
	feedback_data->crc = crcRfCal((unsigned char *)&(feedback_data->length), feedback_data->length);
#if defined(CTRL_RF)
	write(rf_st10_getID(), (unsigned char *)feedback_data, sizeof(YUNEEC_FEEDBACK_STR));
#elif defined(CTRL_A9)
	write(AppsA9_getID(), (unsigned char *)feedback_data, sizeof(YUNEEC_FEEDBACK_STR));
#endif
}

#if defined(CTRL_A9)
//返回100Hz姿态角数据
void RFSendHighFreqAttitude(FLOAT_RPY *eur)
{
	Parameter_Send *AttitudeData = (Parameter_Send *)&YuneecSendData;
//	AttitudeData->h1 = 0x55;
//	AttitudeData->h2 = 0x55;
	AttitudeData->length = sizeof(Parameter_Send) - 3;
	AttitudeData->type = PACKET_TYPE_Eur100Hz;
	AttitudeData->Eur_Roll = eur->Rool * 100;
	AttitudeData->Eur_Pitch = eur->Pitch * 100;
	AttitudeData->Eur_Yaw = (eur->Yaw - 180) * 100;
	AttitudeData->TimestampMS = _Get_Millis();

	AttitudeData->crc = crcRfCal((unsigned char *)&(AttitudeData->length), AttitudeData->length);
	write(AppsA9_getID(), (unsigned char *)AttitudeData, sizeof(Parameter_Send));
}
//返回特殊参数
void AppSendYPRCData(int16_t *ParamBuf)
{
	YPRC_Action_t *YPRC_Data = (YPRC_Action_t *)&YuneecSendData;
//	YPRC_Data->h1 = 0x55;
//	YPRC_Data->h2 = 0x55;
	YPRC_Data->length = sizeof(YPRC_Action_t) - 3;
	YPRC_Data->type = YPRC_PACKET_TYPE_ACTION;
	YPRC_Data->ACTION_Type = 1;
	YPRC_Data->ACTION_Parameter_1 = ParamBuf[0];//Dist
	YPRC_Data->ACTION_Parameter_2 = ParamBuf[1];//Angle * 100;
	YPRC_Data->ACTION_Parameter_3 = ParamBuf[2];
	YPRC_Data->ACTION_Parameter_4 = ParamBuf[3];
	YPRC_Data->crc = crcRfCal((unsigned char *)&(YPRC_Data->length), YPRC_Data->length);
	write(AppsA9_getID(), (unsigned char *)YPRC_Data, sizeof(YPRC_Action_t));
}
//返回地磁校准状态
void MagCaliProgSend(uint8_t Step, uint8_t Prog, uint8_t CmpSat)
{
	MagCalProg_t *CalProg = (MagCalProg_t *)&YuneecSendData;

//	CalProg->h1 = 0x55;
//	CalProg->h2 = 0x55;
	CalProg->length = sizeof(MagCalProg_t) - 3;
	CalProg->type = PACKET_TYPE_Calibration_Sta;

	CalProg->Calibration_Type = 1;
	CalProg->Calibration_StaNum = 3;
	CalProg->Calibration_StaNOW = Step;
	CalProg->Calibration_ProgressNum = 100;
	CalProg->Calibration_ProgressNow = Prog;
	CalProg->Calibration_Complete = CmpSat;

	CalProg->crc = crcRfCal((unsigned char *)&(CalProg->length), CalProg->length);
	write(AppsA9_getID(), (unsigned char *)CalProg, sizeof(MagCalProg_t));
}
//返回飞控及调速器版本号
void FW_Ver_Send(void)
{
	FW_Ver_t *FCA_Ver = (FW_Ver_t *)&YuneecSendData;
//	FCA_Ver->h1 = 0x55;
//	FCA_Ver->h2 = 0x55;
	FCA_Ver->length = sizeof(FW_Ver_t) - 3;
	FCA_Ver->type = PACKET_TYPE_Version_ACK;

	FCA_Ver->FCA_FW_Ver = FCA_VER;
	FCA_Ver->ESC_FW_Ver = ESC_Version;
	for(uint8_t i = 0; i < 16; i ++)
		FCA_Ver->DroneSN[i] = DroneSN[i];
	FCA_Ver->crc = crcRfCal((unsigned char *)&(FCA_Ver->length), FCA_Ver->length);
	write(AppsA9_getID(), (unsigned char *)FCA_Ver, sizeof(FW_Ver_t));
	AppsGetInfoFlag &= 0xFE;
}
//系统参数应答包
void WriteAllParamAck(void)
{
	FCA_SysParamSetAck *AckParSet = (FCA_SysParamSetAck *)&YuneecSendData;
	AckParSet->length = sizeof(FCA_SysParamSetAck) - 3;
	AckParSet->type = PACKET_TYPE_Parameter_ACK;

	AckParSet->SucNum = SetSystemParam.ParNum;//写入成功的数据个数
	AckParSet->Ack_Type = 1;//写入全部成功

	AckParSet->crc = crcRfCal((unsigned char *)&(AckParSet->length), AckParSet->length);
	write(AppsA9_getID(), (unsigned char *)AckParSet, sizeof(FCA_SysParamSetAck));
	AppsGetInfoFlag &= 0xFB;
}
//返回系统配置参数及飞控版本号
void SendFCA_AllParam(void)
{
	FCA_FW_AllParam *AllParam = (FCA_FW_AllParam *)&YuneecSendData;
	AllParam->length = sizeof(FCA_FW_AllParam) - 3;
	AllParam->type = PACKET_TYPE_ALLParameter_Send;

	AllParam->FCA_FW_Ver = (FCA_VER_1 & FCA_VER_1_Msk) | (FCA_VER_2 & FCA_VER_2_Msk) | (FCA_VER_3 & FCA_VER_3_Msk);
	AllParam->ParNum = 7;
	AllParam->SysPar.Distance = DroneSysParam.Distance;//获取配置参数
	AllParam->SysPar.Height = DroneSysParam.Height;
	AllParam->SysPar.LoseGPS_ACT = DroneSysParam.LoseGPS_ACT;
	AllParam->SysPar.GoHomeHeight = DroneSysParam.GoHomeHeight;
	AllParam->SysPar.OutDoorDist = DroneSysParam.OutDoorDist;
	AllParam->SysPar.OutDoorHeight = DroneSysParam.OutDoorHeight;
	AllParam->SysPar.OutDoorSpeeed = DroneSysParam.OutDoorSpeeed;

//	AllParam->LogNumber = 0;

	AllParam->crc = crcRfCal((unsigned char *)&(AllParam->length), AllParam->length);
	write(AppsA9_getID(), (unsigned char *)AllParam, sizeof(FCA_FW_AllParam));
	AppsGetInfoFlag &= 0xFD;
}

//返回系统日志需要记录的数据
void SendFCA_LogInfo(uint8_t LogID, uint8_t *pLogBuf)
{
	FCA_Log_Info *LogInfo = (FCA_Log_Info *)&YuneecSendData;
	LogInfo->length = sizeof(FCA_Log_Info) - 3;
	LogInfo->type = PACKET_TYPE_DroneLog;

	LogInfo->LogID = LogID;
	memcpy(LogInfo->LogInfo, pLogBuf, 38);
//	for(uint8_t i = 0; i < 38; i ++)
//		LogInfo->LogInfo[i] = pLogBuf[i];

	LogInfo->crc = crcRfCal((unsigned char *)&(LogInfo->length), LogInfo->length);
	write(AppsA9_getID(), (unsigned char *)LogInfo, sizeof(FCA_Log_Info));
}
#endif /* defined(CTRL_A9) */

inline FCA_SystemParam *GetDroneSysParam(void)
{
	return &DroneSysParam;
}

uint8_t rfIsLost(void)
{
	if(rfLostCount > 200)
		return 1;
	else
		return 0;
}

REMOTE_DATA* get_rf_data(void)
{
	return &remoteData;
}

unsigned char get_rf_relink_flag(void)
{
	return rfRelinkClose;
}

#if defined(CTRL_A9)
rfGPS_DATA* get_rf_GPS(void)
{
	return &rfGPSInfo;
}
#endif
