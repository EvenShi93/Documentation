#include "flashM.h"

void flashM_earse(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();
	open(flash_getID());
	ioctrl(flash_getID(),FLASH_RWE_SECTOR_ADDR_SETTING,(void*)FLASH_PARAM_ADDR);
	ioctrl(flash_getID(),FLASH_EARSE,(void*)FLASH_EARSE_SECTOR);
	close(flash_getID());
	OS_EXIT_CRITICAL();
}

void flashM_read(unsigned char* buffer,unsigned int len)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();
	open(flash_getID());
	ioctrl(flash_getID(),FLASH_RWE_SECTOR_ADDR_SETTING,(void*)FLASH_PARAM_ADDR);
	read(flash_getID(),buffer,len);
	close(flash_getID());
	OS_EXIT_CRITICAL();	
}

void flashM_write(unsigned char* buffer,unsigned int len)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();
	open(flash_getID());
	ioctrl(flash_getID(),FLASH_RWE_SECTOR_ADDR_SETTING,(void*)FLASH_PARAM_ADDR);
	write(flash_getID(),buffer,len);
	close(flash_getID());
	OS_EXIT_CRITICAL();	
}
