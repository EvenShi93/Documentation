#include "UltraSonicM.h"

static Sonar Son_Dis = {0, 0, 1};
static ErrCode SonicErr = ERR_OK;
static uint32_t SonicUpdateTimeBase = 0;
static uint32_t SonicDisValidTimeCnt = 0;

Sonar GetSonicDistance(void)
{
	static float SonicDist = 0;

	if(read(Ultrasonic_getID(), &SonicDist, 4))//Get Timetick.
	{
		SonicUpdateTimeBase = _Get_Micros();

		SonicErr = ERR_WARNING;
		Son_Dis.distance_valid = 0;//无效
		Son_Dis.UnStable = 1;
		if(SonicDist > SonicUpperLimit)//红外给出了一个很大的值,就需要重新等待
			SonicDisValidTimeCnt = 0;
		else if(SonicDisValidTimeCnt < 50)//连续收到1s
			SonicDisValidTimeCnt ++;
		else if(SonicDisValidTimeCnt >= 50)//连续收到的50个数据都在有效范围内说明红外数据正常
		{
			Son_Dis.UnStable = 0;
			if(SonicDist < SonicUpperLimit && SonicDist > SonicLowerLimit)
			{
				SonicErr = ERR_OK;
				Son_Dis.distance_valid = 1;  //有效
			}
		}
		Son_Dis.Sonic_speed = SonicDist - Son_Dis.sonar_distance_raw;//current - last
		Son_Dis.sonar_distance_raw = SonicDist;
		Son_Dis.sonar_distance_filtered = SonicDist;
	}
	else
	{
		if(_Get_Micros() - SonicUpdateTimeBase > 200000)//200ms
		{
			SonicErr = ERR_BAD;
			Son_Dis.distance_valid = 0;//无效
		}
	}
	return Son_Dis;
}

inline ErrCode GetSonicStat(void)
{
	return SonicErr;
}
