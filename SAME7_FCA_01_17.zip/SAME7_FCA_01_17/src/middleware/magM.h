#ifndef _MAGM_H_
#define _MAGM_H_

#include "bsp.h"
#include "global_type.h"

void magM_task(void);
FLOAT_MAG* get_mag(void);
float *GetCalMatrix(void);
ErrCode GetMagErrFlag(void);
void SetCalMatrix(float M[]);
MAGNET_RAW_SHORT *get_magRaw(void);

#endif 
