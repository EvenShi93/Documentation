#ifndef __CAMERAM_H
#define __CAMERAM_H

#include "middleware.h"

uint8_t GetImageBuffer(uint8_t **previous_image, uint8_t **current_image);
uint8_t CalLumVal(void);
uint32_t GetImage_T(void);
uint8_t GetCamLumValue(void);
uint8_t GetImageUpdate(void);

#endif /* __CAMERAM_H */
