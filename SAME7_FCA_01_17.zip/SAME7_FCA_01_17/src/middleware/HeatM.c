#include "HeatM.h"

void OpenHeater(void)
{
//	open(Heat_getID());
}

void CloseHeater(void)
{
	close(Heat_getID());
}
