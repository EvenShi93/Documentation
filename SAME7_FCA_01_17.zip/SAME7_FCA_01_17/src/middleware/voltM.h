#ifndef _VOLTM_H_
#define _VOLTM_H_

#include "bsp.h"

//void voltM_task(void);
float get_volt(void);
void InitVoltCal(void);void GetVoltCalParam(float *fData);
uint8_t VoltCalibrate(uint8_t Flag);
void SetVoltCalParam(float k, float b);

#endif 
