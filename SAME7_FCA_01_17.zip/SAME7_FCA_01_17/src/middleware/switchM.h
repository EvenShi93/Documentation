#ifndef _SWITCHM_H_
#define _SWITCHM_H_

#include "bsp.h"

uint8_t GetSwitchLevel(void);

#endif 
