#ifndef _ACCM_H_
#define _ACCM_H_

#include "bsp.h"
#include "global_type.h"

void acc_gyro_temp_M_task(void);


FLOAT_ACC* get_acc_unit(void);
ACC_RAW_SHORT* get_acc_raw(void);
void  acc_calibration_200ms_task(void);

float GetGravity(void);
float *GetGyrPeaceOff(void);
FLOAT_GYRO* get_gyro_unit(void);
GYRO_RAW_SHORT* get_gyro_raw(void);
//uint8_t gyroPeace(uint8_t milis);//�е���ʱ��Ҫ��,�������ⲿ����
uint8_t GetGyrPeaceSta(void);
void gyro_calibration_10ms_task(void);
uint8_t GetIMURunSta(void);
uint8_t GetAccStableFlag(void);
float get_IMUtemperature_unit(void);

#endif 
