#ifndef _LEDM_H_
#define _LEDM_H_

#include "bsp.h"

void led_on_board_open(void);
void led_on_board_close(void);

#endif
