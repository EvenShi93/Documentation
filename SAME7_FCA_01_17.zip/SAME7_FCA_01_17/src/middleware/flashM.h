#ifndef _FLASHM_H_
#define _FLASHM_H_


#include "bsp.h"

void flashM_earse(void);
void flashM_read(unsigned char* buffer,unsigned int len);
void flashM_write(unsigned char* buffer,unsigned int len);

#endif 
