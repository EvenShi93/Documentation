﻿#include "ledM.h"


void led_on_board_open(void)
{
	open(led_getID());
}

void led_on_board_close(void)
{
	close(led_getID());
}
