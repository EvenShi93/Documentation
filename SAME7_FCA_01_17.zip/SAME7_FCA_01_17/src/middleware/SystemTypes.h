#ifndef __SYSTEMTYPES_H
#define __SYSTEMTYPES_H

#include "stdint.h"
#include "_funcConfig.h"

#define FCA_VER_1 (1 << 12) /* ���汾�� */
#define FCA_VER_2 (1 << 8) /* ���汾�� */
#define FCA_VER_3 (3 << 0) /* ������ */

#define FCA_VER_1_Msk 0xF000
#define FCA_VER_2_Msk 0x0F00
#define FCA_VER_3_Msk 0x00FF

#define FCA_VER ((FCA_VER_1 & FCA_VER_1_Msk) | (FCA_VER_2 & FCA_VER_2_Msk) | (FCA_VER_3 & FCA_VER_3_Msk))

/* --------------------------------------------------- */
__packed typedef union
{
	__packed struct
	{
		uint8_t h1;
		uint8_t h2;
		uint16_t StarPoint;
		int16_t accBase[3];
		int16_t gryBase[3];
		uint8_t crc8;
	} members;
	uint8_t Page32[32];
}HeadPage;

__packed typedef union
{
	__packed struct
	{
		int16_t accOffset_1[3];
		int16_t gryOffset_1[3];
		int16_t accOffset_2[3];
		int16_t gryOffset_2[3];
	}members;
	uint8_t Page32[32];
}Temp_Cal_DataPage;

__packed typedef struct
{
	int16_t GryPecX;
	int16_t GryPecY;
	int16_t GryPecZ;
}GyrOffDataSave;//6B

__packed typedef struct
{
	uint16_t DataNumb;
	uint16_t DataIndex;
}GyrOffDataInfo;

__packed typedef union
{
	__packed struct
	{
		HeadPage  Vrefhead;//32B
		__packed union
		{
			uint8_t accCalreserve[32];
			float accCalM[8];
		}accCalData;//32B
		Temp_Cal_DataPage CalData[30];//30 * 32B
		GyrOffDataSave GyrErrVal[10];//60B
		GyrOffDataInfo GyrErrInfo;//4B
	}members;
	uint8_t Page32[34][32];
}Vref_DataPage;

/* --------------------------------------------------- */
__packed typedef enum
{
	PACKET_TYPE_CHANNELDATA12 = 0x0,
	PACKET_TYPE_CHANNELDATA24 = 0x1,
	PACKET_TYPE_TELEMETRYDATA = 0x2,
	PACKET_TYPE_CHANNELDATA12_GPS = 0x3,
	PACKET_TYPE_BINDCMD = 0x4,
	PACKET_TYPE_FWUpgradeData = 0x5,
	PACKET_TYPE_ACK_FWUpgrade = 0x6,
	PACKET_TYPE_File_Ready = 0x7,
	PACKET_TYPE_Parameter_Set = 0x8,
	PACKET_TYPE_Parameter_ACK = 0x9,
	PACKET_TYPE_ALLParameter_Chk = 0xA,
	PACKET_TYPE_ALLParameter_Send = 0xB,
	PACKET_TYPE_Version_Chk = 0xC,
	PACKET_TYPE_Version_ACK = 0xD,
	PACKET_TYPE_Calibration_Set = 0xE,
	PACKET_TYPE_Calibration_Sta = 0xF,
	PACKET_TYPE_Eur100Hz = 0x10,
	PACKET_TYPE_DroneLog = 0x11,
	YPRC_PACKET_TYPE_ACTION = 0x14,
}PACKET_TYPE;

#if defined(CTRL_A9)
typedef signed char Calibration_Type;//1 - Mag, 2 - IMU

__packed typedef struct
{
	uint8_t ParNum;
	uint8_t ParOffset;
	int16_t ParData[7];
}FCA_SysParamSet;

__packed typedef struct
{
	int16_t Distance;
	int16_t Height;
	int16_t LoseGPS_ACT;
	int16_t GoHomeHeight;
	int16_t OutDoorHeight;
	int16_t OutDoorDist;
	int16_t OutDoorSpeeed;
}FCA_SystemParam;//7 * 2Bytes

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
    unsigned char type;

	int32_t TimestampMS;
	int16_t Eur_Roll;
	int16_t Eur_Pitch;
	int16_t Eur_Yaw;

	unsigned char crc;
}Parameter_Send;//11Bytes

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
    unsigned char type;

   uint8_t ACTION_Type;
   int16_t ACTION_Parameter_1;
   int16_t ACTION_Parameter_2;
   int16_t ACTION_Parameter_3;
   int16_t ACTION_Parameter_4;

	unsigned char crc;
}YPRC_Action_t;//10Bytes

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
    unsigned char type;

	uint8_t Calibration_Type;
	uint8_t Calibration_StaNum;
	uint8_t Calibration_StaNOW;
	uint8_t Calibration_ProgressNum;
	uint8_t Calibration_ProgressNow;
	uint8_t Calibration_Complete;

	unsigned char crc;
}MagCalProg_t;

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
    unsigned char type;

	uint16_t FCA_FW_Ver;
	uint16_t ESC_FW_Ver;
	uint8_t DroneSN[16];

	unsigned char crc;
}FW_Ver_t;//10Bytes

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
    unsigned char type;

	uint8_t SucNum;
	uint8_t Ack_Type;

	unsigned char crc;
}FCA_SysParamSetAck;

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
    unsigned char type;

	uint16_t FCA_FW_Ver;
	uint8_t ParNum;
	FCA_SystemParam SysPar;

//	uint8_t LogNumber;
//	uint16_t LogData[10];

	unsigned char crc;
}FCA_FW_AllParam;

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
    unsigned char type;

	uint8_t LogID;
	uint8_t LogInfo[38];

	unsigned char crc;
}FCA_Log_Info;

#endif /* defined(CTRL_A9) */

__packed typedef struct
{
	unsigned short t;
	unsigned char status[2];
	unsigned char channel[24];

	int lat;
	int lon;
	float alt;
	unsigned short accurancy;
	unsigned short speed;
	short heading;
	unsigned char fixType;
}RF_GPS_DATA;

__packed typedef struct
{
	double lat;
	double lon;
	float alt;
	float accurancy;
	float speed;
	float heading;
	unsigned char fixType;
}rfGPS_DATA;

#endif /* __SYSTEMTYPES_H */
