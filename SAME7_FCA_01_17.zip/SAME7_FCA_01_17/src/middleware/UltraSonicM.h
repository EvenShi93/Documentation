#ifndef __ULTRASONICM_H
#define __ULTRASONICM_H

#include "bsp.h"
#include "global_type.h"

#if defined(USE_SONIC)
	#define SonicUpperLimit 5.0f
	#define SonicLowerLimit 0.4f
#elif defined(USE_INFRA)
	#define SonicUpperLimit 6.0f
	#define SonicLowerLimit 0.2f
#endif /* defined(USE_SONIC) */

/* sonar config*/
typedef struct{
	float sonar_distance_filtered; // distance in meter
	float sonar_distance_raw; // distance in meter
	bool distance_valid;
	float Sonic_speed;
	bool UnStable;
}Sonar;

Sonar GetSonicDistance(void);
ErrCode GetSonicStat(void);

#endif /* __ULTRASONICM_H */
