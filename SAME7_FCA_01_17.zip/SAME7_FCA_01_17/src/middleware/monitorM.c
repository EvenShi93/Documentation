#include "monitorM.h"
#include "monitor.h"

static unsigned char testBuffer[300]={0};

void comm_data_send(COMM_DATA* pcomm)
{
	unsigned char checksum=0;
	pcomm->head = 0x55;
	pcomm->cmd = 0xDD;
	pcomm->length = 36;
	for(unsigned char kk=0;kk<36;kk++)
	{
		checksum += pcomm->data[kk/4].c_data[kk%4];
	}
	pcomm->checksum = checksum;
	ioctrl(monitor_getID(), MONITOR_IOCTRL_COMM_DATA_WRITE, pcomm);
}

void comm_str_send(unsigned char* buffer,unsigned int size)
{
	unsigned char checksum=0;
	unsigned char data = 0; 
	data = 0x55;
	write(monitor_getID(),&data,1);
	data = 0xCC;
	write(monitor_getID(),&data,1);
	data = size;
	write(monitor_getID(),&data,1);
	for(unsigned char kk=0;kk<size;kk++)
	{
		checksum += buffer[kk];	
	}
	write(monitor_getID(),buffer,size);
	write(monitor_getID(),&checksum,1);
}
unsigned int str_len(unsigned char* buffer)
{
	unsigned int count = 0;
	while(buffer[count] != 0)
	{
		 count ++;
	}
	return count;
}

void str_add(unsigned char* buffer,unsigned char* bufferAdd,unsigned int len)
{
	for(unsigned int i=0;i<len;i++)
	{
		buffer[i] = bufferAdd[i];
	}
}

unsigned char* get_monitor_buffer_ptr(void)
{
	return testBuffer;
}

unsigned char MonitorRecData(RecPackTypeDef* RecData)
{
	if(read(monitor_getID(), RecData, ParPack))
	{
		return 1;
	}
	else return 0;
}

unsigned char MonitorCommData(RecCommTypeDef* RecData)
{
	if(read(monitor_getID(), RecData, CommPack))
	{
		return 1;
	}
	else return 0;
}
