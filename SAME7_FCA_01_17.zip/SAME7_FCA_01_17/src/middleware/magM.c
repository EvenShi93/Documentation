#include "magM.h"
#include "maths.h"
#include "height_task.h"

#define MagModRange 200.0f

static MAGNET_RAW_SHORT magnetRawShort = {0};
static FLOAT_MAG magMUnit;
static float MagM[7] = {0, 0, 0, 0, 1, 1, 1};
static int16_t Mbuffer[3] = {0};

static uint8_t MagErrCnt = 0;
static ErrCode Mag_ErrFlag = ERR_OK;

void magM_task(void)
{
	if(ioctrl(IST8307_getID(), READ_DATA, Mbuffer))
	{
		OS_ALLOC_SR();
		OS_ENTER_CRITICAL();
		float tempx, tempy, tempz;

		magnetRawShort.magX = Mbuffer[0];
		magnetRawShort.magY = Mbuffer[2];
		magnetRawShort.magZ = Mbuffer[1];
		OS_EXIT_CRITICAL();

		tempx = (float)magnetRawShort.magX;
		tempy = (float)magnetRawShort.magY;
		tempz = (float)magnetRawShort.magZ;

		tempx += MagM[0];
		tempy += MagM[1];
		tempz += MagM[2];

		tempx *= MagM[4];
		tempy *= MagM[5];
		tempz *= MagM[6];

		OS_ENTER_CRITICAL();

		magMUnit.magX = -tempz;
		magMUnit.magY = -tempx;
		magMUnit.magZ = tempy;

		MagErrCnt = 0;
		if(sqrtf(magMUnit.magX * magMUnit.magX + magMUnit.magY * magMUnit.magY + magMUnit.magZ * magMUnit.magZ) > MagModRange)
			Mag_ErrFlag = ERR_WARNING;
		else
			Mag_ErrFlag = ERR_OK;

		OS_EXIT_CRITICAL();
	}
	else
	{
		if(MagErrCnt < 20)
			MagErrCnt ++;
		else
			Mag_ErrFlag = ERR_BAD;
	}
}

FLOAT_MAG* get_mag(void)
{
	return &magMUnit;
}

MAGNET_RAW_SHORT *get_magRaw(void)
{
	return &magnetRawShort;
}

void SetCalMatrix(float M[])
{
	for(uint8_t i = 0; i < 7; i ++)
		MagM[i] = M[i];
}

float *GetCalMatrix(void)
{
	return MagM;
}

inline ErrCode GetMagErrFlag(void)
{
	return Mag_ErrFlag;
}
