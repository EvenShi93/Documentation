#ifndef _RFM_H_
#define _RFM_H_

#include "bsp.h"
#include "maths.h"
#include "gpsM.h"

__packed typedef union
{
	__packed struct
	{
		unsigned short aThrottle, aRoll, aPitch, aYaw, aRFMode, aReserve[7];
	}CtrlVar;
	unsigned short RemoteD[12];
}REMOTE_DATA;

__packed typedef struct
{
	unsigned char h1;   //0x55
	unsigned char h2;   //0x55
	unsigned char length;
	unsigned char type;
	unsigned short t;
	int lat;
	int lon;
	int alt;
	short vx,vy,vz;
	unsigned char nsat;
	unsigned char voltage;
	unsigned char current;
	short roll, pitch, yaw;
	unsigned char motorStatus;
	unsigned char imuStatus;
	unsigned char baroMagGpsStatus;
	unsigned char flightMode;
	unsigned char vehicleType;
	unsigned char errorFlags;
	unsigned char gpsAccH;
	unsigned char crc;
} YUNEEC_FEEDBACK_STR;

typedef struct
{
	GPS_DATA_RAW *gpsData;
	float alt;
	float voltage;
	FLOAT_RPY *eur;
	uint8_t flightMode;
	uint8_t errorFlags;
	uint8_t IMU_Sta;
	float GPSaccV;
	uint8_t LockFlag;
	uint8_t TakeOffSta;
	uint8_t motorStatus;
	uint8_t DeviceInit;
	uint8_t ElectricQuantity;
}rfFeedBackData;

void rfM_task(void);

#if defined(CTRL_RF)
void rf_relink(void);
#endif
void rf_send_remote_data(rfFeedBackData *Data);
#if defined(CTRL_A9)
void RFSendHighFreqAttitude(FLOAT_RPY *eur);
void AppSendYPRCData(int16_t *ParamBuf);
void MagCaliProgSend(uint8_t Step, uint8_t Prog, uint8_t CmpSat);
void FW_Ver_Send(void);
void WriteAllParamAck(void);
void SendFCA_AllParam(void);
void SendFCA_LogInfo(uint8_t LogID, uint8_t *pLogBuf);
#endif /* defined(CTRL_A9) */

uint8_t rfIsLost(void);
REMOTE_DATA* get_rf_data(void);
unsigned char get_rf_relink_flag(void);
#if defined(CTRL_A9)
rfGPS_DATA* get_rf_GPS(void);
#endif

FCA_SystemParam *GetDroneSysParam(void);

#endif
