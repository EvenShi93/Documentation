#include "motoM.h"
#include "maths.h"

static void Send_280QX_RpmCmd(short rpm0, short rpm1, short rpm2, short rpm3);

void motoM_run_set(float MOTO1_PWM, float MOTO2_PWM, float MOTO3_PWM, float MOTO4_PWM)
{
	if((MOTO1_PWM == 0) && (MOTO2_PWM == 0) && (MOTO3_PWM == 0) && (MOTO4_PWM == 0))
	{
		Send_280QX_RpmCmd(MOTO1_PWM, MOTO2_PWM, MOTO3_PWM, MOTO4_PWM);
	}
	else
	{
		if(MOTO1_PWM > Moto_PwmMax)	MOTO1_PWM = Moto_PwmMax;
		if(MOTO2_PWM > Moto_PwmMax)	MOTO2_PWM = Moto_PwmMax;
		if(MOTO3_PWM > Moto_PwmMax)	MOTO3_PWM = Moto_PwmMax;
		if(MOTO4_PWM > Moto_PwmMax)	MOTO4_PWM = Moto_PwmMax;

		if(MOTO1_PWM < Moto_PwmMin)	MOTO1_PWM = Moto_PwmMin;
		if(MOTO2_PWM < Moto_PwmMin)	MOTO2_PWM = Moto_PwmMin;
		if(MOTO3_PWM < Moto_PwmMin)	MOTO3_PWM = Moto_PwmMin;
		if(MOTO4_PWM < Moto_PwmMin)	MOTO4_PWM = Moto_PwmMin;

		Send_280QX_RpmCmd(MOTO1_PWM, MOTO2_PWM, MOTO3_PWM, MOTO4_PWM);
	}
}

//ferq0 len1-100 pwr1-100
void Send_ESC_Tone(uint16_t ferq, uint16_t len, uint8_t pwr)
{
	unsigned char ESCData[9] = {0};

	ESCData[0] = 0xFE;
	ESCData[1] = 5;
	ESCData[2] = ESCBUS_MSG_ID_TUNE;

	ESCData[3] = ferq & 0x00FF;
	ESCData[4] = (ferq >> 8);
	ESCData[5] = len & 0x00FF;
	ESCData[6] = (len >> 8);
	ESCData[7] = pwr;

	ESCData[8] = crcMotoCal(ESCData + 1, 7);

	write(moto_getID(), ESCData, 9);
}

static void Send_280QX_RpmCmd(short rpm0, short rpm1, short rpm2, short rpm3)
{
	unsigned char ESCData[12] = {0};
	static uint32_t cmdCntr = 0;
	int cmod;

	cmdCntr ++;
	cmod = cmdCntr % 4;
	if(cmod == 0) rpm0 |= 1 << 14;
	if(cmod == 1) rpm1 |= 1 << 14;
	if(cmod == 2) rpm2 |= 1 << 14;
	if(cmod == 3) rpm3 |= 1 << 14;

	ESCData[0] = 0xFE;
	ESCData[1] = 8;
	ESCData[2] = ESCBUS_MSG_ID_RUN;

	ESCData[3] = rpm0 & 0x00ff;
	ESCData[4] = (rpm0 >> 8);
	ESCData[5] = rpm1 & 0x00ff;
	ESCData[6] = rpm1 >> 8; 
	ESCData[7] = rpm2 & 0x00ff;
	ESCData[8] = rpm2 >> 8;
	ESCData[9] = rpm3 & 0x00ff;
	ESCData[10] = rpm3 >> 8;

	ESCData[11] = crcMotoCal(ESCData + 1, 10);

	write(moto_getID(), ESCData, 12);
}
