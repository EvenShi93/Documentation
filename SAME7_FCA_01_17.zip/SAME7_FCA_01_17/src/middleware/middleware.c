#include "middleware.h"

#if USE_EEPROM_DATA
extern HeadPage BackupHeader;
extern Vref_DataPage EEPROM_Cal_Data;
extern FCA_SystemParam DroneSysParam;
AT24CXX_RW_struct tt;
#endif /* USE_EEPROM_DATA */

static void CheckAccEllData(void);//У����������

static uint8_t SystemHW_InitSta = 0;
static uint8_t SysCalDataSta = 0;

extern uint8_t SysParamChanged;

inline uint8_t middleware_init(void)
{
	return bsp_init();
}

uint8_t DroneSystemParamInit(uint8_t DevInitSta)
{
	uint8_t ReadIndex = 0;

	if((DevInitSta & DEV_ERR_AT24CXX) == 0)//��ʼ���ɹ�
	{
		tt.len = 32;
		for(ReadIndex = 0; ReadIndex < 34; ReadIndex ++)//34 Pages
		{
			tt.DataAddr = ReadIndex * 32;
			tt.pData = &EEPROM_Cal_Data.Page32[ReadIndex][0];
			if(!ioctrl(AT24CXX_getID(), AT24_READ_DATA, &tt)) break;
		}
		if(ReadIndex < 34)
			DevInitSta |= DEV_ERR_DATAGET;//EEPROM��ȡʧ��
		if((DevInitSta & DEV_ERR_DATAGET) == 0)//ǰ��Ķ�ȡ���ǳɹ���
		{
			tt.len = 14;
			tt.DataAddr = 34 * 32;
			tt.pData = (uint8_t *)&DroneSysParam;//��ȡϵͳ���ò���
			if(!ioctrl(AT24CXX_getID(), AT24_READ_DATA, &tt))
				DevInitSta |= DEV_ERR_DATAGET;//EEPROM��ȡʧ��
		}
		if((DevInitSta & DEV_ERR_DATAGET) == 0)//ǰ��Ķ�ȡ���ǳɹ���
		{
			tt.len = 17;
			tt.DataAddr = 40 * 32;
			tt.pData = (uint8_t *)&BackupHeader.Page32[0];//��ȡ��������
			if(!ioctrl(AT24CXX_getID(), AT24_READ_DATA, &tt))
				DevInitSta |= DEV_ERR_DATAGET;//EEPROM��ȡʧ��
		}
	}

	SysCalDataSta = 0;
	if(EEPROM_Cal_Data.members.Vrefhead.members.crc8 == crcRfCal((uint8_t *)EEPROM_Cal_Data.Page32, 16))//header data crc
	{
		if(BackupHeader.members.crc8 != crcRfCal((uint8_t *)BackupHeader.Page32, 16))//��������У��
		{
			SysCalDataSta |= EEPROM_HEAD_2_ERR;//�������ݳ���
			for(uint8_t Index = 0; Index < 17; Index ++)
				BackupHeader.Page32[Index] = EEPROM_Cal_Data.Page32[0][Index];
		}
		CheckAccEllData();//У��
	}
	else
	{
		SysCalDataSta |= EEPROM_HEAD_1_ERR;//ԭ���ݳ���,���ñ�������
		if(BackupHeader.members.crc8 == crcRfCal((uint8_t *)BackupHeader.Page32, 16))//У�鱸������
		{
			for(uint8_t Index = 0; Index < 17; Index ++)
				EEPROM_Cal_Data.Page32[0][Index] = BackupHeader.Page32[Index];
			CheckAccEllData();//У��
		}
		else
		{
			SysCalDataSta |= EEPROM_HEAD_2_ERR;
			SysCalDataSta |= EEPROM_HEADER_ERR;
		}
	}

	if((DevInitSta & DEV_ERR_DATAGET) == 0)
	{
		/* ������Ч�Լ��� */
		if(DroneSysParam.Distance < 40 || DroneSysParam.Distance > 200)//40 - 200
			{DroneSysParam.Distance = 40; SysParamChanged = 1;}
		if(DroneSysParam.Height < 4 || DroneSysParam.Height > 20)//4 - 20
			{DroneSysParam.Height = 10; SysParamChanged = 1;}
		if(DroneSysParam.LoseGPS_ACT < 0 || DroneSysParam.LoseGPS_ACT > 4)//0, 1, 2, 3, 4...
			{DroneSysParam.LoseGPS_ACT = 1; SysParamChanged = 1;}
		if(DroneSysParam.GoHomeHeight < 30 || DroneSysParam.GoHomeHeight > 300)//30 - 300
			{DroneSysParam.GoHomeHeight = 200; SysParamChanged = 1;}
		if(DroneSysParam.OutDoorDist < 100 || DroneSysParam.OutDoorDist > 1000)//100 - 1000
			{DroneSysParam.OutDoorDist = 600; SysParamChanged = 1;}
		if(DroneSysParam.OutDoorHeight < 30 || DroneSysParam.OutDoorHeight > 800)//30 - 800
			{DroneSysParam.OutDoorHeight = 600; SysParamChanged = 1;}
		if(DroneSysParam.OutDoorSpeeed < 100 || DroneSysParam.OutDoorSpeeed > 500)//100 - 500
			{DroneSysParam.OutDoorSpeeed = 500; SysParamChanged = 1;}
	}
	SystemHW_InitSta = DevInitSta;
	return DevInitSta;
}

static void CheckAccEllData(void)
{
#if defined(USE_ELLIP_DATA)
	uint8_t i = 0;
	for(i = 0; i < 7; i ++)
	{
		if(__ARM_isnanf(EEPROM_Cal_Data.members.accCalData.accCalM[i]))
			break;
	}
	if(i < 7)
		SysCalDataSta |= EEPROM_ELPDAT_ERR;
	else
	{
		if(	fabs(EEPROM_Cal_Data.members.accCalData.accCalM[4] - 1.0f) < 0.05f && \
			fabs(EEPROM_Cal_Data.members.accCalData.accCalM[5] - 1.0f) < 0.05f && \
			fabs(EEPROM_Cal_Data.members.accCalData.accCalM[6] - 1.0f) < 0.05f )
			SysCalDataSta |= SYSTEM_PARAMT_OK;
		else
			SysCalDataSta |= EEPROM_ELPDAT_ERR;
	}
#endif /* defined(USE_ELLIP_DATA) */
}

uint8_t GetSysHW_InitSta(void)
{
	return SystemHW_InitSta;
}

uint8_t GetSysParam_Sta(void)
{
	return SysCalDataSta;
}
