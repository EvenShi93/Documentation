#include "cameraM.h"

COMPILER_WORD_ALIGNED static uint8_t ImageFrame_A[IMAGE_BUFF_SIZE] = {0};
COMPILER_WORD_ALIGNED static uint8_t ImageFrame_B[IMAGE_BUFF_SIZE] = {0};

static uint8_t Buf_AB_Tog = 0;
static uint8_t GetImgFlag = 0;
static uint8_t LumVal = 0;

uint8_t GetImageBuffer(uint8_t **previous_image, uint8_t **current_image)
{
	uint8_t *CurImage, *PreImage;

	if(Buf_AB_Tog == 0)
	{
		CurImage = ImageFrame_A;
		PreImage = ImageFrame_B;
	}
	else if(Buf_AB_Tog == 1)
	{
		CurImage = ImageFrame_B;
		PreImage = ImageFrame_A;
	}
	if(read(camera_getID(), CurImage, IMAGE_SIZE))
	{
		Buf_AB_Tog ^= 1;
		GetImgFlag = 1;
		*previous_image = PreImage;
		*current_image  = CurImage;
		return 1;
	}
	return 0;
}

uint32_t GetImage_T(void)
{
	uint32_t T;
	ioctrl(camera_getID(), GetImageT, &T);
	return T;
}

uint8_t GetCamLumValue(void)
{
	uint8_t Temp = 0, ret;
	ret = ioctrl(camera_getID(), GetLumValue, &Temp);
	LumVal = (LumVal > Temp) ? (LumVal - 1) : ((LumVal < Temp) ? (LumVal + 1) : Temp);
	return ret;
}

inline uint8_t CalLumVal(void)
{
	return LumVal;
}

uint8_t GetImageUpdate(void)
{
	if(GetImgFlag == 1)
	{
		GetImgFlag = 0;
		return 1;
	}
	return 0;
}
