#include "gpsM.h"

static GPS_DATA_RAW gpsRawData = {0};
static GPS_DATA gpsData = {0};
static unsigned char gps_set_flag = 0;
static unsigned char gps_update = 0;

void gpsM_task(void)
{
	ioctrl(ublox_m8q_getID(), UBLOX_M8Q_IOCTRL_GPS_INIT_FLAG_READ, &gps_set_flag);
	if(gps_set_flag == 1)
	{
		OS_ALLOC_SR();
		OS_ENTER_CRITICAL();
		gps_update= read(ublox_m8q_getID(),&gpsRawData,0);
		gpsData.numSV = gpsRawData.numSV;
		gpsData.lon = (gpsRawData.lon) * 0.0000001;
		gpsData.lat = (gpsRawData.lat) * 0.0000001;
		gpsData.height = (float)(gpsRawData.height) * 0.1f;
		gpsData.hMSL = (float)(gpsRawData.hMSL) * 0.1f;
		gpsData.year = gpsRawData.year;
		gpsData.month = gpsRawData.month;
		gpsData.day = gpsRawData.day;
		gpsData.hour = gpsRawData.hour;
		gpsData.min = gpsRawData.min;
		gpsData.sec = gpsRawData.sec;
		gpsData.fixType = gpsRawData.fixType;
		gpsData.hAcc =(float)(gpsRawData.hAcc) * 0.1f;
		gpsData.vAcc =(float)(gpsRawData.vAcc) * 0.1f;
		gpsData.velN =(float)(gpsRawData.velN) * 0.1f;
		gpsData.velE =(float)(gpsRawData.velE) * 0.1f;
		gpsData.velD =(float)(gpsRawData.velD) * 0.1f;
		gpsData.sAcc =(float)(gpsRawData.sAcc) * 0.1f;
		OS_EXIT_CRITICAL();
	}
}

unsigned char get_gps_update_flag(void)
{
	unsigned char temp = gps_update;
	gps_update = 0;
	return temp;
}

unsigned char get_gps_set_flag(void)
{
	return gps_set_flag;
}

GPS_DATA_RAW* get_gps_raw_data(void)
{
	return &gpsRawData;
}

GPS_DATA* get_gps_data(void)
{
	return &gpsData;
}
