#include "acc_gyro_temp_M.h"
#include "maths.h"

static FLOAT_ACC accUnit = {0};
ACC_RAW_SHORT accRawShort = {0};
static uint8_t accStableFlag = 0;//acc stable flag.
static float accCoefficient;
float AccM[7] = {0, 0, 0, 0, 1, 1, 1};

float Gravity = 9.8f;//Init Val

static uint8_t IMU_ErrFlag = 0;

#if defined(USE_PEACE_DATA)
extern uint8_t IMUTempCaliInit;
extern short acceTempOff[3];
extern short gyroTempOff[3];
#endif /* defined(USE_PEACE_DATA) */

int16_t temperature_RAW = 0;

static FLOAT_GYRO gyroUnit;
static GYRO_RAW_SHORT gyroRawShort;

static float gyroOffset[3] = {0, 0, 0};
static float gyroCoefficient;

unsigned char gyroCalibrationFlag = 0;

uint8_t IMU_Retry = 0;

void acc_gyro_temp_M_task(void)
{
	unsigned char IMU_ReadBuffer[14] = {0};
	float tempx = 0;
	float tempy = 0;
	float tempz = 0;

	//重配置IMU
	if(IMU_ErrFlag == 1 && IMU_Retry > 0)
	{
		if(ioctrl(mpu6500_getID(), MPU6500_IOCTRL_REBOOT, &accCoefficient))//重置成功
		{
			IMU_Retry = 0;
			IMU_ErrFlag = 0;
		}
		else
			IMU_Retry --;
	}

	ioctrl(mpu6500_getID(), MPU6500_IOCTRL_ACC_COEFF_READ, &accCoefficient);
	ioctrl(mpu6500_getID(), MPU6500_IOCTRL_GYRO_COEFF_READ, &gyroCoefficient);

	if(IMU_Retry == 0 && IMU_ErrFlag == 0)
	{
		if(!ioctrl(mpu6500_getID(), MPU6500_IOCTRL_IMU_READ, (void *)IMU_ReadBuffer))
		{
			IMU_ErrFlag = 1;
			IMU_Retry = 20;//最多重试20次
			for(uint8_t i = 0; i < 14; i ++) IMU_ReadBuffer[i] = 0;
		}
	}

	((char*)&accRawShort.accX)[0] = IMU_ReadBuffer[1];
	((char*)&accRawShort.accX)[1] = IMU_ReadBuffer[0];

	((char*)&accRawShort.accY)[0] = IMU_ReadBuffer[3];
	((char*)&accRawShort.accY)[1] = IMU_ReadBuffer[2];

	((char*)&accRawShort.accZ)[0] = IMU_ReadBuffer[5];
	((char*)&accRawShort.accZ)[1] = IMU_ReadBuffer[4];

#if defined(USE_PEACE_DATA)
	if(IMUTempCaliInit == 1)
	{
		accRawShort.accX -= acceTempOff[0];
		accRawShort.accY -= acceTempOff[1];
		accRawShort.accZ -= acceTempOff[2];
	}
#endif /* defined(USE_PEACE_DATA) */

	tempx = (float)(accRawShort.accX);
	tempy = (float)(accRawShort.accY);
	tempz = (float)(accRawShort.accZ);

	tempx += AccM[0];
	tempy += AccM[1];
	tempz += AccM[2];

	tempx *= AccM[4];
	tempy *= AccM[5];
	tempz *= AccM[6];

	tempx *= accCoefficient;
	tempy *= accCoefficient;
	tempz *= accCoefficient;

	accUnit.accX = tempx;
	accUnit.accY = tempy;//accUnit.accY*0.5f + tempy*0.5f;
	accUnit.accZ = -tempz;

	float g_tempx = 0;
	float g_tempy = 0;
	float g_tempz = 0;

	((char*)&gyroRawShort.gyroX)[0] = IMU_ReadBuffer[9];
	((char*)&gyroRawShort.gyroX)[1] = IMU_ReadBuffer[8];

	((char*)&gyroRawShort.gyroY)[0] = IMU_ReadBuffer[11];
	((char*)&gyroRawShort.gyroY)[1] = IMU_ReadBuffer[10];

	((char*)&gyroRawShort.gyroZ)[0] = IMU_ReadBuffer[13];
	((char*)&gyroRawShort.gyroZ)[1] = IMU_ReadBuffer[12];

#if defined(USE_PEACE_DATA)
	if(IMUTempCaliInit == 1)
	{
		gyroRawShort.gyroX -= gyroTempOff[0];
		gyroRawShort.gyroY -= gyroTempOff[1];
		gyroRawShort.gyroZ -= gyroTempOff[2];
	}
#endif /* defined(USE_PEACE_DATA) */

	g_tempx = (float)(gyroRawShort.gyroX);
	g_tempy = (float)(gyroRawShort.gyroY);
	g_tempz = (float)(gyroRawShort.gyroZ);

#if defined(USE_PEACE_DATA)
	if(gyroCalibrationFlag == 1 || IMUTempCaliInit == 1)
#endif /* defined(USE_PEACE_DATA) */
	{
		g_tempx -= gyroOffset[0];
		g_tempy -= gyroOffset[1];
		g_tempz -= gyroOffset[2];
	}

	g_tempx *= gyroCoefficient;
	g_tempy *= gyroCoefficient;
	g_tempz *= gyroCoefficient;

	gyroUnit.gyroX = -g_tempx;// * 0.5f + gyroUnit.gyroX * 0.5f;
	gyroUnit.gyroY = -g_tempy;
	gyroUnit.gyroZ = g_tempz;

	static int16_t pertemperature_RAW = 0;
	temperature_RAW = (((int16_t)IMU_ReadBuffer[6] << 8) | IMU_ReadBuffer[7]);

	static uint16_t tempInit = 0;
	if(tempInit == 0)
	{
		pertemperature_RAW = temperature_RAW;
		tempInit = 1;
	}

	if(abs(temperature_RAW - pertemperature_RAW) < 100)
		pertemperature_RAW = temperature_RAW;
	else
		temperature_RAW = pertemperature_RAW;
}

inline uint8_t GetIMURunSta(void)
{
	return IMU_ErrFlag;
}

FLOAT_ACC* get_acc_unit(void)
{
	return &accUnit;
}

ACC_RAW_SHORT* get_acc_raw(void)
{
	return &accRawShort;
}

unsigned char accCalibrationFlag = 0;
unsigned char accParamDirty = 0;
unsigned char  doAccCalibrationFlag = 0;

unsigned char  AccCal_Sta = 0;
unsigned char  AccCal_Sta_succeed = 0;

void acc_calibration()
{
	static uint16_t GetData_count = 0;
	static uint16_t Delaycount = 0;

	OS_ALLOC_SR();

	switch(AccCal_Sta)
	{
		case 0: //init
			doAccCalibrationFlag = 1;
			Delaycount=0;
			GetData_count=0;
			AccCal_Sta_succeed=0;
			AccCal_Sta=1;
		break;
		case 1:  //进入延时1s
			if(Delaycount<5)Delaycount++;
		  if(Delaycount>=5){ AccCal_Sta=2; Delaycount=0; }
	  break;
	  case 2: //采集
		if(GetData_count < SAMPLE_NUMBER)
		{
			OS_ENTER_CRITICAL();
			matrixQ[GetData_count][0] = accRawShort.accX;
			matrixQ[GetData_count][1] = accRawShort.accY;
			matrixQ[GetData_count][2] = accRawShort.accZ;
			OS_EXIT_CRITICAL();

			GetData_count ++;
		}
		else AccCal_Sta=3;
	  break;
	  case 3: //计算
	    	ellipsoid_init();
		    ellipsoid_step1();
		    ellipsoid_step2();
		    ellipsoid_step3(9.8f/accCoefficient);
        AccCal_Sta = 4;
		break;
		case 4: //判断
			if((fabs(matrixM[4]-1.0f)<0.05f &&  fabs(matrixM[5]-1.0f)<0.05f && fabs(matrixM[6]-1.0f)<0.05f))
			{
				for(unsigned short i = 0; i < 7; i++)
				{
					AccM[i] = matrixM[i];
				}
				accParamDirty = 1;
			  AccCal_Sta_succeed=1;
			}
		    else
			{
			  AccCal_Sta_succeed=0;
			}
		    AccCal_Sta=5;		
		break;		
	  case 5:  //退出延时2s
			if(Delaycount<10)Delaycount++;
		  if(Delaycount>=10){ AccCal_Sta=6; Delaycount=0; }
	  break;
		case 6:   //校准结束,退出
		  doAccCalibrationFlag = 0;
		  accCalibrationFlag = 0;
      AccCal_Sta=0;		
		break;
		default:
		  doAccCalibrationFlag = 0;
		  accCalibrationFlag = 0;
      AccCal_Sta=0;		
		break;
	}
}

extern unsigned char testMode;
extern FLOAT_RPY expEur;
extern float thr;

void acc_calibration_200ms_task(void)
{
#if defined(CTRL_RF)
	if((testMode == 1) && (expEur.Yaw < -25) && (thr > 1900)) //向左

	{
		accCalibrationFlag = 1;
	}
#endif /* defined(CTRL_RF) */

	if(accCalibrationFlag == 1)
	{
		acc_calibration();
	}
}


//----------------------------------------GYRO------------------------------------------------

FLOAT_GYRO* get_gyro_unit(void)
{
	return &gyroUnit;
}

GYRO_RAW_SHORT* get_gyro_raw(void)
{
	return &gyroRawShort;
}

float *GetGyrPeaceOff(void)
{
	return gyroOffset;
}

uint8_t PeaceDataCnt = 0, PeaceDataIndex = 0;

#define BUF_SIZE 100

static GYRO_RAW_SHORT GryPeaceBuf[BUF_SIZE];
float AccModelBuf[BUF_SIZE] = {0};

uint8_t gyroPeace(uint8_t milis)
{
	static uint32_t PeaceTimeCnt = 0;
	static short oldGyroX = 0, oldGyroY = 0, oldGyroZ = 0;

	unsigned int turbulen = abs(gyroRawShort.gyroX - oldGyroX) + abs(gyroRawShort.gyroY - oldGyroY) + abs(gyroRawShort.gyroZ - oldGyroZ);
	float AccMod = sqrtf(accUnit.accX * accUnit.accX + accUnit.accY * accUnit.accY + accUnit.accZ * accUnit.accZ);

	oldGyroX = gyroRawShort.gyroX; oldGyroY = gyroRawShort.gyroY; oldGyroZ = gyroRawShort.gyroZ;

	if(turbulen < 20)
	{
		if(PeaceTimeCnt < (1000 / milis))
		{
			PeaceTimeCnt ++;
			return 0;
		}
		else
		{
			if(gyroCalibrationFlag == 0)
			{
				gyroCalibrationFlag = 1;
				gyroOffset[0] = oldGyroX; gyroOffset[1] = oldGyroY; gyroOffset[2] = oldGyroZ;
				Gravity = AccMod;
				accStableFlag = 1;
			}
			else
			{
				if(PeaceDataCnt < BUF_SIZE)
				{
					GryPeaceBuf[PeaceDataCnt].gyroX = oldGyroX;
					GryPeaceBuf[PeaceDataCnt].gyroY = oldGyroY;
					GryPeaceBuf[PeaceDataCnt].gyroZ = oldGyroZ;
					AccModelBuf[PeaceDataCnt] = AccMod;
					PeaceDataCnt ++;
				}
				else
				{
					GryPeaceBuf[PeaceDataIndex].gyroX = oldGyroX;
					GryPeaceBuf[PeaceDataIndex].gyroY = oldGyroY;
					GryPeaceBuf[PeaceDataIndex].gyroZ = oldGyroZ;
					AccModelBuf[PeaceDataIndex] = AccMod;
					PeaceDataIndex ++;

					if(PeaceDataIndex == BUF_SIZE)
						PeaceDataIndex = 0;

					gyroOffset[0] = gyroOffset[0] * 0.9f + GryPeaceBuf[PeaceDataIndex].gyroX * 0.1f;
					gyroOffset[1] = gyroOffset[1] * 0.9f + GryPeaceBuf[PeaceDataIndex].gyroY * 0.1f;
					gyroOffset[2] = gyroOffset[2] * 0.9f + GryPeaceBuf[PeaceDataIndex].gyroZ * 0.1f;
					Gravity = Gravity * 0.99f + AccModelBuf[PeaceDataIndex] * 0.01f;
				}
			}
			return 1;
		}
	}
	else
	{
		PeaceDataCnt = 0;
		PeaceTimeCnt = 0;
		PeaceDataIndex = 0;
		return 0;
	}
}

uint32_t AccStableCnt = 0, AccSampleCnt = 0;
float AccModRaw = 0, LastAccRaw = 0;
float AccSum = 0;

uint8_t AccStable(uint8_t milis)
{
	uint8_t Flag = 0;
	AccModRaw = sqrtf(get_acc_raw()->accX*get_acc_raw()->accX+get_acc_raw()->accY*get_acc_raw()->accY+get_acc_raw()->accZ*get_acc_raw()->accZ);
	if(fabs(LastAccRaw - AccModRaw) < 60)
	{
		if(AccStableCnt < (1000 / milis))
			AccStableCnt ++;
		else
		{
			Flag = 1;
			if(accStableFlag == 0)
			{
				float AccMod = sqrtf(accUnit.accX * accUnit.accX + accUnit.accY * accUnit.accY + accUnit.accZ * accUnit.accZ);
				if(AccSampleCnt < 100)
					AccSum += AccMod;
				else
				{
					Gravity = AccSum / 100;
					accStableFlag = 1;
				}
				AccSampleCnt ++;
			}
//			else
//			{
//				Gravity = Gravity * 0.99f + sqrtf(accUnit.accX * accUnit.accX + accUnit.accY * accUnit.accY + accUnit.accZ * accUnit.accZ) * 0.01f;
//			}
		}
	}
	else
	{
		AccStableCnt = 0;
		AccSampleCnt = 0;
		AccSum = 0;
	}
	LastAccRaw = AccModRaw;
	return Flag;
}

static uint8_t PeaceSta = 0;
void gyro_calibration_10ms_task(void)
{
#if defined(USE_PEACE_DATA)
	if(IMUTempCaliInit == 1)
#endif /* defined(USE_PEACE_DATA) */
	{
		PeaceSta = gyroPeace(10);
		AccStable(10);
	}
}

inline uint8_t GetGyrPeaceSta(void)
{
	return PeaceSta;
}

inline float GetGravity(void)
{
	return Gravity;
}

inline uint8_t GetAccStableFlag(void)
{
	return accStableFlag;
}

//----------------------------------------Temperature------------------------------------------------
float get_IMUtemperature_unit()
{
  return  ((float)temperature_RAW / 333.87f + 21.0f);
}
