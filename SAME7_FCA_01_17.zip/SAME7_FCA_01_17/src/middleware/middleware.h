#ifndef _MIDDLEWARE_H_
#define _MIDDLEWARE_H_

#include "gpsM.h"
#include "ledM.h"
#include "magM.h"
#include "monitorM.h"
#include "motoM.h"
#include "pressureM.h"
#include "switchM.h"
#include "voltM.h"
#include "rfM.h"
#include "flashM.h"
#include "bsp.h"
#include "SteerM.h"
#include "UltraSonicM.h"
#include "HeatM.h"
#include "acc_gyro_temp_M.h"

#if USE_CAM_FLOW
#include "cameraM.h"
#endif /* USE_CAM_FLOW */

#define EEPROM_HEADER_ERR 0x01
#define EEPROM_ELPDAT_ERR 0x02
#define EEPROM_HEAD_1_ERR 0x04
#define EEPROM_HEAD_2_ERR 0x08
#define SYSTEM_PARAMT_OK  0x80

uint8_t middleware_init(void);
uint8_t GetSysParam_Sta(void);
uint8_t GetSysHW_InitSta(void);
uint8_t DroneSystemParamInit(uint8_t DevInitSta);

#endif
