#ifndef _IRQ_H_
#define _IRQ_H_

#include "samv71.h"
#include "chip.h"

#define NVIC_VectTab_FLASH 0x400000

void NVIC_SetVectorTable(uint32_t NVIC_VectTab, uint32_t Offset);


#endif 
