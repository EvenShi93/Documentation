#ifndef _I2C_H_
#define _I2C_H_

#include "samv71.h"
#include "chip.h"

void i2c_init(Twihs* pTwi,unsigned int i2c_fck,unsigned int mck);

/*slaveAddr 7biit addr*/
uint8_t i2c_read(Twihs* pTwi,unsigned char slaveAddr,unsigned char* readBuffer,unsigned int readNumber);
/*slaveAddr 7biit addr*/
uint8_t i2c_write_read(Twihs* pTwi,unsigned char slaveAddr,unsigned char* writeBuffer, unsigned int writeNumber, unsigned char* readBuffer,unsigned int readNumber);
/*slaveAddr 7biit addr*/
uint8_t i2c_write(Twihs* pTwi,unsigned char slaveAddr,unsigned char* writeBuffer, unsigned int writeNumber);

#endif 
