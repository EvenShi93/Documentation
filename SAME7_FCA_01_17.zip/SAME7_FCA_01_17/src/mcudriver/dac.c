﻿#include "dac.h"

void dac_reset(void)
{
	DACC->DACC_CR = DACC_CR_SWRST;
}

void dac_set_mode(unsigned int mode)
{
	DACC->DACC_MR = mode;
}

void dac_channel_enable(unsigned char channel)
{
	DACC->DACC_CHER = 1<<channel;
}

void dac_channel_disable(unsigned char channel)
{
	DACC->DACC_CHDR = 1<<channel;
}

unsigned int dac_get_channel_status(void)
{
	return DACC->DACC_CHSR;
}

void dac_set_channel_data(unsigned char channel,unsigned short data)
{
		DACC->DACC_CDR[channel] = data;
}
