#include "TimeCounter.h"

volatile uint32_t TicksMSB = 0;

void _TimeTicksInit(void)
{
	/* ---------------------- Timer Counter Configuration ---------------------- */
	/* Configure the PMC to enable the Timer Counter clock for TC wave */
	PMC_EnablePeripheral(ID_TC3);
	PMC->PMC_PCK[6] = (4 << 0) | (149 << 4);
	PMC->PMC_SCER |= (1 << 14);
	/*  Disable TC clock */
	TC1->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKDIS;
	/*  Disable interrupts */
	TC1->TC_CHANNEL[0].TC_IDR = 0xFFFFFFFF;
	/*  Clear status register */
	TC1->TC_CHANNEL[0].TC_SR;
	/* UP mode with automatic trigger on RC Compare */
	/* Clock selected: internal PCK6 clock signal (from PMC) */
	TC1->TC_CHANNEL[0].TC_CMR = TC_CMR_TCCLKS_TIMER_CLOCK1;
	TC1->TC_CHANNEL[0].TC_RC = 0xFFFF;

	NVIC_ClearPendingIRQ(TC3_IRQn);
	NVIC_SetPriority(TC3_IRQn, 0);
	NVIC_EnableIRQ(TC3_IRQn);

	TC1->TC_CHANNEL[0].TC_IER = TC_IER_COVFS;

	/* Enable TC1 channel0 */
	TC1->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKEN | TC_CCR_SWTRG;/* Counter Clock Enable Command & Software Trigger Command */
	TicksMSB = 0;
}

uint16_t _Get_Ticks(void)
{
	return (TC1->TC_CHANNEL[0].TC_CV);
}

uint32_t _Get_Micros(void)
{
	//反复高频读取时,TicksMSB值会被中途中断更改,引起时间错误,读取两次一样时再输出,可以防止错误
	uint32_t t1,t2;
	do
	{
	   t1 = ((TicksMSB << 16) + ((TC1->TC_CHANNEL[0].TC_CV) & 0xFFFF));
	   t2 = ((TicksMSB << 16) + ((TC1->TC_CHANNEL[0].TC_CV) & 0xFFFF));
	}
	while(t1!=t2);

	return t1;
}

uint32_t _Get_Millis(void)
{
	return ((_Get_Micros()) / 1000);
}

uint32_t _Get_Secnds(void)
{
	return ((_Get_Millis()) / 1000);
}

/**
  * TC1 channel0 interrupt request handler.  65535us 
  */
void TC3_Handler(void)
{
	if((TC1->TC_CHANNEL[0].TC_SR & TC_SR_COVFS) == TC_SR_COVFS) TicksMSB ++;
}
