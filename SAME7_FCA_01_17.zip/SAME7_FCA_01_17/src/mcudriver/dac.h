#ifndef _DAC_H_
#define _DAC_H_

#include "samv71.h"
#include "chip.h"


void dac_reset(void);
void dac_set_mode(unsigned int mode);
void dac_channel_enable(unsigned char channel);
void dac_channel_disable(unsigned char channel);
unsigned int dac_get_channel_status(void);
void dac_set_channel_data(unsigned char channel,unsigned short data);

#endif 
