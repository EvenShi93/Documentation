#ifndef __TIMECOUNTER_H
#define __TIMECOUNTER_H

#include "platform.h"

/* current ticks in microsecond */
#define _Ticks_us (TC1->TC_CHANNEL[0].TC_CV)

void _TimeTicksInit(void);

uint16_t _Get_Ticks(void);
uint32_t _Get_Micros(void);
uint32_t _Get_Millis(void);
uint32_t _Get_Secnds(void);

#endif /* __TIMECOUNTER_H */
