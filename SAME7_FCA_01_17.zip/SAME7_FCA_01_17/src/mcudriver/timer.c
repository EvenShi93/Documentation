﻿#include "timer.h"
#include "samv71.h"
#include "chip.h"

void TC0_init(unsigned int freq)
{
	/* Configure the PMC to enable the Timer Counter clock for TC wave */
	PMC_EnablePeripheral(ID_TC0);
//	PMC->PMC_PCK[6] = (4 << 0) | (149 << 4);
//	PMC->PMC_SCER |= (1 << 14);
	/*  Disable TC clock */
	TC0->TC_CHANNEL[0].TC_CCR = TC_CCR_CLKDIS;
	/*  Disable interrupts */
	TC0->TC_CHANNEL[0].TC_IDR = 0xFFFFFFFF;
	/*  Clear status register */
	TC0->TC_CHANNEL[0].TC_SR;
	/*  UP mode with automatic trigger on RC Compare(f = (PCK6 = 150M)/150M = 1M) */
	TC0->TC_CHANNEL[0].TC_CMR = TC_CMR_CPCTRG|TC_CMR_WAVE|TC_CMR_TCCLKS_TIMER_CLOCK1;//TC_CMR_TCCLKS_TIMER_CLOCK2

	TC0->TC_CHANNEL[0].TC_RC = 1000000 / freq;
	NVIC_ClearPendingIRQ(TC0_IRQn);
	NVIC_SetPriority(TC0_IRQn, 5);
	NVIC_EnableIRQ(TC0_IRQn);

	TC0->TC_CHANNEL[0].TC_IER = TC_IER_CPCS ;
}

void TC0_enable(void)
{
	/* Enable TC0 channel 0 */
	TC0->TC_CHANNEL[0].TC_CCR =  TC_CCR_CLKEN | TC_CCR_SWTRG;
}
