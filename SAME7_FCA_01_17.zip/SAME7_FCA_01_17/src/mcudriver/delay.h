#ifndef _DELAY_H_
#define _DELAY_H_

#include "platform.h"

void delay_s(unsigned int s);
void delay_ms(unsigned int ms);
void delay_us(unsigned int us);

#endif 
