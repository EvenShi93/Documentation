#ifndef _TIMER_H_
#define _TIMER_H_

void TC0_init(unsigned int freq);
void TC0_enable(void);

#endif 
