#include "i2c.h"
#include "TimeCounter.h"

#define TWI_TIMEOUT_uS 400

void i2c_init(Twihs* pTwi, unsigned int i2c_fck, unsigned int mck)
{
	TWI_ConfigureMaster(pTwi, i2c_fck, mck);
}

/* slaveAddr 7biit addr */
uint8_t i2c_read(Twihs* pTwi, unsigned char slaveAddr, unsigned char* readBuffer, unsigned int readNumber)
{
	uint8_t sta = 1;

	uint32_t TimeStart = 0;
	/* Set slave address and number of internal address bytes. */
	pTwi->TWIHS_MMR = 0;
	pTwi->TWIHS_MMR = TWIHS_MMR_MREAD | (slaveAddr << 16);

	/* Set internal address bytes */
	pTwi->TWIHS_IADR = 0;

	/* Send START condition */
	pTwi->TWIHS_CR = TWIHS_CR_START;

	while(readNumber > 0)
	{
		if(readNumber == 1)
		{
			TWI_Stop(pTwi);
		}
		TimeStart = _Get_Micros();
		while(!TWI_ByteReceived(pTwi))
		{
			if(_Get_Micros() - TimeStart > TWI_TIMEOUT_uS){return 0;} 
		}
		*readBuffer = TWI_ReadByte(pTwi);
		readBuffer++;
		readNumber--;
	}
	TimeStart = _Get_Micros();
	while(!TWI_TransferComplete(pTwi))
	{
		if(_Get_Micros() - TimeStart > TWI_TIMEOUT_uS) {return 0;} 
	}
	return sta;
}

/*slaveAddr 7biit addr*/
uint8_t i2c_write_read(Twihs* pTwi,unsigned char slaveAddr,unsigned char* writeBuffer, unsigned int writeNumber, unsigned char* readBuffer,unsigned int readNumber)	
{
	uint8_t sta = 1;
	sta &= i2c_write(pTwi,slaveAddr,writeBuffer,writeNumber);
	sta &= i2c_read(pTwi,slaveAddr,readBuffer,readNumber);
	return sta;
}


/*slaveAddr 7biit addr*/
uint8_t i2c_write(Twihs* pTwi, unsigned char slaveAddr, unsigned char* writeBuffer, unsigned int writeNumber)	
{
	uint8_t  sta = 1;

	uint32_t TimeStart = 0;
	/* Set slave address and number of internal address bytes. */
	pTwi->TWIHS_MMR = 0;
	pTwi->TWIHS_MMR = (slaveAddr << 16);

	/* Set internal address bytes */
	pTwi->TWIHS_IADR = 0;

//	/* Send START condition */
//	pTwi->TWIHS_CR = TWIHS_CR_START;

	TWI_WriteByte(pTwi, *writeBuffer);
	writeBuffer ++;
	writeNumber --;

	while(writeNumber > 0)
	{
		TimeStart = _Get_Micros();
		while(!TWI_ByteSent(pTwi))
		{
			if(_Get_Micros() - TimeStart > TWI_TIMEOUT_uS) {return 0;}//timeout. 
		}
		TWI_WriteByte(pTwi, *writeBuffer);	

		writeBuffer ++;
		writeNumber --;
	}

	TWI_SendSTOPCondition(pTwi);
	TimeStart = _Get_Micros();
	while(!TWI_TransferComplete(pTwi))
	{
		if(_Get_Micros() - TimeStart > TWI_TIMEOUT_uS) {return 0;}
	}

	return sta;
}
