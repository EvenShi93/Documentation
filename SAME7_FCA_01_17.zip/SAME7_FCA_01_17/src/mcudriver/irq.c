#include "irq.h"
#include "_funcConfig.h"

void NVIC_SetVectorTable(uint32_t NVIC_VectTab, uint32_t Offset)
{  
  SCB->VTOR = NVIC_VectTab | (Offset & (uint32_t)0x1FFFFF80);
}

extern void task_1ms_int(void);
void TC0_Handler()
{
	//TC0 channle 0  RC interrupt // 1ms
	if((TC0->TC_CHANNEL[0].TC_SR & TC_SR_CPCS) == TC_SR_CPCS)
	{
		task_1ms_int();
	}
}

extern void SysTick_1ms_irq(void);
void SysTick_Handler()
{
	SysTick_1ms_irq();
}

extern void motoUsartTxDmaIrq(void);
extern unsigned char motoUsartTxDmaChannel;

#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
extern void rfSt10UartDmaIrq(void);
extern unsigned char rfSt10UartDmaChannel;
#endif

#if USE_DATA_TRANSFER
extern void monitorUartDmaIrq(void);
extern unsigned char monitorUartDmaChannel;
#endif

#if defined(CTRL_A9)
extern void AppsA9_UartDmaIrq(void);
extern unsigned char AppsA9_UartDmaChannel;
#endif

extern void ubloxM8_UartDmaIrq(void);
extern unsigned char ubloxM8UartDmaChannel;

void XDMAC_Handler(void)
{
	 unsigned int intChannel = 0;
	intChannel = XDMAC_GetGIsr(XDMAC);
	
	if((intChannel & (1<<motoUsartTxDmaChannel)) == (1<<motoUsartTxDmaChannel))
	{
		if((XDMAC_GetMaskChannelIsr( XDMAC, motoUsartTxDmaChannel) & XDMAC_CIS_BIS) == XDMAC_CIS_BIS)
		{
			 motoUsartTxDmaIrq();
		}
	}
	if((intChannel & (1<<ubloxM8UartDmaChannel)) == (1<<ubloxM8UartDmaChannel))
	{
		if((XDMAC_GetMaskChannelIsr( XDMAC, ubloxM8UartDmaChannel) & XDMAC_CIS_BIS) == XDMAC_CIS_BIS)
		{
			 ubloxM8_UartDmaIrq();
		}
	}
#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
	if((intChannel & (1 << rfSt10UartDmaChannel)) == (1 << rfSt10UartDmaChannel))
	{
		if((XDMAC_GetMaskChannelIsr(XDMAC, rfSt10UartDmaChannel) & XDMAC_CIS_BIS) == XDMAC_CIS_BIS)
		{
			 rfSt10UartDmaIrq();
		}
	}
#endif
#if USE_DATA_TRANSFER
	if((intChannel & (1 << monitorUartDmaChannel)) == (1 << monitorUartDmaChannel))
	{
		
		if((XDMAC_GetMaskChannelIsr( XDMAC, monitorUartDmaChannel) & XDMAC_CIS_BIS) == XDMAC_CIS_BIS)
		{
			 monitorUartDmaIrq();
		}
	}
#endif
#if defined(CTRL_A9)
	if((intChannel & (1 << AppsA9_UartDmaChannel)) == (1 << AppsA9_UartDmaChannel))
	{
		if((XDMAC_GetMaskChannelIsr(XDMAC, AppsA9_UartDmaChannel) & XDMAC_CIS_BIS) == XDMAC_CIS_BIS)
		{
			AppsA9_UartDmaIrq();
		}
	}
#endif
}

extern void ublox_m8q_uart_rx_irq(unsigned char data);
void UART4_Handler(void)
{
	if((UART_GetStatus(UART4) & UART_SR_RXRDY) == UART_SR_RXRDY)
	{
		ublox_m8q_uart_rx_irq((UART4->UART_RHR)&0xff);
	}
}

#if defined(TRANS_RX_ENABLE)
extern void monitor_uart_rx_irq(unsigned char data);
#endif

#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
extern void rf_st10_uart_rx_irq(unsigned char data);
#endif
void UART3_Handler(void)
{
	if((UART_GetStatus(UART3) & UART_SR_RXRDY) == UART_SR_RXRDY) 
	{
#if defined(TRANS_RX_ENABLE) && defined(USE_RF_SERIAL_PORT)
		monitor_uart_rx_irq((UART3->UART_RHR)&0xff);
#endif
#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
		rf_st10_uart_rx_irq((UART3->UART_RHR)&0xff);
#endif
	}
}

#if defined(A9_RX_ENABLE)
extern void AppsA9_uart_rx_irq(unsigned char data);
#endif
void USART2_Handler(void)
{
	if((USART_GetStatus(USART2) & US_CSR_RXRDY) == US_CSR_RXRDY) 
	{
#if defined(TRANS_RX_ENABLE) && defined(USE_A9_SERIAL_PORT)
		monitor_uart_rx_irq((USART2->US_RHR)&0xff);
#endif
#if defined(A9_RX_ENABLE)
		AppsA9_uart_rx_irq((USART2->US_RHR)&0xff);
#endif
	}
}

void UART0_Handler(void)
{
	if((UART_GetStatus(UART0) & UART_SR_RXRDY) == UART_SR_RXRDY) 
	{
	}
}

extern void moto_uart_rx_irq(unsigned char data);
void USART0_Handler(void)
{
	if((USART_GetStatus(USART0) & US_CSR_RXRDY) == US_CSR_RXRDY) 
	{
		moto_uart_rx_irq((USART0->US_RHR)&0xff);
	}
}
