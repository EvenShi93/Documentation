#include "moto_task.h"
#include "rf_task.h"
#include "maths.h"

extern float thr;
extern PID pidPitch, pidRoll, pidPitchRate, pidRollRate, pidYawRate;

float Motor1, Motor2, Motor3, Motor4;
float Motor1ESC, Motor2ESC, Motor3ESC, Motor4ESC;

extern unsigned char flyEnable;

float moto1PRYOutput;
float moto2PRYOutput;
float moto3PRYOutput;
float moto4PRYOutput;

extern unsigned char RFMode;
extern float thrAltOut;

uint32_t UsrToneCmd = 0x0;

static void ESC_ToneTask(void);

#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
uint8_t MotorBurnFlag = 0;
uint16_t BurnSpeed = 0;
void EntryMotoBurnMode(void)
{
	ClrToneReq();
	MotorBurnFlag = 1;
}

void SetMotoSpeed(uint16_t Speed)
{
	if(Speed != 555)
		BurnSpeed = Speed;
}
#endif

//力矩输入0-1000 代表 0-100%
//PWM输出为怠速以上调速器PWM值

#define Max_realTorque 244 //单螺旋桨输出的最大力量 单位:克 
#define Min_realTorque 12.8 //单螺旋桨怠速力量 单位:克 

//FCA2016-01: y = 0.00006x^3 - 0.03136x^2 + 6.7782x + 1136.1
//FCA2016-04: y = 0.00004x^3 - 0.02208x^2 + 6.1494x + 1144.9

void TorqueFormula_to_PWM(float Torque1000, float* PWMout)
{
	float Torque_target = 0;
	Torque1000 = constrain_float(Torque1000, 0, 1000);

    //将0-1000的百分比转换为真实范围
    linermap(1000, 0, Max_realTorque, Min_realTorque, Torque1000, &Torque_target);

    //动力系统推力拟合曲线 Torque_vs_ESC
    *PWMout = 0.00004f*(Torque_target*Torque_target*Torque_target)- \
			0.02208f*(Torque_target*Torque_target)+ \
            6.14940f*(Torque_target) + 1144.9f;
    //减去怠速
    *PWMout-=Moto_PwmMin;
    *PWMout=constrain_float(*PWMout,0,MotoRange);
}

#define Max_YawrealTorque 19 //单螺旋桨输出的最大反转矩 单位:克
#define Min_YawrealTorque 0  //单螺旋桨怠速反转矩 单位:克
//FCA2016-04: y = 0.04008x^3 - 2.0192x^2 + 59.513x + 1200

void YawTorqueFormula_to_PWM(float Torque1000,float* PWMout)
{
    float Torque_target = 0;
    Torque1000 = constrain_float(Torque1000,0,1000);

    //将0-1000的百分比转换为真实范围
    linermap(1000, 0, Max_YawrealTorque, Min_YawrealTorque, Torque1000, &Torque_target);

    //动力系统推力拟合曲线 Torque_vs_ESC
    *PWMout=0.04008f*(Torque_target*Torque_target*Torque_target)- \
            2.0192f*(Torque_target*Torque_target)+ \
            59.513f*(Torque_target) + 1200.0f;
    //减去怠速
    *PWMout-=Moto_PwmMin;
    *PWMout=constrain_float(*PWMout,0,MotoRange);
}

uint8_t ToneReady = 0;
uint32_t MotoReadyCnt = 0;
static uint8_t MotorErrFlag = 0;
uint8_t ESC_Stat[4] = {0};
void moto_1ms_task(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();
	unsigned char curRFMode = RFMode;
	OS_EXIT_CRITICAL();

	float tempThr = constrain_float(thr, ThrChannel_min, ThrChannel_max);

	float Alt_Torque = 0;

	switch(curRFMode)
	{
		case RFMODE_9AXIE:
			Alt_Torque = (((tempThr-ThrChannel_min)/ThrRange)*ThrFactor*1000) - 220;
			break;
		case RFMODE_HEIGHT:
		case RFMODE_READY:
		case RFMODE_POSITION:
		case RFMODE_GOHOME:
		case RFMODE_SMART:
		case RFMODE_FOLLOWME:
		case RFMODE_SELFIE:
		case RFMODE_ORBIT:
		case RFMODE_JOURNEY:
		default :
			Alt_Torque = thrAltOut*ThrFactor;
		break;
	}

	float P_MotoOutput = constrain_float( pidPitchRate.Output, -1000, 1000);
	float R_MotoOutput = constrain_float( pidRollRate.Output, -1000, 1000);
	float Y_MotoOutput = constrain_float( pidYawRate.Output, -1000, 1000);

	//--------------------将输出值融合到四个电机--------------------------------//
	//2015-07
	//飞机电机编号
	// 3    2
	// 1    4
	//3、4号电机顺时针转,1、2逆时针
	moto1PRYOutput = -P_MotoOutput +R_MotoOutput +Y_MotoOutput;
	moto2PRYOutput = +P_MotoOutput -R_MotoOutput +Y_MotoOutput;
	moto3PRYOutput = +P_MotoOutput +R_MotoOutput -Y_MotoOutput;
	moto4PRYOutput = -P_MotoOutput -R_MotoOutput -Y_MotoOutput;

	Motor1 = Alt_Torque + moto1PRYOutput;
	Motor2 = Alt_Torque + moto2PRYOutput;
	Motor3 = Alt_Torque + moto3PRYOutput;
	Motor4 = Alt_Torque + moto4PRYOutput;

	//超限时平衡油门
	if(Motor1 > 1000 || Motor2 > 1000 || Motor3 > 1000 || Motor4 > 1000)
	{
		//找出最大值
		float max1 = Motor1 > Motor2?Motor1:Motor2;
		float max2 = max1 > Motor3?max1:Motor3;
		float max3 = max2 > Motor4?max2:Motor4;
		//计算油门衰减
		float thr_attenuation = Alt_Torque - (max3 - 1000);
		//从新混合马达
		Motor1 = thr_attenuation + moto1PRYOutput;
		Motor2 = thr_attenuation + moto2PRYOutput;
		Motor3 = thr_attenuation + moto3PRYOutput;
		Motor4 = thr_attenuation + moto4PRYOutput;
	}

    TorqueFormula_to_PWM(Motor1, &Motor1ESC);
    TorqueFormula_to_PWM(Motor2, &Motor2ESC);
    TorqueFormula_to_PWM(Motor3, &Motor3ESC);
    TorqueFormula_to_PWM(Motor4, &Motor4ESC);

	ioctrl(moto_getID(), MOTO_IOCTRL_GET_ESC_STAT, ESC_Stat);//马达堵转保护
	if(ESC_Stat[0] != 0 || ESC_Stat[1] != 0 || ESC_Stat[2] != 0 || ESC_Stat[3] != 0)
	{
		if(ESC_Stat[0] != 0)
			MotorErrFlag |= 0x02;
		if(ESC_Stat[1] != 0)
			MotorErrFlag |= 0x08;
		if(ESC_Stat[2] != 0)
			MotorErrFlag |= 0x01;
		if(ESC_Stat[3] != 0)
			MotorErrFlag |= 0x04;
	}

#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
	if(MotorBurnFlag == 1)
	{
		if(BurnSpeed < Moto_PwmMin) BurnSpeed = 0;
		motoM_run_set(BurnSpeed, BurnSpeed, BurnSpeed, BurnSpeed);
	}
    else
#endif
	if(flyEnable == 1)
    {
		motoM_run_set(Moto_PwmMin + Motor1ESC, Moto_PwmMin + Motor2ESC, Moto_PwmMin + Motor3ESC, Moto_PwmMin + Motor4ESC);
//		motoM_run_set(0, 0, 0, 0);
        MotoReadyCnt = 0;
        ToneReady = 0;
    }
    else
    {
        if(ToneReady == 0)
        {
            motoM_run_set(0, 0, 0, 0);
            if(MotoReadyCnt < 1000)
                MotoReadyCnt ++;
            else
            {
//                UsrToneCmd = 0;
                ToneReady = 1;
            }
        }
        else
        {
            ESC_ToneTask();
            //Send_ESC_Tone(2000, 100, 60);
        }
    }
}

inline uint8_t GetMotorErrFlag(void)
{
	return MotorErrFlag;
}

ToneType Tone0_rfLink[2] = {
	{.freq = 1200, .len = 150, .pwr = 30, .Times = 1, .Delay = 80},
    {.freq = 1000, .len = 150, .pwr = 30, .Times = 1, .Delay = 80}};

ToneType Tone1_rfLost[2] = {
    {.freq = 1000, .len = 150, .pwr = 30, .Times = 1, .Delay = 80},
    {.freq = 1200, .len = 150, .pwr = 30, .Times = 1, .Delay = 80}};

ToneType Tone2_User_1[1] = {
    {.freq = 1200, .len = 200, .pwr = 30, .Times = 3, .Delay = 100}};

ToneType Tone3_GPSReady[1] = {
	{.freq = 1000, .len = 500, .pwr = 30, .Times = 1, .Delay = 100}};

ToneType Tone_Default[1] = {
    {.freq = 1000, .len = 200, .pwr = 50, .Times = 1, .Delay = 200}};

//一次->EEPROM错误
ToneType Tone_EEPROMErr[1] = {
    {.freq = 500, .len = 200, .pwr = 70, .Times = 1, .Delay = 500}};

//两次->MPU6500错误
ToneType Tone_MPUErr[2] = {
    {.freq = 500, .len = 100, .pwr = 70, .Times = 1, .Delay = 100},
	{.freq = 500, .len = 100, .pwr = 70, .Times = 1, .Delay = 500}};

//三次->地磁错误
ToneType Tone_ISTErr[2] = {
    {.freq = 500, .len = 100, .pwr = 70, .Times = 2,.Delay = 100},
	{.freq = 500, .len = 100, .pwr = 70, .Times = 1, .Delay = 500}};

//四次->气压计错误
ToneType Tone_BARErr[2] = {
    {.freq = 500, .len = 100, .pwr = 70, .Times = 3, .Delay = 100},
	{.freq = 500, .len = 100, .pwr = 70, .Times = 1, .Delay = 500}};

//五次->光流镜头错误
ToneType Tone_CAMERAErr[2] = {
    {.freq = 500, .len = 100, .pwr = 70, .Times = 4, .Delay = 100},
	{.freq = 500, .len = 100, .pwr = 70, .Times = 1, .Delay = 500}};

//六次->GPS错误
ToneType Tone_UBLOXM8Err[2] = {
    {.freq = 500, .len = 100, .pwr = 70, .Times = 5, .Delay = 100},
	{.freq = 500, .len = 100, .pwr = 70, .Times = 1, .Delay = 500}};

//加速度校准数据出错
ToneType Tone_AccCalDataErr[2] = {
    {.freq = 1400, .len = 400, .pwr = 30, .Times = 1, .Delay = 10},
    {.freq = 1000, .len = 400, .pwr = 30, .Times = 1, .Delay = 200}};
//地磁校准成功提示
ToneType Tone_MagCalOK[2] = {
	{.freq = 1400, .len = 200, .pwr = 50, .Times = 1, .Delay = 200},
	{.freq = 1400, .len = 700, .pwr = 50, .Times = 1, .Delay = 200}};
//开机
ToneType Tone_Startup[3] = {
	{.freq = 880, .len = 175, .pwr = 50, .Times = 1, .Delay = 0},
	{.freq = 1175, .len = 125, .pwr = 50, .Times = 1, .Delay = 150},
	{.freq = 1760, .len = 225, .pwr = 50, .Times = 1, .Delay = 200}};
//关机
ToneType Tone_Shutdown[3] = {
	{.freq = 1760, .len = 175, .pwr = 50, .Times = 1, .Delay = 0},
	{.freq = 1175, .len = 125, .pwr = 50, .Times = 1, .Delay = 150},
	{.freq = 880, .len = 225, .pwr = 50, .Times = 1, .Delay = 200}};

static ToneType *pTone;
static uint8_t ToneCase = 0;
uint8_t ToneCaseCnt = 0, ToneTimesCnt = 0;
uint16_t ToneDlyCnt = 0;
static void ESC_ToneTask(void)
{
    if((UsrToneCmd & ToneRunFlag) == 0)//未运行,检测命令
    {
        if(UsrToneCmd & ToneTypMsk_13)//开机
		{
			pTone = Tone_Startup;//获取声音信息
            ToneCase = sizeof(Tone_Startup) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_13;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
		}
		else if(UsrToneCmd & ToneTypMsk_14)//关机
		{
			pTone = Tone_Shutdown;//获取声音信息
            ToneCase = sizeof(Tone_Shutdown) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_14;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
		}
		else if(UsrToneCmd & ToneTypMsk_5)//EEPROM错误
        {
            pTone = Tone_EEPROMErr;//获取声音信息
            ToneCase = sizeof(Tone_EEPROMErr) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_5;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
		else if(UsrToneCmd & ToneTypMsk_6)//MPU6500错误
        {
            pTone = Tone_MPUErr;//获取声音信息
            ToneCase = sizeof(Tone_MPUErr) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_6;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
		else if(UsrToneCmd & ToneTypMsk_7)//地磁错误
        {
            pTone = Tone_ISTErr;//获取声音信息
            ToneCase = sizeof(Tone_ISTErr) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_7;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
		else if(UsrToneCmd & ToneTypMsk_8)//气压计错误
        {
            pTone = Tone_BARErr;//获取声音信息
            ToneCase = sizeof(Tone_BARErr) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_8;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
		else if(UsrToneCmd & ToneTypMsk_9)//光流镜头错误
        {
            pTone = Tone_CAMERAErr;//获取声音信息
            ToneCase = sizeof(Tone_CAMERAErr) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_9;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
		else if(UsrToneCmd & ToneTypMsk_10)//GPS错误
        {
            pTone = Tone_UBLOXM8Err;//获取声音信息
            ToneCase = sizeof(Tone_UBLOXM8Err) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_10;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
		else if(UsrToneCmd & ToneTypMsk_11)//加速度校准数据出错
		{
			pTone = Tone_AccCalDataErr;//获取声音信息
            ToneCase = sizeof(Tone_AccCalDataErr) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_11;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
		}
		else if(UsrToneCmd & ToneTypMsk_12)//地磁校准成功
		{
			pTone = Tone_MagCalOK;//获取声音信息
            ToneCase = sizeof(Tone_MagCalOK) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_12;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
		}
		else if(UsrToneCmd & ToneTypMsk_1)//接上信号
        {
            pTone = Tone0_rfLink;//获取声音信息
            ToneCase = sizeof(Tone0_rfLink) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_1;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
        else if(UsrToneCmd & ToneTypMsk_2)//丢信号
        {
            pTone = Tone1_rfLost;//获取声音信息
            ToneCase = sizeof(Tone1_rfLost) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_2;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
        else if(UsrToneCmd & ToneTypMsk_3)//用户...
        {
            pTone = Tone2_User_1;//获取声音信息
            ToneCase = sizeof(Tone2_User_1) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_3;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
		else if(UsrToneCmd & ToneTypMsk_4)//GPS就绪
        {
            pTone = Tone3_GPSReady;//获取声音信息
            ToneCase = sizeof(Tone3_GPSReady) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_4;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }
        else if(UsrToneCmd & ToneTypMsk_15)
        {
            pTone = Tone_Default;//获取声音信息
            ToneCase = sizeof(Tone_Default) / sizeof(ToneType);
            UsrToneCmd &= ~ToneTypMsk_15;
            UsrToneCmd |= ToneRunFlag;//最高位置1,执行命令
        }

        if(UsrToneCmd != 0)
        {
            ToneCaseCnt = 0;
            ToneTimesCnt = 0;
            ToneDlyCnt = 0;
        }
    }
    else//声音
    {
        if(ToneCaseCnt < ToneCase)
        {
            if(ToneTimesCnt < pTone[ToneCaseCnt].Times)
            {
                if(ToneDlyCnt == 0)//第一次
                {
                    Send_ESC_Tone(pTone[ToneCaseCnt].freq, pTone[ToneCaseCnt].len, pTone[ToneCaseCnt].pwr);
                }
                ToneDlyCnt ++;
                if(ToneDlyCnt == pTone[ToneCaseCnt].len + pTone[ToneCaseCnt].Delay)//时间到
                {
                    ToneTimesCnt ++;
                    ToneDlyCnt = 0;
                }
            }
            else
            {
                ToneCaseCnt ++;
                ToneTimesCnt = 0;
            }
        }
        else
        {
            UsrToneCmd &= ~ToneRunFlag;
            ToneCaseCnt = 0;
        }
    }
}

inline void SetToneCmd(ToneCmd Cmd)
{
#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
	if(MotorBurnFlag == 0)
#endif	
	UsrToneCmd |= (1 << Cmd);
}

inline void ClrToneCmd(ToneCmd Cmd)
{
	UsrToneCmd &= ~(1 << Cmd);
}

inline void ClrToneReq(void)
{
	UsrToneCmd = 0x0;
}

uint8_t GetToneSta(void)
{
    if(UsrToneCmd == 0)
        return 0;
    else
        return 1;
}
