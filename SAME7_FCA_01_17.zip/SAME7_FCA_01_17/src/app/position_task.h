#ifndef _POSITION_TASK_H_
#define _POSITION_TASK_H_

#include "maths.h"
#include "PosEst.h"
#include "rf_task.h"
#include "global_type.h"
#include "attitude_task.h"

__packed typedef struct
{
	float X;
	float Y;
}Point;

extern float _leash;
extern float vel_max;

extern float POS_KP;
extern Nav_struct_PosHold PH;
//extern float RC_velDesired_x, RC_velDesired_y;

void position_param_clear(void);
void PosHold_task(void);
void desired_vel_to_pos(void);
void Pos_to_rate_xy(float DesireX, float DesireY);
void Rate_to_accel_xy(float DesireX, float DesireY);
void Acc_XYtoQuat(float ACCX, float ACCY, Quat* XY_Q);//, FLOAT_RPY* XY_EUR

Quat *GetPositionQuat(void);
void ComputePositionQuat(void);
void GetTrigYaw(float *sin_yaw, float *cos_yaw);

#endif
