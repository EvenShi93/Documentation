#include "selfie_task.h"

#define SELFIE_MAXVEL 350

static void SELFIE_exp_pos(float YawAng);

uint8_t SelfieInit = 0;
/* SELFIE Paramter */
static float CirVel_trg = 0, RadVel_trg = 0;
float RealDist = 0.0f, RealAngl = 0.0f, InitAngl = 0.0f;

static Point SelfieInit_Center = {0.0f, 0.0f};

//Yaw微调相关变量
float YawModify = 0.0f, YawModifyTarget = 0.0f;
uint8_t YawModifyCmd = 0;

Point SELFIE_origin = {0, 0}; //圆心
Point SELFIE_start = {0, 0}; //起飞点
float SELFIE_angle = 0; //飞机相对人的角度

void Selfie_Task(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

	static unsigned char oldRFMode = RFMODE_9AXIE;
	unsigned char curRFMode = GetCurMode();
	FLOAT_RPY curExpEur = expEur;

	OS_EXIT_CRITICAL();

	if(((oldRFMode != curRFMode) && (curRFMode == RFMODE_SELFIE || curRFMode == RFMODE_ORBIT)) || \
		(curRFMode == RFMODE_ORBIT && OrbitAct == OrbitAct_POI) || \
		(AutoTakeOff_Sta == ONGROUND))
	{
		SelfieInit = 0;

		CirVel_trg = RadVel_trg = 0;
		YawModify = 0.0f, YawModifyTarget = 0.0f;
		YawModifyCmd = 0;
	}
	oldRFMode = curRFMode;

    if(curRFMode == RFMODE_SELFIE || (curRFMode == RFMODE_ORBIT && OrbitAct == OrbitAct_ME))
    {
//		if(POS_KP < 0.8f)
//			POS_KP += 0.004f;

		float CirVelMax = constrain_float((SELFIE_MAXVEL / RealDist) * RAD_TO_DEG, 0, 25);

        float CirVel_t =  (constrain_float(apply_deadband(curExpEur.Rool, 3), -35, 35) / 35) * CirVelMax;//25 Deg/s
        float RadVel_t = -(constrain_float(apply_deadband(curExpEur.Pitch, 10), -35, 35) / 35) * 250;//250cm/s

		if(SelfieInit)
		{
			if(IsEntryNFZ_2() && RadVel_t != 0)//in no fly zone
			{
				uint8_t NFZ_Numb = NumEntryNFZ();
				if(NFZ_Numb > 0)
				{
					_2AxisFloat vectTmp1, vectTmp2;
					for(uint8_t i = 0; i < NFZ_Numb; i ++)
					{
						vectTmp1.X = SELFIE_origin.X - NFZ_NearCoord[In2_4VectIndex[i]].X;//NFZ Center -> Selfie Center.
						vectTmp1.Y = SELFIE_origin.Y - NFZ_NearCoord[In2_4VectIndex[i]].Y;
						vectTmp2.X = PH.pos_target_x - SELFIE_origin.X;//Selfie Center -> Drone.
						vectTmp2.Y = PH.pos_target_y - SELFIE_origin.Y;
						float xtmp = vectTmp1.X * vectTmp2.X + vectTmp1.Y * vectTmp2.Y;
						if(xtmp * RadVel_t < 0)
						{
							RadVel_t = 0;
							break;
						}
					}
				}
			}
			else if(IsEntryNFZ_1() && CurExpAlt() >= 2000 && RadVel_t != 0)
			{
				uint8_t NFZ_Numb = NumNearByNFZ();
				if(NFZ_Numb > 0)
				{
					_2AxisFloat vectTmp1, vectTmp2;
					for(uint8_t i = 0; i < NFZ_Numb; i ++)
					{
						vectTmp1.X = SELFIE_origin.X - NFZ_NearCoord[In6_5VextIndex[i]].X;//NFZ Center -> Selfie Center.
						vectTmp1.Y = SELFIE_origin.Y - NFZ_NearCoord[In6_5VextIndex[i]].Y;
						vectTmp2.X = PH.pos_target_x - SELFIE_origin.X;//Selfie Center -> Drone.
						vectTmp2.Y = PH.pos_target_y - SELFIE_origin.Y;
						float xtmp = vectTmp1.X * vectTmp2.X + vectTmp1.Y * vectTmp2.Y;
						if(xtmp * RadVel_t < 0)
						{
							RadVel_t = 0;
							break;
						}
					}
				}
			}
		}

//		if(IsEntryNFZ_2() || (IsEntryNFZ_1() && CurExpAlt() >= 2000))
//		{
//			RadVel_t = 0;
//		}

        step_change(&CirVel_trg, CirVel_t, 2, 2);
        step_change(&RadVel_trg, RadVel_t, 25, 25);

		// 遥控输入 -> 期望位置
		if(GoHomeModeExit() == 0)
			SELFIE_exp_pos(GetCurEuler()->Yaw);
		Pos_to_rate_xy(0, 0);// 位置误差 -> 速度控制
		Rate_to_accel_xy(0, 0);// 速度误差 -> 期望加速度
		ComputePositionQuat();
		SetAppsShowDist(RealDist);
    }
}

float SELFIE_Yawtrg = 0;
float SELFIE_Radtrg = 500;
float SELFIE_ExpYaw = 0.0f, SELFIE_ExpYawTemp = 0.0f;
float curSELFIE_Angle = 0.0f;

uint8_t YawInit = 0, RadInit = 0;
int8_t YawRoundDir = 1;
float InitErrYaw;

static void SELFIE_exp_pos(float YawAng)
{
	if(AutoTakeOff_Sta == SUCCEED)
    {
		if(SelfieInit == 0)//set center.
		{
			SELFIE_start.X = PH.pos_target_x;//set start point.
			SELFIE_start.Y = PH.pos_target_y;

			YawModify = 0.0f, YawModifyTarget = 0.0f;
			YawModifyCmd = 0;

			if(RFMode == RFMODE_ORBIT && OrbitCenter == UserCenter)//根据模式设定
			{
				SELFIE_origin.X = SelfieInit_Center.X;
				SELFIE_origin.Y = SelfieInit_Center.Y;
			}
			else
			{
				SELFIE_origin.X = SELFIE_start.X + GetDroneSysParam()->Distance * 10.0f * cosf(YawAng * (float)DEG_TO_RAD);//设置圆心//400.0f
				SELFIE_origin.Y = SELFIE_start.Y + GetDroneSysParam()->Distance * 10.0f * sinf(YawAng * (float)DEG_TO_RAD);
			}
		}

        float dx = PosEst_x - SELFIE_origin.X;//compute dx
        float dy = PosEst_y - SELFIE_origin.Y;//compute dy
        RealDist = sqrtf(dx * dx + dy * dy);//compute distance

        if(RealDist != 0)
        {
            curSELFIE_Angle = RAD_TO_DEG * atan2f(dy, dx);
            SELFIE_ExpYawTemp = curSELFIE_Angle - 180;
			if(SELFIE_ExpYawTemp > 180) SELFIE_ExpYawTemp -= 360;
			else if(SELFIE_ExpYawTemp < -180) SELFIE_ExpYawTemp += 360;//根据位置计算出来的期望YAW

            RealAngl = curSELFIE_Angle - InitAngl;
			if(RealAngl > 180) RealAngl -= 360;
			else if(RealAngl < -180) RealAngl += 360;
        }
        else
        {
			curSELFIE_Angle = 180;
            SELFIE_ExpYawTemp = 0;
        }

		if(SelfieInit == 0)
		{
			if(RFMode == RFMODE_ORBIT && OrbitCenter == UserCenter)//根据模式设定
			{
				InitAngl = SELFIE_angle = curSELFIE_Angle;
				SELFIE_Radtrg = RealDist;//R Init.
				RealAngl = 0;
			}
			else
			{
				InitAngl = SELFIE_angle = YawAng + 180;//起始 0度 4米
				if(InitAngl > 180) InitAngl -= 360;
				else if(InitAngl < -180) InitAngl += 360;
				SELFIE_Radtrg = GetDroneSysParam()->Distance * 10.0f;//400;
				RealAngl = 0;
			}

/* 初始化Yaw相关计算 */
			InitErrYaw = fabs(SELFIE_ExpYawTemp - SELFIE_ExpYaw);
			if(InitErrYaw > (360 - InitErrYaw)) YawRoundDir = (SELFIE_ExpYaw > SELFIE_ExpYawTemp)? 1 : (-1);//需要跨过奇点
			else YawRoundDir = (SELFIE_ExpYaw > SELFIE_ExpYawTemp)? (-1) : 1;//不需要,则往正方向加
			if(InitErrYaw > 180) InitErrYaw = 360 - InitErrYaw;//求Yaw误差
			if(RFMode == RFMODE_ORBIT && OrbitCenter == UserCenter && InitErrYaw > 0.25f)
				YawInit = 1;//大于2度,需要对准yaw.
			else YawInit = 0;
/* 初始化半径相关计算 */
			if(RealDist > 2000 || RealDist < 400)
			{
				RadInit = 1;
				POS_KP = 0;
			}
			else
				RadInit = 0;

			SelfieInit = 1;
		}

		if(RadInit == 1)
		{
			if(POS_KP < 0.8f)
				POS_KP += 0.006f;
			if(RealDist <= 2000 && RealDist >= 400)
			{
				RadInit = 0;
				POS_KP = 0.8f;
			}
		}

		if(YawInit == 0)//YAW对准OK
		{
			SELFIE_ExpYaw = SELFIE_ExpYawTemp;//follow
//			if(CirVel_trg == 0)//没有打舵
//			{
				if(YawModifyCmd == 1)
					YawModifyTarget -= 0.1f;//10ms,20deg/s
				else if(YawModifyCmd == 2)
					YawModifyTarget += 0.1f;//10ms,20deg/s
				YawModifyTarget = constrain_float(YawModifyTarget, -90, 90);//+- 10deg
				YawModify = YawModifyTarget;
//			}
//			else
//			{
//				YawModifyTarget = 0.0f;
//				step_change(&YawModify, 0, 0.2f, 0.2f);
//			}
			SELFIE_ExpYaw += YawModify;
		}
		else
		{
			InitErrYaw = fabs(SELFIE_ExpYawTemp - SELFIE_ExpYaw);//cal yaw err.YawAng
			if(InitErrYaw > 180) InitErrYaw = 360 - InitErrYaw;//求Yaw误差
			if(InitErrYaw <= 0.25f) YawInit = 0;//Yaw误差小
			else SELFIE_ExpYaw += 0.25f * YawRoundDir;
		}

		if(SELFIE_ExpYaw > 180) SELFIE_ExpYaw = SELFIE_ExpYaw - 360;
		else if(SELFIE_ExpYaw < -180) SELFIE_ExpYaw = SELFIE_ExpYaw + 360;

		SELFIE_angle += CirVel_trg * 0.01f;//selfie angle limit
        if(SELFIE_angle > 180) SELFIE_angle -= 360;
        if(SELFIE_angle < -180) SELFIE_angle += 360;

        SELFIE_Radtrg += RadVel_trg * 0.01f;
		SELFIE_Radtrg = constrain_float(SELFIE_Radtrg, 400, 2000);//selfie radius limit

		PH.pos_exp_x = SELFIE_origin.X + SELFIE_Radtrg * cosf(SELFIE_angle * (float)DEG_TO_RAD);//coordinate exchange
		PH.pos_exp_y = SELFIE_origin.Y + SELFIE_Radtrg * sinf(SELFIE_angle * (float)DEG_TO_RAD);
	}
}

inline void InitSelfieYaw(float Yaw)
{
	SELFIE_ExpYaw = Yaw;
}

void SetSelfieCenter(void)
{
	SelfieInit_Center.X = PosEst_x;
	SelfieInit_Center.Y = PosEst_y;
}

float GetDisToCenter(void)
{
	float dx = PosEst_x - SelfieInit_Center.X;//compute dx
	float dy = PosEst_y - SelfieInit_Center.Y;//compute dy
	return sqrtf(dx * dx + dy * dy);//compute distance
}

void SetYawModify(uint16_t rfCmd)
{
	if(rfCmd == 400)
		YawModifyCmd = 1;//Yaw --;
	else if(rfCmd == 1200)
		YawModifyCmd = 0;
	else if(rfCmd == 2000)
		YawModifyCmd = 2;//Yaw ++;
}
