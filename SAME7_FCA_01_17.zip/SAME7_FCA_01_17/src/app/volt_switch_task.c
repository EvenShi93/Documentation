#include "volt_switch_task.h"
#include "app.h"

/* (SCR) Sleep deep bit */
#define SCR_SLEEPDEEP   (0x1 <<  2)

uint8_t VoltParamValid = 0;

static unsigned char lowPowerFlag = 0;
static unsigned char preLowPowerFlag = 0;
static unsigned int lowPowerCount = 0;
static unsigned int preLowPowerCount = 0;

uint8_t ElectricQTimeCnt = 0;
static uint8_t ElectricQuantity = 100;
static float voltValue = 12.5f;//PRE_LOW_POWER_VALUE;
static float VoltLPF = 12.5f;

/* 关机任务 */
static unsigned char powerStatue = POWER_ON;
static uint8_t SwitchLevel = POWER_HIGH;
static uint8_t SwitchInitFlag = 0;
static uint16_t SwitchLevelCnt = 0;

static void PowerOff(void);

void volt_switch_1ms_task(void)
{
	float voltage = get_volt();
    voltValue = voltValue * 0.95f + voltage * 0.05f;
    if(voltValue > PRE_LOW_POWER_VALUE)
        preLowPowerCount = 0;
    else if(voltValue >= LOW_POWER_VALUE)
    {
        lowPowerCount = 0;
        preLowPowerCount ++;
        if(preLowPowerCount >= LOW_POWER_COUNT)
        {
            preLowPowerCount = LOW_POWER_COUNT;
            preLowPowerFlag = 1;
        }
    }
    else
    {
        preLowPowerCount = 0;
        lowPowerCount ++;
        if(lowPowerCount >= LOW_POWER_COUNT)
        {
            lowPowerCount = LOW_POWER_COUNT;
            lowPowerFlag = 1;
            preLowPowerFlag = 1;
        }
    }

	if(VoltParamValid == 1)
	{
		lowPowerFlag = 1;
		preLowPowerFlag = 1;
	}

	ElectricQTimeCnt ++;
	if(ElectricQTimeCnt >= 100)
	{
		ElectricQTimeCnt = 0;
/* compute electric quantity */
		VoltLPF = VoltLPF * 0.95f + voltage * 0.05f;
		if(VoltLPF > 12.5f)
			ElectricQuantity = 100;
		else if(VoltLPF > 11.7f)
			ElectricQuantity = Min((uint8_t)(20 * VoltLPF - 150.0f), ElectricQuantity);
		else if(VoltLPF > 11.2f)
			ElectricQuantity = Min((uint8_t)(32 * VoltLPF - 290.4f), ElectricQuantity);
		else if(VoltLPF > 10.8f)
			ElectricQuantity = Min((uint8_t)(80 * VoltLPF - 828.0f), ElectricQuantity);//(10.8f,11.0] <==> (11.0,11.2]
		else if(VoltLPF > 10.65f)
			ElectricQuantity = Min((uint8_t)(106.67f * VoltLPF - 1116.035f), ElectricQuantity);
		else if(VoltLPF > 10.35f)
			ElectricQuantity = Min((uint8_t)(53.33f * VoltLPF - 547.9655f), ElectricQuantity);
		else
			ElectricQuantity = 4;
/* compute electric quantity */
	}

	SwitchLevel = GetSwitchLevel();
	if(SwitchLevel == POWER_LOW)
	{
		if(SwitchInitFlag)//开机后有过松手
		{
			if(SwitchLevelCnt < 500)
			{
				SwitchLevelCnt ++;
			}
			else if(powerStatue != POWER_OFF)
			{
				ClrToneReq();//清除当前的声音请求
				SetToneCmd(Shutdown);
				flyEnable = 0;
				powerStatue = POWER_OFF;//关闭电源
			}
		}
	}
	else
	{
		SwitchLevelCnt = 0;
		SwitchInitFlag = 1;
	}
}

uint8_t GetLowPowerFlag(void)
{
	if(lowPowerFlag)
		return 2;
	else if(preLowPowerFlag)
		return 1;
	else
		return 0;
}

inline uint8_t GetElectricQuantity(void)
{
	return ElectricQuantity;
}

uint16_t rfLostTimeCnt = 0;
uint8_t ShutDownFlag = 0;
void AutoShutDown_Task(void)//10ms
{
    if((rfIsLost() || ShutDownFlag == 1) && flyEnable == 0
#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
		&& GetEngineModeSta() == 0
#endif
		)//不在飞行状态下,不在老化模式下,丢信号5min自动关机
    {
        rfLostTimeCnt ++;
        if(rfLostTimeCnt >= 30000 && ShutDownFlag == 0)//5min
        {
			ClrToneReq();//清除当前的声音请求
            SetToneCmd(Shutdown);
            ShutDownFlag = 1;
        }
		if(rfLostTimeCnt >= 30050)// && (GetToneSta() == 0)
			SetPowerStat(POWER_OFF);//close(switch_getID());
    }
    else rfLostTimeCnt = 0;
    if(voltValue < LOW_POWER_SHUTDOWN && flyEnable == 0
#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
		&& GetEngineModeSta() == 0
#endif
		)//不在飞行状态下,不在老化模式下,低于切断电压直接关机
        PowerOff();
}

extern AT24CXX_RW_struct tt;
extern FCA_SystemParam DroneSysParam;
extern uint8_t SysParamChanged;
extern uint8_t DeviceInit;

extern unsigned char gyroCalibrationFlag;
extern Vref_DataPage EEPROM_Cal_Data;
extern HeadPage BackupHeader;

uint8_t PeaceDataSaveStep = 0, SysParamSaved = 0;
uint8_t HeaderInfo = 0, HeaderWriteFlag = 0;
void ShutDownTask(void)
{
	if(powerStatue == POWER_OFF)
	{
		if(GetToneSta() != 0
#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
		&& GetEngineModeSta() == 0
#endif
		)
			return;
#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
		if(GetEngineModeSta() == 1)
		{
			PowerOff();
			return;
		}
#endif
		if((DeviceInit & DEV_ERR_AT24CXX) == 0 && (DeviceInit & DEV_ERR_DATAGET) == 0 && (DeviceInit & DEV_ERR_MPU6500) == 0)
		{
			HeaderInfo = GetSysParam_Sta();
			if(gyroCalibrationFlag == 1 && PeaceDataSaveStep != 2)//校准完成且成功,未存储完毕// && GyroPeaceFailed == 0
			{
				if(PeaceDataSaveStep == 0)
				{
					open(AT24CXX_getID());
					if(EEPROM_Cal_Data.members.GyrErrInfo.DataNumb < 10)
						EEPROM_Cal_Data.members.GyrErrInfo.DataNumb ++;

					EEPROM_Cal_Data.members.GyrErrInfo.DataIndex ++;
					if(EEPROM_Cal_Data.members.GyrErrInfo.DataIndex >= 10)
						EEPROM_Cal_Data.members.GyrErrInfo.DataIndex = 0;
					float *gyroOffset = GetGyrPeaceOff();
					/* 注:(int16_t)强制类型转换有丢失精度的风险 */
					EEPROM_Cal_Data.members.GyrErrVal[EEPROM_Cal_Data.members.GyrErrInfo.DataIndex].GryPecX = (int16_t)gyroOffset[0];
					EEPROM_Cal_Data.members.GyrErrVal[EEPROM_Cal_Data.members.GyrErrInfo.DataIndex].GryPecY = (int16_t)gyroOffset[1];
					EEPROM_Cal_Data.members.GyrErrVal[EEPROM_Cal_Data.members.GyrErrInfo.DataIndex].GryPecZ = (int16_t)gyroOffset[2];
					tt.DataAddr = 32 * 32;
					tt.len = 32;
					tt.pData = (uint8_t *)&EEPROM_Cal_Data.members.GyrErrVal[0].GryPecX;
					ioctrl(AT24CXX_getID(), AT24_WRITE_1Page, &tt);
					PeaceDataSaveStep = 1;
					close(AT24CXX_getID());
				}
				else if(PeaceDataSaveStep == 1)
				{
					open(AT24CXX_getID());
					tt.DataAddr = 33 * 32;
					tt.len = 32;
					tt.pData = (uint8_t *)&EEPROM_Cal_Data.members.GyrErrVal[5].GryPecY;
					ioctrl(AT24CXX_getID(), AT24_WRITE_1Page, &tt);
					PeaceDataSaveStep = 2;
					close(AT24CXX_getID());
				}
			}
			else if(SysParamChanged == 1 && SysParamSaved == 0)
			{
				open(AT24CXX_getID());
				tt.DataAddr = 34 * 32;
				tt.len = 14;
				tt.pData = (uint8_t *)&DroneSysParam;
				ioctrl(AT24CXX_getID(), AT24_WRITE_1Page, &tt);
				SysParamSaved = 1;
				close(AT24CXX_getID());
			}
			else if((HeaderInfo & 0x04) != 0 && (HeaderInfo & 0x08) == 0 && (HeaderInfo & 0x80) != 0 && HeaderWriteFlag == 0)//第一页丢失
			{
				open(AT24CXX_getID());
				tt.DataAddr = 0;
				tt.len = 17;
				tt.pData = (uint8_t *)&EEPROM_Cal_Data.Page32[0][0];
				ioctrl(AT24CXX_getID(), AT24_WRITE_1Page, &tt);
				HeaderWriteFlag = 1;
				close(AT24CXX_getID());
			}
			else if((HeaderInfo & 0x08) != 0 && (HeaderInfo & 0x04) == 0 && (HeaderInfo & 0x80) != 0 && HeaderWriteFlag == 0)//备份数据丢失
			{
				open(AT24CXX_getID());
				tt.DataAddr = 40 * 32;
				tt.len = 17;
				tt.pData = (uint8_t *)&BackupHeader.Page32[0];
				ioctrl(AT24CXX_getID(), AT24_WRITE_1Page, &tt);
				HeaderWriteFlag = 1;
				close(AT24CXX_getID());
			}
			else if(GetToneSta() == 0)
			{
				close(AT24CXX_getID());
				PowerOff();
			}
		}
		else// if(GetToneSta() == 0)
		{
			PowerOff();
		}
	}
	else
	{
		PeaceDataSaveStep = 0;
		SysParamSaved = 0;
	}
}

static void PowerOff(void)
{
	close(switch_getID());
	/* Entry sleep mode */
	PMC->PMC_FSMR &= (uint32_t)~PMC_FSMR_LPM;
	SCB->SCR &= (uint32_t)~SCR_SLEEPDEEP;

	//__WFI();//wait for interrupt.(exit sleep mode)
}

void SetPowerStat(uint8_t Sta)
{
	powerStatue = Sta;
}

unsigned char GetPowerStat(void)
{
	return powerStatue;
}
