#ifndef _MATHS_H_
#define _MATHS_H_

#include "bsp.h"
#include "global_type.h"

#define DEG_TO_RAD 0.017453292519943295769236907684886f
#define RAD_TO_DEG 57.295779513082320876798154814105f

#define LimitMAX(x, y) ((x > y)? y : x)
#define LimitMIN(x, y) ((x < y)? y : x)

#define GETDIR(x, y) (x > y ? (1) : (x < y ? (-1) : (0)))
#define SGN(x) ((x) > 0 ? 1 : ((x) < 0 ? -1 : 0))
#define SQUARE(x) ((x) * (x))

void sensfusion6UpdateQ(FLOAT_GYRO* gyro, FLOAT_ACC* accel,float dt,volatile Quat* Q);
void sensfusion9UpdateQ(FLOAT_GYRO* gyro, FLOAT_ACC* accel,FLOAT_MAG* mag,float dt,volatile Quat* Q);
void dotCal(FLOAT_ACC* accel,volatile Quat* Q,volatile Quat* dot);
void EulerAngleToQuaternion1(FLOAT_RPY* eur,volatile Quat* Q);
void Quat2Euler(volatile  Quat* Q,FLOAT_RPY* eur);
void QuaternionMultiplicationCross(Quat* Q_Start, Quat* Q_Rotate, volatile Quat* Q_Terminal);
void QuaternionDiviCross(Quat* Q_Start, Quat* Q_Terminal, volatile Quat* Q_Rotate);
void QuatToRotate(volatile Quat* rotateQ, volatile FLOAT_XYZ * rotateAngle);
void quaternion_rotateVector(Quat* Q,FLOAT_XYZ* from,volatile FLOAT_XYZ* to,unsigned char Dir);
float invSqrt(float x);
void ellipsoid_init(void);
void ellipsoid_step1(void);
void ellipsoid_step2(void);
void ellipsoid_step3(double unitValue);
float constrain_float(float amt, float low, float high);
float apply_deadband(float value, float deadband);
float apply_limit(float value, float limit);
void step_change(float* in,float target,float step,float deadBand );
void pid_loop(PID* pid,float eurDesir,float measure);
void pid_loop_TDD(PID* pid,float eurDesir,float tdd,float measure);
void sort(int* buffer,unsigned int len,unsigned char dir);
void Quick_Sort(int s[],int l,int r);
unsigned char crcMotoCal(unsigned char* buffer,unsigned int len);
unsigned char crcRfCal(unsigned char* buffer,unsigned int len);

extern short matrixQ[SAMPLE_NUMBER][3];
extern double  matrixA[6][6] ;
extern double  matrixB[6];
extern double  matrixX[6];
extern float   matrixM[7]; 

void linermap(const float L_max,   const float L_min,  \
	          const float tar_max, const float tar_min,\
			  const float input_t, float* output_t)  ;

void rotateV(FLOAT_XYZ *v, FLOAT_RPY *delta);
void ADRC_td(float input ,ADRC_str* adrc);
void ADRC_ESO(ESO* t,float input_y);
float fal_GAIN(float input,float sw,float a,float h);
float PID_sech(float ex_input, float cp);
uint8_t QuadCurveCtrl(QuadCurve *pCurve, uint8_t Condition);						
						
#endif
