#ifndef _ACC_GYRO_MAG_TASK_H_
#define _ACC_GYRO_MAG_TASK_H_

#include "middleware.h"

void acc_gyro_1ms_task(void);
void mag_5ms_task(void);

#endif
