#ifndef _LED_TASK_H_
#define _LED_TASK_H_

#include "middleware.h"

void LedTask(void);

#endif
