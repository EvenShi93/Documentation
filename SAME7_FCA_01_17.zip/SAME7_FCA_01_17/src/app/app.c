#include "app.h"

OS_STK TaskStartStk[TASK_START_STK_SIZE];
OS_STK Task1_Stk[TASK1_STK_SIZE];
OS_STK Task2_Stk[TASK2_STK_SIZE];
OS_STK Task3_Stk[TASK3_STK_SIZE];
OS_STK Task4_Stk[TASK4_STK_SIZE];
OS_STK Task5_Stk[TASK5_STK_SIZE];
#if USE_CAM_FLOW
OS_STK FlowTask_Stk[FLOWTASK_STK_SIZE];
#endif

void AppTaskStart(void *p_arg);

int main(void)
{
    WDT_Disable( WDT );

    NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x8000);//0x8000

    SysTick_Config(CoreCK / OS_TICKS_PER_SEC);
    _TimeTicksInit();

    /* Operation system kernel initialize */
    OSInit();

    /* Create start task */
    OSTaskCreateExt((void (*)(void *)) AppTaskStart,
                    (void           *) 0,
                    (OS_STK         *)&TaskStartStk[TASK_START_STK_SIZE - 1],
                    (INT8U           ) TASK_START_PRIO,
                    (INT16U          ) TASK_START_PRIO,
                    (OS_STK         *)&TaskStartStk[0],
                    (INT32U          ) TASK_START_STK_SIZE,
                    (void           *) 0,
                    (INT16U          )(OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR));

    /* Start OS */
    OSStart();
}

void AppTaskStart(void *p_arg)
{
    (void)p_arg;

#if (OS_TASK_STAT_EN > 0)
    OSStatInit();
#endif
    /* task1 */
    OSTaskCreateExt((void (*)(void *)) AppTask1,
                    (void           *) 0,
                    (OS_STK         *)&Task1_Stk[TASK1_STK_SIZE-1],
                    (INT8U           ) TASK1_PRIO,
                    (INT16U          ) TASK1_PRIO,
                    (OS_STK         *)&Task1_Stk[0],
                    (INT32U          ) TASK1_STK_SIZE,
                    (void           *) 0,
                    (INT16U          )(OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR));
    /* task2 */
    OSTaskCreateExt((void (*)(void *)) AppTask2,
                    (void           *) 0,
                    (OS_STK         *)&Task2_Stk[TASK2_STK_SIZE-1],
                    (INT8U           ) TASK2_PRIO,
                    (INT16U          ) TASK2_PRIO,
                    (OS_STK         *)&Task2_Stk[0],
                    (INT32U          ) TASK2_STK_SIZE,
                    (void           *) 0,
                    (INT16U          )(OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR));
    /* task3 */
    OSTaskCreateExt((void (*)(void *)) AppTask3,
                    (void           *) 0,
                    (OS_STK         *)&Task3_Stk[TASK3_STK_SIZE-1],
                    (INT8U           ) TASK3_PRIO,
                    (INT16U          ) TASK3_PRIO,
                    (OS_STK         *)&Task3_Stk[0],
                    (INT32U          ) TASK3_STK_SIZE,
                    (void           *) 0,
                    (INT16U          )(OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR));
    /* task4 */
    OSTaskCreateExt((void (*)(void *)) AppTask4,
                    (void           *) 0,
                    (OS_STK         *)&Task4_Stk[TASK4_STK_SIZE-1],
                    (INT8U           ) TASK4_PRIO,
                    (INT16U          ) TASK4_PRIO,
                    (OS_STK         *)&Task4_Stk[0],
                    (INT32U          ) TASK4_STK_SIZE,
                    (void           *) 0,
                    (INT16U          )(OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR));
    /* task5 */
    OSTaskCreateExt((void (*)(void *)) AppTask5,
                    (void           *) 0,
                    (OS_STK         *)&Task5_Stk[TASK5_STK_SIZE-1],
                    (INT8U           ) TASK5_PRIO,
                    (INT16U          ) TASK5_PRIO,
                    (OS_STK         *)&Task5_Stk[0],
                    (INT32U          ) TASK5_STK_SIZE,
                    (void           *) 0,
                    (INT16U          )(OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR));
#if USE_CAM_FLOW
    OSTaskCreateExt((void (*)(void *)) FlowTaskLoop,
                    (void           *) 0,
                    (OS_STK         *)&FlowTask_Stk[FLOWTASK_STK_SIZE-1],
                    (INT8U           ) FLOWTASK_PRIO,
                    (INT16U          ) FLOWTASK_PRIO,
                    (OS_STK         *)&FlowTask_Stk[0],
                    (INT32U          ) FLOWTASK_STK_SIZE,
                    (void           *) 0,
                    (INT16U          )(OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR));
#endif
    OSTaskDel(OS_PRIO_SELF);
    while(1)
    {

    }
}

void SysTick_1ms_irq()
{
    OSIntEnter();
    OSTimeTick();
    OSIntExit();
}
