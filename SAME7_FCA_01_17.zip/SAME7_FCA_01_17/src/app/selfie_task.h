#ifndef __SELFIE_TASK_H
#define __SELFIE_TASK_H

#include "position_task.h"

void Selfie_Task(void);
void SetSelfieCenter(void);
float GetDisToCenter(void);
void InitSelfieYaw(float Yaw);
void SetYawModify(uint16_t rfCmd);

#endif /* __SELFIE_TASK_H */
