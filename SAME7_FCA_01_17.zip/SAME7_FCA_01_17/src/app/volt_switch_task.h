#ifndef _VOLT_SWITCH_TASK_H_
#define _VOLT_SWITCH_TASK_H_

#include "middleware.h"

//#define PRE_LOW_POWER_VALUE 11.0f
//#define LOW_POWER_VALUE     10.6f
//#define LOW_POWER_SHUTDOWN  9.8f
//#define LOW_POWER_COUNT     500

//2016-09����
#define PRE_LOW_POWER_VALUE 10.6f
#define LOW_POWER_VALUE     10.4f
#define LOW_POWER_SHUTDOWN  9.6f

#define LOW_POWER_COUNT     500


void volt_switch_1ms_task(void);
uint8_t GetLowPowerFlag(void);
uint8_t GetElectricQuantity(void);
void AutoShutDown_Task(void);
void ShutDownTask(void);
void SetPowerStat(uint8_t Sta);
unsigned char GetPowerStat(void);

#endif
