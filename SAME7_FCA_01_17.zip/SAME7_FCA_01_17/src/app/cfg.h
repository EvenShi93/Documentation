#ifndef _CFG_H_
#define _CFG_H_

//ucos_iiϵͳ��������

#define TASK_START_PRIO         3
#define TASK1_PRIO              4
#define TASK2_PRIO              5
#define TASK3_PRIO              6
#define FLOWTASK_PRIO           7
#define TASK4_PRIO              8
#define TASK5_PRIO              9

#define TASK_START_STK_SIZE     128
#define TASK1_STK_SIZE          128
#define TASK2_STK_SIZE          1024
#define TASK3_STK_SIZE          1024
#define FLOWTASK_STK_SIZE       1024
#define TASK4_STK_SIZE          2200
#define TASK5_STK_SIZE          1024

//������������
#define DEV_DRV_NUMBER 50
//�豸������󳤶�
#define DEV_NAME_LEN 15

//flash ����
typedef enum
{
    FLASH_PARAM_ADDR = 0x47FC00,
    FLASH_PARAM_LEN = 0x400,         //1K
} FLASH_ROM_ASSIGN;

//�㷨����
#define SAMPLE_NUMBER 300

#endif
