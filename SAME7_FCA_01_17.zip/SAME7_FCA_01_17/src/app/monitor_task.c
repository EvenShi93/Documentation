#include "monitor_task.h"
#include "rfM.h"
#include "FlowAlgorithm.h"
#include "position_task.h"
#include "KF_filter.h"
static RecPackTypeDef RecParam = {0};
static RecCommTypeDef RecComm = {0};

extern ESO ESOtest;
unsigned char strFlag = 1;
static COMM_DATA commData;
unsigned char  debugSel = 1;
extern FLOAT_GYRO *gyroUnit;
extern FLOAT_MAG *magUnit;
extern FLOAT_ACC *accUnit;
extern FLOAT_RPY curEur;
extern PID pidPitch, pidRoll, pidPitchRate, pidRollRate, pidYawRate;
extern PID fuzzy_Pitch, fuzzy_Roll;

extern PID fPitch_LPF, fRoll_LPF;

extern float PitchErr, RollErr;
extern float PitchEC, RollEC;

extern float PitchPreErrLPF, PitchEC_LPF;
extern float RollPreErrLPF, RollEC_LPF;

extern float LPF_PAR;
extern FLOAT_RPY magErrorEur;
extern FLOAT_RPY expEur;
extern float moto1PRYOutput, moto2PRYOutput, moto3PRYOutput, moto4PRYOutput;
extern float accZOffset;
extern float vel_acc;
extern FLOAT_XYZ accLowPass;
extern FLOAT_XYZ accEF;
extern float pressure;
extern float groundPressure;
extern float groundAltitude;
extern float pressureAlt ;

extern float HoverLevel;
extern float velRateCorr;
extern INT8U  OSCPUUsage;
extern float vel_acc_lowPass;
extern float IMU_temperature;
extern float velAccCorr ;
extern float velRateCorr;
#if defined(USE_PEACE_DATA)
extern short gyroTempOff[3];
extern short acceTempOff[3];
#endif /* defined(USE_PEACE_DATA) */
extern float thrAltOut;
extern float VelDesir;
extern Quat imuQ;
extern FLOAT_XYZ  rotateAngleBF;

extern float PosEst_x, PosEst_y;

extern float velRateCorr_x, velRateCorr_y;

extern Nav_struct_PosHold PH;

extern float GPS_SpeedQuality;
extern float GPS_PositionQuality;

extern FLOAT_RPY PositionXY6axis_tEUR;
extern FLOAT_RPY Q_Result_tEUR;
extern FLOAT_RPY test_Result_tEUR;
extern float GPShome_x_cm , GPShome_y_cm;

extern float BF_X, BF_Y;

extern float accXY;
extern FLOAT_RPY errEur;
extern float pixel_flow_x, pixel_flow_y;
extern FLOAT_XYZ  rotateAngleEF;

extern OPTICAL_DATA_TypeDef optical_flow;
extern float new_velocity_x, new_velocity_y;
extern FlowMovDef FlowSpeed;
extern INTEGRATED_DATA_TypeDef optical_flow_rad;
extern uint32_t deltatime;
extern FLOAT_XYZ FlowaccBF_LPF;
extern PID FlowPID_X, FlowPID_Y;
/******************************Flow************************************/
extern float BF_AccCorrect_Flow_x, BF_AccCorrect_Flow_y, BF_VelCorrect_Flow_x, BF_VelCorrect_Flow_y;
extern float Flow_ExpAngPit, Flow_ExpAngRol;
extern float Flow_OffsetAngPit, Flow_OffsetAngRol;

float dis_x = 0.0f, dis_y = 0.0f, dis_cm = 0.0f;
extern void get_xy(double lon_home, double lat_home, double lon_now, double lat_now, float *x_cm, float *y_cm, float *dis_cm);
extern PID FlowAcc_X, FlowAcc_Y;

extern FLOAT_RPY BrakeEur;
extern float  XBrakeForce;
extern float Flow_ACCOFFSET_X, Flow_ACCOFFSET_Y ;
extern float  Xacc_diff, Yacc_diff;
extern uint8_t GET_Sonic_STEP;
extern float SonicOffsetAlt;
extern float pos_err_baro;

extern int B_buffer[2];
extern  float RC_z_vel ;
extern float Z_ExpVel ;
extern volatile uint8_t AutoTakeOff_Sta ;

extern unsigned char BaroErr;

extern uint8_t fuseVelData;
extern float Motor1ESC, Motor2ESC, Motor3ESC, Motor4ESC;
/* --------------------------- Parameters --------------------------- */
extern float VelNE_NOISE;
extern float VelD_NOISE;
extern float PosNE_NOISE;
extern float Alt_NOISE;
extern float Acc_NOISE;
extern uint8_t Vel_GATE;
extern uint8_t Pos_GATE;
extern uint8_t Hgt_GATE;
/* --------------------------- Parameters --------------------------- */
extern uint16_t FlowCopy;
extern uint8_t BaroFusion_OFF;
extern float sonicAlt ;
extern PID PH_Pos_P, PH_Rate_x, PH_Rate_y;
extern float GyroT;
extern float FlowT;

extern ADRC_str Pitch_RC;
extern ADRC_str Roll_RC;

float  Debug_Param[15] = {0};
extern GPS_DATA *gpsData;
extern float RC_velDesired_x, RC_velDesired_y;

extern float BF_X, BF_Y;
extern  ADRC_str Vel_xTD, Vel_yTD;
extern  ADRC_str vLoop_xTD, vLoop_yTD;
extern float vel_deltaLPF_x, vel_deltaLPF_y;

extern uint16_t ekfdt;
extern float Vaccx;
extern float AltOut;
extern Sonar SonicHeightInfo;

extern unsigned char RFMode;

extern FLOAT_RPY PositionXY_EUR;

extern float GPS_Height, GPS_GroundHeight;

extern float Volt_k, Volt_b;

extern Sonar SonicHeightInfo ;

typedef enum
{
    _9Asix_IMU = 1,
    EurRatePID = 2,
    OSTaskSta,
    FlowSta,
    GPSSta,
    AltSta,
    RF_Sta,
    PosLoop,
    AltLoop,
    AttLoop,
    View_1,
    View_2,
} PageName;

extern unsigned int task2_1_s_count ;
extern unsigned int task3_1_s_count ;
extern unsigned int task4_1_s_count ;
extern unsigned int task5_1_s_count ;
extern FLOAT_RPY rotateEur ;
extern float ACCDesired, VelDesired;
extern float acc_OFFSET ;
extern REMOTE_DATA remoteData;
extern float Sonic_Speed ;
extern float acc_correction_z_sonic_I;
extern float vel_correction_z_baro ;
extern float time_const_z_baro;

extern float _6staEKF_states[6];
extern float time_const_sonic;
extern  float gyroOffset[3] ;
void monitor_10ms_task(void)
{
    unsigned char *buffer = get_monitor_buffer_ptr();
    unsigned char *p;
    unsigned int count = 0;
    static unsigned int count1 = 0;
    unsigned int len = 0;
    static unsigned char oldDebugSel = 0;
    unsigned char uartSendFlag = 0;
    GPS_DATA *CurGpsData = get_gps_data();
    rfGPS_DATA *RFGPS_test = get_rf_GPS();

    if(expEur.Yaw < -25)
    {
        count1 ++;

        if(count1 == 30)
        {
            //debugSel ++;
        }
				

        if(count1 > 30)
        {
            count1 = 30;
        }
    }

    if(expEur.Yaw > 25)
    {
        count1 ++;

        if(count1 == 30)
        {
            //debugSel --;
        }

        if(count1 > 30)
        {
            count1 = 30;
        }
    }

    if(fabs(expEur.Yaw) < 20.0f)
    {
        count1 = 0;
    }

    if(oldDebugSel != debugSel)
    {
        strFlag = 1;
        uartSendFlag = 1;
    }
    oldDebugSel = debugSel;

    static unsigned int timeCount = 0;
    timeCount ++;
    if(timeCount >= 200)
    {
        timeCount = 0;
        strFlag = 1;
        uartSendFlag = 1;
    }

    //参数给定
    if(MonitorRecData(&RecParam))
    {
        if(RecParam.GetData.DataID < 12)
        {
            Debug_Param[RecParam.GetData.DataID] = RecParam.GetData.uData.fData;
        }
    }

    //按键命令
    if(MonitorCommData(&RecComm))
    {
        //选某一页
        if(RecComm.CommData.CommType == 0) debugSel = RecComm.CommData.CommID;
        //特殊命令
        if(RecComm.CommData.CommType == 2)
        {
            if(RecComm.CommData.CommID == 1)
            {
                __set_FAULTMASK(1);
                NVIC_SystemReset();
            };//reset MCU
            if(RecComm.CommData.CommID == 2) {}; //moto OFF
            if(RecComm.CommData.CommID == 3) {}; //ACC_cali
            if(RecComm.CommData.CommID == 4) {}; //MAG_cali
        }
        if(RecComm.CommData.CommType == 1)
        {
            if(RecComm.CommData.CommID == 1)
            {
                if(debugSel < 12)debugSel ++;
            }//Page +
            if(RecComm.CommData.CommID == 2)
            {
                if(debugSel > 0)
                    debugSel --;
            }//PAge -
        }
    }

    switch(debugSel)
    {
    case _9Asix_IMU:
        commData.data[0].f_data = sqrtf(get_acc_raw()->accX*get_acc_raw()->accX+get_acc_raw()->accY*get_acc_raw()->accY+get_acc_raw()->accZ*get_acc_raw()->accZ);//
        commData.data[1].f_data = GetGyrPeaceSta();//accEF.Y;
        commData.data[2].f_data = GetGravity();//accEF.Z;
        commData.data[3].f_data = accEF.X;
        commData.data[4].f_data = accEF.Y;
        commData.data[5].f_data = accEF.Z;
        commData.data[6].f_data = accUnit->accX;//gyroUnit->gyroX;//get_acc_raw()->accX;//
        commData.data[7].f_data = accUnit->accY;//gyroUnit->gyroY;//get_acc_raw()->accY;//
        commData.data[8].f_data = accUnit->accZ;//GetGyrPeaceSta();//gyroUnit->gyroZ;//get_acc_raw()->accZ;//
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"modacc,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"peace,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"G,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"EF.x,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"EF.y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"EF.z,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"accX,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"accY,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"accZ,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    case EurRatePID :
        commData.data[0].f_data = curEur.Pitch;
        commData.data[1].f_data = curEur.Rool;
        commData.data[2].f_data = curEur.Yaw;
        commData.data[3].f_data = expEur.Pitch;
        commData.data[4].f_data = expEur.Rool;
        commData.data[5].f_data = expEur.Yaw;
        commData.data[6].f_data = pidPitch.Output;
        commData.data[7].f_data = 0;
        commData.data[8].f_data = 0;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"Eur.Pitch,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"Eur.Rool,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"Eur.Yaw,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"exp.Pitch,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"exp.Rool,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"exp.Yaw,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"pidPitch.Oput,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)","  ;
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    case OSTaskSta:
        commData.data[0].f_data = OSCPUUsage;
        commData.data[1].f_data = IMU_temperature;
        commData.data[2].f_data = 0;
        commData.data[3].f_data = 0;
        commData.data[4].f_data = GetGyrPeaceSta()*100;
        commData.data[5].f_data = BaroErr;
        commData.data[6].f_data = task2_1_s_count;
        commData.data[7].f_data = task3_1_s_count;
        commData.data[8].f_data = task5_1_s_count;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"CPU_Usage,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"IMU_temperature,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"0,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"GyrPeace,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"BaroErr,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"task2_1s,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"task3_1s,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"task5_1s,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    case FlowSta:
        commData.data[0].f_data = -(FlowSpeed.x_Speed)*2 ;
        commData.data[1].f_data = -(FlowSpeed.y_Speed)*2 ;
        commData.data[2].f_data = FlowaccBF_LPF.X*100;
        commData.data[3].f_data = FlowaccBF_LPF.Y*100;
        commData.data[4].f_data = _6staEKF_states[0]*100;
        commData.data[5].f_data = _6staEKF_states[1]*100;
        commData.data[6].f_data = Flow_ExpAngPit;
        commData.data[7].f_data = Flow_ExpAngRol;
        commData.data[8].f_data = SonicHeightInfo.sonar_distance_raw * 100;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"FlowSpeed.x,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"FlowSpeed.y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"FlowaccBF_LPF.X,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"FlowaccBF_LPF.Y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;


            p = (unsigned char *)"states[0],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;


            p = (unsigned char *)"states[1],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"Flow_ExpAngPit,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;


            p = (unsigned char *)"Flow_ExpAngRol,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"Flow_alt,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    case GPSSta:
        commData.data[0].f_data = GetGPSPoint()->X;
        commData.data[1].f_data = GetGPSPoint()->Y;
        commData.data[2].f_data = CurGpsData->velN;//
        commData.data[3].f_data = CurGpsData->velE;//
        commData.data[4].f_data = CurGpsData->hMSL;//CurGpsData->velD;
        commData.data[5].f_data = velRateCorr_x;
        commData.data[6].f_data = velRateCorr_y;
        commData.data[7].f_data = PosEst_x;
        commData.data[8].f_data = PosEst_y;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"Pos_N,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"Pos_E,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"Vel_N,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"VEL_E,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"hMSL,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"vel_x,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"vel_y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;


            p = (unsigned char *)"PosEst_x,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"PosEst_y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
		case AltSta:
        commData.data[0].f_data = SonicHeightInfo.sonar_distance_raw * 100;
        commData.data[1].f_data = SonicHeightInfo.sonar_distance_raw * 100 + SonicOffsetAlt;//velAccCorr;
        commData.data[2].f_data = time_const_sonic;//pressureAlt;
        commData.data[3].f_data = AutoTakeOff_Sta;
        commData.data[4].f_data = (sonicAlt + SonicOffsetAlt) ;//GPS_Height - GPS_GroundHeight;//VelDesired;//vel_acc;
        commData.data[5].f_data = vel_acc;
        commData.data[6].f_data = EstAlt;
        commData.data[7].f_data = velRateCorr;
        commData.data[8].f_data = GET_Sonic_STEP;//SonicOffsetAlt;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"Son_Dis,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"Sonar+Off,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

			
            p = (unsigned char *)"time_const_sonic,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"AutoTakeOff,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"sonicAlt+Offse,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"vel_acc,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"EstAlt,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"velRateCorr,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"GET_Sonic_STEP,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;

    case RF_Sta:
        commData.data[0].f_data = remoteData.RemoteD[0];//expEur.Pitch;
        commData.data[1].f_data = remoteData.RemoteD[1];//expEur.Rool;
        commData.data[2].f_data = remoteData.RemoteD[2];//expEur.Yaw;
        commData.data[3].f_data = remoteData.RemoteD[3];//RFGPS_test->lat;
        commData.data[4].f_data = remoteData.RemoteD[4];//RFGPS_test->lon;
        commData.data[5].f_data = remoteData.RemoteD[5];//recA9Package.t;//RFGPS_test->alt;
        commData.data[6].f_data = remoteData.RemoteD[6];//RFGPS_test->accurancy;
        commData.data[7].f_data = remoteData.RemoteD[7];//RFGPS_test->speed;
        commData.data[8].f_data = remoteData.RemoteD[8];//RFGPS_test->heading;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"fixType,";

            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[1],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[2],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[3],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[4],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[5],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[6],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[7],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"D[8],";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
		case PosLoop:
        commData.data[0].f_data = PosEst_x;//RCdesired_accel_x;
        commData.data[1].f_data = PosEst_y;//RCdesired_accel_y;
        commData.data[2].f_data = get_volt();//RC_velDesired_x;//
        commData.data[3].f_data = 0;//RC_velDesired_y;//
        commData.data[4].f_data = PH.vel_target_x;
        commData.data[5].f_data = PH.vel_target_y;
        commData.data[6].f_data = PH.pos_target_x;//BF_X;//gpsData->velN;
        commData.data[7].f_data = PH.pos_target_y;//BF_Y;//gpsData->velE;
        commData.data[8].f_data = curEur.Yaw;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"PosEst_x,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"PosEst_y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"volt,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"vel_tar_x,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"vel_tar_y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"pos_tar_x,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"pos_tar_y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"curEur.Yaw,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
		case AltLoop:
        commData.data[0].f_data = velAccCorr * 0.01f;
        commData.data[1].f_data = Motor1ESC;
        commData.data[2].f_data = Motor2ESC;
        commData.data[3].f_data = Motor3ESC;
        commData.data[4].f_data = Motor4ESC;
        commData.data[5].f_data = GetMotorErrFlag();
        commData.data[6].f_data = 0;//TakeOffAlt;
        commData.data[7].f_data = CurExpAlt();
        commData.data[8].f_data = thrAltOut;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"AccCorVel,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"ESC_1,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"ESC_2,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"ESC_3,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"ESC_4,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"MotorErrFlag,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"TakeOffAlt,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"CurExpAlt,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"thrAltOut,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    case AttLoop:
        commData.data[0].f_data = BF_X;
        commData.data[1].f_data = BF_Y;
        commData.data[2].f_data = YawTarVal();
        commData.data[3].f_data = pidPitch.Output;
        commData.data[4].f_data = pidRoll.Output;
        commData.data[5].f_data = pidPitchRate.PreErr;
        commData.data[6].f_data = pidRollRate.PreErr;
        commData.data[7].f_data = 0;
        commData.data[8].f_data = 0;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"BF_X,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"BF_Y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"YawTar,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"pidPitch.Output,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"pidRoll.Output,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"PitRate.Err,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"RolRate.Err,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    case View_1:
        commData.data[0].f_data = pidYawRate.Output;
        commData.data[1].f_data = 0;
        commData.data[2].f_data = 0;
        commData.data[3].f_data = 0;
        commData.data[4].f_data = 0;
        commData.data[5].f_data = 0;//vel_correction_z_sonic ;
        commData.data[6].f_data = 0;
        commData.data[7].f_data = 0;//time_const_z_baro;
        commData.data[8].f_data = 0;//(pressureAlt );
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"YawOutput,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)",";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    case View_2:

        commData.data[0].f_data = rotateAngleEF.X;
        commData.data[1].f_data = rotateAngleEF.Y;
        commData.data[2].f_data = rotateAngleEF.Z;
        commData.data[3].f_data = rotateAngleBF.X;
        commData.data[4].f_data = rotateAngleBF.Y;
        commData.data[5].f_data = rotateAngleBF.Z;
        commData.data[6].f_data = errEur.Rool;
        commData.data[7].f_data = errEur.Pitch;
        commData.data[8].f_data = errEur.Yaw;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)"EF_X,"; //gx_Off
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"EF_Y,"; //gy_Off
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"EF_Z,"; //gz_Off
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"BF_X,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"BF_Y,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"BF_Z,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"errEur_rol,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"errEur_pit,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"errEur_yaw,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    default:
        debugSel = 1;
        commData.data[0].f_data = 0;
        commData.data[1].f_data = 0;
        commData.data[2].f_data = 0;
        commData.data[3].f_data = 0;
        commData.data[4].f_data = 0;
        commData.data[5].f_data = 0;
        commData.data[6].f_data = 0;
        commData.data[7].f_data = 0;
        commData.data[8].f_data = 0;
        if(strFlag == 1)
        {
            strFlag = 0;
            p = (unsigned char *)","; //gx_Off
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)","; //gy_Off
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)","; //gz_Off
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            p = (unsigned char *)"----,";
            len = str_len(p);
            str_add(buffer + count, p, len);
            count += len;

            comm_str_send(buffer, count);
        }
        break;
    }
    if(uartSendFlag == 0)
    {
        comm_data_send(&commData);
    }
}
