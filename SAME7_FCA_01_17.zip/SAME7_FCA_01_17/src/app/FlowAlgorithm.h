#ifndef __FLOWALGORITHM_H
#define __FLOWALGORITHM_H

#include "middleware.h"



extern float pixel_flow_x;
extern float pixel_flow_y;

typedef struct
{
    uint64_t time_usec;
    float flow_comp_m_x;
    float flow_comp_m_y;
    float ground_distance;
    int16_t flow_x;
    int16_t flow_y;
    uint8_t quality;
} OPTICAL_DATA_TypeDef;

typedef struct
{
    uint64_t time_usec;
    uint32_t integration_time_us;
    float integrated_x;
    float integrated_y;
    float integrated_xgyro;
    float integrated_ygyro;
    float integrated_zgyro;
    uint32_t time_delta_distance_us;
    float distance;
    int16_t temperature;
    uint8_t quality;
} INTEGRATED_DATA_TypeDef;

typedef struct
{
	float x_Speed;
	float y_Speed;
	float x_gyro;
	float y_gyro;
	float quality;
	float alt;
} FlowMovDef;

void FlowTask_1ms(void);
void Flow_Main(void);
FlowMovDef* Get_Flow_Move_Data(void);
unsigned char Get_Flow_Update_Flag(void);

#endif /* __FLOWALGORITHM_H */
