#include "PosEst.h"

static uint8_t GPS_ReadyFlag = 0;
static double lon_origin = 0.0, lat_origin = 0.0;

//This uses the "haversine" formula to calculate the great-circle distance between two points
static void get_xy(double lon_home, double lat_home, double lon_now, double lat_now, float *x_cm, float *y_cm, float *dis_cm)
{
    double RAD_lon_A = lon_home * 0.017453292519943295769236907684886;
    double RAD_lat_A = lat_home * 0.017453292519943295769236907684886;

    double RAD_lon_B = lon_now * 0.017453292519943295769236907684886;
    double RAD_lat_B = lat_now * 0.017453292519943295769236907684886;

    double DIF_lon =  RAD_lon_A - RAD_lon_B;
    double DIF_lat =  RAD_lat_A - RAD_lat_B;

    float term2 = cosf(RAD_lat_B);
    float term3 = term2 * sinf(DIF_lon / 2.0f);

    *x_cm = -1 * DIF_lat * 6371.004f * 100000.0f;
    *y_cm = -2 * asinf(term3) * 6371.004f * 100000.0f;

    *dis_cm = sqrtf((*x_cm) * (*x_cm) + (*y_cm) * (*y_cm));
}

void set_origin_point(double lon_origin_c, double lat_origin_c)
{
    lon_origin = lon_origin_c;
    lat_origin = lat_origin_c;
}

void get_xy_distance(double lon_now, double lat_now, float *x_cm, float *y_cm, float *dis_cm)
{
    get_xy(lon_origin, lat_origin, lon_now, lat_now, x_cm, y_cm, dis_cm);
}

static float MagDecline = 0.0f;
float get_declination(float lat, float lon)
{
	int16_t decSW, decSE, decNW, decNE, lonmin, latmin;
	float decmin, decmax;
	uint8_t latmin_index, lonmin_index;

	// Validate input values
	lat = constrain_float(lat, -90, 90);
	lon = constrain_float(lon, -180, 180);

	latmin = floor(lat / 5) * 5;
	lonmin = floor(lon / 5) * 5;

	latmin_index = (90 + latmin) / 5;
	lonmin_index = (180 + lonmin) / 5;

	decSW = dec_tbl[latmin_index][lonmin_index];
	decSE = dec_tbl[latmin_index][lonmin_index + 1];
	decNE = dec_tbl[latmin_index + 1][lonmin_index + 1];
	decNW = dec_tbl[latmin_index + 1][lonmin_index];

	decmin = (lon - lonmin) / 5 * (decSE - decSW) + decSW;
	decmax = (lon - lonmin) / 5 * (decNE - decNW) + decNW;
	return (lat - latmin) / 5 * (decmax - decmin) + decmin;
}

/* ------------------- NFZ ------------------- */
static float CalLonDis(double lon1, double lon2)
{
    float dis = fabs(lon1 - lon2);
    if(dis > 180) dis = 360 - dis;
    return dis;
}

static uint8_t FindApIndexByLat(double lat, uint16_t IndexBuf[])
{
    uint8_t Number = 0;

    for(uint16_t Index = 0; Index < AIRPORT_NUMBER; Index ++)
	{
        if(fabs(lat - AirPortPos[Index].X) < 0.13489816)
		{
			if(Number < INDEX_BUF_SIZE)
				IndexBuf[Number] = Index;
			else
			{
				Number = 0xFF;
				break;
			}
			Number ++;
		}
	}

    return Number;
}

/* !< Variables ------------------------------ */
static uint8_t NFZ_Info = 0;

static uint8_t NFZ_SearchFlag = 0;
static uint8_t APNumIn30KmLat = 0;
static uint8_t NearAirPortNum = 0;
static uint16_t AirPortIndex[INDEX_BUF_SIZE] = {0};

static uint8_t In2_4NFZCnt = 0;
static uint8_t In6_5NFZCnt = 0;
uint8_t In6_5VextIndex[MAX_NEAR_AIRPORT] = {0};
uint8_t In2_4VectIndex[MAX_NEAR_AIRPORT] = {0};
_2AxisFloat NFZ_NearCoord[MAX_NEAR_AIRPORT] = {0};
_2AxisFloat NFZToDronVect[MAX_NEAR_AIRPORT] = {0};

float NFZDis, NFZDis_x, NFZDis_y;
/* ------------------- NFZ ------------------- */

/* ------------ Electronic fence ------------- */
static uint8_t DropOuteFenceFlag = 0;

static rfGPS_DATA *pCellPhoneGPSInfo;
_2AxisFloat eFenceCenter = {0};
_2AxisFloat CellPhoneCoord = {0};
_2AxisFloat FenceToDroneVect = {0};
float cellPhoneToOrigin, cellPhoneToDrone = 0;
/* ------------ Electronic fence ------------- */

uint8_t GPS_Can_Used = 0;
uint8_t GPS_ResetFlag = 0;
uint8_t GPSOriginSetFlag = 0;
float GPS_SpeedQuality = 500;
float GPS_PositionQuality = 3000;
uint16_t GPS_numSV_LostCount = 0;
uint16_t GPSPositionLockcount = 0;

unsigned char magErrorFlag = 0;

float PosEst_x = 0, PosEst_y = 0;
float velRateCorr_x = 0, velRateCorr_y = 0;

static _2AxisFloat GPSHome = {0};
static _2AxisFloat GPSPosition = {0};
float GPSposition_dis_cm = 0, DistanceToHome = 0;

void ComputeDisToHome(void)
{
	float dx = GPSPosition.X - GPSHome.X;
	float dy = GPSPosition.Y - GPSHome.Y;
	DistanceToHome = sqrtf(dx * dx + dy * dy);
}

void PosEst_task(void)
{
    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    GPS_DATA curGpsData = *gpsData;
    unsigned char curFlyEnable = flyEnable;
    unsigned char curGpsUpdate = gps_update_1time;

	pCellPhoneGPSInfo = get_rf_GPS();

    OS_EXIT_CRITICAL();

    static uint16_t GPSLostCount = 0;

    if(curGpsUpdate == 1)
    {
        GPS_PositionQuality = curGpsData.hAcc * 0.2f + GPS_PositionQuality * 0.8f;
        GPS_SpeedQuality = curGpsData.sAcc * 0.2f + GPS_SpeedQuality * 0.8f;
    }

    if(GPS_ReadyFlag == 0)
    {
		DistanceToHome = 0;
        if(curGpsUpdate == 1)
        {
            if(curGpsData.numSV >= 10)//��������1:>10��
				GPS_numSV_LostCount = 0;
            else
            {
				if(GPS_numSV_LostCount < 20)
					GPS_numSV_LostCount ++;
				else
                {
                    GPS_PositionQuality = 3000;
                    GPS_SpeedQuality = 500 ;
                }
            }
        }
        if(GPS_PositionQuality < 180 && GPS_SpeedQuality < 70)//׼������2:PosAcc < 180 && VelAcc < 70
        {
            if(GPSPositionLockcount <= 100)
                GPSPositionLockcount ++;
            else if(GPS_numSV_LostCount == 0)
            {
				GPS_ReadyFlag = 1;
				GPSLostCount = 0;
				GPSPositionLockcount = 0;
				SetToneCmd(GPSReady);
			}
        }
        else
        {
			GPSPositionLockcount = 0;
        }
    }
    else//GPS Is Ready
    {
		if(curFlyEnable == 1)//���֮ǰ
		{
			if(GPS_SpeedQuality < 18)
				step_change(&VelNE_NOISE, 6, 0.05f, 0.05f);
			else if(GPS_SpeedQuality < 36)
				step_change(&VelNE_NOISE, 10, 0.05f, 0.05f);
			else if(GPS_SpeedQuality < 50)
				step_change(&VelNE_NOISE, 16, 0.05f, 0.05f);
			else
				step_change(&VelNE_NOISE, 50, 0.25f, 0.25f);

			if(GPS_PositionQuality < 60)
				step_change(&PosNE_NOISE, 30, 0.08f, 0.08f);
			else if(GPS_PositionQuality < 80)
				step_change(&PosNE_NOISE, 40, 0.08f, 0.08f);
			else if(GPS_PositionQuality < 110)
				step_change(&PosNE_NOISE, 50, 0.09f, 0.09f);
			else
				step_change(&PosNE_NOISE, 100, 0.3f, 0.3f);

			step_change(&Acc_NOISE, 0.15f, 0.38f, 0.38f);
		}
		else
		{
			VelNE_NOISE = 2.0f;
			PosNE_NOISE = 8.0f;
			Acc_NOISE = 20.0f;
			if(GPS_Can_Used == 0) GPS_Can_Used = 1;				
		}

        if(magErrorFlag == 0)//�����ƫ��
        {
			MagDecline = get_declination(curGpsData.lat, curGpsData.lon);
            magErrorFlag = 1;
        }

        if(GPSOriginSetFlag == 0)
        {
            set_origin_point(curGpsData.lon, curGpsData.lat);//GPS��һ�ξ�����������ԭ��
            GPSOriginSetFlag = 1;
        }

		if(curGpsUpdate == 1)
            get_xy_distance(curGpsData.lon, curGpsData.lat, &GPSPosition.X, &GPSPosition.Y, &GPSposition_dis_cm);

/* ------------------- NFZ ------------------- */
		if(NFZ_SearchFlag == 1)
		{
			if((NFZ_Info & NFZ_NUMBE_ERROR) == 0)
			{
				NFZ_Info &= 0xFC;
				In2_4NFZCnt = In6_5NFZCnt = 0;
				for(uint8_t i = 0; i < NearAirPortNum; i ++)
				{
					NFZToDronVect[i].X = GPSPosition.X - NFZ_NearCoord[i].X;//Vector:NFZ center -> Drone postion
					NFZToDronVect[i].Y = GPSPosition.Y - NFZ_NearCoord[i].Y;
					NFZDis = sqrtf(SQUARE(GPSPosition.X - NFZ_NearCoord[i].X) + SQUARE(GPSPosition.Y - NFZ_NearCoord[i].Y));//distance to NFZ Center.
// <==>				get_xy(curGpsData.lon, curGpsData.lat, AirPortPos[AirPortIndex[i]].Y, AirPortPos[AirPortIndex[i]].X, &NFZDis_x, &NFZDis_y, &NFZDis);
					if(NFZDis / 100000 < 2.4f)//2.4km
					{
						NFZ_Info |= NFZ_LEVEL_BIT_1;
						NFZ_Info |= NFZ_LEVEL_BIT_2;
						In2_4VectIndex[In2_4NFZCnt] = i;
						In2_4NFZCnt ++;
					}
					else if(NFZDis / 100000 < 6.5f)//6.5km
					{
						NFZ_Info |= NFZ_LEVEL_BIT_1;
						In6_5VextIndex[In6_5NFZCnt] = i;
						In6_5NFZCnt ++;
					}
				}
			}
		}
		else if(NFZ_SearchFlag == 0)
		{
			NFZ_Info = 0;
			NearAirPortNum = 0;
			APNumIn30KmLat = FindApIndexByLat(curGpsData.lat, AirPortIndex);//(max = 10)
			if(APNumIn30KmLat <= INDEX_BUF_SIZE)
			{
				for(uint8_t i = 0; i < APNumIn30KmLat; i ++)
				{
					if(CalLonDis(curGpsData.lon, AirPortPos[AirPortIndex[i]].Y) < 2.0f)
					{
						get_xy(curGpsData.lon, curGpsData.lat, AirPortPos[AirPortIndex[i]].Y, AirPortPos[AirPortIndex[i]].X, &NFZDis_x, &NFZDis_y, &NFZDis);
// <==>					get_xy_distance(AirPortPos[AirPortIndex[i]].Y, AirPortPos[AirPortIndex[i]].X, &NFZDis_x, &NFZDis_y, &NFZDis);
						if(NFZDis / 100000 < 15.0f)
						{
							AirPortIndex[NearAirPortNum] = AirPortIndex[i];
							if(NearAirPortNum < MAX_NEAR_AIRPORT)
							{
								NFZ_NearCoord[NearAirPortNum].X = NFZDis_x;
								NFZ_NearCoord[NearAirPortNum].Y = NFZDis_y;
// <==>							get_xy_distance(AirPortPos[AirPortIndex[i]].Y, AirPortPos[AirPortIndex[i]].X, &NFZ_NearCoord[NearAirPortNum].X, &NFZ_NearCoord[NearAirPortNum].Y, NULL);
							}
							NearAirPortNum ++;
						}
					}
				}
			}
			if(NearAirPortNum > MAX_NEAR_AIRPORT || APNumIn30KmLat > INDEX_BUF_SIZE)
				NFZ_Info |= NFZ_NUMBE_ERROR;
			NFZ_Info |= (NearAirPortNum << NFZ_NUMB_OFFSET);
			NFZ_SearchFlag = 1;
		}
/* ------------------- NFZ ------------------- */

		if(flyEnable == 0)//home point & electronic fence center.
		{
			eFenceCenter.X = GPSHome.X = GPSPosition.X;
			eFenceCenter.Y = GPSHome.Y = GPSPosition.Y;
		}

/* ------------ Electronic fence ------------- */
		if(pCellPhoneGPSInfo->accurancy <= 5.0f && pCellPhoneGPSInfo->accurancy > 0.0f)
		{
			get_xy_distance(pCellPhoneGPSInfo->lon, pCellPhoneGPSInfo->lat, &CellPhoneCoord.X, &CellPhoneCoord.Y, &cellPhoneToOrigin);
			eFenceCenter.X = CellPhoneCoord.X;
			eFenceCenter.Y = CellPhoneCoord.Y;
		}
		FenceToDroneVect.X = GPSPosition.X - eFenceCenter.X;
		FenceToDroneVect.Y = GPSPosition.Y - eFenceCenter.Y;
		cellPhoneToDrone = sqrtf(SQUARE(GPSPosition.X - eFenceCenter.X) + SQUARE(GPSPosition.Y - eFenceCenter.Y));
		if(cellPhoneToDrone > GetDroneSysParam()->OutDoorDist * 10.0f)
			DropOuteFenceFlag = 1;
		else
			DropOuteFenceFlag = 0;
/* ------------ Electronic fence ------------- */

        if((curGpsData.numSV >= 8) && (GPS_SpeedQuality <= 100) && (GPS_PositionQuality <= 200))//��ʧ����:����<8 ���� VelAcc>100 ���� PosAcc>200
        {
            NavEKFThread();
            velRateCorr_x = states[0] * 100.0f;
            velRateCorr_y = states[1] * 100.0f;
            PosEst_x = states[3] * 100.0f;
            PosEst_y = states[4] * 100.0f;
			ComputeDisToHome();

			GPSLostCount = 0;
			GPS_ResetFlag = 1;
        }
        else if((RFMode > 1 && RFMode < 9) || (RFMode == 0xF && ReadyAct == ReadyHoldGPS))
        {
			if(GPSLostCount < 100)//1s
				GPSLostCount ++;
			else
			{
				if(GPS_ResetFlag == 1)
				{
					GPS_SpeedQuality = 1000;
					GPS_PositionQuality = 2000;
					GPS_Can_Used = 0;
					GPS_ReadyFlag = 0;
					GPSOriginSetFlag = 0;
					position_param_clear();
					GPS_ResetFlag = 0;
				}
			}
        }
    }/* if(GPS_ReadyFlag == 1) */
}

inline uint8_t GPS_IsReady(void)
{
	return GPS_ReadyFlag;
}

inline float GetMagDecline(void)
{
	return MagDecline;
}

inline _2AxisFloat *GetGPSPoint(void)
{
	return &GPSPosition;
}

inline _2AxisFloat *GetHomePoint(void)
{
	return &GPSHome;
}

inline float GetDisToHome(void)
{
	return DistanceToHome;
}

inline uint8_t GetNumOfNearbyAirport(void)
{
	return NearAirPortNum;
}

inline uint8_t GetNFZSearchFlag(void)
{
	return NFZ_SearchFlag;
}

inline uint8_t GetNFZInfo(void)
{
	return NFZ_Info;
}

inline uint8_t IsEntryNFZ_1(void)// 2.4Km - 6.5Km
{
	return ((NFZ_Info & NFZ_LEVEL_BIT_1) == NFZ_LEVEL_BIT_1);
}

inline uint8_t IsEntryNFZ_2(void)// < 2.4Km
{
	return ((NFZ_Info & NFZ_LEVEL_BIT_2) == NFZ_LEVEL_BIT_2);
}

inline uint8_t NumEntryNFZ(void)// < 2.4Km
{
	return In2_4NFZCnt;
}

inline uint8_t NumNearByNFZ(void)// 2.4Km - 6.5Km
{
	return In6_5NFZCnt;
}

inline uint8_t IsDropOutElecFence(void)
{
	return DropOuteFenceFlag;
}
