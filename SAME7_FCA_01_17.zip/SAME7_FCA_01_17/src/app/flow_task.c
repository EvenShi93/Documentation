#include "flow_task.h"
#include "maths.h"
#include "global_type.h"
#include "rf_task.h"
#include "FlowAlgorithm.h"
#include "height_task.h"
#include "KF_filter.h"


extern FLOAT_RPY curEur;
extern FLOAT_ACC* accUnit;
extern FLOAT_XYZ accLowPass;
extern float accZOffset;

uint8_t FlowVelEstStart = 0, FlowValUpdate = 0;

float BF_VelErr_Flow_x = 0.0f, BF_VelErr_Flow_y = 0.0f;
float BF_AccCorrection_x = 0.0f, BF_AccCorrection_y = 0.0f;
float BF_AccCorrection_x_I = 0.0f, BF_AccCorrection_y_I = 0.0f;
float BF_VelCorrection_x = 0.0f, BF_VelCorrection_y = 0.0f;
float BF_AccCorrect_Flow_x = 0.0f, BF_AccCorrect_Flow_y = 0.0f;
float BF_VelCorrect_Flow_x = 0.0f, BF_VelCorrect_Flow_y = 0.0f;

float Time_const_Flow = 0;

float Task_T = 0.005f;
FLOAT_XYZ FlowaccBF_LPF = {0};
FLOAT_XYZ FlowaccBF_raw = {0};
uint32_t flow_Dt = 0, Last_Dt = 0;

float GyroT = 0;
float FlowT = 0;

uint8_t X_needBrake=0,Y_needBrake=0;
float  Xacc_diff=0,Yacc_diff=0;
extern unsigned char flyEnable;

FLOAT_RPY LastfExpEur = {0};
extern FLOAT_RPY expEurRate;

extern float EstAlt,SonicOffsetAlt;
float user_Vel1=0;
float user_Vel=0;
float FlowFilter = 0;

FlowMovDef* FlowMovInfo;

float flow_pos_x;
float flow_pos_y;

#define Flow_SAVE_LEN 10
float FlowVelx_SAVE[Flow_SAVE_LEN] = {0}, FlowVely_SAVE[Flow_SAVE_LEN] = {0};
uint8_t Flow_SAVECnt = 0;

 PID FlowPID_X, FlowPID_Y;
PID FlowAcc_X, FlowAcc_Y;

ADRC_str Flow_velTDx,Flow_velTDy;
ADRC_str td_x,td_y;
extern float _6staEKF_states[6];
void FlowComp_5msTask(void)
{
	static uint16_t flowcount = 0;
  FlowMovInfo = Get_Flow_Move_Data();
	
	FLOAT_RPY curEurTemp ;
	FLOAT_ACC curAccBF = *accUnit;
	FLOAT_GYRO *curGyroUnit = get_gyro_unit();

	flow_Dt= _Get_Micros();

	Task_T=(float)(flow_Dt - Last_Dt) / 1000000.0f ;

	Last_Dt = flow_Dt;

	if ( Task_T > 0.1f ) Task_T = 0.005f;

	if(Get_Flow_Update_Flag() && FlowVelEstStart==0)
	{                                 
		FlowVelEstStart = 1;
		FlowValUpdate = 1;
	}
	else FlowValUpdate = 0;

	curEurTemp.Pitch = curEur.Pitch * DEG_TO_RAD;
	curEurTemp.Rool = curEur.Rool * DEG_TO_RAD;
	curEurTemp.Yaw = 0;

	rotateV((FLOAT_XYZ *)&curAccBF, &curEurTemp);                                        

//	FlowaccBF_LPF.X = curAccBF.accX*0.2f + FlowaccBF_LPF.X*0.8f;
//	FlowaccBF_LPF.Y = curAccBF.accY*0.2f + FlowaccBF_LPF.Y*0.8f;
//	FlowaccBF_raw.X = curAccBF.accX*0.1f + FlowaccBF_LPF.X*0.9f;
//	FlowaccBF_raw.Y = curAccBF.accY*0.1f + FlowaccBF_LPF.Y*0.9f;
	
	FlowaccBF_LPF.X= curAccBF.accX;
	FlowaccBF_LPF.Y= curAccBF.accY;
	FlowaccBF_raw.X= curAccBF.accX;
	FlowaccBF_raw.Y= curAccBF.accY;

	if(FlowVelEstStart == 1 && (flyEnable == 0))
	{
		_6staEKF_setNOISE(1.0f,10,1000000,0.1f,0.7f,1.5f);
	}	
	
	
	if(FlowVelEstStart == 1 && (flyEnable == 1||1))
	{
		GyroT = sqrtf(FlowMovInfo->x_gyro * FlowMovInfo->x_gyro + (FlowMovInfo->y_gyro * FlowMovInfo->y_gyro));
    FlowT = sqrtf( (FlowMovInfo->x_Speed) * (FlowMovInfo->x_Speed) + (FlowMovInfo->y_Speed) * (FlowMovInfo->y_Speed) ) ;

		_6staEKF_setNOISE(0.8f,80,1000000,0.1f,0.7f,1.5f);
		_6staEKF_EKFThread(FlowaccBF_LPF.X,FlowaccBF_LPF.Y,0,-(FlowMovInfo->x_Speed)/50.0f,-(FlowMovInfo->y_Speed)/50.0f,0,flow_pos_x,flow_pos_y,0,0.005f);
			
		flow_pos_x+=(-(FlowMovInfo->x_Speed)/100.0f)*0.005f;
		flow_pos_y+=(-(FlowMovInfo->y_Speed)/100.0f)*0.005f;	
		
		if(flowcount < 300) flowcount ++;
		
	}
	else
	{
		BF_AccCorrection_x_I = 0;
		BF_AccCorrection_y_I = 0;
		BF_AccCorrect_Flow_x = 0;
		BF_AccCorrect_Flow_y = 0;
		BF_VelCorrect_Flow_x = 0;
		BF_VelCorrect_Flow_y = 0;
		flow_pos_x=0;
		flow_pos_y=0;
	}
}



void FlowPID_Init(void)
{
	
	FlowPID_X.kp = 2.5f;
	FlowPID_X.ki = 2.0f;
	FlowPID_X.kd = 0.0f;
	FlowPID_X.I_max = 200.0f;
	FlowPID_X.Dt = 0.005f;
	
	FlowAcc_X.kp = 0.10f;
	FlowAcc_X.ki = 0.02f;
	FlowAcc_X.kd = 0.0f;        
	FlowAcc_X.I_max = 10.0f;
	FlowAcc_X.Dt = 0.005f;
	
	FlowAcc_Y.kp= FlowAcc_X.kp;
  FlowAcc_Y.ki= FlowAcc_X.ki;
	FlowAcc_Y.kd= FlowAcc_X.kd;
	FlowAcc_Y.Dt= FlowAcc_X.Dt;
	FlowAcc_Y.I_max= FlowAcc_X.I_max;
	
	
	FlowPID_Y.kp = FlowPID_X.kp;
	FlowPID_Y.ki = FlowPID_X.ki;
	FlowPID_Y.kd = FlowPID_X.kd;
	FlowPID_Y.I_max = FlowPID_X.I_max;
	FlowPID_Y.Dt = FlowPID_X.Dt;
	
	Flow_velTDy.delta=Flow_velTDx.delta=5000;
	Flow_velTDy.dt=Flow_velTDx.dt=0.01;
	Flow_velTDy.h0=Flow_velTDx.h0=0.01;
	
	td_y.delta=td_x.delta=800;
	td_y.dt=td_x.dt=0.01;
	td_y.h0=td_x.h0=0.01;
	
}

float GetDesirAcc(float DesirVelErr, float BF_Acc_FF, float dt)
{
	return (DesirVelErr/dt - BF_Acc_FF);
}

#define G 980 /* 980cm/s^2 */

float Flow_ExpAngPit = 0.0f, Flow_ExpAngRol = 0.0f;
extern unsigned char flyEnable ;
extern unsigned char RFMode;
extern FLOAT_RPY expEur;
float velSqrt = 0;

float Flow_OffsetAngPit, Flow_OffsetAngRol = 0;
float Flow_ACCOFFSET_X=0, Flow_ACCOFFSET_Y = 0;


float RCAccFF_X = 0.0f, RCAccFF_Y = 0.0f;

extern FLOAT_RPY expEur;

float XSpd_LPF=0,YSpd_LPF=0;

FLOAT_RPY BrakeEur={0};

float  XBrakeForce=0;
float  YBrakeForce=0;

unsigned char FlowAngOffCorrected = 0;
unsigned char AngOffNeedCorrect = 0;
extern ModeReadyAct ReadyAct;
extern float  Debug_Param[15];
float accLFP=0.1;
float FLOWSPEED=1.8;

uint16_t I_reduce=0;

float flow_exp_pos_x,flow_exp_pos_y;

void FlowHold_Task(void)
{
	static uint8_t FlowInit = 0;  
	unsigned char curRFMode = RFMode;
	static FLOAT_RPY curExpEur = {0};
  static float KP_BASE=4;
	if(FlowInit == 0)
	{
		FlowPID_Init();
		FlowInit = 1;
	}
	if((curRFMode == RFMODE_HEIGHT || (curRFMode == RFMODE_READY && ReadyAct == ReadyHoldFlow)) && FlowVelEstStart == 1 && flyEnable == 1)//定高模式下使用光流
	{
		//速度给定
		curExpEur.Rool=expEur.Rool; 
		curExpEur.Pitch=expEur.Pitch;	
		
		ADRC_td(curExpEur.Pitch * FLOWSPEED,&td_x);
		ADRC_td(-curExpEur.Rool * FLOWSPEED,&td_y);

		user_Vel=  sqrtf((td_x.r2*td_x.r2)+(td_y
		.r2*td_y.r2));
		user_Vel1 =  sqrtf((td_x.r1*td_x.r1)+(td_y.r1*td_y.r1));

		ADRC_td(td_x.r1 - BF_VelCorrect_Flow_x,&Flow_velTDx);
		ADRC_td(td_y.r1 - BF_VelCorrect_Flow_y,&Flow_velTDy);
		
    //变增益
		if(AutoTakeOff_Sta!=SUCCEED) 
		{	
		  step_change(&KP_BASE, 4, 0.04, 0.04);
			step_change(&KP_BASE, 4, 0.04, 0.04);
		}	
		else
		{	
		  step_change(&KP_BASE, 2.5, 0.04, 0.04);
			step_change(&KP_BASE, 2.5, 0.04, 0.04);
      
			FlowPID_X.kp= KP_BASE+ 2.0f*(1-PID_sech((td_x.r1-_6staEKF_states[0]*100),0.01));
      FlowPID_Y.kp= KP_BASE+ 2.0f*(1-PID_sech((td_y.r1-_6staEKF_states[1]*100),0.01));
			
			FlowPID_X.ki= 1.0f + 2.0f*(PID_sech((td_x.r1-_6staEKF_states[0]*100),0.01));
			FlowPID_Y.ki= 1.0f + 2.0f*(PID_sech((td_y.r1-_6staEKF_states[1]*100),0.01));		
		}
		
		if(user_Vel>0.1f || user_Vel1>1.0f||I_reduce>0)
		{
			if(I_reduce>0)I_reduce--;
		}		
		if(user_Vel>0.1f) I_reduce=200;
		
		//速度给定,做速度PID
		pid_loop_TDD(&FlowPID_X, td_x.r1,Flow_velTDx.r2, _6staEKF_states[0]*100);  //速度误差->加速度需求
		pid_loop_TDD(&FlowPID_Y, td_y.r1,Flow_velTDy.r2, _6staEKF_states[1]*100);

		static float ACCdesir_X=0,ACCdesir_Y=0; 
		static float ACCdesirX_last=0,ACCdesirY_last=0; 

		ACCdesir_X =FlowPID_X.Output;
		ACCdesir_Y =FlowPID_Y.Output;

		Xacc_diff= ACCdesir_X- ACCdesirX_last;
		Yacc_diff= ACCdesir_Y- ACCdesirY_last;
		
		ACCdesirX_last=ACCdesir_X;
		ACCdesirY_last=ACCdesir_Y;
		
    //加速度内环pid
		pid_loop_TDD(&FlowAcc_X,ACCdesir_X,0, (FlowaccBF_raw.X*100));
		pid_loop_TDD(&FlowAcc_Y,ACCdesir_Y,0, (FlowaccBF_raw.Y*100));

		//加速度执行->期望角度
		float AngPit = constrain_float( atanf(FlowPID_X.Output / G) * RAD_TO_DEG, -10.0f, 10.0f);//加速度->角度
		float AngRol = constrain_float(-atanf(FlowPID_Y.Output / G) * RAD_TO_DEG, -10.0f, 10.0f);
    
		Flow_ExpAngPit=AngPit + Flow_OffsetAngPit;
		Flow_ExpAngRol=AngRol + Flow_OffsetAngRol;
		
//-------------------------------------------------------------------------------		

			if(user_Vel1<1.0f && (fabs(curExpEur.Pitch) + fabs(curExpEur.Rool)) <= 6.0f &&  GyroT<10 && FlowT<20 && AutoTakeOff_Sta == SUCCEED)
			{
				if(FlowAngOffCorrected<50)FlowAngOffCorrected++;
				
				if(FlowAngOffCorrected==50)
				{
					Flow_OffsetAngPit = Flow_OffsetAngPit * 0.99f + AngPit * 0.01f;
					Flow_OffsetAngRol = Flow_OffsetAngRol * 0.99f + AngRol * 0.01f;
					
					Flow_OffsetAngPit=constrain_float(Flow_OffsetAngPit,-2,2);
				  Flow_OffsetAngRol=constrain_float(Flow_OffsetAngRol,-2,2);
					FlowAngOffCorrected = 1;
				}			
			} else 
			{
			   FlowAngOffCorrected=0;
				 Flow_OffsetAngPit*=0.999f;
				 Flow_OffsetAngRol*=0.999f;
	    }
	}
	else
	{
		FlowPID_X.I_sum = 0;
		FlowPID_Y.I_sum = 0;	
		FlowAcc_X.I_sum=0;
		FlowAcc_Y.I_sum=0;
 
	}
}
