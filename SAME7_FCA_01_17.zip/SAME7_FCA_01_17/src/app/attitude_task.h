#ifndef _ATTITUDE_H_
#define _ATTITUDE_H_

#include "middleware.h"
#include "maths.h"

float YawTarVal(void);
void attitude_quat_1ms_task(void);
void attitude_quat_5ms_loop(void);
void attitude_pid_5ms_task(void);
void attitude_pid_1ms_task(void);
void attitude_accEF_1ms_task(void);
void pid_init(void);

FLOAT_RPY *GetCurEuler(void);

#endif 
