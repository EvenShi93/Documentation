#include "IMU_CaliTask.h"

#if USE_EEPROM_DATA

Vref_DataPage EEPROM_Cal_Data;
HeadPage BackupHeader;

float LastTemp = 0.0f;
extern float IMU_temperature;

extern float AccM[7];
short gyrOffSum[3] = {0};
short gyroTempOff[3] = {0};
short acceTempOff[3] = {0};

unsigned char IMU_TempStableFlag = 0;
uint8_t LowTempCnt = 0, TempReadyCnt = 0, Index = 0;
uint8_t HeaderErrNoticeFlag = 0;
uint8_t IMUTempCaliInit = 0, DataCheckInit = 0;
static uint8_t SysParam_Sta = 0;

void UpdateGyroOffset(float Temperature);

void IMUCaliTask(void)
{
	float curTemp = (float)((int)(IMU_temperature * 2)) / 2;

	if(DataCheckInit == 0)
	{
		DataCheckInit = 1;
		SysParam_Sta = GetSysParam_Sta();
		if((SysParam_Sta & EEPROM_ELPDAT_ERR) == 0 && (SysParam_Sta & SYSTEM_PARAMT_OK) != 0)
		{
			for(uint8_t i = 0; i < 7; i ++)
				AccM[i] = EEPROM_Cal_Data.members.accCalData.accCalM[i];
		}
	}
	if(SysParam_Sta & EEPROM_HEADER_ERR)
	{
		if((GetPowerStat() == POWER_ON))
			SetToneCmd(Default);
		return;
	}
	else if(SysParam_Sta & EEPROM_ELPDAT_ERR)
	{
		if((GetPowerStat() == POWER_ON))
			SetToneCmd(AccCalDataErr);
		return;
	}

	if((SysParam_Sta & EEPROM_HEAD_1_ERR || SysParam_Sta & EEPROM_HEAD_2_ERR) && HeaderErrNoticeFlag == 0)//有一个数据头出错,提示一次
	{
		HeaderErrNoticeFlag = 1;
		SetToneCmd(User_1);//三声报警提示
	}

	if(curTemp < 30.0f)
		OpenHeater();
	else
		CloseHeater();

	if(curTemp < 0.0f)
	{
		TempReadyCnt = 0;
		if(LowTempCnt <= 10)//2s
			LowTempCnt ++;
		else
		{
			IMU_TempStableFlag = 0;
		}
	}
	else if((curTemp * 100) <= EEPROM_Cal_Data.members.Vrefhead.members.StarPoint + 4000)
	{
		LowTempCnt = 0;
		if(TempReadyCnt <= 10)//2s
			TempReadyCnt ++;
		else
		{
			if(IMUTempCaliInit == 0)
			{
				IMUTempCaliInit = 1;
				UpdateGyroOffset(curTemp);
				LastTemp = curTemp;

				if(EEPROM_Cal_Data.members.GyrErrInfo.DataIndex > 10 || \
					EEPROM_Cal_Data.members.GyrErrInfo.DataNumb > 10 || \
					EEPROM_Cal_Data.members.GyrErrInfo.DataNumb == 0)
				{
					EEPROM_Cal_Data.members.GyrErrInfo.DataNumb = 0;
					EEPROM_Cal_Data.members.GyrErrInfo.DataIndex = 10;
//					gyroOffset[0] = gyroOffset[1] = gyroOffset[2] = 0;//flush
				}
				else
				{
					gyrOffSum[0] = gyrOffSum[1] = gyrOffSum[2] = 0;
					for(Index = 0; Index < EEPROM_Cal_Data.members.GyrErrInfo.DataNumb; Index ++)
					{
						gyrOffSum[0] += EEPROM_Cal_Data.members.GyrErrVal[Index].GryPecX;
						gyrOffSum[1] += EEPROM_Cal_Data.members.GyrErrVal[Index].GryPecY;
						gyrOffSum[2] += EEPROM_Cal_Data.members.GyrErrVal[Index].GryPecZ;
					}
					float *gyroOffset = GetGyrPeaceOff();
					/* 存储时丢失了精度,下面的运算结果会有小量的差异 */
					gyroOffset[0] = (float)gyrOffSum[0] / EEPROM_Cal_Data.members.GyrErrInfo.DataNumb;
					gyroOffset[1] = (float)gyrOffSum[1] / EEPROM_Cal_Data.members.GyrErrInfo.DataNumb;
					gyroOffset[2] = (float)gyrOffSum[2] / EEPROM_Cal_Data.members.GyrErrInfo.DataNumb;
				}
			}
			else
			{
				IMU_TempStableFlag = 1;
				if(LastTemp != curTemp)
				{
					UpdateGyroOffset(curTemp);
					LastTemp = curTemp;
				}
			}
		}
	}//过热?
	else
	{
		IMU_TempStableFlag = 0;
	}
}

void UpdateGyroOffset(float Temperature)
{
    if(((Temperature * 100) >= EEPROM_Cal_Data.members.Vrefhead.members.StarPoint) && ((Temperature * 100) < EEPROM_Cal_Data.members.Vrefhead.members.StarPoint + 3000))
    {
        uint8_t Index = (uint8_t)((Temperature * 100 - EEPROM_Cal_Data.members.Vrefhead.members.StarPoint) / 50);
        gyroTempOff[0] = ((int16_t *)(&EEPROM_Cal_Data.members.CalData[Index / 2].members.accOffset_1[0]))[(Index % 2) * 6 + 3] + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[0];
        gyroTempOff[1] = ((int16_t *)(&EEPROM_Cal_Data.members.CalData[Index / 2].members.accOffset_1[0]))[(Index % 2) * 6 + 4] + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[1];
        gyroTempOff[2] = ((int16_t *)(&EEPROM_Cal_Data.members.CalData[Index / 2].members.accOffset_1[0]))[(Index % 2) * 6 + 5] + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[2];

        acceTempOff[0] = ((int16_t *)(&EEPROM_Cal_Data.members.CalData[Index / 2].members.accOffset_1[0]))[(Index % 2) * 6 + 0];
        acceTempOff[1] = ((int16_t *)(&EEPROM_Cal_Data.members.CalData[Index / 2].members.accOffset_1[0]))[(Index % 2) * 6 + 1];
        acceTempOff[2] = ((int16_t *)(&EEPROM_Cal_Data.members.CalData[Index / 2].members.accOffset_1[0]))[(Index % 2) * 6 + 2];
    }
    else if((Temperature * 100) < EEPROM_Cal_Data.members.Vrefhead.members.StarPoint)
    {
        float gstep0 = (EEPROM_Cal_Data.members.CalData[5].members.gryOffset_1[0] - \
                        EEPROM_Cal_Data.members.CalData[0].members.gryOffset_1[0]) / 5.0f;
        float gstep1 = (EEPROM_Cal_Data.members.CalData[5].members.gryOffset_1[1] - \
                        EEPROM_Cal_Data.members.CalData[0].members.gryOffset_1[1]) / 5.0f;
        float gstep2 = (EEPROM_Cal_Data.members.CalData[5].members.gryOffset_1[2] - \
                        EEPROM_Cal_Data.members.CalData[0].members.gryOffset_1[2]) / 5.0f;//step per deg.

        float astep0 = (EEPROM_Cal_Data.members.CalData[5].members.accOffset_1[0] - \
                        EEPROM_Cal_Data.members.CalData[0].members.accOffset_1[0]) / 5.0f;
        float astep1 = (EEPROM_Cal_Data.members.CalData[5].members.accOffset_1[1] - \
                        EEPROM_Cal_Data.members.CalData[0].members.accOffset_1[1]) / 5.0f;
        float astep2 = (EEPROM_Cal_Data.members.CalData[5].members.accOffset_1[2] - \
                        EEPROM_Cal_Data.members.CalData[0].members.accOffset_1[2]) / 5.0f;//step per deg.

        float DeltaTemp = (EEPROM_Cal_Data.members.Vrefhead.members.StarPoint - Temperature * 100.0f) / 100.0f;

        gyroTempOff[0] = (short)((float)EEPROM_Cal_Data.members.CalData[0].members.gryOffset_1[0] - (gstep0 * DeltaTemp)) + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[0];
        gyroTempOff[1] = (short)((float)EEPROM_Cal_Data.members.CalData[0].members.gryOffset_1[1] - (gstep1 * DeltaTemp)) + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[1];
        gyroTempOff[2] = (short)((float)EEPROM_Cal_Data.members.CalData[0].members.gryOffset_1[2] - (gstep2 * DeltaTemp)) + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[2];

        acceTempOff[0] = (short)((float)EEPROM_Cal_Data.members.CalData[0].members.accOffset_1[0] - (astep0 * DeltaTemp));
        acceTempOff[1] = (short)((float)EEPROM_Cal_Data.members.CalData[0].members.accOffset_1[1] - (astep1 * DeltaTemp));
        acceTempOff[2] = (short)((float)EEPROM_Cal_Data.members.CalData[0].members.accOffset_1[2] - (astep2 * DeltaTemp));
    }
    else if((Temperature * 100) <= EEPROM_Cal_Data.members.Vrefhead.members.StarPoint + 4000)
    {
        float gstep0 = (EEPROM_Cal_Data.members.CalData[29].members.gryOffset_2[0] - \
                        EEPROM_Cal_Data.members.CalData[24].members.gryOffset_2[0]) / 5.0f;
        float gstep1 = (EEPROM_Cal_Data.members.CalData[29].members.gryOffset_2[1] - \
                        EEPROM_Cal_Data.members.CalData[24].members.gryOffset_2[1]) / 5.0f;
        float gstep2 = (EEPROM_Cal_Data.members.CalData[29].members.gryOffset_2[2] - \
                        EEPROM_Cal_Data.members.CalData[24].members.gryOffset_2[2]) / 5.0f;//step per deg.

        float astep0 = (EEPROM_Cal_Data.members.CalData[29].members.accOffset_2[0] - \
                        EEPROM_Cal_Data.members.CalData[24].members.accOffset_2[0]) / 5.0f;
        float astep1 = (EEPROM_Cal_Data.members.CalData[29].members.accOffset_2[1] - \
                        EEPROM_Cal_Data.members.CalData[24].members.accOffset_2[1]) / 5.0f;
        float astep2 = (EEPROM_Cal_Data.members.CalData[29].members.accOffset_2[2] - \
                        EEPROM_Cal_Data.members.CalData[24].members.accOffset_2[2]) / 5.0f;//step per deg.

        float DeltaTemp = (Temperature * 100.0f - EEPROM_Cal_Data.members.Vrefhead.members.StarPoint - 3000.0f) / 100.0f;

        gyroTempOff[0] = (short)((float)EEPROM_Cal_Data.members.CalData[29].members.gryOffset_2[0] + (gstep0 * DeltaTemp)) + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[0];
        gyroTempOff[1] = (short)((float)EEPROM_Cal_Data.members.CalData[29].members.gryOffset_2[1] + (gstep1 * DeltaTemp)) + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[1];
        gyroTempOff[2] = (short)((float)EEPROM_Cal_Data.members.CalData[29].members.gryOffset_2[2] + (gstep2 * DeltaTemp)) + \
                         EEPROM_Cal_Data.members.Vrefhead.members.gryBase[2];

        acceTempOff[0] = (short)((float)EEPROM_Cal_Data.members.CalData[29].members.accOffset_2[0] + (astep0 * DeltaTemp));
        acceTempOff[1] = (short)((float)EEPROM_Cal_Data.members.CalData[29].members.accOffset_2[1] + (astep1 * DeltaTemp));
        acceTempOff[2] = (short)((float)EEPROM_Cal_Data.members.CalData[29].members.accOffset_2[2] + (astep2 * DeltaTemp));
    }
}

#endif /* USE_EEPROM_DATA */

#define EngineDetectTime 30

FLOAT_GYRO *EngineGyr;
FLOAT_RPY *CurEuler;

uint8_t EngineMagEntryFlag = 0;
uint32_t EngineTimeCnt = 0;

void MagCalCmdDetect(void)//进入地磁校准的工程动作
{
	if(EngineMagEntryFlag == 0 && (_Get_Secnds() < EngineDetectTime))//30s内进入校准
	{
		EngineGyr = get_gyro_unit();
		if(fabs(EngineGyr->gyroY) > 150)
		{
			if(EngineTimeCnt < 200)//2s
				EngineTimeCnt ++;
			else
			{
				StartMagCalibrate();//启动校准
				EngineMagEntryFlag = 1;
				SetToneCmd(Default);//响一声,进入
			}
		}
		else
			EngineTimeCnt = 0;
	}
}

unsigned char doMagCalibrationFlag = 0;
unsigned char magCalibrationFlag = 0;
unsigned char magParamDirty = 0;
static float IntegGyrX = 0, IntegGyrY = 0, IntegGyrZ = 0;

void MagCalGyrIntegTask(void)//用于地磁校准参考的陀螺仪积分任务
{
	if(magCalibrationFlag == 1)//在地磁校准状态下
	{
		IntegGyrX += EngineGyr->gyroX * 0.001f;
		IntegGyrY += EngineGyr->gyroY * 0.001f;
		IntegGyrZ += EngineGyr->gyroZ * 0.001f;
	}
}

///****/
//uint8_t ToneTestCnt = 0, ToneTimeCnt = 0;

////Do  Re  Mi  Fa  So  La  Si -
//uint16_t ToneFreq[3][7] = {
//{262, 294, 330, 349, 392, 440, 494},
//{523, 587, 659, 698, 784, 880, 988},
//{1046, 1175, 1318, 1397, 1568, 1760, 1967}
//};

//uint8_t SKY[117][3] = {
//{2,6,1},{2,7,1},{3,1,2},{2,7,1},{3,1,2},{3,3,2},{2,7,2},{2,3,1},{2,3,1},{2,6,2},{2,5,1},{2,6,2},
//{3,1,2},{2,5,2},{2,3,2},{2,4,2},{2,3,1},{2,4,1},{3,1,2},{2,3,2},{3,1,1},{3,1,1},{3,1,1},{2,7,2},
//{2,4,1},{2,4,1},{2,7,2},{2,7,2},{2,6,1},{2,7,1},{3,1,2},{2,7,1},{3,1,2},{3,3,2},{2,7,2},{2,3,1},
//{2,3,1},{2,6,2},{2,5,1},{2,6,2},{3,1,2},{2,5,2},{2,2,1},{2,3,1},{2,4,2},{3,1,1},{2,7,1},{2,7,1},
//{3,1,1},{3,1,2},{3,2,1},{3,2,1},{3,3,1},{3,1,1},{3,1,2},{3,1,1},{2,7,1},{2,6,1},{2,6,1},{2,7,2},
//{2,5,2},{2,6,2},{3,1,1},{3,2,1},{3,3,2},{3,2,1},{3,3,2},{3,5,2},{3,2,2},{2,5,1},{2,5,1},{3,1,2},
//{2,7,1},{3,1,2},{3,3,2},{3,3,2},{2,6,1},{2,7,1},{3,1,2},{2,7,2},{3,2,1},{3,2,1},{3,1,2},{2,5,1},
//{2,5,2},{3,4,2},{3,3,2},{3,2,2},{3,1,2},{3,3,2},{3,3,2},{3,6,2},{3,5,2},{3,5,2},{3,3,1},{3,2,1},
//{3,1,2},{3,1,1},{3,2,2},{3,1,1},{3,2,1},{3,2,2},{3,5,2},{3,3,2},{3,3,2},{3,6,2},{3,5,2},{3,3,1},
//{3,2,1},{3,1,2},{3,1,1},{3,2,2},{3,1,1},{3,2,1},{3,2,2},{2,7,2},{2,6,2}};

//void PlaySKY(void)
//{
//	if(ToneTestCnt < 117)
//	{
//		if(ToneTimeCnt == 0)
//			Send_ESC_Tone(ToneFreq[SKY[ToneTestCnt][0] - 1][SKY[ToneTestCnt][1] - 1], SKY[ToneTestCnt][2] * 300, 30);
//		ToneTimeCnt ++;
//		if(ToneTimeCnt >= SKY[ToneTestCnt][2] * 3)
//		{
//			ToneTestCnt ++;
//			ToneTimeCnt = 0;
//		}
//	}
//}
///****/

uint8_t MagCalStep = 0, MagSampleStep = 0;
unsigned char MagCal_Sta_succeed = 0;
float LastGyrInteg = 0;
static uint16_t GetData_count = 0;
static uint8_t SampleFlag = 0;
static void mag_calibration(void)
{
	static uint16_t Delaycount = 0;
	OS_ALLOC_SR();

	switch(MagCalStep)
	{
		case 0: //init
//			ToneTestCnt = 0, ToneTimeCnt = 0;

			doMagCalibrationFlag = 1;
			SampleFlag = 0;
			Delaycount = 0;
			LastGyrInteg = 0;
			MagSampleStep = 0;
			GetData_count = 0;
			MagCal_Sta_succeed = 0;
			CurEuler = GetCurEuler();
			MagCalStep ++;
		break;
		case 1://进入延时1s
			if(Delaycount < 10) Delaycount ++;
			if(Delaycount >= 10)
			{
				MagCalStep ++;
				Delaycount = 0;
				IntegGyrY = 0;
			}
		break;
		case 2: //采集
			if(GetData_count < SAMPLE_NUMBER)
			{
				if(MagSampleStep == 0)//step 1
				{
					if(fabs(IntegGyrY) > fabs(LastGyrInteg) && fabs(EngineGyr->gyroY) > 20 && fabs(EngineGyr->gyroY) < 100)//积分一直在往同一个方向增长并且角速度比较大
					{
						OS_ENTER_CRITICAL();
						SampleFlag = 1;
						matrixQ[GetData_count][0] = get_magRaw()->magX;
						matrixQ[GetData_count][1] = get_magRaw()->magY;
						matrixQ[GetData_count][2] = get_magRaw()->magZ;
						OS_EXIT_CRITICAL();
						LastGyrInteg = IntegGyrY;
						GetData_count ++;

						if(GetData_count == 100)
						{
							MagSampleStep ++;
							LastGyrInteg = 0;
							IntegGyrX = 0;
							SetToneCmd(EEPROMErr);//1
						}
					}
					else SampleFlag = 0;
				}
				else if(MagSampleStep == 1)//step 2
				{
					if(fabs(IntegGyrX) > fabs(LastGyrInteg) && fabs(EngineGyr->gyroX) > 20 && fabs(EngineGyr->gyroX) < 100)//积分一直在往同一个方向增长并且角速度比较大
					{
						OS_ENTER_CRITICAL();
						SampleFlag = 1;
						matrixQ[GetData_count][0] = get_magRaw()->magX;
						matrixQ[GetData_count][1] = get_magRaw()->magY;
						matrixQ[GetData_count][2] = get_magRaw()->magZ;
						OS_EXIT_CRITICAL();
						LastGyrInteg = IntegGyrX;
						GetData_count ++;

						if(GetData_count == 200)
						{
							MagSampleStep ++;
							LastGyrInteg = 0;
							IntegGyrZ = 0;
							SetToneCmd(MPU6500Err);//2
						}
					}
					else SampleFlag = 0;
				}
				else if(MagSampleStep == 2)//step 3
				{
					if(fabs(IntegGyrZ) > fabs(LastGyrInteg) && fabs(EngineGyr->gyroZ) > 20 && fabs(EngineGyr->gyroZ) < 100 \
						&& fabs(CurEuler->Pitch) < 45 && fabs(CurEuler->Rool) < 45)//积分一直在往同一个方向增长并且角速度比较大
					{
						OS_ENTER_CRITICAL();
						SampleFlag = 1;
						matrixQ[GetData_count][0] = get_magRaw()->magX;
						matrixQ[GetData_count][1] = get_magRaw()->magY;
						matrixQ[GetData_count][2] = get_magRaw()->magZ;
						OS_EXIT_CRITICAL();
						LastGyrInteg = IntegGyrZ;
						GetData_count ++;

						if(GetData_count == 300)
						{
//							MagSampleStep ++;
							SetToneCmd(IST8307Err);//3
						}
					}
					else SampleFlag = 0;
				}
				else
				{
					SampleFlag = 0;
				}
			}
			else
			{
				MagCalStep = 3;
				SampleFlag = 0;
			}
		break;
		case 3: //计算
			ellipsoid_init();
			ellipsoid_step1();
			ellipsoid_step2();
			ellipsoid_step3(140);
			MagCalStep = 4;
		break;
		case 4: //判断
			if( (fabsf(matrixM[4] - 1.0f) < 0.3f && fabsf(matrixM[5] - 1.0f) < 0.3f && fabsf(matrixM[6] - 1.0f) < 0.3f) && \
				(fabsf(matrixM[0]) < 70 && fabsf(matrixM[1]) < 70 && fabsf(matrixM[2]) < 70))
			{
				SetCalMatrix(matrixM);
				magParamDirty = 1;
				MagCal_Sta_succeed = 1;
				SetToneCmd(MagCalOK);
			}
		    else
			{
				MagCal_Sta_succeed = 0;
			}
		    MagCalStep = 5;
		break;
		case 5://退出延时2s
			if(EngineMagEntryFlag != 1)//如果进入了工程下的校准就不退出了.
			{
				if(Delaycount < 10) Delaycount ++;
				if(Delaycount >= 10) { MagCalStep = 6; Delaycount = 0; }
			}
		break;
		case 6://校准结束,退出
			doMagCalibrationFlag = 0;
			magCalibrationFlag = 0;
			MagCalStep = 0;
		break;
		default:
			doMagCalibrationFlag = 0;
			magCalibrationFlag = 0;
			MagCalStep = 0;
		break;
	}
}

#if defined(CTRL_RF)
extern unsigned char testMode;
extern FLOAT_RPY expEur;
extern float thr;
#endif /* defined(CTRL_RF) */

void mag_calibration_100ms_task(void)
{
#if defined(CTRL_RF)
	if((testMode == 1) &&  (expEur.Yaw > 25) && (thr > 1900)) //向右
	{
		magCalibrationFlag = 1;
	}
#endif /* defined(CTRL_RF) */
     if(magCalibrationFlag == 1)
	 {
		 mag_calibration();
	 }
}

extern unsigned char lowPowerFlag;
void StartMagCalibrate(void)
{
	if(GetLowPowerFlag() == 0 && flyEnable == 0)//电压正常(没有任何电压报警),且不在起飞状态
		magCalibrationFlag = 1;
}

uint8_t MagCalibrateSta(void)
{
	return magCalibrationFlag;
}

inline uint8_t GetSampleStat(void)
{
	return SampleFlag;
}

void GetMagCalSta(uint8_t *Param)
{
	Param[0] = MagSampleStep + 1;
	Param[1] = (GetData_count > 200) ? (GetData_count - 200) : ((GetData_count > 100) ? (GetData_count - 100) : GetData_count);
	if(MagCalStep <= 4)
		Param[2] = 0;
	else if(MagCal_Sta_succeed == 1)
		Param[2] = 1;
	else
		Param[2] = 2;
}
