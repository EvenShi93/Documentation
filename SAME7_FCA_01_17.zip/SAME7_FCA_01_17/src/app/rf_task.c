#include "rf_task.h"

float thr = 0;
REMOTE_DATA rfData;
uint8_t flightMode = 0, UserExpMode = 0;
FLOAT_RPY expEur = {0};

uint8_t rfLinked = 0;
uint8_t testMode = 1;
uint8_t flyEnable = 0;
uint8_t flyStatus = 1;
uint8_t RFMode = RFMODE_9AXIE, LastRFMode = RFMODE_9AXIE;

ModeReadyAct ReadyAct = ReadyHoldFlow;
ModeOrbitAct OrbitAct = OrbitAct_ME;
OrbitCenterType OrbitCenter = AutoCenter;

float expPitch = 0.0f, expRoll = 0.0f;
FLOAT_RPY expEurRate = {0}, LastExpEur = {0};
uint8_t switchButton = SWITCH_BUTTON_OFF;
uint8_t CurStick = 0, LastStick = 0, StickReady = 0;

uint32_t rfLostTimCnt = 0;
uint32_t CutOffTimeCnt = 0;

void rf_5ms_task(void)
{
    float tempPitch, tempRool, tempYaw;//欧拉角

    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    rfData = *get_rf_data();//获取数据

    OS_EXIT_CRITICAL();
    if(rfIsLost() == 0)//未丢信号
    {
		rfLostTimCnt = 0;

        if(rfLinked == 0)
        {
            rfLinked = 1;
			ClrToneCmd(rfLost);
			if(GetPowerStat() == POWER_ON)
				SetToneCmd(rfLink);
        }
		if(rfData.CtrlVar.aThrottle >= 400)
			thr = rfData.CtrlVar.aThrottle;

        tempPitch = -(float)(rfData.CtrlVar.aPitch - RF_MidVal) / 18.0f;
#if defined(CTRL_RF)
        tempRool = -(float)(rfData.CtrlVar.aRoll - RF_MidVal) / 18.0f;
        tempYaw = -(float)(rfData.CtrlVar.aYaw - RF_MidVal) / 17.0f;
#elif defined(CTRL_A9)
        tempRool = (float)(rfData.CtrlVar.aRoll - RF_MidVal) / 18.0f;
        tempYaw = (float)(rfData.CtrlVar.aYaw - RF_MidVal) / 17.0f;
#endif

        tempPitch = constrain_float(tempPitch, -MAX_EUR, MAX_EUR);
        tempRool = constrain_float(tempRool, -MAX_EUR, MAX_EUR);
        tempYaw = constrain_float(tempYaw, -45, 45);

        float targetLen = tempPitch * tempPitch + tempRool * tempRool;

        if(targetLen > MAX_EUR*MAX_EUR)
        {
            tempPitch = MAX_EUR*MAX_EUR*(tempPitch/targetLen);
            tempRool = MAX_EUR*MAX_EUR*(tempRool/targetLen);
        }
		tempPitch = apply_deadband(tempPitch, 0.4f);//加死区
		tempRool = apply_deadband(tempRool, 0.4f);
		tempYaw = apply_deadband(tempYaw, 0.4f);
	}
	else//丢信号,归中
	{
        tempPitch = 0;
        tempRool = 0;
        tempYaw = 0;
        thr = RF_MidVal;
        if(rfLinked == 1)
        {
            rfLinked = 0;
			ClrToneCmd(rfLink);
			if(GetPowerStat() == POWER_ON)
				SetToneCmd(rfLost);
        }
		if(flyEnable == 1)
		{
			if(rfLostTimCnt < 2000)     //10s -> 2000
				rfLostTimCnt ++;
			else //丢信号已经大于10秒
			{
				if(RFMode < RFMODE_POSITION || (RFMode == RFMODE_READY && ReadyAct == ReadyHoldFlow))//按模式自动降落
					EntryAutoLand();
				else if(GPS_IsReady()) //GPS可用,进入返航
				{
					if(rfLostTimCnt < 6000)
						rfLostTimCnt ++;
					else
					{
						if(RFMode != RFMODE_GOHOME)//不在gohome模式下自动切入gohome模式
						{
							RFMode = RFMODE_GOHOME;
							flightMode = 8;
						}
					}
				}
				else  EntryAutoLand(); //GPS不可用,进入降落			
			}
		}
	}

	if(rfIsLost() == 0)
	{
		if(flyEnable == 0 && CutOffTimeCnt < 400)
			CutOffTimeCnt ++;

		if(flyEnable == 1)
			SetGB_Angle(rfData.RemoteD[6], GetCurEuler()->Pitch + GetWatchAng());//, GetWatchAng());
		else
			SetGB_Angle(rfData.RemoteD[6], 0);//, 0);

		uint8_t ModeErrFlag = 0;//模式错误标志位

#if defined(CTRL_RF)
		if(rfData.CtrlVar.aRFMode <= 500)
		{
			RFMode = RFMODE_SELFIE;//RFMODE_POSITION;RFMODE_SMART
			flightMode = 2;
		}
		else if(rfData.CtrlVar.aRFMode <= 1400)
		{
			RFMode = RFMODE_POSITION;//RFMODE_9AXIE;RFMODE_HEIGHT;
			flightMode = 3;
		}
		else
		{
			RFMode = RFMODE_HEIGHT;//RFMODE_9AXIE;
			flightMode = 4;
		}

		if(RFMode == RFMODE_9AXIE)
		{
			expEurRate.Pitch = (expEur.Pitch - LastExpEur.Pitch) / 0.005f;
			expEurRate.Rool = (expEur.Rool - LastExpEur.Rool) / 0.005f;
//			expEurRate.Yaw = (expEur.Yaw - LastExpEur.Yaw) / 0.005f;
			LastExpEur.Pitch = expEur.Pitch;
			LastExpEur.Rool = expEur.Rool;
			LastExpEur.Yaw = expEur.Yaw;
		}
#elif defined(CTRL_A9)
		if(rfData.CtrlVar.aRFMode <= 500 && GPS_Can_Used)//Mode 400 SELFIE,GPS_IsReady()
		{
			RFMode = RFMODE_SELFIE;//RFMODE_POSITION;RFMODE_SMART
			SetYawModify(rfData.RemoteD[9]);//设置YAW修正
			flightMode = 2;
		}
		else if(rfData.CtrlVar.aRFMode <= 1100 && rfData.CtrlVar.aRFMode > 900 && GPS_Can_Used)//Mode 1000 JOURNEY,GPS_IsReady()
		{
			if(rfData.CtrlVar.aRFMode == 950)
			{
				RFMode = RFMODE_SELFIE;
				SetYawModify(rfData.RemoteD[9]);//设置YAW修正
			}
			else if(rfData.CtrlVar.aRFMode == 1050)
			{
				static uint16_t JourneyCmd = 400;
				RFMode = RFMODE_JOURNEY;
				if(JourneyCmd != rfData.RemoteD[8] && rfData.RemoteD[8] == 2000)
				{
					JourneyRunSet(JourneyStart);//起
				}
				else if(JourneyCmd != rfData.RemoteD[8] && rfData.RemoteD[8] == 400)
				{
					JourneyRunSet(JourneyStop);//停
				}
				JourneyCmd = rfData.RemoteD[8];
				JourneySetParam(rfData.RemoteD[7] * 10, (float)rfData.RemoteD[6] * 9.0f / 160.0f - 22.5f);//0 - 90度
			}
			flightMode = 5;
		}
		else if(rfData.CtrlVar.aRFMode <= 1300 && rfData.CtrlVar.aRFMode > 1100 && GPS_Can_Used)//Mode 1200 TRIPOD(outdoor),GPS_IsReady()
		{
			RFMode = RFMODE_POSITION;//RFMODE_POSITION;//RFMODE_9AXIE;RFMODE_SMART
			flightMode = 6;
			SetAppsShowDist(GetDisToHome());
		}
		else if(rfData.CtrlVar.aRFMode <= 700 && rfData.CtrlVar.aRFMode > 500)//Mode 600 READY(choose or exchange)
		{
			RFMode = RFMODE_READY;
			if((GPS_IsReady() == 0) || (GPS_IsReady() == 1 && LastRFMode == RFMODE_HEIGHT))//GPS不可用或者GPS可用,但却是从室内三脚架退出的均使用光流来悬停
				ReadyAct = ReadyHoldFlow;//使用光流悬停
			else if(GPS_IsReady() == 1 && LastRFMode != RFMODE_HEIGHT && LastRFMode != RFMODE_READY)
				ReadyAct = ReadyHoldGPS;//使用GPS悬停
			if((GPS_IsReady() == 0) && ReadyAct == ReadyHoldGPS)//Ready模式下使用GPS悬停时出现GPS丢失,切为光流悬停.
				ReadyAct = ReadyHoldFlow;
//			if(GPS_IsReady() == 1 && LastRFMode == RFMODE_HEIGHT && GPS_Can_Used == 0 && GetAutoLandSta() == 0)//GPS未启用,自动降落以启用GPS
//			{
//				EntryAutoLand();//自动降落
//				LockAutoLand();
//			}
			flightMode = 3;
		}
		else if(rfData.CtrlVar.aRFMode > 1900)//Mode 2000 TRIPOD(indoor)
		{
			RFMode = RFMODE_HEIGHT;//RFMODE_9AXIE;
			flightMode = 10;
		}
		else if(rfData.CtrlVar.aRFMode < 1500 && rfData.CtrlVar.aRFMode >= 1300 && GPS_Can_Used)//Mode 1400 ORBIT,GPS_IsReady()
		{
			RFMode = RFMODE_ORBIT;
			//Step 1: ORBIT WHAT?
			if(rfData.CtrlVar.aRFMode == 1350)//ORBIT ME
			{
				OrbitAct = OrbitAct_ME;
				OrbitCenter = AutoCenter;
				SetYawModify(rfData.RemoteD[9]);//设置YAW修正
			}
			else if(rfData.CtrlVar.aRFMode == 1450)//ORBIT POI
			{
				//Step 2: Action
				if(rfData.RemoteD[8] == 1200)
				{
//					RFMode = RFMODE_SELFIE;
					OrbitAct = OrbitAct_ME;
					OrbitCenter = UserCenter;
					SetYawModify(rfData.RemoteD[9]);//设置YAW修正
				}
				else if(rfData.RemoteD[8] == 2000 || rfData.RemoteD[8] == 400)
				{
//					RFMode = RFMODE_POSITION;
					OrbitAct = OrbitAct_POI;
					if(rfData.RemoteD[8] == 400)//set center point.
					{
						SetSelfieCenter();
						SetAppsShowDist(0);
					}
					else
						SetAppsShowDist(GetDisToCenter());
				}
			}
			flightMode = 7;
		}
		else if(rfData.CtrlVar.aRFMode < 1700 && rfData.CtrlVar.aRFMode >= 1500 && GPS_Can_Used)//Mode 1600 GOHOME,GPS_IsReady()
		{
			RFMode = RFMODE_GOHOME;
			flightMode = 8;
			SetAppsShowDist(GetDisToHome());
		}
		else if(rfData.CtrlVar.aRFMode < 900 && rfData.CtrlVar.aRFMode >= 700 && GPS_Can_Used)//Mode 800 FOLLOWME,GPS_IsReady()
		{
			RFMode = RFMODE_FOLLOWME;
			SetImgFollowData(rfData.RemoteD[5], rfData.RemoteD[11]);
			flightMode = 4;
			SetAppsShowDist(GetDisToHome());
		}
		else//接收到异常异常模式(几乎不可能)后的默认模式,或GPS未就绪却发送了需要GPS就绪才能使用的模式
		{
//			if(GPS_IsReady() == 0)//GPS丢失,所有GPS相关的模式不给设置,使用室内模式
//			{
				ModeErrFlag = 1;//出现模式错误(1,不允许起飞;2,不允许取消降落)
//			if(rfData.CtrlVar.aRFMode > 1300 || rfData.CtrlVar.aRFMode <= 1100)//"非" Mode 1200 PILOT(outdoor) 不允许打舵
			{
				tempPitch = 0;
				tempRool = 0;
				tempYaw = 0;
				thr = RF_MidVal;
			}
			if(rfData.CtrlVar.aRFMode < 1700 && rfData.CtrlVar.aRFMode >= 1500 && GetAutoLandSta() == 0)//Mode 1600 GOHOME, not Landing...
			{
				EntryAutoLand();
				LockAutoLand();
			}
				RFMode = RFMODE_HEIGHT;//RFMODE_9AXIE;
				flightMode = 10;
//			}
		}
#endif
		LastRFMode = RFMode;
/* ----------------------- TAKE OFF ----------------------- */
        if(rfData.RemoteD[10] > 1400) //降落档
        {
			CurStick = 1;
			StickReady = 1 & (testMode == 0 || flyEnable == 1);
        }
        else if(rfData.RemoteD[10] < 1000) //起飞档
        {
            CurStick = 0;
            if(StickReady == 1 && testMode == 1) testMode = 0;
        }
        if((CurStick != LastStick) && (RFMode != RFMODE_9AXIE) && (StickReady == 1))
        {
            if(CurStick == 1 && flyEnable == 1) EntryAutoLand();//降落命令
            else if(ModeErrFlag == 0 && CurStick == 0 && GetMotorErrFlag() == 0 && \
				GetLowPowerFlag() < 2 && get_acc_unit()->accZ > 6.929f && \
			(GetNFZInfo() & NFZ_LEVEL_BIT_2) == 0)//马达正常,电压正常,角度小于45deg,不在禁飞区 -> 允许触发起飞以及取消自动降落
            {
                if(AutoTakeOff_Sta == ONGROUND)
                {
                    ClrAutoLandFlag();//ExitAutoLand();//清自动降落标志位,取消自动降落
					UnLockAutoLand();//解锁自动降落
					if(RFMode != RFMODE_READY && RFMode != RFMODE_9AXIE && CutOffTimeCnt >= 400)//Ready下不允许起飞,切断2s后才能重新起飞
						AutoTakeOff_Sta = TRIGGER;//往上打触发自动起飞
                }
				else if(GetAutoLandSta() == 1 && AutoTakeOff_Sta == SUCCEED)//起飞成功状态下正在自动降落则取消
					ExitAutoLand();
//                else
//                    AutoTakeOff_Sta = FAILED;//异常
            }
        }
        LastStick = CurStick;
		UserExpMode = flightMode;
    }

	step_change(&expPitch, tempPitch, 1.4f, 1.4f);//加斜坡
	step_change(&expRoll, tempRool, 1.4f, 1.4f);

	expEur.Pitch = expPitch * 0.3f + expEur.Pitch * 0.7f;//加低通
	expEur.Rool = expRoll * 0.3f + expEur.Rool * 0.7f;
	expEur.Yaw = tempYaw * 0.3f + expEur.Yaw * 0.7f;

	if(GetMotorErrFlag() != 0 && (GetPowerStat() == POWER_ON))
	{
		if(AutoTakeOff_Sta != ONGROUND)
			EntryAutoLand();
		flyEnable = 0;
		SetToneCmd(EEPROMErr);//1
	}

    static unsigned char trigStep = 0;
    if((rfData.CtrlVar.aThrottle > 400) && (trigStep == 0) && (switchButton == SWITCH_BUTTON_OFF))
    {
        trigStep = 1;
        switchButton = SWITCH_BUTTON_ON;
    }

    if((rfData.CtrlVar.aThrottle < 100 ) && (trigStep == 1) && (switchButton == SWITCH_BUTTON_ON))
    {
        switchButton = SWITCH_BUTTON_OFF;
        trigStep = 0;
    }
}

extern unsigned char accCalibrationFlag;
extern unsigned char magCalibrationFlag;
extern unsigned char gyroCalibrationFlag;
extern unsigned char IMU_TempStableFlag;
//extern unsigned char accZStableFlag;
extern unsigned int imuStableFlag;
extern unsigned char pressureOffsetFlag;
extern uint8_t DeviceInit;

unsigned char flySwitch = 0;
unsigned char powerAndRfStatus = 1;

uint32_t LowPowerLandTimeCnt = 5000;

void fly_switch_1ms_task(void)
{
    unsigned char curRFMode;
    float pitchLen, roolLen;

    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    pitchLen = fabs(expEur.Pitch);
    roolLen = fabs(expEur.Rool);
    curRFMode = RFMode;
    OS_EXIT_CRITICAL();

    static unsigned char oldSwitchButton = SWITCH_BUTTON_OFF;
    unsigned char curSwitchButton = switchButton;
    static unsigned char flySwitchStep = 0;

    if((oldSwitchButton == SWITCH_BUTTON_ON) && (curSwitchButton == SWITCH_BUTTON_OFF)&&(flySwitchStep == 0))//Pressed ->
    {
        flySwitchStep = 1;
    }
    if((oldSwitchButton == SWITCH_BUTTON_OFF) && (curSwitchButton == SWITCH_BUTTON_ON)&&(flySwitchStep == 1))//Released ->
    {
        flySwitchStep = 0;
        flySwitch ^= 1;//Toggle flySwitch;

        if(curRFMode != RFMODE_9AXIE)
        {
            //flyEnable = 0;//cut off
			CutOff();
            if(AutoTakeOff_Sta != ONGROUND) AutoTakeOff_Sta = ONGROUND;
        }
    }

    oldSwitchButton = curSwitchButton;

    if((testMode == 1) && (pitchLen > 15) && (roolLen > 15) && (flySwitchStep == 1))//解除测试模式
    {
        testMode = 0;
        flySwitchStep = 0;
        flySwitch = 0;
    }

    //起飞条件判断,条件不满足则不给起飞
	flyStatus = (GetAccStableFlag() == 0) | (DeviceInit != 0) | ((GetSysParam_Sta() & SYSTEM_PARAMT_OK) == 0) | \
				(pressureOffsetFlag == 0) | (accCalibrationFlag == 1) | (magCalibrationFlag == 1) | \
				(GetIMURunSta() == 1) | (imuStableFlag == 0) | (GetSonicStat() == ERR_BAD) | (GetMagErrFlag() == ERR_BAD)
#if defined(USE_PEACE_DATA)
						| (IMU_TempStableFlag == 0);
#else
						| (gyroCalibrationFlag == 0);
#endif /* defined(USE_PEACE_DATA) */

    switch(curRFMode)
    {
//		case RFMODE_9AXIE:
//        break;
		case RFMODE_READY:
			if(ReadyAct == ReadyHoldFlow)
				flyStatus |= (CalLumVal() < 7);
			else if(ReadyAct == ReadyHoldGPS)
				flyStatus |= (GPS_IsReady() == 0);
			else
				flyStatus |= (CalLumVal() < 7) | (GPS_IsReady() == 0);
		break;
		case RFMODE_HEIGHT:
			flyStatus |= (CalLumVal() < 7);
        break;
		case RFMODE_POSITION:
		case RFMODE_GOHOME:
		case RFMODE_SMART:
		case RFMODE_FOLLOWME:
		case RFMODE_SELFIE:
		default :
			flyStatus |= (GPS_IsReady() == 0) | (MagCalDataValid() == 0);//GPS未就绪或地磁校准数据异常均不允许启动
        break;
    }

    //条件不符合,需要从新解锁
    if(flyStatus == 1)
    {
        flySwitch = 0;
        testMode = 1;
    }
    else if(curRFMode != RFMODE_9AXIE) testMode = 0;

    powerAndRfStatus = (GetLowPowerFlag() != 2);// && (rfLostCount < 250);

    switch(curRFMode)
    {
		case RFMODE_9AXIE:
			powerAndRfStatus &= (rfIsLost() == 0);
			if((powerAndRfStatus == 1) && (testMode == 0) && (flySwitch == 1)) flyEnable = 1;
			else flyEnable = 0;
        break;
		case RFMODE_READY:
		case RFMODE_HEIGHT:
		case RFMODE_POSITION:
		case RFMODE_GOHOME:
		case RFMODE_SMART:
		case RFMODE_FOLLOWME:
		case RFMODE_SELFIE:
		default :
			if(powerAndRfStatus == 0)
			{
				if(LowPowerLandTimeCnt > 0)
					LowPowerLandTimeCnt --;
				else
				{
					EntryAutoLand();
					LockAutoLand();
				}
			}
			powerAndRfStatus = 1;
        break;
	}
	if(GetMagErrFlag() == ERR_BAD)
	{
		if(AutoTakeOff_Sta != ONGROUND)
		{
			EntryAutoLand();
			LockAutoLand();
		}
	}
}

/* 回传用到的数据 */
extern float EstAlt;
extern unsigned char doMagCalibrationFlag;
extern float IMU_temperature;
extern float RealAngl;
extern float GPS_SpeedQuality;
extern uint8_t AppsGetInfoFlag;

rfFeedBackData fdbData = {0};
int16_t Param[4] = {0};
static float rfSendDistInfo = 0.0f;

/* 数据回传 */
void rfSend_Task(void)//5ms
{
    static unsigned int rfPackSendTimeCnt = 0;
    rfPackSendTimeCnt ++;

#if defined(CTRL_RF)
    if((flyEnable == 0) && (rfLostCount >= 600))//丢数据
    {
        if(rfPackSendTimeCnt % 400 == 0)//2s
        {
            if(get_rf_relink_flag() == 0)//第一次,从未有过数据
                rf_relink();
        }
    }
    else
#elif defined(CTRL_A9)
    if(AppsGetInfoFlag == 0 && (rfIsLost() == 0))
    {
        if((rfPackSendTimeCnt % 2) == 1)//10ms奇数次
        {
            RFSendHighFreqAttitude(GetCurEuler());
        }
        else
		{
#endif /* defined(CTRL_A9) */
			if((rfPackSendTimeCnt % 20) == 0)//100ms
			{
				fdbData.alt = EstAlt;
				fdbData.DeviceInit = DeviceInit;
				fdbData.eur = GetCurEuler();
				fdbData.voltage = get_volt();
				fdbData.LockFlag = GPS_Can_Used;//GPS_IsReady();
				fdbData.GPSaccV = GPS_SpeedQuality;
				fdbData.ElectricQuantity = GetElectricQuantity();

				if(AutoTakeOff_Sta == 0)
					fdbData.TakeOffSta = 0;
				else if(AutoTakeOff_Sta <= 3)
					fdbData.TakeOffSta = 1;
				else if(AutoTakeOff_Sta == 4)
					fdbData.TakeOffSta = 2;
				else if(AutoTakeOff_Sta == 5)
				{
					fdbData.TakeOffSta = 3;
					fdbData.TakeOffSta |= GetTakeOffFailed() << 5;
				}
				if(GetAutoLandSta() == 1)
					fdbData.TakeOffSta |= 0x10;

				fdbData.gpsData = get_gps_raw_data();

				fdbData.IMU_Sta = 0xFF;
				if(GetIMURunSta() || ((DeviceInit & DEV_ERR_MPU6500) != 0)) fdbData.IMU_Sta &= ~IMU_ERROR;
				if(GetMagErrFlag() == ERR_BAD || ((DeviceInit & DEV_ERR_IST8307) != 0)) fdbData.IMU_Sta &= ~MAG_ERROR;
				if(GetMagErrFlag() == ERR_WARNING || MagCalDataValid() == 0) fdbData.IMU_Sta &= ~MAG_WARNING;//地磁模长异常或校准数据异常
				if(GetSonicStat() == ERR_BAD) fdbData.IMU_Sta &= ~INF_ERROR;//硬件坏或者数据错误
				if(GetSonicStat() == ERR_WARNING || GetSonicDistance().distance_valid == 0 || Bad_Sonic == 1) fdbData.IMU_Sta &= ~INF_WARNING;
				if((DeviceInit & DEV_ERR_FLOWCAM) != 0) fdbData.IMU_Sta &= ~FLOW_ERROR;
				if(CalLumVal() < 7) fdbData.IMU_Sta &= ~FLOW_WARNING;

				if(flyStatus == 1) flightMode = 0;
				else if(doMagCalibrationFlag == 1) flightMode = 1;
				fdbData.flightMode = flightMode;

				fdbData.motorStatus = (~GetMotorErrFlag()) & 0x0f;
				fdbData.errorFlags = 0;
				if(GetLowPowerFlag() >= 1) fdbData.errorFlags |= BAT_PRELOW_BIT;
				if(GetLowPowerFlag() == 2) fdbData.errorFlags |= BAT_LOW_BIT;
				if(GetMotorErrFlag() != 0x0) fdbData.errorFlags |= MOT_ERR_BIT;
				if(MagCalDataValid() == 0) fdbData.errorFlags |= MAG_PARAM_BIT;
				if(IMU_temperature > 60) fdbData.errorFlags |= TEMP_HIGH_BIT;
//				if(...) fdbData.errorFlags |= MAG_WARN_BIT;
				if(IMU_temperature < 0) fdbData.errorFlags |= TEMP_LOW_BIT;
				if(IsDropOutElecFence() || IsOverrangeAltLimit()) fdbData.errorFlags |= REGION_ERR_BIT;

				rf_send_remote_data(&fdbData);
			}
#if defined(CTRL_A9)
			else if((rfPackSendTimeCnt % 20) == 10)
			{
				Param[0] = (int16_t)rfSendDistInfo;
				if(AutoTakeOff_Sta != SUCCEED)//未起飞成功均显示0
					Param[1] = 0;
				else
					Param[1] = RealAngl * 100;//显示真实角度
				if(RFMode == RFMODE_JOURNEY)
					Param[2] = JourneyRunGet() * 100;
				else
					Param[2] = 0;
				Param[3] = 0;
				AppSendYPRCData(Param);
			}
			else if((rfPackSendTimeCnt % 20) == 14)
			{
				if(MagCalibrateSta() == 1)
				{
					GetMagCalSta((uint8_t *)Param);
					MagCaliProgSend(((uint8_t *)Param)[0], ((uint8_t *)Param)[1], ((uint8_t *)Param)[2]);
				}
			}
			else if((rfPackSendTimeCnt % 20) == 16)
			{
				uint8_t Data[38];
				Data[0] = GetNFZInfo();
				Data[1] = GetNFZSearchFlag();
				Data[2] = NumEntryNFZ();
				Data[3] = NumNearByNFZ();
				SendFCA_LogInfo(1, Data);
			}
		}
	}
	else //丢信号情况下
	{
		if((AppsGetInfoFlag & 0x01) == 0x01)
			FW_Ver_Send();//返回版本号
		else if((AppsGetInfoFlag & 0x02) == 0x02)
			SendFCA_AllParam();//返回所有参数
		else if((AppsGetInfoFlag & 0x04) == 0x04)
			WriteAllParamAck();//参数设置应答
	}
#endif /* defined(CTRL_A9) */

	if(rfPackSendTimeCnt >= 60000)
	{
		rfPackSendTimeCnt = 0;
	}
}

inline uint8_t GetCurMode(void)
{
	return RFMode;
}

inline void SetCurMode(uint8_t Mode)
{
	RFMode = Mode;
}

inline void SetAppsShowDist(float Dist)
{
	rfSendDistInfo = Dist;
}

inline void CutOff(void)
{
	flyEnable = 0;
	CutOffTimeCnt = 0;
}
