#include "led_task.h"
#include "rf_task.h"
#include "IMU_CaliTask.h"

extern unsigned char doMagCalibrationFlag;
extern unsigned char flyStatus;
extern uint8_t SonicWarningFlag;

extern unsigned char MagCalStep;
extern unsigned char MagCal_Sta_succeed;

extern uint8_t DeviceInit;

static void LedSetColor(uint8_t Color)
{
	ioctrl(led_getID(), LED_Indep, &Color);
}
//GetToneSta()
static uint8_t PowerOnInit = 4;
void LedTask(void)//5ms
{
	static uint16_t LedTimeCnt = 0;
	LedTimeCnt ++;

	if(PowerOnInit > 0)
	{
		if((DeviceInit & DEV_ERR_ALLMASK) != 0)//硬件初始化故障
		{
			if(GetToneSta() != 0)//正在发提示音
			{
				if((LedTimeCnt / 20) % 2 == 0)
					LedSetColor(0);
				else
					LedSetColor(RED);
			}
			else
			{
				LedSetColor(0);
//				PowerOnInit = 0;
				if(LedTimeCnt % 30 == 0)
					-- PowerOnInit;
			}
		}
		else
		{
			if(LedTimeCnt % 90 == 0)
				-- PowerOnInit;
			if((LedTimeCnt / 30) % 3 == 0)//B
				LedSetColor(BLUE);
			else if((LedTimeCnt / 30) % 3 == 1)//R
				LedSetColor(RED);
			else if((LedTimeCnt / 30) % 3 == 2)//G
				LedSetColor(GREEN);
		}
		if(PowerOnInit == 0) LedTimeCnt = 0;//Exit
	}
	else if(LedTimeCnt < 200)
	{
		if(GetLowPowerFlag() == 2)//低电压
		{
			if((LedTimeCnt / 20) % 2 == 0)
				LedSetColor(0);
			else
				LedSetColor(RED);
		}
		else if(rfIsLost())//掉信号
		{
			if((LedTimeCnt / 20) % 2 == 0)
				LedSetColor(0);
			else
				LedSetColor(BLUE);
		}
		else if(doMagCalibrationFlag == 1)//地磁校准
		{
			if(MagCalStep < 5)
			{
				if(GetSampleStat() == 1)
				{
					if((LedTimeCnt / 20) % 2 == 0)//白灯快闪
						LedSetColor(0);
					else
						LedSetColor(WHITE);
				}
				else
				{
					if(LedTimeCnt < 100)//黄灯慢闪
						LedSetColor(0);
					else
						LedSetColor(RED | GREEN);
				}
			}
			else
			{
				if(MagCal_Sta_succeed == 0)
				{
					if((LedTimeCnt / 20) % 2 == 0)//红灯快闪
						LedSetColor(0);
					else
						LedSetColor(RED);
				}
				else
				{
					if((LedTimeCnt / 20) % 2 == 0)//绿灯快闪
						LedSetColor(0);
					else
						LedSetColor(GREEN);
				}
			}
		}
		else if(flyStatus == 1)//蓝灯慢闪
		{
			if(LedTimeCnt < 100)
				LedSetColor(0);
			else
				LedSetColor(BLUE);
		}
//		else if(SonicWarningFlag == 1)
//		{
			//nothing to do...
//		}
		else if(GetAutoLandSta() == 1)
			LedSetColor(RED);
		else
		{
			uint8_t curMode = GetCurMode();
			switch(curMode)
			{
				case RFMODE_READY:
				case RFMODE_9AXIE:
					LedSetColor(BLUE);
				break;//BLUE
				case RFMODE_HEIGHT:
					LedSetColor(GREEN | BLUE);
				break;//PURPLE
				case RFMODE_POSITION:
				case RFMODE_SMART:
				case RFMODE_FOLLOWME:
				case RFMODE_SELFIE:
				case RFMODE_ORBIT:
				case RFMODE_JOURNEY:
					LedSetColor(GREEN);
				break;
				case RFMODE_GOHOME:
					LedSetColor(RED);
				break;//RED
				default :
				break;//WHITE
			}
		}
	}
	else if(GetLowPowerFlag() >= 1)
	{
		if(LedTimeCnt < 220)
			LedSetColor(0);
		else if(LedTimeCnt < 240)
			LedSetColor(RED);
		else if(LedTimeCnt < 260)
			LedSetColor(0);
		else if(LedTimeCnt < 280)
			LedSetColor(RED);
		else LedTimeCnt = 0;
	}
	else
		LedTimeCnt = 0;

	if(GetPowerStat() == POWER_OFF)
		LedSetColor(RED);
}
