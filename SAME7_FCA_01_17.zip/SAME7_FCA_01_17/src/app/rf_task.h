#ifndef _RF_TASK_H_
#define _RF_TASK_H_

#include "Journey.h"
#include "selfie_task.h"
#include "IMU_CaliTask.h"
#include "flash_task.h"
#include "height_task.h"

#define RF_MinVal 400
#define RF_MidVal 1200
#define RF_MaxVal 2000

#define ThrChannel_min RF_MinVal
#define ThrChannel_max RF_MaxVal
#define ThrRange  (ThrChannel_max-ThrChannel_min)
#define MotoRange (Moto_PwmMax-Moto_PwmMin) // 700
#define ThrFactor 0.85f
#define MAX_EUR  35.0f

#define BAT_PRELOW_BIT 0x01
#define BAT_LOW_BIT 0x02
#define MOT_ERR_BIT 0x04
#define MAG_PARAM_BIT 0x08
#define TEMP_HIGH_BIT 0x10
#define MAG_WARN_BIT 0x20
#define TEMP_LOW_BIT 0x40
#define REGION_ERR_BIT 0x80

#define IMU_ERROR 0x01
#define MAG_ERROR 0x02
#define MAG_WARNING 0x04
#define INF_ERROR 0x08
#define INF_WARNING 0x10
#define FLOW_ERROR 0x20
#define FLOW_WARNING 0x40

typedef enum
{
    SWITCH_BUTTON_OFF = 0,
    SWITCH_BUTTON_ON = 1
} SWITCH_BUTTON;

typedef enum
{
    RFMODE_9AXIE = 0,
    RFMODE_HEIGHT = 1,
    RFMODE_POSITION = 2,
    RFMODE_GOHOME = 3,
    RFMODE_SMART = 4,
    RFMODE_FOLLOWME = 5,
    RFMODE_SELFIE = 6,
	RFMODE_ORBIT = 7,
	RFMODE_JOURNEY = 8,
	RFMODE_READY = 0xF,
} RFMODE;

typedef enum
{
	ReadyHoldFlow = 0,
	ReadyHoldGPS = 1
}ModeReadyAct;

typedef enum
{
	OrbitAct_ME = 0,
	OrbitAct_POI = 1
}ModeOrbitAct;

typedef enum
{
	AutoCenter = 0,
	UserCenter = 1
}OrbitCenterType;

extern uint8_t RFMode;
extern uint8_t UserExpMode;
extern uint8_t testMode;
extern FLOAT_RPY expEur;
extern uint8_t Bad_Sonic;
extern uint8_t flyEnable;

extern ModeReadyAct ReadyAct;
extern ModeOrbitAct OrbitAct;
extern OrbitCenterType OrbitCenter;

void rf_5ms_task(void);
void rfSend_Task(void);
void fly_switch_1ms_task(void);

uint8_t GetCurMode(void);
void SetCurMode(uint8_t Mode);
void SetAppsShowDist(float Dist);

void CutOff(void);

#endif
