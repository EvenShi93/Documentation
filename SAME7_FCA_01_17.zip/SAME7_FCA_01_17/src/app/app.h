#ifndef _APP_H_
#define _APP_H_

#include "middleware.h"
#include "task.h"

//定义全局枚举

#endif
