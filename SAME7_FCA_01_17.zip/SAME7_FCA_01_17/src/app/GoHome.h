#ifndef _GOHOME_TASK_H_
#define _GOHOME_TASK_H_

#include "middleware.h"

#include "position_task.h"

void GoHomeTask(void);
uint8_t GoHomeModeExit(void);

#endif
