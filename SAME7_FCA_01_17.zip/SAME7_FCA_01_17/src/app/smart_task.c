#include "smart_task.h"

/* 定义最大切向速度(cm/s) */
#define MAX_AROUND_VEL 500.0f
/* 定义最大径向速度(cm/s) */
#define MAX_RADIUS_VEL 400.0f
/* 定义最小旋转半径(cm) */
#define MIN_RADIUS 800.0f
/* 控制周期(10ms) */
#define SmpT 0.01f

#define MIN_LMT(val, min) ((val < min)? min : val)

//float kp,ki,kd,PreErr,Pout,Iout,Dout,Output,I_max,I_sum,Dt;
PID RadVelPID = {1.2, 0, 0, 0, 0, 0, 0, 0, 300, 0, SmpT};     //半径定位环
PID RadAccPID = {2.0, 0.03f, 0, 0, 0, 0, 0, 0, 300, 0, SmpT};  //半径速度环
PID CirVelPID = {1.0, 0, 0, 0, 0, 0, 0, 0, 300, 0, SmpT};     //切线定位环
PID CirAccPID = {2.0, 0.03f, 0, 0, 0, 0, 0, 0, 300, 0, SmpT};  //切线速度环

float ExpAccV = 0.0f, ExpAccR = 0.0f;//期望切向加速度，期望向心加速度

float DesRadAcc ;//遥感给径向加速度
float DesCirAcc ;//遥感给定切向加速度

float EstRadius ;//当前半径
float EstRadVel ;//当前径向速度
float EstCirAng ;//当前角度
float EstCirVel ;//当前切向速度

float ExpRadAcc = 0.0f, ExpCirAcc = 0.0f;//期望径向切向加速度
float ExpRadVel = 0.0f, ExpCirVel = 0.0f;//期望半径，期望径向速度，期望切向速度
float ExpRadius = 0.0f, ExpCirAng = 0.0f;//期望半径，期望角度

float PIDRadVel = 0.0f, PIDRadAcc = 0.0f;//半径保持PID输出，速度，加速度
float PIDCirVel = 0.0f, PIDCirAcc = 0.0f;//切向角度与速度保持PID输出

unsigned char SmartInit = 0;

float x_Center = 0.0f, y_Center = 0.0f;

float smart_cos_yaw, smart_sin_yaw;

void Smart_PIDLoop(PID* pid, float Desir, float measure, float* Output);

void GetSmartExpAcc(void)
{
    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    FLOAT_RPY curEurTemp = *GetCurEuler();
    FLOAT_RPY curExpEur = expEur;

    OS_EXIT_CRITICAL();

    //旋转加速度方向所用的三角量
    smart_cos_yaw = cosf(curEurTemp.Yaw * (float)DEG_TO_RAD);
    smart_sin_yaw = sinf(curEurTemp.Yaw * (float)DEG_TO_RAD);

    float DeltaX, DeltaY, EstVelX, EstVelY;

    if(SmartInit == 0)
    {
        x_Center = GetHomePoint()->X - (MIN_RADIUS) * smart_cos_yaw;//初始化圆心位置
        y_Center = GetHomePoint()->Y - (MIN_RADIUS) * smart_sin_yaw;
    }

    DeltaX = PosEst_x - x_Center; DeltaY = PosEst_y - y_Center;//距离Home点距离
    EstVelX = velRateCorr_x; EstVelY = velRateCorr_y;//获取当前速度

    EstRadius = sqrtf( DeltaX * DeltaX + DeltaY * DeltaY);//估算出当前半径
    EstRadVel = (EstVelX * DeltaX + EstVelY * DeltaY) / EstRadius;//径向速度
	EstCirVel = (EstVelY * DeltaX - EstVelX * DeltaY) / EstRadius;//切向速度

    EstCirAng = GETDIR(DeltaY, 0)*acosf(DeltaX/EstRadius) * (float)RAD_TO_DEG ;//当前角度
    if(EstCirAng <= 0)  EstCirAng = 360 + EstCirAng;

    //动态速度限制，半径=10m，限制到一半
    float Rad_vel_Max = constrain_float( MAX_RADIUS_VEL * (EstRadius/2000), 0, MAX_RADIUS_VEL);
    float Cir_vel_Max = MAX_AROUND_VEL;//constrain_float( MAX_AROUND_VEL*(EstRadius/2000),0,MAX_AROUND_VEL);

    if(SmartInit == 0)
    {
        SmartInit = 1;
        ExpRadius = EstRadius;//初始化期望半径
        ExpCirAng = EstCirAng;//初始化期望角度
    }

    DesRadAcc = -(constrain_float(apply_deadband(curExpEur.Pitch, 3), -35, 35)/35)* 400;//遥感给径向加速度
    DesCirAcc = (constrain_float(apply_deadband(curExpEur.Rool, 3) , -35, 35)/35)* 400;//遥感给定切向加速度

    step_change(&ExpRadAcc, DesRadAcc, 50, 50);
    step_change(&ExpCirAcc, DesCirAcc, 50, 50);

    /* -------------------------------  切向速度处理 ------------------------------- */
    float Cir_speed_reduce=3; //刹车风阻大小
    if(fabs(ExpCirAcc) >= 3)//有舵量，切向加速
    {
        ExpCirVel += ExpCirAcc * SmpT; //累加到切线速度
//          ExpCirVel -= (Cir_speed_reduce/2) * (ExpCirVel/Cir_vel_Max);

        ExpCirVel=constrain_float( ExpCirVel, -Cir_vel_Max, Cir_vel_Max);
        ExpAccV = ExpCirAcc;
        ExpCirAng = EstCirAng;

        if(CirVelPID.kp > 0.0f)CirVelPID.kp -= 0.005f;
    }
    else //没有舵量，刹车
    {
        ExpAccV = 0.0f;
        if(fabs(ExpCirVel)>=50)//期望速度较大，分段减速
        {
            ExpCirVel  -= (Cir_speed_reduce) * (ExpCirVel/Cir_vel_Max); //风阻减速
            ExpCirAng = EstCirAng;
        }
        else
        {
            if(fabs(ExpCirVel)<20) ExpCirVel -=GETDIR(ExpCirVel,0)*0.5f; //残蚕
            else
                ExpCirVel  -= Cir_speed_reduce * (ExpCirVel/Cir_vel_Max); //风阻减速
        }
    }
    if(fabs(ExpCirVel)<1) ExpCirVel=0; //防止跳动

    if(ExpCirVel == 0 && CirVelPID.kp < 1.2f) CirVelPID.kp += 0.005f;

    //ExpCirAng += ExpCirVel * SmpT / EstRadius;//期望角度累加

    if(ExpCirAng>=360) ExpCirAng-=360;
    if(ExpCirAng<=0) ExpCirAng+=360;
    float Cirtemp=ExpCirAng;

    if( (EstCirAng-ExpCirAng)>180 ) Cirtemp= EstCirAng+(360-(EstCirAng-ExpCirAng));
    if( (EstCirAng-ExpCirAng)<-180 ) Cirtemp= EstCirAng-(EstCirAng-ExpCirAng+360);

    Smart_PIDLoop(&CirVelPID, Cirtemp, EstCirAng, &PIDCirVel);//切向角度环

    Smart_PIDLoop(&CirAccPID, ExpCirVel - PIDCirVel, EstCirVel, &PIDCirAcc);//切线速度环
    //PIDCirAcc= EstCirVel- ExpCirVel;

    ExpAccV += (PIDCirAcc*-1.0f);     // PID修正切线速度

    /* ------------------------------- 径向速度处理 ------------------------------- */
    float Rad_speed_reduce=3; //刹车风阻大小
    if(fabs(ExpRadAcc) >= 3)//有舵量，径向加速
    {
        //累加到期望速度
        ExpRadVel += ExpRadAcc * SmpT;
        //越接近800,加速度越小
        if(ExpRadius<900 || ExpRadAcc<0)
        {
            ExpRadVel+=  (900-constrain_float(ExpRadius,800,900))/100;
            ExpRadAcc*= -(800-constrain_float(ExpRadius,800,900))/100;
        }
        //加速时使用弱风阻
        ExpRadVel -= (Rad_speed_reduce/2) * (ExpRadVel/Rad_vel_Max);

        ExpRadVel=constrain_float( ExpRadVel,-Rad_vel_Max,Rad_vel_Max);
    }
    else //没有舵量，进入减速曲线
    {
        if(fabs(ExpRadVel)>=50)//期望速度较大，分段减速
        {
            ExpRadVel  -= (Rad_speed_reduce) * (ExpRadVel/Rad_vel_Max); //风阻减速
        }
        else
        {
            if(fabs(ExpRadVel)<20) ExpRadVel -=GETDIR(ExpRadVel,0)*0.5f; //残蚕
            else
                ExpRadVel  -= Rad_speed_reduce * (ExpRadVel/Rad_vel_Max); //风阻减速
        }
        //刹车完毕
    }

    if(fabs(ExpRadVel)<1) ExpRadVel=0; //防止跳动
    //累加到期望半径
    ExpRadius += ExpRadVel * SmpT;
    //期望半径不超过当前半径+-1m
    if(fabs(ExpRadius-EstRadius)>500)  ExpRadius = EstRadius+(500*GETDIR(ExpRadius,EstRadius));

    if(ExpRadius<800) ExpRadius=800;

    //误差大，并且当前半径小，加强半径环kp
    //if(fabs(ExpRadius-EstRadius)>100 && EstRadius<1000) RadVelPID.kp=constrain_float(fabs(ExpRadius-EstRadius)/100,1,2);

    Smart_PIDLoop(&RadVelPID, ExpRadius, EstRadius, &PIDRadVel);//半径位置环，控制半径误差
    Smart_PIDLoop(&RadAccPID, ExpRadVel-PIDRadVel, EstRadVel, &PIDRadAcc);//径向速度环，得到径向加速度

    //径向加速度合成= 向心力 + PID输出
    ExpAccR = (-(ExpCirVel * ExpCirVel)/MIN_LMT(EstRadius, 800)) - PIDRadAcc + ExpRadAcc;//离心为正，向心为负

    /* ------------------------------- 最终加速度输出，转化到XY系 ------------------------------- */
    PH.accel_target_x = (ExpAccR * DeltaX - ExpAccV * DeltaY) / EstRadius;
    PH.accel_target_y = (ExpAccR * DeltaY + ExpAccV * DeltaX) / EstRadius;
}

void Smart_PIDLoop(PID* pid, float Desir, float measure, float* Output)
{
    float Err,Diff;

    Err= measure-Desir;

    Diff=(Err-pid->PreErr)/ pid->Dt;

    pid->PreErr=Err;

    pid->I_sum+=(Err*pid->Dt);
    if(pid->I_sum> pid->I_max)pid->I_sum= pid->I_max;
    if(pid->I_sum<-pid->I_max)pid->I_sum=-pid->I_max;

    pid->Pout = pid->kp * Err;
    pid->Iout = pid->ki * pid->I_sum;
    pid->Dout = pid->kd * Diff;

    *Output=pid->Pout+pid->Iout+pid->Dout;
}

Quat smartPositionLoop_Q;

void smart_10ms_task(void)
{
    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    unsigned char curRFMode = RFMode;

    OS_EXIT_CRITICAL();
    static unsigned char oldRFMode = RFMODE_9AXIE;
    if((oldRFMode != curRFMode) && (curRFMode == RFMODE_SMART))
    {
        SmartInit = 0;
        RadVelPID.I_sum = 0;
        RadAccPID.I_sum = 0;
        CirVelPID.I_sum = 0;
        CirAccPID.I_sum = 0;
        _leash = 500;//定位环最大误差为5m
        vel_max = 200;//定位环最大目标速度 2m/s
    }
    oldRFMode = curRFMode;
    if(curRFMode == RFMODE_SMART)
    {
        GetSmartExpAcc();
		ComputePositionQuat();
    }
}
