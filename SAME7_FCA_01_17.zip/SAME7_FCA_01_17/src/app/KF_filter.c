#include "maths.h"
#include "KF_filter.h"


#define C_0 1.0f


void Kalman_Filter_init(KF_str* str,float Q_pos, float Q_spd, float R_spd)
{
  str->Q_pos=Q_pos;
	str->Q_spd=Q_spd;
	str->R_spd=R_spd;
	
	str->PP[0][0]=1;
	str->PP[0][1]=0;
	str->PP[1][0]=0;
	str->PP[1][1]=1;
	
	str->filter_Output=0;
	str->spd_bias=0;
	str->E=0;
	str->K_0=0;
	str->K_1=0;
	str->t_0=0;
	str->t_1=0;
	str->Pdot[0]=0;
	str->Pdot[1]=0;
	str->Pdot[2]=0;
	str->Pdot[3]=0;
	str->PCt_0=0;
	str->PCt_1=0;
}	


void Kalman_Filter_Update(KF_str* str, float new_vel,float new_pos,float Filter_dt)	
{
	//�������
	str->filter_Output+=( new_vel - str->spd_bias) * Filter_dt;          
	
	//�������Э��������΢�־���
	str->Pdot[0]=str->Q_pos - str->PP[0][1] - str->PP[1][0]; 
	str->Pdot[1]= - str->PP[1][1];                  
	str->Pdot[2]= - str->PP[1][1];
	str->Pdot[3]=str->Q_spd;
	
	//Э����΢�ֵĻ���=>״̬Э����
	str->PP[0][0] += str->Pdot[0] * Filter_dt;   
	str->PP[0][1] += str->Pdot[1] * Filter_dt;   
	str->PP[1][0] += str->Pdot[2] * Filter_dt;
	str->PP[1][1] += str->Pdot[3] * Filter_dt;	
		
	str->pos_err = new_pos - str->filter_Output;
	
	str->PCt_0 = C_0 * str->PP[0][0];
	str->PCt_1 = C_0 * str->PP[1][0];
	str->E = str->R_spd + C_0 * str->PCt_0; 
	str->K_0 = str->PCt_0 / str->E;
	str->K_1 = str->PCt_1 / str->E;
	str->t_0 = str->PCt_0;
	str->t_1 = C_0 * str->PP[0][1];
	
	//����״̬Э����
	str->PP[0][0] -= str->K_0 * str->t_0;		 
	str->PP[0][1] -= str->K_0 * str->t_1;
	str->PP[1][0] -= str->K_1 * str->t_0;
	str->PP[1][1] -= str->K_1 * str->t_1;
	
	//���	
	str->filter_Output	+= str->K_0 *  str->pos_err;	   
	str->spd_bias	+= str->K_1 * str->pos_err;	 
}



float VelXY_NOISE = 60;
float VelZ_NOISE  = 0.7f;
float PosXY_NOISE = 1000000.0f;
float PosZ_NOISE  = 1.5f;
float AccXY_NOISE = 0.8f;
float AccZ_NOISE = 0.1f;
float process_NOISE = 0.01;


float _6staEKF_dt = 0.005f;

float _6staEKF_states[6] = {0,0,0,0,0,0};


void _6staEKF_setNOISE(float acc_xy,float vxy,float pos_xy,float acc_z,float vz,float pos_z)
{
  AccXY_NOISE=acc_xy; 
	VelXY_NOISE=vxy;
  PosXY_NOISE=pos_xy;

  AccZ_NOISE=acc_z;
	VelZ_NOISE=vz;
	PosZ_NOISE=pos_z;
}



//״̬����,������������Χ
void _6staEKF_EKF_ConstrainStates()
{
	for (uint8_t i = 0; i <= 2; i ++) 
	_6staEKF_states[i] = constrain_float(_6staEKF_states[i], -500,500);
	for (uint8_t i = 3; i <= 4; i ++) 
	_6staEKF_states[i] = constrain_float(_6staEKF_states[i], -1000000,1000000);
	_6staEKF_states[5] = constrain_float(_6staEKF_states[5], -10000, 10000);
}



//״̬������,ʹ�ü��ٶȵ���
void _6staEKF_EKF_UpdateStrapdownEquationsNED(float accx,float accy,float accz,float Update_dt)
{	
	_6staEKF_states[0] += accx * Update_dt;
	_6staEKF_states[1] += accy * Update_dt;
	_6staEKF_states[2] += accz * Update_dt;
	_6staEKF_states[3] += _6staEKF_states[0] * Update_dt;
	_6staEKF_states[4] += _6staEKF_states[1] * Update_dt;
	_6staEKF_states[5] += _6staEKF_states[2] * Update_dt;
	_6staEKF_EKF_ConstrainStates();
}


//����Э�������
float _6staEKF_P[6][6] = {{0.01,0,0,0,0,0 },{0,0.01,0,0,0,0},{0,0,0.01,0,0,0},{0,0,0,4,0,0},{0,0,0,0,4,0},{0,0,0,0,0,4}};

//������� ����������Э�������
void _6staEKF_EKF_CovariancePrediction(float dt)
{
	float dvxCov;
	float dvyCov;   
	float dvzCov;    

	float nextP[6][6] = {{ 0,0,0,0,0,0 },{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}};   
	float processNoise[6] = {0,0,0,0,0,0};

	//�����������,��Դ����Ʈ������
	for (uint8_t i = 0; i <= 5; i ++)
	{
		processNoise[i] = process_NOISE;
	}

	dvxCov = AccXY_NOISE * AccXY_NOISE;
	dvyCov = dvxCov;
	dvzCov = AccZ_NOISE*AccZ_NOISE;

    //����Э�������P
    nextP[0][0] = _6staEKF_P[0][0] + dvxCov;
    nextP[0][1] = _6staEKF_P[0][1];
    nextP[0][2] = _6staEKF_P[0][2];
    nextP[0][3] = _6staEKF_P[0][3] + _6staEKF_P[0][0]*dt;
    nextP[0][4] = _6staEKF_P[0][4] + _6staEKF_P[0][1]*dt;
    nextP[0][5] = _6staEKF_P[0][5] + _6staEKF_P[0][2]*dt;
    nextP[1][0] = _6staEKF_P[1][0];
    nextP[1][1] = _6staEKF_P[1][1] + dvyCov;
    nextP[1][2] = _6staEKF_P[1][2];
    nextP[1][3] = _6staEKF_P[1][3] + _6staEKF_P[1][0]*dt;
    nextP[1][4] = _6staEKF_P[1][4] + _6staEKF_P[1][1]*dt;
    nextP[1][5] = _6staEKF_P[1][5] + _6staEKF_P[1][2]*dt;
    nextP[2][0] = _6staEKF_P[2][0];
    nextP[2][1] = _6staEKF_P[2][1];
    nextP[2][2] = _6staEKF_P[2][2] + dvzCov;
    nextP[2][3] = _6staEKF_P[2][3] + _6staEKF_P[2][0]*dt;
    nextP[2][4] = _6staEKF_P[2][4] + _6staEKF_P[2][1]*dt;
    nextP[2][5] = _6staEKF_P[2][5] + _6staEKF_P[2][2]*dt;
    nextP[3][0] = _6staEKF_P[3][0] + _6staEKF_P[0][0]*dt;
    nextP[3][1] = _6staEKF_P[3][1] + _6staEKF_P[0][1]*dt;
    nextP[3][2] = _6staEKF_P[3][2] + _6staEKF_P[0][2]*dt;
    nextP[3][3] = _6staEKF_P[3][3] + _6staEKF_P[0][3]*dt + dt*(_6staEKF_P[3][0] + _6staEKF_P[0][0]*dt);
    nextP[3][4] = _6staEKF_P[3][4] + _6staEKF_P[0][4]*dt + dt*(_6staEKF_P[3][1] + _6staEKF_P[0][1]*dt);
    nextP[3][5] = _6staEKF_P[3][5] + _6staEKF_P[0][5]*dt + dt*(_6staEKF_P[3][2] + _6staEKF_P[0][2]*dt);
    nextP[4][0] = _6staEKF_P[4][0] + _6staEKF_P[1][0]*dt;
    nextP[4][1] = _6staEKF_P[4][1] + _6staEKF_P[1][1]*dt;
    nextP[4][2] = _6staEKF_P[4][2] + _6staEKF_P[1][2]*dt;
    nextP[4][3] = _6staEKF_P[4][3] + _6staEKF_P[1][3]*dt + dt*(_6staEKF_P[4][0] + _6staEKF_P[1][0]*dt);
    nextP[4][4] = _6staEKF_P[4][4] + _6staEKF_P[1][4]*dt + dt*(_6staEKF_P[4][1] + _6staEKF_P[1][1]*dt);
    nextP[4][5] = _6staEKF_P[4][5] + _6staEKF_P[1][5]*dt + dt*(_6staEKF_P[4][2] + _6staEKF_P[1][2]*dt);
    nextP[5][0] = _6staEKF_P[5][0] + _6staEKF_P[2][0]*dt;
    nextP[5][1] = _6staEKF_P[5][1] + _6staEKF_P[2][1]*dt;
    nextP[5][2] = _6staEKF_P[5][2] + _6staEKF_P[2][2]*dt;
    nextP[5][3] = _6staEKF_P[5][3] + _6staEKF_P[2][3]*dt + dt*(_6staEKF_P[5][0] + _6staEKF_P[2][0]*dt);
    nextP[5][4] = _6staEKF_P[5][4] + _6staEKF_P[2][4]*dt + dt*(_6staEKF_P[5][1] + _6staEKF_P[2][1]*dt);
    nextP[5][5] = _6staEKF_P[5][5] + _6staEKF_P[2][5]*dt + dt*(_6staEKF_P[5][2] + _6staEKF_P[2][2]*dt);

    // �����������
    for (uint8_t i=0; i<= 5; i++)
    {
        nextP[i][i] = nextP[i][i] + processNoise[i];
    }

    // λ�ñ䶯����100m,ֹͣ����Э����,��ֹ��GPS�ź�ʱ�˲�����ɢ
    if ((_6staEKF_P[3][3] + _6staEKF_P[4][4]) > 10000)
    {
        for (uint8_t i=3; i<=4; i++)
        {
            for (uint8_t j=0; j<=5; j++)
            {
                nextP[i][j] = _6staEKF_P[i][j];
                nextP[j][i] = _6staEKF_P[j][i];
            }
        }
    }

  //�������,�����P����
	for (uint8_t i = 0; i <= 5; i ++)
	{
		_6staEKF_P[i][i] = nextP[i][i];
	}
	for (uint8_t i = 1; i <= 5; i ++)
	{
		for (uint8_t j = 0; j <= i - 1; j ++)
		{
			_6staEKF_P[i][j] = 0.5f * (nextP[i][j] + nextP[j][i]);
			_6staEKF_P[j][i] = _6staEKF_P[i][j];
		}
	}
	for(uint8_t i = 0; i <= 2; i ++) _6staEKF_P[i][i] = constrain_float(_6staEKF_P[i][i], 0.0f, 1.0e3f); // velocities
	for(uint8_t i = 3; i <= 5; i ++) _6staEKF_P[i][i] = constrain_float(_6staEKF_P[i][i], 0.0f, 1.0e6f); // positions
}

//������Գ� ��ֹ�������
void _6staEKF_ForceSymmetry()
{
    for (uint8_t i = 1; i <= 5; i ++)
    {
        for (uint8_t j = 0; j <= i-1; j ++)
        {
            float temp = 0.5f * (_6staEKF_P[i][j] + _6staEKF_P[j][i]);
            _6staEKF_P[i][j] = temp;
            _6staEKF_P[j][i] = temp;
        }
    }
}

float _6staEKF_observation[6] = {0,0,0,0,0,0};
float _6staEKF_innovVelPos[6] = {0,0,0,0,0,0};
float _6staEKF_R_OBS[6] = {0,0,0,0,0,0};
float _6staEKF_varInnovVelPos[6] = {0,0,0,0,0,0};

float _6staEKF_Kfusion[6] = {0,0,0,0,0,0};

uint8_t _6staEKF_obsIndex;

//�������� �ں��ٶȺ�λ����
void _6staEKF_EKF_FuseVelPosNED(float vx,float vy,float vz,float pos_x,float pos_y,float pos_z,float dt)
{
		uint8_t stateIndex;

		float R_OBS_DATA_CHECKS[6] = {0,0,0,0,0,0};

		float SK;
		float KHP[6][6] = {{0,0,0,0,0,0 }, {0,0,0,0,0,0}, {0,0,0,0,0,0}, {0,0,0,0,0,0}, {0,0,0,0,0,0}, {0,0,0,0,0,0}};

		//unit m
		_6staEKF_observation[0] = vx; //vx
		_6staEKF_observation[1] = vy; //vy
		_6staEKF_observation[2] = vz; //vz
		_6staEKF_observation[3] = pos_x; //pos_x
		_6staEKF_observation[4] = pos_y; //pos_y
		_6staEKF_observation[5] = pos_z; //pos_z

		_6staEKF_R_OBS[0] = SQ_t(VelXY_NOISE);   //vx noise
		_6staEKF_R_OBS[1] = _6staEKF_R_OBS[0];	//vy noise
		_6staEKF_R_OBS[2] = SQ_t(VelZ_NOISE);   //vz noise
			
		_6staEKF_R_OBS[3] = SQ_t(PosXY_NOISE);  //pos_x noise
		_6staEKF_R_OBS[4] = _6staEKF_R_OBS[3];  //pos_y noise
		_6staEKF_R_OBS[5] = SQ_t(PosZ_NOISE);	  //pos_z noise

		for (uint8_t i = 0; i <= 1; i ++) R_OBS_DATA_CHECKS[i] = SQ_t(constrain_float(VelXY_NOISE, 0.05f, 5.0f));
		for (uint8_t i = 2; i <= 5; i ++) R_OBS_DATA_CHECKS[i] = _6staEKF_R_OBS[i];

			
		_6staEKF_innovVelPos[0] = _6staEKF_states[0] - _6staEKF_observation[0];
		_6staEKF_innovVelPos[1] = _6staEKF_states[1] - _6staEKF_observation[1];
		_6staEKF_innovVelPos[2] = _6staEKF_states[2] - _6staEKF_observation[2];
		_6staEKF_varInnovVelPos[0] = _6staEKF_P[0][0] + R_OBS_DATA_CHECKS[0];
		_6staEKF_varInnovVelPos[1] = _6staEKF_P[1][1] + R_OBS_DATA_CHECKS[1];
		_6staEKF_varInnovVelPos[2] = _6staEKF_P[2][2] + R_OBS_DATA_CHECKS[2];

		//����������ܺ�,�����жϴ���������
		float innovVelSumSq = 0; 
		float varVelSum = 0; 
		for (uint8_t i = 0; i <= 2; i ++)
		{
				innovVelSumSq += _6staEKF_innovVelPos[i] * _6staEKF_innovVelPos[i];
				varVelSum += _6staEKF_varInnovVelPos[i];
		}

		_6staEKF_observation[3] += _6staEKF_states[0] * dt;
		_6staEKF_observation[4] += _6staEKF_states[1] * dt;
		_6staEKF_innovVelPos[3]  = _6staEKF_states[3] - _6staEKF_observation[3];
		_6staEKF_innovVelPos[4]  = _6staEKF_states[4] - _6staEKF_observation[4];
		_6staEKF_varInnovVelPos[3] = _6staEKF_P[3][3] + R_OBS_DATA_CHECKS[3];
		_6staEKF_varInnovVelPos[4] = _6staEKF_P[4][4] + R_OBS_DATA_CHECKS[4];


    _6staEKF_innovVelPos[5] = _6staEKF_states[5] - _6staEKF_observation[5];
    _6staEKF_varInnovVelPos[5] = _6staEKF_P[5][5] + R_OBS_DATA_CHECKS[5];

    for (_6staEKF_obsIndex = 0; _6staEKF_obsIndex <= 5; _6staEKF_obsIndex ++)
	  {
        stateIndex = _6staEKF_obsIndex;
        //����������
        _6staEKF_innovVelPos[_6staEKF_obsIndex] = _6staEKF_states[_6staEKF_obsIndex] - _6staEKF_observation[_6staEKF_obsIndex];
        //���㿨��������
        _6staEKF_varInnovVelPos[_6staEKF_obsIndex] = _6staEKF_P[stateIndex][stateIndex] + _6staEKF_R_OBS[_6staEKF_obsIndex];
        SK = 1.0f/_6staEKF_varInnovVelPos[_6staEKF_obsIndex];
		
        for(uint8_t i = 0; i <= 5; i ++)
		    {
            _6staEKF_Kfusion[i] = _6staEKF_P[i][stateIndex] * SK;
        }
        for (uint8_t i = 0; i <= 5; i ++)
		    {
            _6staEKF_states[i] = _6staEKF_states[i] - _6staEKF_Kfusion[i] * _6staEKF_innovVelPos[_6staEKF_obsIndex];
        }
        //����Э�������P = (I - K*H)*P;
        for (uint8_t i = 0; i <= 5; i ++)
		    {
            for (uint8_t j = 0; j <= 5; j ++)
            {
                KHP[i][j] = _6staEKF_Kfusion[i] * _6staEKF_P[stateIndex][j];
            }
        }
        for (uint8_t i = 0; i <= 5; i ++)
		    {
            for (uint8_t j = 0; j <= 5; j ++)
			      {
                _6staEKF_P[i][j] = _6staEKF_P[i][j] - KHP[i][j];
            }
        }
    }

    _6staEKF_ForceSymmetry();        
	  for (uint8_t i = 0; i <= 2; i ++)
		_6staEKF_P[i][i] = constrain_float(_6staEKF_P[i][i], 0.0f, 1.0e3f); // velocities
    for (uint8_t i = 3; i <= 5; i ++)
		_6staEKF_P[i][i] = constrain_float(_6staEKF_P[i][i], 0.0f, 1.0e6f); // positions
}

void _6staEKF_EKFThread(float accx,float accy,float accz,float vx,float vy,float vz,float pos_x,float pos_y,float pos_z,float dt)
{		
		_6staEKF_EKF_UpdateStrapdownEquationsNED(accx,accy,accz,dt);
		_6staEKF_EKF_CovariancePrediction(dt); 
		_6staEKF_EKF_FuseVelPosNED(vx,vy,vz,pos_x,pos_y,pos_z,dt);
}














