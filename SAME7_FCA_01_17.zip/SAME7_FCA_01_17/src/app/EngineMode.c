#include "EngineMode.h"

#if defined(CTRL_A9) && MOT_PREBURNING_ENABLE

static YUNEEC_RF_STR BurnCmdPackage = {0};

static uint8_t rfSendSensorFlag = 0;
static uint8_t rfImageFlag = 0;

static uint8_t SysHWInitSta = 0;
static uint8_t SysParam_Sta = 0;

static uint8_t ADC_CalFlag = 0;
static uint8_t CalCompCnt = 0;
static uint8_t ADC_CalCmd = 0;

extern uint8_t DeviceInit;
extern float pixel_flow_x, pixel_flow_y;

static unsigned char gps_ubx_nav_flag;

static void SendADC_Prog(uint8_t Prog);
static void SendDroneSN(void);
static void SensorData_Send(void);
static void GpsData_Send(void);
static void ImageData_Send(void);
static void GetEngineCmd(void);
static void EntryEngineMode(void);
static void EntryADC_Cal(void);

extern void EntryMotoBurnMode(void);
extern void SetMotoSpeed(uint16_t Speed);

#endif /* defined(CTRL_A9) && MOT_PREBURNING_ENABLE */
void EngineModeTask(void)
{
#if defined(CTRL_A9) && MOT_PREBURNING_ENABLE
	static uint32_t EngineTimeCnt = 0;
//	OS_ALLOC_SR();

	GetEngineCmd();
	if(rfSendSensorFlag == 1)
	{
		EngineTimeCnt ++;
if(ADC_CalFlag == 0 && rfImageFlag == 0)
{
		if(EngineTimeCnt % 5 == 0)//50ms
		{
			SensorData_Send();
		}
		else if(EngineTimeCnt % 5 == 3)
		{
			SendDroneSN();
		}
		else if(EngineTimeCnt >= 100)//1s
		{
			EngineTimeCnt = 0;
			if((DeviceInit & DEV_ERR_UBLOXM8) == 0)
			{
				if(gps_ubx_nav_flag == 0)
					ioctrl(ublox_m8q_getID(), UBLOX_M8Q_IOCTRL_GPS_NAV_FLAG_READ, &gps_ubx_nav_flag);
				if(gps_ubx_nav_flag == 0)
					ioctrl(ublox_m8q_getID(), UBLOX_M8Q_IOCTRL_GPS_INIT_NAV_WRITE, 0);
				else
					GpsData_Send();
			}
		}
}
else if(rfImageFlag == 1)
{
		ImageData_Send();
}
else if(ADC_CalFlag == 1)
{
			uint8_t ADC_Prog;
			if((ADC_Prog = VoltCalibrate(ADC_CalCmd)) >= 100)
			{
				if(CalCompCnt < 5)
					CalCompCnt ++;
				else
					ADC_CalFlag = 0;
			}
			SendADC_Prog(ADC_Prog);
}
	}
#endif /* defined(CTRL_A9) && MOT_PREBURNING_ENABLE */
}

#if defined(CTRL_A9) && MOT_PREBURNING_ENABLE
static YUNEEC_SND_STR EngineUploadData = {
	.h1 = 0x55,
	.h2 = 0x55
};

static void SendADC_Prog(uint8_t Prog)
{
	uint8_t *pProg = (uint8_t *)&EngineUploadData;
	pProg[2] = 3;
	pProg[3] = 6;
	pProg[4] = Prog;
	pProg[5] = crcRfCal((pProg + 2), 3);
	write(rf_st10_getID(), pProg, 6);
}

extern uint8_t DroneSN[16];
static void SendDroneSN(void)
{
	GetDroneSN *getSN = (GetDroneSN *)&EngineUploadData;
	getSN->length = 18;
	getSN->type = 5;

	for(uint8_t i = 0; i < 16; i ++)
		getSN->SN[i] = DroneSN[i];
	getSN->crc = crcRfCal((unsigned char *)&(getSN->length), getSN->length);
	write(rf_st10_getID(), (unsigned char *)getSN, sizeof(GetDroneSN));
}

static void SensorData_Send(void)
{
	uint8_t ESCStatus[4] = {0};
	rfSensorData *sensorData = (rfSensorData *)&EngineUploadData;

	sensorData->length = 39;
	sensorData->type = 2;

//	bit 0:	motor0 is normal
//	bit 1:	motor1 is normal
//	bit 2:	motor2 is normal
//	bit 3:	motor3 is normal
//	bit 4:	IMU State, 1 -> err, 0 -> ok
//	bit 5:	Mag State, 1 -> err, 0 -> ok
//	bit 6:	Baro, 1 -> err, 0 -> ok
//	bit 7:	GPS, 1 -> err, 0 -> ok
//	bit 8:	EEPROM, 1 -> err, 0 -> ok
//	bit 9:	FLOW, 1 -> err, 0 -> ok
//	bit 10:	Ultrasonic, 1 -> err, 0 -> ok
//	bit 11:	AccCalibData, 1 -> err, 0 -> ok
	sensorData-> status = 0;

	ioctrl(moto_getID(), MOTO_IOCTRL_GET_ESC_STAT, ESCStatus);
	if(ESCStatus[0] != 0) sensorData-> status |= 0x0001;
	if(ESCStatus[1] != 0) sensorData-> status |= 0x0002;
	if(ESCStatus[2] != 0) sensorData-> status |= 0x0004;
	if(ESCStatus[3] != 0) sensorData-> status |= 0x0008;
	if((SysHWInitSta & DEV_ERR_MPU6500) != 0) sensorData-> status |= 0x0010;//MPU6500
	if((SysHWInitSta & DEV_ERR_IST8307) != 0) sensorData-> status |= 0x0020;//Magnetic
	if((SysHWInitSta & DEV_ERR_BMS56XX) != 0) sensorData-> status |= 0x0040;//pressure
	if((SysHWInitSta & DEV_ERR_UBLOXM8) != 0) sensorData-> status |= 0x0080;//GPS
	if((SysHWInitSta & DEV_ERR_AT24CXX) != 0 || (SysHWInitSta & DEV_ERR_DATAGET) != 0) sensorData-> status |= 0x0100;//EEPROM
	if((SysHWInitSta & DEV_ERR_FLOWCAM) != 0) sensorData-> status |= 0x0200;//Flow
	if(GetSonicStat() == ERR_BAD) sensorData-> status |= 0x0400;//Infrared
	if((SysParam_Sta & EEPROM_ELPDAT_ERR) != 0) sensorData-> status |= 0x0800;//Acc Cal Data

	sensorData->gyroX = get_gyro_unit()->gyroX * 100;
	sensorData->gyroY = get_gyro_unit()->gyroY * 100;
	sensorData->gyroZ = get_gyro_unit()->gyroZ * 100;

	sensorData->accX = get_acc_unit()->accX * 100;
	sensorData->accY = get_acc_unit()->accY * 100;
	sensorData->accZ = get_acc_unit()->accZ * 100;

	sensorData->roll = GetCurEuler()->Rool * 100;
	sensorData->pitch = GetCurEuler()->Pitch * 100;
	sensorData->yaw = GetCurEuler()->Yaw * 100;

	sensorData->magX = get_mag()->magX;
	sensorData->magY = get_mag()->magY;
	sensorData->magZ = get_mag()->magZ;

	sensorData->pressure = GetPressureVal();
	sensorData->Volt = (get_volt() * 10) - 50;

	sensorData->flowX = pixel_flow_x * 100;
	sensorData->flowY = pixel_flow_x * 100;
	sensorData->sonarDist = GetSonicDistance().sonar_distance_filtered * 100;

	sensorData->crc = crcRfCal((unsigned char *)&(sensorData->length), sensorData->length);
	write(rf_st10_getID(), (unsigned char *)sensorData, sizeof(rfSensorData));
}

GPS_DATA_NAV EngineGPS_DataNav;//������Ϣ
static void GpsData_Send(void)
{
	int CNO[32] = {0};//flush
	uint8_t i;

	EngineGpsData *gpsData = (EngineGpsData *)&EngineUploadData;
	gpsData->length = 17;
	gpsData->type = 3;

	GPS_DATA_RAW *gpsRawData = get_gps_raw_data();
	ioctrl(ublox_m8q_getID(), UBLOX_M8Q_IOCTRL_GPS_NAV_DATA_GET, &EngineGPS_DataNav);//��ȡ������Ϣ

	if(EngineGPS_DataNav.numSV >= 30)
		gpsData->nsat = 0x00 | EngineGPS_DataNav.numSV;
	else
		gpsData->nsat = 0x80 | EngineGPS_DataNav.numSV;

	gpsData->lon = gpsRawData->lon;
	gpsData->lat = gpsRawData->lat;
	gpsData->alt = gpsRawData->height;

	for(i = 0; i < EngineGPS_DataNav.numSV; i ++)
		CNO[i] = EngineGPS_DataNav.slmsg[i].cno;

	sort(CNO, EngineGPS_DataNav.numSV, 1);

	gpsData->cno = (CNO[0] + CNO[1] + CNO[2] + CNO[3] + CNO[4]) / 5;

	gpsData->crc = crcRfCal((unsigned char *)&(gpsData->length), gpsData->length);
	write(rf_st10_getID(), (unsigned char *)gpsData, sizeof(EngineGpsData));
}

extern uint8_t *previous_image;
static uint16_t imageSendCnt = 0;
static void ImageData_Send(void)
{
	uint8_t buff[200];
	buff[0] = 0x55;
	buff[1] = 0x55;
	buff[2] = 68;
	buff[3] = 1;

	uint8_t *txBuff = previous_image;
	if(imageSendCnt < 256)
	{
		*(uint16_t *)&buff[4] = imageSendCnt;
		for(uint8_t i = 0; i < 64; i ++)
		{
			buff[6 + i] = txBuff[64 * imageSendCnt + i];
		}

		buff[6 + 64] = crcRfCal(buff + 2, 68);
		write(rf_st10_getID(), buff, 71);
		imageSendCnt ++;
	}
	else if(imageSendCnt >= 256)
	{
		imageSendCnt = 0;
		rfImageFlag = 0;
		open(camera_getID());//����ͼ��ɼ�
	}
}

uint16_t BurnCHData;
uint8_t SN_WriteCnt = 0;
uint8_t SerialNmb[16] = {0};
uint8_t DroneSN_WriteFlag = 0;
static void GetEngineCmd(void)
{
	if(read(rf_st10_getID(), &BurnCmdPackage, 0) == 1)//��ȡ�ϻ��������ݰ�
	{
		BurnCHData = (((uint16_t)BurnCmdPackage.channel[16] & 0x0F) << 8) | BurnCmdPackage.channel[17];//Channel 12
		if(BurnCHData == 555 && rfSendSensorFlag == 0)
		{
			EntryEngineMode();
			SysHWInitSta = GetSysHW_InitSta();
			SysParam_Sta = GetSysParam_Sta();
		}
		else if(rfSendSensorFlag == 1)
		{
			SetMotoSpeed(BurnCHData);
		}
	}
	else if(read(rf_st10_getID(), &ADC_CalCmd, 7) == 1 && rfSendSensorFlag == 1)//ADCУ׼
	{
		//Entry ADC Calibration.
		if(ADC_CalCmd == 1 || ADC_CalCmd == 2)
			EntryADC_Cal();
	}
	else if(read(rf_st10_getID(), NULL, 1) == 1 && rfSendSensorFlag == 1)//��ȡͼ�������
	{
		if(rfImageFlag == 0 && rfSendSensorFlag == 1)
		{
			rfImageFlag = 1;
			close(camera_getID());
		}
	}
	else if(read(rf_st10_getID(), SerialNmb, 8) == 1 && rfSendSensorFlag == 1)
	{
		if(*SerialNmb == 'Y' && *(SerialNmb + 1) == 'U' && SN_WriteCnt == 0 && DroneSN_WriteFlag == 0)
		{
			for(uint8_t i = 0; i < 16; i ++)
				DroneSN[i] = SerialNmb[i];
			DroneSN_WriteFlag = 1;
		}
	}
}

static void EntryADC_Cal(void)
{
	ADC_CalFlag = 1;
	CalCompCnt = 0;
	InitVoltCal();
}

static void EntryEngineMode(void)//���빤��ģʽ
{
	EntryMotoBurnMode();
	rfSendSensorFlag = 1;
}

uint8_t GetEngineModeSta(void)//��ȡ�ϻ�ģʽ״̬
{
	return rfSendSensorFlag;
}
#endif /* defined(CTRL_A9) && MOT_PREBURNING_ENABLE */
