#include "maths.h"
extern float  Debug_Param[15];
float IMU_P = 5.0f;
float IMU_I = 0.00f;

//6轴计算得到四元数
void sensfusion6UpdateQ(FLOAT_GYRO *gyro, FLOAT_ACC *accel, float dt, volatile Quat *Q)
{
    float recipNorm;
    float halfvx, halfvy, halfvz;
    float halfex, halfey, halfez;

    float twoKp = IMU_P;    // 2 * proportional gain (Kp)
    float twoKi = IMU_I;     // 2 * integral gain (Ki)

    static float integralFBx = 0.0f;
    static float integralFBy = 0.0f;
    static float integralFBz = 0.0f;  // integral error terms scaled by Ki

    float qw, qx, qy, qz;
    float gx, gy, gz;
    float ax, ay, az;

    OS_ALLOC_SR();

    OS_ENTER_CRITICAL();

    qw = Q->qw;
    qx = Q->qx;
    qy = Q->qy;
    qz = Q->qz;

    gx =  gyro->gyroX;
    gy =  gyro->gyroY;
    gz =  gyro->gyroZ;

    ax =  accel->accX;
    ay =  accel->accY;
    az =  accel->accZ;

    OS_EXIT_CRITICAL();

    gx = gx * DEG_TO_RAD;
    gy = gy * DEG_TO_RAD;
    gz = gz * DEG_TO_RAD;

    // Compute feedback only if accelerometer measurement valid (avoids NaN in accelerometer normalisation)
    if(!((ax == 0.0f) && (ay == 0.0f) && (az == 0.0f)))
    {
        // Normalise accelerometer measurement
        recipNorm = 1.0f / sqrtf(ax * ax + ay * ay + az * az);
        ax *= recipNorm;
        ay *= recipNorm;
        az *= recipNorm;

        // Estimated direction of gravity and vector perpendicular to magnetic flux
        halfvx = qx * qz - qw * qy;
        halfvy = qw * qx + qy * qz;
        halfvz = qw * qw - 0.5f + qz * qz;

        // Error is sum of cross product between estimated and measured direction of gravity
        halfex = (ay * halfvz - az * halfvy);
        halfey = (az * halfvx - ax * halfvz);
        halfez = (ax * halfvy - ay * halfvx);

        // Compute and apply integral feedback if enabled

        integralFBx += twoKi * halfex * dt;  // integral error scaled by Ki
        integralFBy += twoKi * halfey * dt;
        integralFBz += twoKi * halfez * dt;
        gx += integralFBx;  // apply integral feedback
        gy += integralFBy;
        gz += integralFBz;

        // Apply proportional feedback
        gx += twoKp * halfex;
        gy += twoKp * halfey;
        gz += twoKp * halfez;
    }

    float delta2 = (gx * gx + gy * gy + gz * gz) * dt * dt;

    float qw_last =  qw;
    float qx_last =  qx;
    float qy_last =  qy;
    float qz_last =  qz;

    qw = qw_last * (1.0f - delta2 * 0.125f) + (-qx_last * gx - qy_last * gy - qz_last * gz) * 0.5f * dt;
    qx = qx_last * (1.0f - delta2 * 0.125f) + (qw_last * gx + qy_last * gz - qz_last * gy) * 0.5f * dt;
    qy = qy_last * (1.0f - delta2 * 0.125f) + (qw_last * gy - qx_last * gz + qz_last * gx) * 0.5f * dt;
    qz = qz_last * (1.0f - delta2 * 0.125f) + (qw_last * gz + qx_last * gy - qy_last * gx) * 0.5f * dt;

    // Normalise quaternion
    recipNorm = 1.0f / sqrtf(qw * qw + qx * qx + qy * qy + qz * qz);
    qw *= recipNorm;
    qx *= recipNorm;
    qy *= recipNorm;
    qz *= recipNorm;

    OS_ENTER_CRITICAL();

    Q->qw = qw;
    Q->qx = qx;
    Q->qy = qy;
    Q->qz = qz;

    OS_EXIT_CRITICAL();
}

// integral error terms scaled by Ki
float integralFBx = 0.0f;
float integralFBy = 0.0f;
float integralFBz = 0.0f;


//9轴计算得到四元数
void sensfusion9UpdateQ(FLOAT_GYRO *gyro, FLOAT_ACC *accel, FLOAT_MAG *mag, float dt, volatile Quat *Q)
{
    float qw, qx, qy, qz;

    float recipNorm;
    float qwqw, qwqx, qwqy, qwqz, qxqx, qxqy, qxqz, qyqy, qyqz, qzqz;
    float hx, hy, bx, bz;
    float halfvx, halfvy, halfvz, halfwx, halfwy, halfwz;
    float halfex, halfey, halfez;

    float twoKp = IMU_P;
    float twoKi = IMU_I;

    float mex;
    float mey;
    float mez;

    float gx, gy, gz;
    float ax, ay, az;
    float mx, my, mz;

    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    gx =  gyro->gyroX;
    gy =  gyro->gyroY;
    gz =  gyro->gyroZ;

    ax =  accel->accX;
    ay =  accel->accY;
    az =  accel->accZ;

    gx = gx * DEG_TO_RAD;
    gy = gy * DEG_TO_RAD;
    gz = gz * DEG_TO_RAD;

    mx =   mag->magX;
    my =   mag->magY;
    mz =   mag->magZ;

    qw = Q->qw;
    qx = Q->qx;
    qy = Q->qy;
    qz = Q->qz;

    OS_EXIT_CRITICAL();

    // Normalise accelerometer measurement
    if((ax != 0) || (ay != 0) || (az != 0))
    {
        recipNorm =  1.0f / sqrtf(ax * ax + ay * ay + az * az);
        ax *= recipNorm;
        ay *= recipNorm;
        az *= recipNorm;
    }

    // Normalise magnetometer measurement
    if((mx != 0) || (my != 0) || (mz != 0))
    {
        recipNorm =  1.0f / sqrtf(mx * mx + my * my + mz * mz);
        mx *= recipNorm;
        my *= recipNorm;
        mz *= recipNorm;
    }
    // Auxiliary variables to avoid repeated arithmetic
    qwqw = qw * qw;
    qwqx = qw * qx;
    qwqy = qw * qy;
    qwqz = qw * qz;
    qxqx = qx * qx;
    qxqy = qx * qy;
    qxqz = qx * qz;
    qyqy = qy * qy;
    qyqz = qy * qz;
    qzqz = qz * qz;

    halfvx = qxqz - qwqy;
    halfvy = qwqx + qyqz;
    halfvz = qwqw - 0.5f + qzqz;

    // Reference direction of Earth's magnetic field
    hx = 2.0f * (mx * (0.5f - qyqy - qzqz) + my * (qxqy - qwqz) + mz * (qxqz + qwqy));
    hy = 2.0f * (mx * (qxqy + qwqz) + my * (0.5f - qxqx - qzqz) + mz * (qyqz - qwqx));

    bx = sqrtf(hx * hx + hy * hy);
    bz = 2.0f * (mx * (qxqz - qwqy) + my * (qyqz + qwqx) + mz * (0.5f - qxqx - qyqy));

    halfwx = bx * (0.5f - qyqy - qzqz) + bz * (qxqz - qwqy);
    halfwy = bx * (qxqy - qwqz) + bz * (qwqx + qyqz);
    halfwz = bx * (qwqy + qxqz) + bz * (0.5f - qxqx - qyqy);

    // Error is sum of cross product between estimated direction and measured direction of field vectors

    mex = (my * halfwz - mz * halfwy);
    mey = (mz * halfwx - mx * halfwz);
    mez = (mx * halfwy - my * halfwx);

    //	 mex= 0;
    //	 mey= 0;
    //	 mez= 0;

    halfex = (ay * halfvz - az * halfvy) + mex/10;
    halfey = (az * halfvx - ax * halfvz) + mey/10;
    halfez = (ax * halfvy - ay * halfvx) + mez;

    // Compute and apply integral feedback if enabled

    integralFBx += twoKi * halfex * dt;	// integral error scaled by Ki
    integralFBy += twoKi * halfey * dt;
    integralFBz += twoKi * halfez * dt;
    gx += integralFBx;	// apply integral feedback
    gy += integralFBy;
    gz += integralFBz;

    // Apply proportional feedback
    gx += twoKp * halfex;
    gy += twoKp * halfey;
    gz += twoKp * halfez;


    float delta2 = (gx * gx + gy * gy + gz * gz) * dt * dt;

    float qw_last =  qw;
    float qx_last =  qx;
    float qy_last =  qy;
    float qz_last =  qz;

    qw = qw_last * (1.0f - delta2 * 0.125f) + (-qx_last * gx - qy_last * gy - qz_last * gz) * 0.5f * dt;
    qx = qx_last * (1.0f - delta2 * 0.125f) + (qw_last * gx + qy_last * gz - qz_last * gy) * 0.5f * dt;
    qy = qy_last * (1.0f - delta2 * 0.125f) + (qw_last * gy - qx_last * gz + qz_last * gx) * 0.5f * dt;
    qz = qz_last * (1.0f - delta2 * 0.125f) + (qw_last * gz + qx_last * gy - qy_last * gx) * 0.5f * dt;

    // Normalise quaternion
    recipNorm = 1.0f / sqrtf(qw * qw + qx * qx + qy * qy + qz * qz);
    qw *= recipNorm;
    qx *= recipNorm;
    qy *= recipNorm;
    qz *= recipNorm;

    OS_ENTER_CRITICAL();

    Q->qw = qw;
    Q->qx = qx;
    Q->qy = qy;
    Q->qz = qz;

    OS_EXIT_CRITICAL();
}

void  dotCal(FLOAT_ACC *accel, volatile Quat *Q, volatile Quat *dot)
{

    float qw, qx, qy, qz;
    float ax, ay, az;

    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    qw = Q->qw;
    qx = Q->qx;
    qy = Q->qy;
    qz = Q->qz;

    ax =  accel->accX;
    ay =  accel->accY;
    az =  accel->accZ;

    OS_EXIT_CRITICAL();

    if((ax != 0) || (ay != 0) || (az != 0))
    {
        float recipNorm =  1.0f / sqrtf(ax * ax + ay * ay + az * az);
        ax *= recipNorm;
        ay *= recipNorm;
        az *= recipNorm;
    }

    //重力方向转到机体系
    Quat dot_c;
    float vx = 2.0f * (qx * qz - qw * qy);
    float vy = 2.0f * (qw * qx + qy * qz);
    float vz = 2.0f * (qw * qw - 0.5f + qz * qz);

    //重力方向与当前加速度差
    float deltaVx = vx - ax;
    float deltaVy = vy - ay;
    float deltaVz = vz - az;

    //加速度差转到世界系
    dot_c.qw = 2.0f * qx * deltaVy - 2.0f * qy * deltaVx;
    dot_c.qx = 2.0f * qz * deltaVx + 2.0f * qw * deltaVy - 4.0f * qx * deltaVz;
    dot_c.qy = 2.0f * qz * deltaVy - 4.0f * qy * deltaVz - 2.0f * qw * deltaVx;
    dot_c.qz = 2.0f * qx * deltaVx + 2.0f * qy * deltaVy;

    OS_ENTER_CRITICAL();
    *dot = dot_c;
    OS_EXIT_CRITICAL();
}

//将欧拉角转换成四元数
void EulerAngleToQuaternion1(FLOAT_RPY *eur, volatile Quat *Q)
{
    float cosHRoll, cosHPitch, cosHYaw; //第一套欧拉角转四元数算法
    float sinHRoll, sinHPitch, sinHYaw;
    float recipNorm;

    float Pitch_in = eur->Pitch;
    float Rool_in = eur->Rool;
    float Yaw_in = eur->Yaw;

    float qw, qx, qy, qz;

    Rool_in  = Rool_in * DEG_TO_RAD;
    Pitch_in = Pitch_in * DEG_TO_RAD;
    Yaw_in   = Yaw_in  * DEG_TO_RAD;

    cosHRoll = cosf(0.5f * Rool_in);
    cosHPitch = cosf(0.5f * Pitch_in);
    cosHYaw = cosf(0.5f * Yaw_in);

    sinHRoll = sinf(0.5f * Rool_in);
    sinHPitch = sinf(0.5f * Pitch_in);
    sinHYaw = sinf(0.5f * Yaw_in);
//Yaw
	qw = cosHRoll * cosHPitch * cosHYaw + sinHRoll * sinHPitch * sinHYaw;
	qx = sinHRoll * cosHPitch * cosHYaw - cosHRoll * sinHPitch * sinHYaw;
	qy = cosHRoll * sinHPitch * cosHYaw + sinHRoll * cosHPitch * sinHYaw;
	qz = cosHRoll * cosHPitch * sinHYaw - sinHRoll * sinHPitch * cosHYaw;
//Roll
//	qw = cosHRoll * cosHPitch * cosHYaw - sinHRoll * sinHPitch * sinHYaw;
//	qx = sinHRoll * cosHPitch * cosHYaw + cosHRoll * sinHPitch * sinHYaw;
//	qy = cosHRoll * sinHPitch * cosHYaw - sinHRoll * cosHPitch * sinHYaw;
//	qz = cosHRoll * cosHPitch * sinHYaw + sinHRoll * sinHPitch * cosHYaw;

    recipNorm = 1.0f / sqrtf(qw * qw + qx * qx + qy * qy + qz * qz);
    qw *= recipNorm;
    qx *= recipNorm;
    qy *= recipNorm;
    qz *= recipNorm;

    Q->qw = qw;
    Q->qx = qx;
    Q->qy = qy;
    Q->qz = qz;

}


//四元数到欧拉角
void Quat2Euler(volatile  Quat *Q, FLOAT_RPY *eur)
{
    float qw, qx, qy, qz;

    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    qw = Q->qw;
    qx = Q->qx;
    qy = Q->qy;
    qz = Q->qz;

    OS_EXIT_CRITICAL();

    eur->Rool    = atan2f(2 * (qw * qx + qy * qz) , 1 - 2 * (qx * qx + qy * qy)) * RAD_TO_DEG; //输出+-90
    eur->Pitch   = asinf(2 * (qw * qy - qz * qx)) * RAD_TO_DEG;                               //输出+-180
    eur->Yaw     = atan2f(2 * (qw * qz + qx * qy) , 1 - 2 * (qy * qy + qz * qz)) * RAD_TO_DEG; //输出+-180
}


//四元数叉乘
/*
Q_Start :起始状态四元数
Q_Rotate：绕该四元数旋转
Q_Terminal：起始状态四元数Q_Start绕 Q_Rotate旋转后得到的新的状态四元数
Q_Terminal = Q_Start +  Q_Rotate
*/
void QuaternionMultiplicationCross(Quat *Q_Start, Quat *Q_Rotate, volatile Quat *Q_Terminal)
{
    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    Quat Q_Start_c =  *Q_Start;
    Quat Q_Rotate_c = *Q_Rotate;

    OS_EXIT_CRITICAL();

    Quat Q_Result;
    //叉乘
    Q_Result.qw = Q_Start_c.qw * Q_Rotate_c.qw - Q_Start_c.qx * Q_Rotate_c.qx - Q_Start_c.qy * Q_Rotate_c.qy - Q_Start_c.qz * Q_Rotate_c.qz;
    Q_Result.qx = Q_Start_c.qw * Q_Rotate_c.qx + Q_Start_c.qx * Q_Rotate_c.qw + Q_Start_c.qz * Q_Rotate_c.qy - Q_Start_c.qy * Q_Rotate_c.qz;
    Q_Result.qy = Q_Start_c.qw * Q_Rotate_c.qy + Q_Start_c.qy * Q_Rotate_c.qw + Q_Start_c.qx * Q_Rotate_c.qz - Q_Start_c.qz * Q_Rotate_c.qx;
    Q_Result.qz = Q_Start_c.qw * Q_Rotate_c.qz + Q_Start_c.qz * Q_Rotate_c.qw + Q_Start_c.qy * Q_Rotate_c.qx - Q_Start_c.qx * Q_Rotate_c.qy;

    float recipNorm;
    recipNorm = 1 / sqrtf(Q_Result.qw * Q_Result.qw + Q_Result.qx * Q_Result.qx + Q_Result.qy * Q_Result.qy + Q_Result.qz * Q_Result.qz);
    Q_Result.qw *= recipNorm;
    Q_Result.qx *= recipNorm;
    Q_Result.qy *= recipNorm;
    Q_Result.qz *= recipNorm;

    OS_ENTER_CRITICAL();

    *Q_Terminal =  Q_Result;

    OS_EXIT_CRITICAL();
}


//求误差四元数
/*
Q_Start:当前起始状态四元数
Q_Terminal：目标状态四元数
Q_Rotate：起始状态四元数到目标状态四元数需要旋转的量（Q_Terminal/Q_Start）
Q_Rotate = Q_Terminal - Q_Start
*/
void QuaternionDiviCross(Quat *Q_Start, Quat *Q_Terminal, volatile Quat *Q_Rotate)
{
    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    Quat Q_Start_c =  *Q_Start;
    Quat Q_Terminal_c = *Q_Terminal;

    OS_EXIT_CRITICAL();

    Quat Q_Result;
    //求共轭
    Q_Start_c.qw =  Q_Start_c.qw;
    Q_Start_c.qx = -Q_Start_c.qx;
    Q_Start_c.qy = -Q_Start_c.qy;
    Q_Start_c.qz = -Q_Start_c.qz;

    //叉乘
    Q_Result.qw = Q_Start_c.qw * Q_Terminal_c.qw - Q_Start_c.qx * Q_Terminal_c.qx - Q_Start_c.qy * Q_Terminal_c.qy - Q_Start_c.qz * Q_Terminal_c.qz;
    Q_Result.qx = Q_Start_c.qw * Q_Terminal_c.qx + Q_Start_c.qx * Q_Terminal_c.qw + Q_Start_c.qz * Q_Terminal_c.qy - Q_Start_c.qy * Q_Terminal_c.qz;
    Q_Result.qy = Q_Start_c.qw * Q_Terminal_c.qy + Q_Start_c.qy * Q_Terminal_c.qw + Q_Start_c.qx * Q_Terminal_c.qz - Q_Start_c.qz * Q_Terminal_c.qx;
    Q_Result.qz = Q_Start_c.qw * Q_Terminal_c.qz + Q_Start_c.qz * Q_Terminal_c.qw + Q_Start_c.qy * Q_Terminal_c.qx - Q_Start_c.qx * Q_Terminal_c.qy;

    float recipNorm;
    recipNorm = 1 / sqrtf(Q_Result.qw * Q_Result.qw + Q_Result.qx * Q_Result.qx + Q_Result.qy * Q_Result.qy + Q_Result.qz * Q_Result.qz);
    Q_Result.qw *= recipNorm;
    Q_Result.qx *= recipNorm;
    Q_Result.qy *= recipNorm;
    Q_Result.qz *= recipNorm;


    OS_ENTER_CRITICAL();

    *Q_Rotate =  Q_Result;

    OS_EXIT_CRITICAL();
}


//得到四元数旋转量
/*
Q: 误差四元数
Vector：得到的误差向量
Alpha： 得到的误差总角度
*/
void QuatToRotate(volatile Quat *rotateQ, volatile FLOAT_XYZ *rotateAngle)
{
    FLOAT_XYZ angle = {0};

    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    Quat rotateQ_c = *rotateQ;

    OS_EXIT_CRITICAL();


    float Alpha = 0;
    Alpha = acosf(rotateQ_c.qw) * RAD_TO_DEG * 2;

    float scale = sqrt(rotateQ_c.qx * rotateQ_c.qx + rotateQ_c.qy * rotateQ_c.qy + rotateQ_c.qz * rotateQ_c.qz);
    if(scale == 0)
    {
        rotateAngle->X = 0;
        rotateAngle->Y = 0;
        rotateAngle->Z = 0;

        return ;
    }

    angle.X = rotateQ_c.qx * Alpha / scale ;
    angle.Y = rotateQ_c.qy * Alpha / scale;
    angle.Z = rotateQ_c.qz * Alpha / scale;

    *rotateAngle  = angle;
}


//误差四元数转到机体系
/*
Q:当前状态四元数
Dir：0:世界系转到机体系 1：机体系转到世界系
from： 需要旋转的向量
to: 旋转后的向量
*/
void quaternion_rotateVector(Quat *Q, FLOAT_XYZ *from, volatile FLOAT_XYZ *to, unsigned char Dir)
{

    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();

    Quat Q_in = *Q;
    FLOAT_XYZ from_c = *from;

    OS_EXIT_CRITICAL();

    FLOAT_XYZ to_c;

    if(Dir == 1) { Q_in.qw *= 1; Q_in.qx *= -1; Q_in.qy *= -1; Q_in.qz *= -1;  }


    float x2 = Q_in.qx * 2;
    float y2 = Q_in.qy * 2;
    float z2 = Q_in.qz * 2;

    float wx2 = Q_in.qw * x2;
    float wy2 = Q_in.qw * y2;
    float wz2 = Q_in.qw * z2;

    float xx2 = Q_in.qx * x2;
    float yy2 = Q_in.qy * y2;
    float zz2 = Q_in.qz * z2;

    float xy2 = Q_in.qx * y2;
    float yz2 = Q_in.qy * z2;
    float xz2 = Q_in.qz * x2;

    to_c.X = from_c.X * (1   - yy2 - zz2) + from_c.Y * (xy2 - wz2)       + from_c.Z * (xz2 + wy2);
    to_c.Y = from_c.X * (xy2 + wz2)       + from_c.Y * (1   - xx2 - zz2) + from_c.Z * (yz2 - wx2);
    to_c.Z = from_c.X * (xz2 - wy2)       + from_c.Y * (yz2 + wx2)       + from_c.Z * (1   - xx2 - yy2);

    OS_ENTER_CRITICAL();

    * to =  to_c;

    OS_EXIT_CRITICAL();
}



float invSqrt(float x)
{
    float halfx = 0.5f * x;
    float y = x;
    long i = *(long *)&y;
    i = 0x5f3759df - (i >> 1);
    y = *(float *)&i;
    y = y * (1.5f - (halfx * y * y));
    return y;
}


short matrixQ[SAMPLE_NUMBER][3] = {{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}};
double  matrixA[6][6] = {{0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0}};
double  matrixB[6] = {0, 0, 0, 0, 0, 0};
double  matrixX[6] = {0, 0, 0, 0, 0, 0};
float   matrixM[7] = {0, 0, 0, 0, 1, 1, 1};


void ellipsoid_init()
{
    for(unsigned short i = 0; i < 6; i++)
    {
        for(unsigned short j = 0; j < 6; j++)
        {
            matrixA[i][j] = 0;
        }
    }
    for(unsigned short i = 0; i < 6; i++)
    {
        matrixB[i] = 0;
    }
    for(unsigned short i = 0; i < 6; i++)
    {
        matrixX[i] = 0;
    }
    for(unsigned short i = 0; i < 7; i++)
    {
        matrixM[i] = 0;
    }
}

void ellipsoid_step1(void)
{

    float matrix_temp1[SAMPLE_NUMBER][6] = {0};

    for (unsigned short i = 0; i < SAMPLE_NUMBER; i++)
    {
        matrix_temp1[i][0] = matrixQ[i][0] * matrixQ[i][0];
        matrix_temp1[i][1] = matrixQ[i][1] * matrixQ[i][1];
        matrix_temp1[i][2] = matrixQ[i][2] * matrixQ[i][2];
        matrix_temp1[i][3] = matrixQ[i][0];
        matrix_temp1[i][4] = matrixQ[i][1];
        matrix_temp1[i][5] = matrixQ[i][2];
    }
    for (unsigned short j = 0; j < 6; j++)
    {
        for (unsigned short i = 0; i < SAMPLE_NUMBER; i++)
        {
            matrixA[j][0] += matrix_temp1[i][j] * matrix_temp1[i][0];
            matrixA[j][1] += matrix_temp1[i][j] * matrix_temp1[i][1];
            matrixA[j][2] += matrix_temp1[i][j] * matrix_temp1[i][2];
            matrixA[j][3] += matrix_temp1[i][j] * matrix_temp1[i][3];
            matrixA[j][4] += matrix_temp1[i][j] * matrix_temp1[i][4];
            matrixA[j][5] += matrix_temp1[i][j] * matrix_temp1[i][5];
        }
    }

    for (int16_t i = 0; i < 6; i++)
    {
        for (int16_t j = 0; j < SAMPLE_NUMBER; j++)    { matrixB[i] += -matrix_temp1[j][i]; }
    }
}

void ellipsoid_step2()
{
    int16_t i = 0, j = 0, k = 0;
    double temp = 0, x[6] = {0, 0, 0, 0, 0, 0};

    double w = 0.9, precision = 0.000000001;

    for(k = 0; k < 6000; k++)
    {
        for(i = 0; i < 6; i++)
        {
            temp = 0;
            for(j = 0; j < 6; j++)
            {
                if(j != i)  { temp += matrixA[i][j] * matrixX[j]; }

            }

            matrixX[i] = (1 - w) * x[i] + w * (matrixB[i] - temp) / matrixA[i][i];

        }
        for(i = 0; i < 6; i++)
        {
            if(fabs(matrixX[i] - x[i]) < precision)
            {
                if(i == 3) { return ; }

            }
            else  { break; }

        }
        for(i = 0; i < 6; i++)  { x[i] = matrixX[i]; }
    }

}

void ellipsoid_step3(double unitValue)
{
    matrixM[0] = matrixX[3] / 2 / matrixX[0];
    matrixM[1] = matrixX[4] / 2 / matrixX[1];
    matrixM[2] = matrixX[5] / 2 / matrixX[2];
    //(1G^2) = (4096*4096) =16777216
    matrixM[3] = unitValue * unitValue / ((double)matrixX[3] * matrixX[3] / matrixX[0] / 4
                                           + matrixX[4] * matrixX[4] / matrixX[1] / 4
                                           + matrixX[5] * matrixX[5] / matrixX[2] / 4
                                           - 1);
    matrixM[4] = sqrtf((matrixM[3]) * matrixX[0] );
    matrixM[5] = sqrtf((matrixM[3]) * matrixX[1] );
    matrixM[6] = sqrtf((matrixM[3]) * matrixX[2] );
}

float constrain_float(float amt, float low, float high)
{
    if (isnan(amt))
    {
        return (low + high) * 0.5f;
    }
    return ((amt) < (low) ? (low) : ((amt) > (high) ? (high) : (amt)));
}

float apply_deadband(float value, float deadband)
{
    if (fabs(value) <= deadband) { value = 0; }

    if( value > deadband ) { value -= deadband; }
    if( value < -deadband ) { value += deadband; }

    return value;
}

float apply_limit(float value, float limit)
{
	if(fabs(value) >= limit) value = (value / fabs(value)) * limit;
	return value;
}

void step_change(float *in, float target, float step, float deadBand )
{
    if(fabs(*in - target) <= deadBand) {*in = target; return;}

    if(*in > target) {*in -= fabs(step); return;}
    if(*in < target) {*in += fabs(step); return;}
}

void pid_loop(PID *pid, float eurDesir, float measure)
{
    float err, diff;
    err = eurDesir - measure; //得到误差

    if(isnan(err)) { return; }

    diff = (err - pid->PreErr) / pid->Dt; //得到误差变化
    pid->PreErr = err;         //更新误差
    pid->EC = diff;


    pid->I_sum += err * pid->Dt;  //积分
    if(pid->I_sum > pid->I_max ) { pid->I_sum = pid->I_max; }
    if(pid->I_sum < -pid->I_max ) { pid->I_sum = -pid->I_max; } //抗饱和

    pid->Pout = pid->kp * err;
    pid->Iout = pid->ki * pid->I_sum;
    pid->Dout = pid->kd * diff;

    pid->Output = pid->Pout + pid->Dout + pid->Iout;
}

void pid_loop_TDD(PID *pid, float eurDesir, float tdd, float measure)
{
    float err, diff;
    err = eurDesir - measure; //得到误差

    if(isnan(err)) { return; }

    diff = tdd; //得到误差变化
    pid->PreErr = err;         //更新误差


    pid->I_sum += err * pid->Dt;  //积分
    if(pid->I_sum > pid->I_max ) { pid->I_sum = pid->I_max; }
    if(pid->I_sum < -pid->I_max ) { pid->I_sum = -pid->I_max; } //抗饱和

    pid->Pout = pid->kp * err;
    pid->Iout = pid->ki * pid->I_sum;
    pid->Dout = pid->kd * diff;


    pid->Output = pid->Pout + pid->Dout + pid->Iout;
}

const unsigned char crcMotoTbl[] =
{
    0x00, 0xE7, 0x29, 0xCE, 0x52, 0xB5, 0x7B, 0x9C, 0xA4, 0x43, 0x8D, 0x6A,
    0xF6, 0x11, 0xDF, 0x38, 0xAF, 0x48, 0x86, 0x61, 0xFD, 0x1A, 0xD4, 0x33,
    0x0B, 0xEC, 0x22, 0xC5, 0x59, 0xBE, 0x70, 0x97, 0xB9, 0x5E, 0x90, 0x77,
    0xEB, 0x0C, 0xC2, 0x25, 0x1D, 0xFA, 0x34, 0xD3, 0x4F, 0xA8, 0x66, 0x81,
    0x16, 0xF1, 0x3F, 0xD8, 0x44, 0xA3, 0x6D, 0x8A, 0xB2, 0x55, 0x9B, 0x7C,
    0xE0, 0x07, 0xC9, 0x2E, 0x95, 0x72, 0xBC, 0x5B, 0xC7, 0x20, 0xEE, 0x09,
    0x31, 0xD6, 0x18, 0xFF, 0x63, 0x84, 0x4A, 0xAD, 0x3A, 0xDD, 0x13, 0xF4,
    0x68, 0x8F, 0x41, 0xA6, 0x9E, 0x79, 0xB7, 0x50, 0xCC, 0x2B, 0xE5, 0x02,
    0x2C, 0xCB, 0x05, 0xE2, 0x7E, 0x99, 0x57, 0xB0, 0x88, 0x6F, 0xA1, 0x46,
    0xDA, 0x3D, 0xF3, 0x14, 0x83, 0x64, 0xAA, 0x4D, 0xD1, 0x36, 0xF8, 0x1F,
    0x27, 0xC0, 0x0E, 0xE9, 0x75, 0x92, 0x5C, 0xBB, 0xCD, 0x2A, 0xE4, 0x03,
    0x9F, 0x78, 0xB6, 0x51, 0x69, 0x8E, 0x40, 0xA7, 0x3B, 0xDC, 0x12, 0xF5,
    0x62, 0x85, 0x4B, 0xAC, 0x30, 0xD7, 0x19, 0xFE, 0xC6, 0x21, 0xEF, 0x08,
    0x94, 0x73, 0xBD, 0x5A, 0x74, 0x93, 0x5D, 0xBA, 0x26, 0xC1, 0x0F, 0xE8,
    0xD0, 0x37, 0xF9, 0x1E, 0x82, 0x65, 0xAB, 0x4C, 0xDB, 0x3C, 0xF2, 0x15,
    0x89, 0x6E, 0xA0, 0x47, 0x7F, 0x98, 0x56, 0xB1, 0x2D, 0xCA, 0x04, 0xE3,
    0x58, 0xBF, 0x71, 0x96, 0x0A, 0xED, 0x23, 0xC4, 0xFC, 0x1B, 0xD5, 0x32,
    0xAE, 0x49, 0x87, 0x60, 0xF7, 0x10, 0xDE, 0x39, 0xA5, 0x42, 0x8C, 0x6B,
    0x53, 0xB4, 0x7A, 0x9D, 0x01, 0xE6, 0x28, 0xCF, 0xE1, 0x06, 0xC8, 0x2F,
    0xB3, 0x54, 0x9A, 0x7D, 0x45, 0xA2, 0x6C, 0x8B, 0x17, 0xF0, 0x3E, 0xD9,
    0x4E, 0xA9, 0x67, 0x80, 0x1C, 0xFB, 0x35, 0xD2, 0xEA, 0x0D, 0xC3, 0x24,
    0xB8, 0x5F, 0x91, 0x76
};

unsigned char  crcMotoCal(unsigned char *buffer, unsigned int len)
{
    unsigned char crc = 0;
    for(unsigned int i = 0; i < len; i++)
    {
        crc =  crcMotoTbl[crc ^ buffer[i]];
    }
    return  crc;
}


const unsigned char crcRfTbl[] =
{
    0x00, 0x07, 0x0E, 0x09, 0x1C, 0x1B, 0x12, 0x15, 0x38, 0x3F, 0x36, 0x31, 0x24, 0x23, 0x2A, 0x2D,
    0x70, 0x77, 0x7E, 0x79, 0x6C, 0x6B, 0x62, 0x65, 0x48, 0x4F, 0x46, 0x41, 0x54, 0x53, 0x5A, 0x5D,
    0xE0, 0xE7, 0xEE, 0xE9, 0xFC, 0xFB, 0xF2, 0xF5, 0xD8, 0xDF, 0xD6, 0xD1, 0xC4, 0xC3, 0xCA, 0xCD,
    0x90, 0x97, 0x9E, 0x99, 0x8C, 0x8B, 0x82, 0x85, 0xA8, 0xAF, 0xA6, 0xA1, 0xB4, 0xB3, 0xBA, 0xBD,
    0xC7, 0xC0, 0xC9, 0xCE, 0xDB, 0xDC, 0xD5, 0xD2, 0xFF, 0xF8, 0xF1, 0xF6, 0xE3, 0xE4, 0xED, 0xEA,
    0xB7, 0xB0, 0xB9, 0xBE, 0xAB, 0xAC, 0xA5, 0xA2, 0x8F, 0x88, 0x81, 0x86, 0x93, 0x94, 0x9D, 0x9A,
    0x27, 0x20, 0x29, 0x2E, 0x3B, 0x3C, 0x35, 0x32, 0x1F, 0x18, 0x11, 0x16, 0x03, 0x04, 0x0D, 0x0A,
    0x57, 0x50, 0x59, 0x5E, 0x4B, 0x4C, 0x45, 0x42, 0x6F, 0x68, 0x61, 0x66, 0x73, 0x74, 0x7D, 0x7A,
    0x89, 0x8E, 0x87, 0x80, 0x95, 0x92, 0x9B, 0x9C, 0xB1, 0xB6, 0xBF, 0xB8, 0xAD, 0xAA, 0xA3, 0xA4,
    0xF9, 0xFE, 0xF7, 0xF0, 0xE5, 0xE2, 0xEB, 0xEC, 0xC1, 0xC6, 0xCF, 0xC8, 0xDD, 0xDA, 0xD3, 0xD4,
    0x69, 0x6E, 0x67, 0x60, 0x75, 0x72, 0x7B, 0x7C, 0x51, 0x56, 0x5F, 0x58, 0x4D, 0x4A, 0x43, 0x44,
    0x19, 0x1E, 0x17, 0x10, 0x05, 0x02, 0x0B, 0x0C, 0x21, 0x26, 0x2F, 0x28, 0x3D, 0x3A, 0x33, 0x34,
    0x4E, 0x49, 0x40, 0x47, 0x52, 0x55, 0x5C, 0x5B, 0x76, 0x71, 0x78, 0x7F, 0x6A, 0x6D, 0x64, 0x63,
    0x3E, 0x39, 0x30, 0x37, 0x22, 0x25, 0x2C, 0x2B, 0x06, 0x01, 0x08, 0x0F, 0x1A, 0x1D, 0x14, 0x13,
    0xAE, 0xA9, 0xA0, 0xA7, 0xB2, 0xB5, 0xBC, 0xBB, 0x96, 0x91, 0x98, 0x9F, 0x8A, 0x8D, 0x84, 0x83,
    0xDE, 0xD9, 0xD0, 0xD7, 0xC2, 0xC5, 0xCC, 0xCB, 0xE6, 0xE1, 0xE8, 0xEF, 0xFA, 0xFD, 0xF4, 0xF3
};


unsigned char  crcRfCal(unsigned char *buffer, unsigned int len)
{
    unsigned char crc = 0;
    for(unsigned int i = 0; i < len; i++)
    {
        crc =  crcRfTbl[crc ^ buffer[i]];
    }
    return  crc;
}


//冒泡排序，dir = 0 小到大  dir = 1 大到小
void sort(int *buffer, unsigned int len, unsigned char dir)
{
    if(len <= 1)
    {
        return ;
    }
    else
    {
        for(unsigned int i = 0; i < len - 1; i++)
        {
            for(unsigned int j = 0; j < len - 1 - i; j++)
            {
                if(dir == 0)
                {
                    if(buffer[j] > buffer[j + 1])
                    {
                        int temp;
                        temp = buffer[j];
                        buffer[j] = buffer[j + 1];
                        buffer[j + 1] = temp;
                    }
                }
                else
                {
                    if(buffer[j] < buffer[j + 1])
                    {
                        int temp;
                        temp = buffer[j];
                        buffer[j] = buffer[j + 1];
                        buffer[j + 1] = temp;
                    }
                }
            }
        }
    }
}

//快速排序
void Quick_Sort(int s[], int l, int r)
{
    if(l < r)
    {
        int32_t i = l, j = r, x = s[l];
        while(i < j)
        {
            while(i < j && s[j] >= x) { j--; }
            if(i < j) { s[i++] = s[j]; }
            while(i < j && s[i] < x) { i++; }
            if(i < j) { s[j--] = s[i]; }
        }
        s[i] = x;
        Quick_Sort(s, l, i - 1);
        Quick_Sort(s, i + 1, r);
    }
}

//线性变换
void linermap(const float L_max,   const float L_min,  \
              const float tar_max, const float tar_min, \
              float input_t, float *output_t)
{
    float input = constrain_float(input_t, L_min, L_max);
    float in_t = (input - L_min) / (L_max - L_min);

    *output_t =	tar_min + ( (tar_max - tar_min) * in_t);
}

void rotateV(FLOAT_XYZ *v, FLOAT_RPY *delta)
{
    FLOAT_XYZ v_tmp = *v;

    // This does a  "proper" matrix rotation using gyro deltas without small-angle approximation
    float mat[3][3];
    float cosx, sinx, cosy, siny, cosz, sinz;
    float coszcosx, coszcosy, sinzcosx, coszsinx, sinzsinx;

    cosx = cosf(-delta->Rool);
    sinx = sinf(-delta->Rool);
    cosy = cosf(-delta->Pitch);
    siny = sinf(-delta->Pitch);
    cosz = cosf(-delta->Yaw);
    sinz = sinf(-delta->Yaw);

    coszcosx = cosz * cosx;
    coszcosy = cosz * cosy;
    sinzcosx = sinz * cosx;
    coszsinx = sinx * cosz;
    sinzsinx = sinx * sinz;

    mat[0][0] = coszcosy;
    mat[0][1] = -cosy * sinz;
    mat[0][2] = siny;
    mat[1][0] = sinzcosx + (coszsinx * siny);
    mat[1][1] = coszcosx - (sinzsinx * siny);
    mat[1][2] = -sinx * cosy;
    mat[2][0] = (sinzsinx) - (coszcosx * siny);
    mat[2][1] = (coszsinx) + (sinzcosx * siny);
    mat[2][2] = cosy * cosx;

    v->X = v_tmp.X * mat[0][0] + v_tmp.Y * mat[1][0] + v_tmp.Z * mat[2][0];
    v->Y = v_tmp.X * mat[0][1] + v_tmp.Y * mat[1][1] + v_tmp.Z * mat[2][1];
    v->Z = v_tmp.X * mat[0][2] + v_tmp.Y * mat[1][2] + v_tmp.Z * mat[2][2];
}

/*====================================================================================================
	fst功能：最快反馈函数
	para:
	delta  速度因子，决定跟踪速度
	h      滤波因子，起对噪声的滤波作用
=====================================================================================*/
#define sign(n) (n==0?(0):(n<0?-1:1))

float fst(float x1, float x2, float delta, float h) // 最快控制函数
{
    float d, d0, y, a, a0;
    static float f;
    d = delta * h;
    d0 = h * d;
    y = x1 + h * x2;
    a0 = sqrt(d * d + 8 * delta * fabsf(y));

    if(fabsf(y) > d0)
    { a = x2 + (a0 - d) / 2 * sign(y); }
    else
    { a = x2 + y / h; }

    if(fabsf(a) > d)
    { f = -delta * sign(a); }
    else
    { f = -delta * a / d; }
    return f;
}

/*====================================================================================================
 ADRC_td功能：跟踪目标-提取微分值
 para:
 float_XYZ v_k  跟踪及微分的对象
 ADRC_str* adrc  跟踪到的值和微分值结构体

	adrc.delta 跟踪速度 几百几千,越大跟踪越紧
  adrc.h0 滤波 0-1     越大滤波越深
	adrc.dt 调用时间秒
	adrc.r1 跟踪后的结果
	adrc.r2 跟踪后的微分
=====================================================================================================*/

//float h0_t=0.05;      //速度因子，决定跟踪速度
//float delta_t=6000;  //滤波因子，起对噪声的滤波作用

void ADRC_td(float input , ADRC_str *adrc)
{
    float x1, x2, delta, h0;
    float h = adrc->dt;  //采样周期

    delta = adrc->delta;    //调整跟踪速度
    h0 = h + adrc->h0;     //对噪声滤波（h0>h），h0 = h 不进行滤波

    //------------X安排过渡过程----------------------------
    x1 = adrc->r1_pre - input;  //估计值与测量值的偏差
    x2 = adrc->r2_pre;  //估计的变化率

    adrc->r1 = adrc->r1_pre + h * adrc->r2_pre; //更新估计值
    adrc->r2 = adrc->r2_pre + h * fst(x1, x2, delta, h0); //更新估计变化率

    adrc->r1_pre = adrc->r1;
    adrc->r2_pre = adrc->r2;
}

/*=====================================================================================
fal功能：非线性函数
para:
d      阀值，决定曲线转折点
a      指数次方，决定曲线的形状
=====================================================================================*/
float fal(float z, float a, float d) // 非线性函数
{
    float out;
    float x1, x2;
    float a1 = 1 - a;

    x1 = powf(fabs(z), a);       //幂次方|z|^a
    x2 = powf(d, a1);            //幂次方d^a1

    if(fabsf(z) >= fabsf(d))
    {
        out = x1 * sign(z);
    }
    else
    {
        out = z / x2;
    }
    return (out);
}


//ESO状态观测器
void ADRC_ESO(ESO *t, float input_y)
{
    t->dt = 0.01;
    float e = (t->z1) - input_y;

    float z1p = t->z1;
    float z2p = t->z2;
    float z3p = t->z3;

    t->z3 = (z3p) - (t->dt) * (     t->B3  * fal( e,0.25,0.25));
    t->z2 = (z2p) + (t->dt) * (z3p - t->B2 * fal( e,0.5,0.25));
    t->z1 = (z1p) + (t->dt) * (z2p - t->B1 * e);
}

/*
非线性反馈调整
使用fal函数得到“小误差大增益，大误差小增益”的效果，改善动态性能和抑制超调

*input  输入待转换的误差
*return 返回转换后的误差

*sw 输入大小增益切换点，在函数上表现为（1，1）点。如：误差5为切换点，小于5使用大增益，大于5使用小增益，则5为（1，1）点
*a输入fal次幂0-1，一般选取0.5~0.9
*h输入死区0-1，一般为0.2~0.8
*/
float fal_GAIN(float input, float sw, float a, float h)
{
	return sw * fal(input / fabsf(sw), a, h);
}

/*
非线性PID调整 基于sech(x)函数

使用cp放大或者缩小ex输入到sech函数.范围0-5左右,输出值为1~0之间

输入3时   结果为0.1
输入1时   结果为0.68
输入0.5时 结果为0.88
输入0.1时 结果为0.99
*/
float PID_sech(float ex_input, float cp)
{
	return 1.0f/coshf(fabsf(ex_input)*cp);
}

/**
  * @brief  quadric curve control function.
  * @param  *pCurve: pointer to a QuadCurve structure.
  * @retval Running status.
  */
uint8_t QuadCurveCtrl(QuadCurve *pCurve, uint8_t Condition)
{
	float DisToExp = fabsf(pCurve->expPos - pCurve->Pos);//distance to expectation.
	float DecDist = (pCurve->Vel * pCurve->Vel) / (2 * pCurve->Acc);//deceleration distance.
	float dVel = pCurve->Acc * pCurve->dt * GETDIR(pCurve->expPos, pCurve->Pos);
	if(pCurve->expPos == pCurve->Pos || ((pCurve->expPos - pCurve->Pos) * (pCurve->expPos - pCurve->LastPos) < 0))//stop point.
	{
		pCurve->Vel = 0;
		pCurve->LastPos = pCurve->Pos;
		pCurve->Pos = pCurve->expPos;
		return 0;//got expPos.
	}
	if(DisToExp <= DecDist || (Condition == 0))//close to expectation
	{
		if(Condition == 1)
		{
			float A = (pCurve->Vel * pCurve->Vel) / (2 * DisToExp);
			dVel = A * pCurve->dt * GETDIR(pCurve->expPos, pCurve->Pos);
		}
		if(fabsf(pCurve->Vel) > 2 * fabsf(dVel))
			pCurve->Vel -= 2 * fabsf(dVel) * SGN(pCurve->Vel);
		else
		{
			pCurve->Vel = 0;
			return 0;
		}
	}
	else
	{
		if(pCurve->velMax != 0)//has velmax limit.
		{
			if(fabsf(pCurve->Vel + dVel) < pCurve->velMax)
				pCurve->Vel += dVel;
			else
				pCurve->Vel = SGN(pCurve->Vel) * pCurve->velMax;
		}
		else
			pCurve->Vel += dVel;
	}

	pCurve->LastPos = pCurve->Pos;
	pCurve->Pos += pCurve->Vel * pCurve->dt;

	return 1;
}
