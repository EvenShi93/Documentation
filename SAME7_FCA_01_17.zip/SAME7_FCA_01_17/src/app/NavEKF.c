#include "NavEKF.h"
#include "maths.h"
#include "position_task.h"
#include "TimeCounter.h"

/******************************************************************************/
extern float BaroAlt;
extern float zero_alt;

extern float  Debug_Param[15];
/*****************************************************************************/
float VelNE_NOISE = 10;
float VelD_NOISE = 0.7f;
float PosNE_NOISE = 5.0f;
float Alt_NOISE = 1.5f;
float Acc_NOISE = 0.2f;

uint8_t Vel_GATE = 5;
uint8_t Pos_GATE = 10;
uint8_t Hgt_GATE = 10;

float states[6] = {0};

float vel_accx;
float vel_accy;
float vel_accz;

uint16_t GetACCPoffset = 400;

extern FLOAT_XYZ accEF;

void ins_to_ned(void)	
{
	vel_accx = -accEF.X;
	vel_accy = -accEF.Y;
	vel_accz = -accEF.Z;
}

uint8_t fuseVelData = 0;
uint8_t fusePosData = 0;
uint8_t fuseHgtData = 0;

// select fusion of GPS velocity, position and height measurements
void NavEKF_SelectVelPosFusion(void)           //��NavEKF_FuseVelPosNED()��ʹ��
{
    if(gps_update_1time && (GPS_IsReady() == 1))//gps ready & updated.
	{
        fuseVelData = 1;
        fusePosData = 1;
    }
    else
	{
        fuseVelData = 0;
        fusePosData = 0;
    }

	fuseHgtData = true;
}

// constrain states to prevent ill-conditioning
void NavEKF_ConstrainStates()
{
	// velocity limit 500 m/sec (could set this based on some multiple of max airspeed * EAS2TAS)
	for (uint8_t i = 0; i <= 2; i ++) 
		states[i] = constrain_float(states[i], -5.0e2f, 5.0e2f);
	// position limit 1000 km - TODO apply circular limit
	for (uint8_t i = 3; i <= 4; i ++) 
		states[i] = constrain_float(states[i], -1.0e6f, 1.0e6f);
	// height limit covers home alt on everest through to home alt at SL and ballon drop
	states[5] = constrain_float(states[5], -4.0e4f, 1.0e4f);
}

float dt = 0.01f;
//extern uint16_t ekfdt;
// update the velocity and position states using IMU measurements
void NavEKF_UpdateStrapdownEquationsNED()
{
	ins_to_ned();
//	static uint32_t ekft=0;
//	ekfdt=_Get_Micros()- ekft;
//	ekft=_Get_Micros();
	states[0] += vel_accx * dt;
	states[1] += vel_accy * dt;
	states[2] += vel_accz * dt;
	states[3] += states[0] * dt;
	states[4] += states[1] * dt;
	states[5] += states[2] * dt;

	// limit states to protect against divergence
	NavEKF_ConstrainStates();
}

float P[6][6] = {{0.01,0,0,0,0,0 },{0,0.01,0,0,0,0},{0,0,0.01,0,0,0},{0,0,0,4,0,0},{0,0,0,0,4,0},{0,0,0,0,0,4}};//����Э�������
//float nextP[6][6] = {{0,0,0,0,0,0 },{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}};//����Э�������

// calculate the predicted state covariance matrix
void NavEKF_CovariancePrediction()
{
	float dvxCov;       // X axis delta velocity variance (m/s)^2
	float dvyCov;       // Y axis delta velocity variance (m/s)^2
	float dvzCov;       // Z axis delta velocity variance (m/s)^2

	float nextP[6][6] = {{ 0,0,0,0,0,0 },{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}};   //����Э�������
	float processNoise[6] = {0,0,0,0,0,0};

	// auto adjust bias process noise according to the current offsets learned from temperature calibration
	for (uint8_t i = 0; i <= 5; i ++)
	{
		processNoise[i] = 1.0e-9f;
	}

    // accelerometer noise.
	Acc_NOISE = constrain_float(Acc_NOISE, 0.005, 100);
	dvxCov = Acc_NOISE * Acc_NOISE;
	dvyCov = Acc_NOISE * Acc_NOISE;
	dvzCov = Acc_NOISE * Acc_NOISE;

    // calculate the predicted covariance due to inertial sensor error propagation
    nextP[0][0] = P[0][0] + dvxCov;
    nextP[0][1] = P[0][1];
    nextP[0][2] = P[0][2];
    nextP[0][3] = P[0][3] + P[0][0]*dt;
    nextP[0][4] = P[0][4] + P[0][1]*dt;
    nextP[0][5] = P[0][5] + P[0][2]*dt;
    nextP[1][0] = P[1][0];
    nextP[1][1] = P[1][1] + dvyCov;
    nextP[1][2] = P[1][2];
    nextP[1][3] = P[1][3] + P[1][0]*dt;
    nextP[1][4] = P[1][4] + P[1][1]*dt;
    nextP[1][5] = P[1][5] + P[1][2]*dt;
    nextP[2][0] = P[2][0];
    nextP[2][1] = P[2][1];
    nextP[2][2] = P[2][2] + dvzCov;
    nextP[2][3] = P[2][3] + P[2][0]*dt;
    nextP[2][4] = P[2][4] + P[2][1]*dt;
    nextP[2][5] = P[2][5] + P[2][2]*dt;
    nextP[3][0] = P[3][0] + P[0][0]*dt;
    nextP[3][1] = P[3][1] + P[0][1]*dt;
    nextP[3][2] = P[3][2] + P[0][2]*dt;
    nextP[3][3] = P[3][3] + P[0][3]*dt + dt*(P[3][0] + P[0][0]*dt);
    nextP[3][4] = P[3][4] + P[0][4]*dt + dt*(P[3][1] + P[0][1]*dt);
    nextP[3][5] = P[3][5] + P[0][5]*dt + dt*(P[3][2] + P[0][2]*dt);
    nextP[4][0] = P[4][0] + P[1][0]*dt;
    nextP[4][1] = P[4][1] + P[1][1]*dt;
    nextP[4][2] = P[4][2] + P[1][2]*dt;
    nextP[4][3] = P[4][3] + P[1][3]*dt + dt*(P[4][0] + P[1][0]*dt);
    nextP[4][4] = P[4][4] + P[1][4]*dt + dt*(P[4][1] + P[1][1]*dt);
    nextP[4][5] = P[4][5] + P[1][5]*dt + dt*(P[4][2] + P[1][2]*dt);
    nextP[5][0] = P[5][0] + P[2][0]*dt;
    nextP[5][1] = P[5][1] + P[2][1]*dt;
    nextP[5][2] = P[5][2] + P[2][2]*dt;
    nextP[5][3] = P[5][3] + P[2][3]*dt + dt*(P[5][0] + P[2][0]*dt);
    nextP[5][4] = P[5][4] + P[2][4]*dt + dt*(P[5][1] + P[2][1]*dt);
    nextP[5][5] = P[5][5] + P[2][5]*dt + dt*(P[5][2] + P[2][2]*dt);

    // add the general state process noise variances
    for (uint8_t i=0; i<= 5; i++)
    {
        nextP[i][i] = nextP[i][i] + processNoise[i];
    }

    // if the total position variance exceeds 1e4 (100m), then stop covariance growth by setting the predicted to the previous values
    // This prevent an ill conditioned matrix from occurring for long periodswithout GPS
    if ((P[3][3] + P[4][4]) > 1e4f)
    {
        for (uint8_t i=3; i<=4; i++)
        {
            for (uint8_t j=0; j<=5; j++)
            {
                nextP[i][j] = P[i][j];
                nextP[j][i] = P[j][i];
            }
        }
    }

	// copy covariances to output and fix numerical errors
	//NavEKF_CopyAndFixCovariances();
	for (uint8_t i = 0; i <= 5; i ++)
	{
		P[i][i] = nextP[i][i];
	}
	// copy predicted covariances and force symmetry
	for (uint8_t i = 1; i <= 5; i ++)
	{
		for (uint8_t j = 0; j <= i - 1; j ++)
		{
			P[i][j] = 0.5f * (nextP[i][j] + nextP[j][i]);
			P[j][i] = P[i][j];
		}
	}

    // constrain diagonals to prevent ill-conditioning
    //NavEKF_ConstrainVariances();
	for(uint8_t i = 0; i <= 2; i ++) P[i][i] = constrain_float(P[i][i], 0.0f, 1.0e3f); // velocities
	for(uint8_t i = 3; i <= 5; i ++) P[i][i] = constrain_float(P[i][i], 0.0f, 1.0e6f); // positions
}

// force symmetry on the covariance matrix to prevent ill-conditioning
void NavEKF_ForceSymmetry()
{
    for (uint8_t i = 1; i <= 5; i ++)
    {
        for (uint8_t j = 0; j <= i-1; j ++)
        {
            float temp = 0.5f * (P[i][j] + P[j][i]);
            P[i][j] = temp;
            P[j][i] = temp;
        }
    }
}

float observation[6] = {0,0,0,0,0,0};
float innovVelPos[6] = {0,0,0,0,0,0};
float R_OBS[6] = {0,0,0,0,0,0};
float varInnovVelPos[6] = {0,0,0,0,0,0};

float Kfusion[6] = {0,0,0,0,0,0};

uint8_t obsIndex;

extern GPS_DATA* gpsData;
extern double lon_origin, lat_origin;
extern float pressureAlt;

// fuse selected position, velocity and height measurements
void NavEKF_FuseVelPosNED()
{
	// health is set bad until test passed
//	uint8_t velHealth = false;
//	uint8_t posHealth = false;
//	uint8_t hgtHealth = false;

	// declare variables used to control access to arrays
	uint8_t stateIndex;

	float R_OBS_DATA_CHECKS[6] = {0,0,0,0,0,0};

	float SK;
	//float Kfusion[6]={0,0,0,0,0,0};
	float KHP[6][6] = {{0,0,0,0,0,0 }, {0,0,0,0,0,0}, {0,0,0,0,0,0}, {0,0,0,0,0,0}, {0,0,0,0,0,0}, {0,0,0,0,0,0}};


	//unit m
	observation[0] = gpsData->velN * 0.01f;
	observation[1] = gpsData->velE * 0.01f;
	observation[2] = gpsData->velD * 0.01f;
	observation[3] = GetGPSPoint()->X * 0.01f;
	observation[4] = GetGPSPoint()->Y * 0.01f;
	observation[5] = pressureAlt * 0.01f;

    // estimate the GPS Velocity, GPS horiz position and height measurement variances.
    // if the GPS is able to report a speed error, we use it to adjust the observation noise for GPS velocity
    // otherwise we scale it using manoeuvre acceleration
    float gpsSpdAccuracy = 0.0f;

    gpsSpdAccuracy = gpsData->hAcc * 0.01f;

  if(gpsSpdAccuracy > 0.0f)
	{
		// use GPS receivers reported speed accuracy - floor at value set by gps noise parameter
		R_OBS[0] = SQ_t(constrain_float(gpsSpdAccuracy, VelNE_NOISE, 100.0f));
		//R_OBS[0] = sq_t(constrain(VelNE_NOISE, 0.05f, 5.0f));
		R_OBS[2] = SQ_t(constrain_float(VelD_NOISE, 0.05f, 50.0f));
	}
	else
	{
		// calculate additional error in GPS velocity caused by manoeuvring
		R_OBS[0] = SQ_t(constrain_float(VelNE_NOISE, 0.05f, 50.0f));
		R_OBS[2] = SQ_t(constrain_float(VelD_NOISE,  0.05f, 50.0f));
	}
	R_OBS[1] = R_OBS[0];
	R_OBS[3] = SQ_t(constrain_float(PosNE_NOISE, 0.1f, 100.0f));
	R_OBS[4] = R_OBS[3];
	R_OBS[5] = SQ_t(constrain_float(Alt_NOISE, 0.1f, 10.0f));

    // For data integrity checks we use the same measurement variances as used to calculate the Kalman gains for all measurements except GPS horizontal velocity
    // For horizontal GPs velocity we don't want the acceptance radius to increase with reported GPS accuracy so we use a value based on best GPS perfomrance
    for (uint8_t i = 0; i <= 1; i ++) R_OBS_DATA_CHECKS[i] = SQ_t(constrain_float(VelNE_NOISE, 0.05f, 5.0f));
    for (uint8_t i = 2; i <= 5; i ++) R_OBS_DATA_CHECKS[i] = R_OBS[i];

    if(gps_update_1time)//fuseVelData
	  {
        innovVelPos[0] = states[0] - observation[0];
        innovVelPos[1] = states[1] - observation[1];
        innovVelPos[2] = states[2] - observation[2];
        varInnovVelPos[0] = P[0][0] + R_OBS_DATA_CHECKS[0];
        varInnovVelPos[1] = P[1][1] + R_OBS_DATA_CHECKS[1];
        varInnovVelPos[2] = P[2][2] + R_OBS_DATA_CHECKS[2];
        // apply an innovation consistency threshold test, calculate max valid position innovation squared based on a maximum horizontal inertial nav accel error and GPS noise parameter
        // max inertial nav error is scaled with horizontal g to allow for increased errors when manoeuvring
        float innovVelSumSq = 0; // sum of squares of velocity innovations
        float varVelSum = 0; // sum of velocity innovation variances
        for (uint8_t i = 0; i <= 2; i ++)
		    {
            // sum the innovation and innovation variances
            innovVelSumSq += innovVelPos[i] * innovVelPos[i];
            varVelSum += varInnovVelPos[i];
        }
//        velTestRatio = innovVelSumSq / (varVelSum * Vel_GATE * Vel_GATE);
//        velHealth = (velTestRatio < 1.0f);
	  }

    // calculate innovations and check GPS data validity using an innovation consistency check test position measurements
//    if(fusePosData)
	{
		observation[3] += states[0] * 0.01f;
		observation[4] += states[1] * 0.01f;
        // test horizontal position measurements
        innovVelPos[3] = states[3] - observation[3];
        innovVelPos[4] = states[4] - observation[4];
        varInnovVelPos[3] = P[3][3] + R_OBS_DATA_CHECKS[3];
        varInnovVelPos[4] = P[4][4] + R_OBS_DATA_CHECKS[4];

        float maxPosInnov2 = SQ_t(Pos_GATE * PosNE_NOISE);
//        posTestRatio = (SQ_t(innovVelPos[3]) + SQ_t(innovVelPos[4])) / maxPosInnov2;
//        posHealth = (posTestRatio < 1.0f);
    }

    // test height measurements
//    if(fuseHgtData)
	{
        // calculate height innovations
        innovVelPos[5] = states[5] - observation[5];

        varInnovVelPos[5] = P[5][5] + R_OBS_DATA_CHECKS[5];
        // calculate the innovation consistency test ratio
//        hgtTestRatio = SQ_t(innovVelPos[5]) / (SQ_t(Hgt_GATE) * varInnovVelPos[5]);
        // fail if the ratio is > 1, but don't fail if bad IMU data
//        hgtHealth = (hgtTestRatio < 1.0f);
    }

    // fuse measurements sequentially
    for (obsIndex = 0; obsIndex <= 5; obsIndex ++)
	{
        stateIndex = obsIndex;
        // calculate the measurement innovation
        innovVelPos[obsIndex] = states[obsIndex] - observation[obsIndex];

        // calculate the Kalman gain and calculate innovation variances
        varInnovVelPos[obsIndex] = P[stateIndex][stateIndex] + R_OBS[obsIndex];
        SK = 1.0f/varInnovVelPos[obsIndex];

        for(uint8_t i = 0; i <= 5; i ++)
		{
            Kfusion[i] = P[i][stateIndex] * SK;
        }

        // calculate state corrections
        for (uint8_t i = 0; i <= 5; i ++)
		{
			//test_ekf[i] = Kfusion[i] * innovVelPos[obsIndex];
            states[i] = states[i] - Kfusion[i] * innovVelPos[obsIndex];
        }

        // update the covariance - take advantage of direct observation of a single state at index = stateIndex to reduce computations
        // this is a numerically optimised implementation of standard equation P = (I - K*H)*P;
        for (uint8_t i = 0; i <= 5; i ++)
		{
            for (uint8_t j = 0; j <= 5; j ++)
            {
                KHP[i][j] = Kfusion[i] * P[stateIndex][j];
            }
        }
        for (uint8_t i = 0; i <= 5; i ++)
		{
            for (uint8_t j = 0; j <= 5; j ++)
			{
                P[i][j] = P[i][j] - KHP[i][j];
            }
        }
    }

    // force the covariance matrix to be symmetrical and limit the variances to prevent ill-condiioning.
    NavEKF_ForceSymmetry();        
    //NavEKF_CopyAndFixCovariances();
    // copy predicted variances
	  for (uint8_t i = 0; i <= 2; i ++)
		P[i][i] = constrain_float(P[i][i], 0.0f, 1.0e3f); // velocities
    for (uint8_t i = 3; i <= 5; i ++)
		P[i][i] = constrain_float(P[i][i], 0.0f, 1.0e6f); // positions
}

void NavEKFThread(void)
{
	if(GPS_IsReady() == 1)
	{
		NavEKF_UpdateStrapdownEquationsNED();
		NavEKF_CovariancePrediction();
		NavEKF_FuseVelPosNED();
	}
}
