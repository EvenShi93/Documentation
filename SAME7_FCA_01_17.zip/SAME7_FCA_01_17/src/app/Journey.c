#include "Journey.h"

#define JOURNEY_DT 0.01f
#define JOURNEY_MAX_VEL 250  /* 2.5m/s */
#define JOURNEY_MAX_ACC 1.5f /* 1.5m/s^2 */

static JourneyParam Journey = {0};
static QuadCurve JourneyCurve = {0};

static JourneyRunSta JourneyRun = AtPoint_A;
static JourneyCmdSta JourneyCmd = JourneyStop;
static JourneyCmdSta LastJouneryCmd = JourneyStop;

static float JourLmtCoef = 1.0f;
static float JourMaxVel = JOURNEY_MAX_VEL;
static float JourMaxAcc = JOURNEY_MAX_ACC;

static float cosJourAng, sinJourAng;
static float cosJourneyYaw, sinJourneyYaw;

static _3AxisFloat JourExpPot = {0, 0, 0};
static _3AxisFloat JourExpVel = {0, 0, 0};

static float JourneyExpAlt = 0.0f;
static float JourneyAltVel = 0.0f;

static uint8_t JourneyExitFlag = 0;
static uint8_t AutoLandLockFlag = 0;

Quat JOURNEY_PositionLoop_Q;

static void GetPointAct(void);
static void JourneyExpAltPos(void);

void JourneyTask(void)
{
	OS_ALLOC_SR();
    OS_ENTER_CRITICAL();
	static unsigned char oldRFMode = RFMODE_9AXIE;
	unsigned char curRFMode = RFMode;
	OS_EXIT_CRITICAL();

	if(oldRFMode != curRFMode && curRFMode == RFMODE_JOURNEY)
	{
		JourneyRunSet(JourneyStop);

		cosJourAng = 1;//0 deg
		sinJourAng = 0;
		JourLmtCoef = 1.0f;
		JourMaxVel = JOURNEY_MAX_VEL * JourLmtCoef;
		JourMaxAcc = JOURNEY_MAX_ACC * JourLmtCoef;

		JourExpPot.X = JourExpPot.Y = JourExpPot.Z = 0;
		JourExpVel.X = JourExpVel.Y = JourExpVel.Z = 0;

		Journey.StartX = PH.pos_target_x;//Start point.
		Journey.StartY = PH.pos_target_y;
		Journey.StartZ = CurExpAlt();//Start Alt.

		JourneyCurve.Acc = JourMaxAcc * 100;
		JourneyCurve.velMax = JourMaxVel;
		JourneyCurve.Pos = 0;
		JourneyCurve.Vel = 0;
		JourneyCurve.LastPos = 0;
		JourneyCurve.expPos = 0;
		JourneyCurve.dt = JOURNEY_DT;

		JourneyRun = AtPoint_A;
		JourneyExitFlag = 0;
		AutoLandLockFlag = 0;
	}
	oldRFMode = curRFMode;
	if(curRFMode == RFMODE_JOURNEY)
	{
		if(POS_KP < 0.8f)
			POS_KP += 0.004f;

		if(JourneyCmd == JourneyStart && LastJouneryCmd != JourneyCmd)//Journey start cmd.
		{
			if(JourneyRun == AtPoint_A)//Drone at start point.
			{
				cosJourAng = cosf(Journey.Angle * (float)DEG_TO_RAD);//Journey Ang.
				sinJourAng = sinf(Journey.Angle * (float)DEG_TO_RAD);
				GetTrigYaw(&sinJourneyYaw, &cosJourneyYaw);

				JourLmtCoef = 1.0f - (Journey.Angle / 225.0f);//vel & acc limit.
				JourMaxVel = JOURNEY_MAX_VEL * JourLmtCoef;
				JourMaxAcc = JOURNEY_MAX_ACC * JourLmtCoef;

				Journey.StartX = PH.pos_target_x;//start point x.
				Journey.StartY = PH.pos_target_y;//start point y.
				Journey.StartZ = CurExpAlt();//start alt.

				JourneyCurve.Acc = JourMaxAcc * 100;
				JourneyCurve.velMax = JourMaxVel;
				JourneyCurve.Pos = 0;
				JourneyCurve.Vel = 0;
				JourneyCurve.LastPos = 0;
				JourneyCurve.expPos = Journey.Length;

				JourneyRun = StartFrom_A;
				JourneyExitFlag = 0;
				AutoLandLockFlag = 0;
			}
		}
		else if(JourneyCmd == JourneyStop && LastJouneryCmd != JourneyCmd)//Journey stop cmd.
		{
			if(JourneyRun != AtPoint_A)
			{
				JourneyCmd = JourneyStart;
				if(JourneyRun == StartFrom_A)
					JourneyExitFlag = 1;//stop Journey.
			}
		}
		LastJouneryCmd = JourneyCmd;

		if(GoHomeModeExit() == 0)
			JourneyExpAltPos();
		Pos_to_rate_xy(JourExpVel.X/2, JourExpVel.Y/2);
        Rate_to_accel_xy(0, 0);

		ComputePositionQuat();

		if(JourneyCmd == JourneyStop)
			SetAppsShowDist(0.0f);
		else if(JourneyCmd == JourneyStart)
			SetAppsShowDist(JourneyCurve.Pos);
	}
}

static void JourneyExpAltPos(void)
{
    Sonar SonarInfo = GetSonicDistance();
	//312.5f * JourLmtCoef = ((JOURNEY_MAX_VEL * JourLmtCoef) * (JOURNEY_MAX_VEL * JourLmtCoef) / (200 * JOURNEY_MAX_ACC * JourLmtCoef)) * 1.5f;
	if(GetAutoLandSta() == 1) AutoLandLockFlag = 1;
	if((IsDropOutElecFence() || IsOverrangeAltLimit() || IsEntryNFZ_2() || \
		(IsEntryNFZ_1() && CurExpAlt() >= 2000)) && JourneyRun == StartFrom_A) JourneyExitFlag = 1;
    uint8_t Cond = !((JourneyExitFlag == 1) || (AutoLandLockFlag == 1) || \
                     (SonarInfo.distance_valid && (SonarInfo.sonar_distance_filtered * 100 - 50.0f) <= 312.5f * JourLmtCoef * sinJourAng && JourneyRun == StartFrom_B));

    if(QuadCurveCtrl(&JourneyCurve, Cond) == 0)//test:need delay any time?
        GetPointAct();

	if(JourneyCmd == JourneyStart)
	{
		JourExpVel.X = -JourneyCurve.Vel * cosJourAng * cosJourneyYaw;
		JourExpVel.Y = -JourneyCurve.Vel * cosJourAng * sinJourneyYaw;
		JourneyAltVel = JourExpVel.Z = JourneyCurve.Vel * sinJourAng;

		JourExpPot.X = -JourneyCurve.Pos * cosJourAng * cosJourneyYaw;
		JourExpPot.Y = -JourneyCurve.Pos * cosJourAng * sinJourneyYaw;
		JourExpPot.Z = JourneyCurve.Pos * sinJourAng;

		PH.pos_exp_x = Journey.StartX + JourExpPot.X;
		PH.pos_exp_y = Journey.StartY + JourExpPot.Y;
		JourneyExpAlt = Journey.StartZ + JourExpPot.Z;
	}
	if(GetAutoLandSta() == 0 && (JourneyCmd != JourneyStop))//test:entry autoland then cancel quickly?
		SetExp_Alt_Vel(JourneyExpAlt, 0);
	else
		JourneyExpAlt = CurExpAlt();
}

static void GetPointAct(void)
{
	if(JourneyRun == StartFrom_A)
	{
		if(AutoLandLockFlag == 0)
		{
			JourneyCurve.expPos = 0;
			JourneyRun = StartFrom_B;
		}
		else
		{
			JourneyRun = AtPoint_A;
			JourneyCmd = JourneyStop;
		}
	}
	else if(JourneyRun == StartFrom_B)
	{
		JourneyRun = AtPoint_A;
		JourneyCmd = JourneyStop;
	}
	JourneyExitFlag = 0;
	AutoLandLockFlag = 0;
}

inline float JourneyModeExpAltVel(void)
{
	float temp = JourneyAltVel;
	JourneyAltVel = 0.0f;
	return temp;
}

void JourneyRunSet(JourneyCmdSta JourneySta)
{
	JourneyCmd = JourneySta;
}

JourneyCmdSta JourneyRunGet(void)
{
	return JourneyCmd;
}

void JourneySetParam(float Length, float Angle)
{
	Journey.Length = Length;
	Journey.Angle = Angle;
}
