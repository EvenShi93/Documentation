#ifndef __NAVEKF_H
#define __NAVEKF_H

#include "PosEst.h"

#define SQ_t(x) ((x) * (x))

extern float states[6];
extern float Acc_NOISE;
extern float VelNE_NOISE;
extern float PosNE_NOISE;

//bool NavEKF_healthy(void);
void NavEKF_SelectVelPosFusion(void);
void NavEKF_UpdateStrapdownEquationsNED(void);
void NavEKF_CovariancePrediction(void);
void NavEKF_FuseVelPosNED(void);
void NavEKFThread(void);

#endif /* __NAVEKF_H */
