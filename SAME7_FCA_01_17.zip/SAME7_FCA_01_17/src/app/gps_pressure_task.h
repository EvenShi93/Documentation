#ifndef _GPS_PRESSURE_TASK_H_
#define _GPS_PRESSURE_TASK_H_

#include "middleware.h"

extern GPS_DATA *gpsData;
extern uint8_t gps_update_1time;

void gps_10ms_task(void);
float GetPressureVal(void);
void pressure_10ms_task(void);

#endif
