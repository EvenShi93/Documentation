#ifndef _SMART_TASK_H_
#define _SMART_TASK_H_

#include "position_task.h"

void smart_10ms_task(void);

#endif
