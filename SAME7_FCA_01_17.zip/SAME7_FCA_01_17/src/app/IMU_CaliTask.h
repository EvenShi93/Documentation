#ifndef __IMU_CALITASK_H
#define __IMU_CALITASK_H

#include "app.h"
#include "attitude_task.h"

void IMUCaliTask(void);
void MagCalCmdDetect(void);
uint8_t GetSampleStat(void);
void StartMagCalibrate(void);
uint8_t MagCalibrateSta(void);
void GetMagCalSta(uint8_t *Param);
void mag_calibration_100ms_task(void);

void MagCalGyrIntegTask(void);

#endif /* __IMU_CALITASK_H */
