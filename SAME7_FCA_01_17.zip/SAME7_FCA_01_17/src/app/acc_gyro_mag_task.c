#include "acc_gyro_mag_task.h"
#include "volt_switch_task.h"

FLOAT_ACC* accUnit;
FLOAT_GYRO* gyroUnit;
FLOAT_MAG* magUnit;

float IMU_temperature = 0;

unsigned char IMU_temp[2] = {0};

void acc_gyro_1ms_task(void)
{
	if(GetPowerStat() == POWER_ON)
	{
		acc_gyro_temp_M_task();

		accUnit = get_acc_unit();
		gyroUnit = get_gyro_unit();

		IMU_temperature = get_IMUtemperature_unit() * 0.05f + IMU_temperature * 0.95f;
	}
}

void mag_5ms_task(void)
{
    magM_task();
    magUnit = get_mag();
}
