#ifndef _MOTO_TASK_H_
#define _MOTO_TASK_H_

#include "middleware.h"

#define ToneRunFlag 0x80000000

typedef struct
{
    uint16_t freq;
    uint16_t len;
    uint8_t pwr;
    uint16_t Delay;
    uint16_t Times;
} ToneType;

void moto_1ms_task(void);
uint8_t GetToneSta(void);
void ClrToneReq(void);
void SetToneCmd(ToneCmd Cmd);
void ClrToneCmd(ToneCmd Cmd);
uint8_t GetMotorErrFlag(void);

#endif
