#include "position_task.h"

#define PosHold_DT 0.01f

Nav_struct_PosHold PH;
PID PH_Rate_x, PH_Rate_y;

Quat PositionLoop_Q;

float _leash = 500;                 //定位环最大误差为5m
float vel_max = 500;                //定位环最大目标速度5m/s
float MAX_speed_cms = 500;          //摇杆量为期望机体运动加速度，通过积分和坐标转化为xy系期望速度和位置，并带饱和限制,并自动刹车

float cosYaw, sinYaw;
float BF_X = 0, BF_Y = 0;

float POS_KP = 0.8f; //位置环增益
float BrakeSpeed = 600;

ADRC_str Vel_xTD = { .dt = 0.01f, .h0 = 0.005f, .delta = 800 };//初始化
ADRC_str Vel_yTD = { .dt = 0.01f, .h0 = 0.005f, .delta = 800 };
ADRC_str vLoop_xTD = { .dt = 0.01f, .h0 = 0.01f, .delta = 8000 };
ADRC_str vLoop_yTD = { .dt = 0.01f, .h0 = 0.01f, .delta = 8000 };

void position_param_clear(void)
{
    PH.pos_exp_x = PH.pos_exp_y = 0;
    PH.pos_target_x = PH.pos_target_y = 0;
	PH.vel_exp_x = PH.vel_exp_y = 0;
	PH.vel_target_x = PH.vel_target_y = 0;
	PH.acc_exp_x = PH.acc_exp_y = 0;
    PH.accel_target_x  = PH.accel_target_y  = 0;
    PH_Rate_x.I_sum = PH_Rate_y.I_sum = 0;

    PosEst_x = PosEst_y = 0;
	velRateCorr_x = velRateCorr_y = 0;
}

void pid_PH_init(void)
{
//    PH_Rate_x.kp = 6.0f;
//    PH_Rate_x.kd = 0.1f;
//    PH_Rate_x.ki = 1.8f;
//    PH_Rate_x.I_max = 100;
//    PH_Rate_x.Dt = 0.01f;

    PH_Rate_x.kp = 6.2f;
    PH_Rate_x.kd = 0.0f;
    PH_Rate_x.ki = 1.4f;
    PH_Rate_x.I_max = 120;
    PH_Rate_x.Dt = 0.01f;

    PH_Rate_y.kp = PH_Rate_x.kp;
    PH_Rate_y.kd = PH_Rate_x.kd;
    PH_Rate_y.ki = PH_Rate_x.ki;
    PH_Rate_y.I_max = PH_Rate_x.I_max ;
    PH_Rate_y.Dt = PH_Rate_x.Dt ;

    Vel_xTD.dt = Vel_yTD.dt = 0.01f;
    Vel_xTD.h0 = Vel_yTD.h0 = 0.005f;
    Vel_xTD.delta = Vel_yTD.delta = BrakeSpeed;

    vLoop_xTD.dt = vLoop_yTD.dt = 0.01f;
    vLoop_xTD.h0 = vLoop_yTD.h0 = 0.01f;
    vLoop_xTD.delta = vLoop_yTD.delta = 8000;
}

void PID_PosHold_Vel(PID *pid, float VelDesir, float tdd , float measure, float *Output)
{
    float Err, Diff;

    Err = measure - VelDesir;//得到误差
    Diff = tdd;

    pid->PreErr = Err;//更新前次误差

    pid->I_sum += (Err * pid->Dt);
    if(pid->I_sum > pid->I_max) { pid->I_sum = pid->I_max; }
    if(pid->I_sum < -pid->I_max) { pid->I_sum = -pid->I_max; } //抗饱和

    pid->Pout = pid->kp * Err;
    pid->Iout = pid->ki * pid->I_sum;
    pid->Dout = pid->kd * Diff;

    *Output = pid->Pout + pid->Iout + pid->Dout;
}

float RCdesired_accel_x = 0, RCdesired_accel_y = 0;
float RC_velDesired_x = 0, RC_velDesired_y = 0;

float x_slow = 0, y_slow = 0;//, xy = 0;

//_2AxisFloat BoundCenterPos = {0};

//遥控pitch和roll是指机体系的
void desired_vel_to_pos(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

	FLOAT_RPY curExpEur = expEur;
	FLOAT_RPY curEurTemp = *GetCurEuler();

	OS_EXIT_CRITICAL();

	float acc_fwd_trg = 0.0f, acc_rgt_trg = 0.0f;
	float acc_x_tar = 0.0f, acc_y_tar = 0.0f;

	acc_fwd_trg = -(constrain_float(apply_deadband(curExpEur.Pitch, 5), -30, 30) / 30) * 300;
	acc_rgt_trg = (constrain_float(apply_deadband(curExpEur.Rool, 5) , -30, 30) / 30) * 300;

	//将加速度变到ef系
	// acc_fwd，acc_rgt转化到飞机向北加速度RCdesired_accel_x   向东加速度RCdesired_accel_y
	acc_x_tar = (acc_fwd_trg * cosYaw - acc_rgt_trg * sinYaw);//RCdesired_accel_x
	acc_y_tar = (acc_fwd_trg * sinYaw + acc_rgt_trg * cosYaw);//RCdesired_accel_y

	if(RFMode == RFMODE_POSITION || (RFMode == RFMODE_ORBIT && OrbitAct == OrbitAct_POI))
	{
		if(IsDropOutElecFence())
		{
			if(acc_x_tar * FenceToDroneVect.X + acc_y_tar * FenceToDroneVect.Y >= 0)
				acc_x_tar = acc_y_tar = 0;
		}

		if(IsEntryNFZ_2())//in no fly zone
		{
			uint8_t NFZ_Numb = NumEntryNFZ();
			if(NFZ_Numb > 0)
			{
				for(uint8_t i = 0; i < NFZ_Numb; i ++)
				{
					if(acc_x_tar * NFZToDronVect[In2_4VectIndex[i]].X + acc_y_tar * NFZToDronVect[In2_4VectIndex[i]].Y < 0)
					{
						acc_x_tar = acc_y_tar = 0;
						break;
					}
				}
			}
		}
		else if(IsEntryNFZ_1() && CurExpAlt() >= 2000)
		{
			uint8_t NFZ_Numb = NumNearByNFZ();
			if(NFZ_Numb > 0)
			{
				for(uint8_t i = 0; i < NFZ_Numb; i ++)
				{
					if(acc_x_tar * NFZToDronVect[In6_5VextIndex[i]].X + acc_y_tar * NFZToDronVect[In6_5VextIndex[i]].Y < 0)
					{
						acc_x_tar = acc_y_tar = 0;
						break;
					}
				}
			}
		}
	}

	step_change(&RCdesired_accel_x, acc_x_tar, 15, 15);
	step_change(&RCdesired_accel_y, acc_y_tar, 15, 15);

	//累加到期望速度
	//Vaccx= RCdesired_accel_x;
	x_slow += RCdesired_accel_x * PosHold_DT;
	y_slow += RCdesired_accel_y * PosHold_DT;

    static uint8_t get_x = 0, get_y = 0;

    //---------------------------------x有舵量.加速过程中---------------------------------
    if(fabs(RCdesired_accel_x) > 0 )
    {
        x_slow -= 4.0f * (x_slow / MAX_speed_cms);

        if(get_x > 0)
        {
            Vel_xTD.delta = BrakeSpeed * 2;
            get_x = 0;
        }
    }
    else //---松杆---x无舵量,减速
    {
        if(get_x < 255) { get_x += 1; }

        if(get_x > 5) { Vel_xTD.delta = BrakeSpeed; }

        x_slow -= 8 * (x_slow / MAX_speed_cms);

        if(fabs(x_slow) < 8) { x_slow = apply_deadband(x_slow, 0.02f); }
    }
    //---------------------------------y有舵量.加速过程中---------------------------------
    if(fabs(RCdesired_accel_y) > 0 )
    {
        y_slow -= 4.0f * (y_slow / MAX_speed_cms);
        if(get_y > 0)
        {
            Vel_yTD.delta = BrakeSpeed * 2;
            get_y = 0;
        }
    }
    else //---松杆---y无舵量,减速
    {
        if(get_y < 255) { get_y += 1; }
        if(get_y > 5) { Vel_yTD.delta = BrakeSpeed; }

        y_slow -= 8 * (y_slow / MAX_speed_cms);

        if(fabs(y_slow) < 8) { y_slow = apply_deadband(y_slow, 0.02f); }
    }
    //---------------------------------------------------------------------------------------

	ADRC_td(x_slow, &Vel_xTD);
	RC_velDesired_x = Vel_xTD.r1;

	ADRC_td(y_slow, &Vel_yTD);
	RC_velDesired_y = Vel_yTD.r1;

	//总速度限幅
	float vel_desired_total = sqrtf(RC_velDesired_x * RC_velDesired_x + RC_velDesired_y * RC_velDesired_y);

	if (vel_desired_total > MAX_speed_cms)
	{
		RC_velDesired_x = MAX_speed_cms * (RC_velDesired_x / vel_desired_total);
		RC_velDesired_y = MAX_speed_cms * (RC_velDesired_y / vel_desired_total);
	}

//	挪动期望定位点
	PH.pos_exp_x = PH.pos_target_x + RC_velDesired_x * PosHold_DT;
	PH.pos_exp_y = PH.pos_target_y + RC_velDesired_y * PosHold_DT;
}

//----------------------------------------------------------------------
//----------------1 根据位置误差得到目标速度----------------------------
//----------------------------------------------------------------------

#define _XYaccel_cms (980.0f)  //XY最大运动加速度不超过1g

void Pos_to_rate_xy(float DesireX, float DesireY)
{
	static float DesireX_t,DesireY_t;

	DesireX_t = DesireX*0.2f + DesireX_t*0.8f;
	DesireY_t = DesireY*0.2f + DesireY_t*0.8f;

//	if(RFMode == RFMODE_FOLLOWME )
//	{
//	  step_change(&_leash,2000,5,5);
//	  step_change(&vel_max,1000,5,5);
//	}
//	else
//	{
//	  step_change(&_leash, GetDroneSysParam()->OutDoorSpeeed,5,5);
//	  step_change(&vel_max, GetDroneSysParam()->OutDoorSpeeed,5,5);
//	}

	float dx = 0.0f, dy = 0.0f, dis_tar = 0.0f;

    PH.pos_target_x = PH.pos_exp_x;
    PH.pos_target_y = PH.pos_exp_y;

	  dx = PH.pos_target_x - PosEst_x;
	  dy = PH.pos_target_y - PosEst_y;
	  dis_tar = sqrtf(dx * dx + dy * dy);

    //如果距离太远，防止后面的控制出现饱和，进行限制
    if (dis_tar > _leash)
    {
        PH.pos_target_x = PosEst_x + (_leash * (dx / dis_tar));
        PH.pos_target_y = PosEst_y + (_leash * (dy / dis_tar));
    }

	//计算位置误差
	PH.pos_error_x = PH.pos_target_x - PosEst_x;
	PH.pos_error_y = PH.pos_target_y - PosEst_y;

	PH.vel_target_x = POS_KP * PH.pos_error_x;//位置环输出
	PH.vel_target_y = POS_KP * PH.pos_error_y;

	PH.vel_exp_x = DesireX_t;//+前馈
	PH.vel_exp_y = DesireY_t;

	PH.vel_target_x += PH.vel_exp_x;
	PH.vel_target_y += PH.vel_exp_y;

    //对目标速度做限幅处理
    float vel_taget_total = sqrtf(PH.vel_target_x * PH.vel_target_x + PH.vel_target_y * PH.vel_target_y);

    if (vel_taget_total > vel_max)
    {
		PH.vel_target_x = vel_max * PH.vel_target_x / vel_taget_total;
		PH.vel_target_y = vel_max * PH.vel_target_y / vel_taget_total;
    }
}

void Rate_to_accel_xy(float DesireX, float DesireY)
{
	float RatePIDout_x = 0, RatePIDout_y = 0;

	ADRC_td(velRateCorr_x - PH.vel_target_x, &vLoop_xTD);
	ADRC_td(velRateCorr_y - PH.vel_target_y, &vLoop_yTD);

	//PID速度控制
	PID_PosHold_Vel(&PH_Rate_x, PH.vel_target_x, vLoop_xTD.r2, velRateCorr_x, &RatePIDout_x);
	PID_PosHold_Vel(&PH_Rate_y, PH.vel_target_y, vLoop_yTD.r2, velRateCorr_y, &RatePIDout_y);

	PH.accel_target_x = -1 * RatePIDout_x;//速度环输出
	PH.accel_target_y = -1 * RatePIDout_y;

	PH.acc_exp_x = DesireX;
	PH.acc_exp_y = DesireY;

	PH.accel_target_x += DesireX;//+前馈
	PH.accel_target_y += DesireY;

	//加速度输出限幅
	float accel_total = sqrtf(PH.accel_target_x * PH.accel_target_x + PH.accel_target_y * PH.accel_target_y);
    if(accel_total > _XYaccel_cms)
    {
        PH.accel_target_x  = _XYaccel_cms * PH.accel_target_x / accel_total;
        PH.accel_target_y  = _XYaccel_cms * PH.accel_target_y / accel_total;
    }
}

// (XY/cm^2) 加速度需求转为四元数
void Acc_XYtoQuat(float ACCX, float ACCY, Quat *XY_Q)//, FLOAT_RPY *XY_EUR
{
	ACCX = constrain_float(ACCX, -980, 980);
	ACCY = constrain_float(ACCY, -980, 980);

//	float accsum = constrain_float( sqrtf(ACCX * ACCX + ACCY * ACCY), 0, 980);
	float accsum = sqrtf(ACCX * ACCX + ACCY * ACCY);
	if(accsum > 980)
	{
		ACCX *= 980/accsum;
		ACCY *= 980/accsum;
	}
	accsum = constrain_float(accsum, 0, 980);
	float theta = atanf(accsum / 980.0f);

    if(accsum == 0)
    {
        XY_Q->qw = 1;
        XY_Q->qx = 0;
        XY_Q->qy = 0;
        XY_Q->qz = 0;
        return;
    }
    XY_Q->qw =  cosf(theta / 2.0f);
    XY_Q->qx =  (ACCY / accsum) * sinf(theta / 2.0f);
    XY_Q->qy = -(ACCX / accsum) * sinf(theta / 2.0f);
    XY_Q->qz =  0;

    float recipNorm = 1.0f / sqrtf(XY_Q->qw * XY_Q->qw + XY_Q->qx * XY_Q->qx + XY_Q->qy * XY_Q->qy + XY_Q->qz * XY_Q->qz);
    XY_Q->qw *= recipNorm;
    XY_Q->qx *= recipNorm;
    XY_Q->qy *= recipNorm;
    XY_Q->qz *= recipNorm;
}

//rfGPS_DATA *pCellPhoneGPSInfo;//手机GPS坐标

void PosHold_task(void)
{
    OS_ALLOC_SR();
    OS_ENTER_CRITICAL();
    unsigned char curRFMode = RFMode;
    static unsigned char PH_init = 0;
    OS_EXIT_CRITICAL();

    if(PH_init == 0)
    {
        pid_PH_init();
//		pCellPhoneGPSInfo = get_rf_GPS();
        PH_init = 1;
    }

	//旋转加速度方向所用的三角量
	cosYaw = cosf(GetCurEuler()->Yaw * (float)DEG_TO_RAD);
	sinYaw = sinf(GetCurEuler()->Yaw * (float)DEG_TO_RAD);

	//testMode在室内模式光流异常时是置1的
    if((flyEnable == 0 || AutoTakeOff_Sta == ONGROUND || curRFMode == RFMODE_HEIGHT || (curRFMode == RFMODE_READY && ReadyAct == ReadyHoldFlow)) && (GPS_IsReady() == 1))
    {
		PH.pos_target_x = PH.pos_exp_x = PosEst_x;
        PH.pos_target_y = PH.pos_exp_y = PosEst_y;

		PH_Rate_x.I_sum = 0.0f;
		PH_Rate_y.I_sum = 0.0f;
    }

    static unsigned char oldRFMode = RFMODE_9AXIE;
    if((oldRFMode != curRFMode) && (curRFMode == RFMODE_POSITION))//进入操作
    {
        PH.pos_exp_x = PH.pos_target_x;
        PH.pos_exp_y = PH.pos_target_y;

//		BoundCenterPos.X = PosEst_x;//初始化禁飞区中心
//		BoundCenterPos.Y = PosEst_y;

		vel_max = GetDroneSysParam()->OutDoorSpeeed;//最大5m/s
		MAX_speed_cms = _leash = vel_max;
    }
	if(oldRFMode == RFMODE_POSITION && curRFMode != RFMODE_POSITION)//退出操作
	{
		if(curRFMode != RFMODE_READY)
		{
			x_slow = 0, y_slow = 0;
			RC_velDesired_x = 0.0f, RC_velDesired_y = 0.0f;
			Vel_xTD.r2 = 0.0f, Vel_yTD.r2 = 0.0f;
			Vel_xTD.r2_pre = 0.0f, Vel_yTD.r2_pre = 0.0f;
			Vel_xTD.r1 = 0.0f, Vel_yTD.r1 = 0.0f;
			Vel_xTD.r1_pre = 0.0f, Vel_yTD.r1_pre = 0.0f;
		}
		vel_max = 500;//恢复默认5m/s的速度
		_leash = 500;
		MAX_speed_cms = 500;
	}
	oldRFMode = curRFMode;

    if(	curRFMode == RFMODE_POSITION || \
		(curRFMode == RFMODE_READY && ReadyAct == ReadyHoldGPS) || \
		(curRFMode == RFMODE_ORBIT && OrbitAct == OrbitAct_POI))
	{
		if(GPS_IsReady())
		{
			if(POS_KP < 0.8f)
				POS_KP += 0.004f;

//			if(curRFMode == RFMODE_POSITION || (curRFMode == RFMODE_ORBIT && OrbitAct == OrbitAct_POI))
//			{
//				if(pCellPhoneGPSInfo->accurancy <= 5.0f && pCellPhoneGPSInfo->accurancy > 0.0f)//更新禁飞区中心
//				{
//					float cellPhoneToHome;
//					get_xy_distance(pCellPhoneGPSInfo->lon, pCellPhoneGPSInfo->lat, &BoundCenterPos.X, &BoundCenterPos.Y, &cellPhoneToHome);
//				}
//			}

			// 遥控输入 -> 期望速度 -> 期望位置 ->减速
			if(GoHomeModeExit() == 0)// && PosModeRdy == 1)
				desired_vel_to_pos();
			// 位置误差 -> 速度控制
			Pos_to_rate_xy(RC_velDesired_x, RC_velDesired_y);
			// 速度误差 -> 期望加速度
			Rate_to_accel_xy(Vel_xTD.r2, Vel_yTD.r2);

			ComputePositionQuat();
		}
    }
}

void ComputePositionQuat(void)
{
	BF_X = PH.accel_target_y * sinYaw + PH.accel_target_x * cosYaw;
	BF_Y = PH.accel_target_y * cosYaw - PH.accel_target_x * sinYaw;

	Acc_XYtoQuat(BF_X, BF_Y, &PositionLoop_Q);
}

void GetTrigYaw(float *sin_yaw, float *cos_yaw)
{
	*sin_yaw = sinYaw;
	*cos_yaw = cosYaw;
}

inline Quat *GetPositionQuat(void)
{
	return &PositionLoop_Q;
}
