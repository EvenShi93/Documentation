#ifndef __FLOW_TASK_H
#define __FLOW_TASK_H

#include "middleware.h"

void FlowComp_5msTask(void);
void FlowHold_Task(void);

#endif /* __FLOW_TASK_H */
