#ifndef _HEIGHT_TASK_H_
#define _HEIGHT_TASK_H_

#include "middleware.h"

#define LowerRegion 0.5f /* unit: m */
#define UpperRegion 3.2f /* unit: m */

typedef enum 
{	
	ONGROUND = 0,
	TRIGGER,
	UP,
	WAIT_SONIC,
	SUCCEED,
	FAILED,
}TakeOff_Sta;

extern float EstAlt;
//extern float ALTDesired;
extern volatile uint8_t AutoTakeOff_Sta;

float CurExpAlt(void);
void height_10ms_task(void);
void Alt_VelHoldLoop_10ms_task(void);
void SetExp_Alt_Vel(float ExpAlt, float ExpVel);
void ThrOutLoop(float ExpAlt, FLOAT_RPY curEurTemp, float ExpVel);

void EntryAutoLand(void);
void ExitAutoLand(void);
void LockAutoLand(void);
void UnLockAutoLand(void);
void ClrAutoLandFlag(void);
uint8_t GetAutoLandSta(void);
uint8_t GetTakeOffFailed(void);
uint8_t IsOverrangeAltLimit(void);

#endif 
