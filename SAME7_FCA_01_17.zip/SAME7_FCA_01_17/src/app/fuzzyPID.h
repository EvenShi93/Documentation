#ifndef __FUZZYPID_H
#define __FUZZYPID_H

#include "bsp.h"
#include "global_type.h"

#define P_level     1.0F     //  rule的信任度
#define D_level     1.0F
#define F_max       1.0F       ///*满幅度值*/

float fuzzyout(float E, float EC, float *pE_DataSet, float *pEc_DataSet, int8_t *pRule, float *pU_DataSet, int8_t n);
void fuzzyDomain(float E, float *pEF, int8_t *pEn, float *pE_DataSet, int8_t n);
void Fuzzy(float E, float EC, PID pid_ref, PID *fuzpid);
void Fuzzy_Rollrate(float E, float EC, PID pid_ref, PID *fuzpid);

#endif
