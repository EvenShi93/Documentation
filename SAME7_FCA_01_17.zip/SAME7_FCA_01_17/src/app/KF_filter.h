typedef struct
{
	double Q_pos;
	double Q_spd;
	double R_spd;
	double spd_bias;
	double filter_Output;
	
	double  pos_err;
	double  PCt_0, PCt_1, E;
	double  K_0, K_1;
  double  t_0, t_1;	
	double  Pdot[4]; 
	double  PP[2][2];
	
} KF_str;



void Kalman_Filter_Update(KF_str* str, float new_vel,float new_pos,float Filter_dt)	;
void Kalman_Filter_init(KF_str* str,float Q_pos, float Q_spd, float R_spd);


void _6staEKF_setNOISE(float acc_xy,float vxy,float pos_xy,float acc_z,float vz,float pos_z);
void _6staEKF_EKFThread(float accx,float accy,float accz,float vx,float vy,float vz,float pos_x,float pos_y,float pos_z,float dt);


#define SQ_t(x) ((x) * (x))








