#ifndef _TASK_H_
#define _TASK_H_

#include "middleware.h"
#include "monitor_task.h"
#include "acc_gyro_mag_task.h"
#include "volt_switch_task.h"
#include "gps_pressure_task.h"
#include "attitude_task.h"
#include "rf_task.h"
#include "moto_task.h"
#include "flash_task.h"
#include "led_task.h"
#include "height_task.h"
#include "position_task.h"
#include "selfie_task.h"
#include "Journey.h"
//#include "gohome_task.h"
#include "GoHome.h"
#include "smart_task.h"
#include "FollowMe.h"
#include "EngineMode.h"
//#include "NavEKF.h"
#include "PosEst.h"

#if USE_CAM_FLOW
#include "FlowAlgorithm.h"
#include "flow_task.h"
#endif /* USE_CAM_FLOW */

#if defined(USE_E2PROM_CAL_DATA)
#include "IMU_CaliTask.h"
#endif /* defined(USE_E2PROM_CAL_DATA) */

void AppTask1(void *p_arg);
void AppTask2(void *p_arg);
void AppTask3(void *p_arg);
void AppTask4(void *p_arg);
void AppTask5(void *p_arg);
void FlowTaskLoop(void *p_arg);

#endif
