#include "FollowMe.h"

#define FOLLOW_DT 0.01f
//#define FOLLOW_MAX_VEL 700  /* 7.0m/s */
//#define FOLLOW_MAX_ACC 1.2f /* 1.2m/s^2 */

static uint8_t FollowMeInit = 0;

//float Test_X = 0, Test_Y = 0;

static ADRC_str FollowX_TD = {.dt = FOLLOW_DT, .h0 = 0.02f, .delta = 800};
static ADRC_str FollowY_TD = {.dt = FOLLOW_DT, .h0 = 0.02f, .delta = 800};
static ADRC_str FollowX_v_TD = {.dt = FOLLOW_DT, .h0 = 0.02f, .delta = 600};
static ADRC_str FollowY_v_TD = {.dt = FOLLOW_DT, .h0 = 0.02f, .delta = 600};

//static _3AxisFloat cellPhonePos_Integ = {0};//λ������
uint16_t Phone_Integ_CNT=0;

static _3AxisFloat cellPhonePos = {0};//�ֻ�λ��
static _3AxisFloat cellPhoneVel = {0};//�ֻ��ٶ�
static _3AxisFloat PosErrVector = {0};//λ�������
static _3AxisFloat cDroneExpPos = {0};//��ǰ�ɻ�����λ��
//static _3AxisFloat cDroneExpVel = {0};//��ǰ�ɻ������ٶ�
static float cosFollowHed, sinFollowHed;

_3AxisFloat FollowExpVel = {0}; //���ƻ��������ĸ����ٶ�

static _3AxisFloat cellPhonePos_LPF = {0};
static _3AxisFloat cellPhoneVel_LPF = {0};

static float cellPhoneToHome = 0;//�ֻ�������ԭ��ľ���
static float cellPhoneToDron = 0;//�ֻ����ɻ�����ľ���

static float FollowExpYaw = 0.0f;
static float V_WatchAng = 0.0f;

static rfGPS_DATA *pRfGPSInfo;

static void FollowExpPos(void);
static void ComputeFollowYaw(void);

//static rfGPS_DATA pRfGPSInfo_last;

uint16_t PhoneGPS_Updated=0;

void FollowMeTask(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();
	static unsigned char oldRFMode = RFMODE_9AXIE;
	unsigned char curRFMode = RFMode;
	OS_EXIT_CRITICAL();

	if(oldRFMode != curRFMode && curRFMode == RFMODE_FOLLOWME)
	{
		FollowMeInit = 0;
	}
	oldRFMode = curRFMode;

	if(curRFMode == RFMODE_FOLLOWME)
	{
		//�����ֻ�GPS��Ϣ
		float dx = 0, dy = 0, dz = 0;
		pRfGPSInfo = get_rf_GPS();
		get_xy_distance(pRfGPSInfo->lon, pRfGPSInfo->lat, &cellPhonePos.X, &cellPhonePos.Y, &cellPhoneToHome);//�����ֻ��������ԭ���λ��
		dx = PosEst_x - cellPhonePos.X;
		dy = PosEst_y - cellPhonePos.Y;
		dz = 0;
		cellPhoneToDron = sqrtf(dx * dx + dy * dy + dz * dz);//�ֻ���ɻ�֮��ľ���
		cosFollowHed = cosf(pRfGPSInfo->heading * (float)DEG_TO_RAD);
		sinFollowHed = sinf(pRfGPSInfo->heading * (float)DEG_TO_RAD);
		cellPhoneVel.X = pRfGPSInfo->speed * cosFollowHed;
		cellPhoneVel.Y = pRfGPSInfo->speed * sinFollowHed;
		cellPhoneVel.Z = 0;

		//��Ϣ����,��ʼ�����λ�õ�
		if(cellPhoneToDron < 6000 && pRfGPSInfo->accurancy <= 5.0f && pRfGPSInfo->accurancy != 0.0f && (rfIsLost() == 0) && (GetAutoLandSta()==0))//����С��60m && ˮƽ����С��5m
		{
			if(FollowMeInit == 0)
			{
				FollowMeInit = 1;
				cellPhoneVel_LPF.Y=0;
				cellPhoneVel_LPF.X=0;
				cellPhonePos_LPF.X = cellPhonePos.X;
				cellPhonePos_LPF.Y = cellPhonePos.Y;
				PosErrVector.X = PH.pos_target_x - cellPhonePos.X;
				PosErrVector.Y = PH.pos_target_y - cellPhonePos.Y;

				FollowX_TD.r1_pre = FollowX_TD.r1 = PH.pos_target_x;
				FollowY_TD.r1_pre = FollowY_TD.r1 = PH.pos_target_y;
				FollowX_TD.r2_pre = FollowX_TD.r2 = 0;
				FollowY_TD.r2_pre = FollowY_TD.r2 = 0;

				FollowX_v_TD.r1_pre = FollowX_v_TD.r1 = 0;
				FollowY_v_TD.r1_pre = FollowY_v_TD.r1 = 0;
				FollowX_v_TD.r2_pre = FollowX_v_TD.r2 = 0;
				FollowY_v_TD.r2_pre = FollowY_v_TD.r2 = 0;
				PosErrVector.Z = 0;
				Phone_Integ_CNT=0;
				PhoneGPS_Updated=0;
			}
		}
		else FollowMeInit = 0;
	}
	else
		V_WatchAng = 0;


	if(curRFMode == RFMODE_FOLLOWME)
	{
		if(POS_KP < 0.8f) POS_KP += 0.004f;		
        if(GoHomeModeExit() == 0) 
        {  
			FollowExpPos(); 		
		}
		   
		Pos_to_rate_xy(FollowX_v_TD.r1*0.2f,FollowY_v_TD.r1*0.2f);     
		Rate_to_accel_xy(0, 0);
		if(GetLowPowerFlag() < 2) ComputeFollowYaw();	
		ComputePositionQuat();
	}
}

static void FollowExpPos(void)
{
	if(FollowMeInit == 1 && GetLowPowerFlag() < 2)
	{
		cellPhonePos_LPF.X = cellPhonePos.X ;
		cellPhonePos_LPF.Y = cellPhonePos.Y ;

		cellPhoneVel_LPF.X = cellPhoneVel.X ;
		cellPhoneVel_LPF.Y = cellPhoneVel.Y ;

		cDroneExpPos.X = PosErrVector.X + cellPhonePos_LPF.X;
		cDroneExpPos.Y = PosErrVector.Y + cellPhonePos_LPF.Y;

		ADRC_td(cDroneExpPos.X, &FollowX_TD);
		ADRC_td(cDroneExpPos.Y, &FollowY_TD);

		ADRC_td(cellPhoneVel_LPF.X, &FollowX_v_TD);
		ADRC_td(cellPhoneVel_LPF.Y, &FollowY_v_TD);

		FollowExpVel.X = (FollowX_TD.r1- PH.pos_target_x)*0.8f;
		FollowExpVel.Y = (FollowY_TD.r1- PH.pos_target_y)*0.8f;

		FollowExpVel.X += cellPhoneVel_LPF.X;
		FollowExpVel.Y += cellPhoneVel_LPF.Y;

		if(GetAutoLandSta() == 1)
		{
			FollowExpVel.X=0;
			FollowExpVel.Y=0;
			FollowMeInit = 1;
		}

		if(IsEntryNFZ_2())//in no fly zone || (IsEntryNFZ_1() && CurExpAlt() >= 2000)
		{
			uint8_t NFZ_Numb = NumEntryNFZ();
			if(NFZ_Numb > 0)
			{
				for(uint8_t i = 0; i < NFZ_Numb; i ++)
				{
					float MulVect;
					if((MulVect = (FollowExpVel.X * NFZToDronVect[In2_4VectIndex[i]].X + FollowExpVel.Y * NFZToDronVect[In2_4VectIndex[i]].Y)) < 0)
					{
						float Square_recipNorm = SQUARE(NFZToDronVect[In2_4VectIndex[i]].X) + SQUARE(NFZToDronVect[In2_4VectIndex[i]].Y);
						FollowExpVel.X -= (NFZToDronVect[In2_4VectIndex[i]].X * MulVect) / Square_recipNorm;
						FollowExpVel.Y -= (NFZToDronVect[In2_4VectIndex[i]].Y * MulVect) / Square_recipNorm;
						break;
					}
				}
			}
		}

		PH.pos_exp_x += FollowExpVel.X * FOLLOW_DT;
		PH.pos_exp_y += FollowExpVel.Y * FOLLOW_DT;
	}
	else
	{
		//...
	}
}

float Follow_kp = 1.4f, Follow_ki = 0.008f;
float Follow_P = 0.0f, Follow_I = 0.0f;
float Follow_V_kp = 1.0f, Follow_V_ki = 0.004f;
float Follow_V_P = 0.0f, Follow_V_I = 0.0f;
float GBPitchRate = 0.0f;
float dYaw_pre = 0.0f, dPit_pre = 0.0f;
static uint16_t Follow_H = 0, Follow_V = 0;
static void ComputeFollowYaw(void)
{
	if(Follow_V <= 1000 && GetAutoLandSta() == 0 && Follow_V > 0)
	{
		float ErrPitRate = apply_deadband(Follow_V - 500, 70);
		float dAng = apply_deadband(Follow_V - 500, 70) * FOLLOW_DT;
		Follow_V_P = dAng * Follow_V_kp;
		Follow_V_I += dAng * Follow_V_ki;
		if(Follow_V_I > 0.1f) Follow_V_I = 0.1f;
		if(Follow_V_I < -0.1f) Follow_V_I = -0.1f;
		if(ErrPitRate * dPit_pre <= 0) {
			Follow_V_I = 0.0f;
		} else {
//			V_WatchAng = (Follow_V_P + Follow_V_I) + V_WatchAng * 0.98f;
		}
		dPit_pre = ErrPitRate;
		GBPitchRate = (Follow_V_P + Follow_V_I);
		V_WatchAng += GBPitchRate * 0.1f;
	}
	if(Follow_H <= 1000 && GetAutoLandSta() == 0 && Follow_H > 0)
	{
		float ErrYawRate = apply_deadband((float)(Follow_H - 500), 0);
		float dPixel = apply_limit((float)(Follow_H - 500), 400);
		float dYaw = (apply_deadband(dPixel, 50)) * FOLLOW_DT * 0.1f;
//		if(dYaw > 0.38f) dYaw = 0.38f;
//		if(dYaw < -0.38f) dYaw = -0.38f;
		Follow_P = (Follow_kp + ((150 - (fabs(apply_limit(dPixel, 250)))) / 150) * 0.3f) * dYaw;//max = 35 deg/s
		Follow_I += (Follow_ki) * dYaw;
		if(Follow_I > 0.1f) Follow_I = 0.1f;//max = .. deg/s
		if(Follow_I < -0.1f) Follow_I = -0.1f;
		if(ErrYawRate * dYaw_pre <= 0) Follow_I = 0.0f;
		dYaw_pre = ErrYawRate;
		FollowExpYaw += Follow_P + Follow_I;
		if(FollowExpYaw > 180) FollowExpYaw -= 360;
		else if(FollowExpYaw < -180) FollowExpYaw += 360;
	}
	else
	{
		Follow_I = 0.0f;
	}
}

inline float GetFollowExpYaw(void)
{
	return FollowExpYaw;
}

inline float GetWatchAng(void)
{
	return V_WatchAng;
}

inline void InitFollowExpYaw(float Yaw)
{
	FollowExpYaw = Yaw;
}

inline void SetImgFollowData(uint16_t rfDataH, uint16_t rfDataV)
{
	Follow_H = rfDataH;
	Follow_V = rfDataV;
}
