#include "height_task.h"
#include "maths.h"
#include "global_type.h"
#include "rf_task.h"
#include "app.h"

//10ms
#define Alt_DT 0.01f

extern float vel_acc;
extern unsigned char flyEnable;
extern float vel_acc_lowPass;

static uint8_t AutoLandLock = 0;
static uint8_t AutoLand_Flag = 0;
float thrAltOut = 0;

float groundPressure = 0;
float groundAltitude = 0;
unsigned char pressureOffsetFlag = 0;
float pressureAlt = 0;
float EstAlt = 0;
float sonicAlt = 0;
float pos_err_z_baro = 0;
float pos_err_baro = 0;
float pos_err_z_sonic = 0;

float pos_baro_airpillow = 0;

uint8_t SonicWarningFlag = 0, SonicUpperWarning = 0, SonicLowerWarning = 0;
float acc_correction_z_baro = 0;
float vel_correction_z_baro = 0;
float pos_correction_z_baro = 0;
float acc_correction_z_Baro_I = 0;

float time_const_z_baro = 6.0f;

float velAccCorr = 0;
float velRateCorr = 0;

float vle_err_z_GPS = 0;
float acc_correction_z_GPS = 0;
float vel_correction_z_GPS = 0;
float time_const_z_GPS = 100.0f;
float acc_correction_z_GPS_I = 0;

Sonar SonicHeightInfo = {0};
float SonicOffsetAlt = 0;
float Sonic_Speed = 0.0f;
uint8_t GET_Sonic_STEP = 0;

float vel_acc_lpf = 0;

static float GPS_Velocity = 0.0f;
float GPS_Height = 0.0f, GPS_GroundHeight = 0.0f;
float GPS_HgtErr = 0.0f;
float GPS_HgtErrConstTime = 6.0f;
float GPS_HgtErr_CorrPos = 0.0f, GPS_HgtErr_CorrVel = 0.0f, GPS_HgtErr_CorrAcc = 0.0f, GPS_HgtErr_CorrAcc_I = 0.0f;

#define SnoicFliter_NUM 20
float snoicBuff[SnoicFliter_NUM] ;
uint16_t SnoicFliter_Cnt=0;

uint8_t Bad_Sonic = 0;
//0 未触发
//1 触发了关闭气压，启动马达
//2 盲区无光流无气压上升
//3 到达超声波可用区40cm,有超声波>40cm的值则启动成功
//4 启动成功 启动气压融合在空中
//5 启动失败立即下降 退回未触发
volatile uint8_t AutoTakeOff_Sta = ONGROUND;

#define VELDELAY 20
float veldelay_buff[VELDELAY]={0};
uint8_t veldelay_count=0;
float veldelayed=0;

uint8_t BaroFusion_OFF = 0;
float acc_OFFSET = 0;
float SnoicAVG=0;
float time_const_sonic = 2.0f;
float vel_correction_z_sonic = 0;
float acc_correction_z_sonic_I = 0;

static uint32_t Use_GPSCnt = 0;
uint8_t  NearSide_flag=0;

void height_10ms_task(void)
{
	FLOAT_RPY curEurtemp = *GetCurEuler();

	//气压稳定部分
	static int pressureOffsetCount = 300;
	if(pressureOffsetCount > 0)
	{
		groundPressure -= groundPressure / 8.0f;
		groundPressure += GetPressureVal();
		groundAltitude = (1.0f - powf((groundPressure / 8.0f) / 101325.0f, 0.190295f)) * 4433000.0f;
		pressureOffsetCount --;
		GET_Sonic_STEP = 0;
		SonicOffsetAlt = 0;
	}
	else
		pressureOffsetFlag = 1;

	if(GPS_IsReady())
	{
		GPS_Height = get_gps_data()->hMSL;
		GPS_Velocity = get_gps_data()->velD;
	}

	//起来之前一直学习气压地面值
	if(flyEnable == 0 && AutoTakeOff_Sta == ONGROUND)
	{
		step_change(&time_const_sonic, 1.5f, 0.1f, 0.1f);
		
		if(fabsf(vel_acc) < 100.0f)
			acc_OFFSET = constrain_float(vel_acc, -20, 20)*0.001f + acc_OFFSET*0.999f;
		SonicOffsetAlt = 0;
		if(pressureOffsetFlag == 1)
		{
			pos_err_baro = 0;
			groundPressure -= groundPressure / 8.0f;
			groundPressure += GetPressureVal();
			groundAltitude = (1.0f - powf((groundPressure / 8.0f) / 101325.0f, 0.190295f)) * 4433000.0f;
		}
		if(GPS_IsReady())//学习地面高度值
			GPS_GroundHeight = GPS_Height;
	}

	//气压初始化和加速度计初始化完毕后启动融合
	if((pressureOffsetFlag == 1) && (GetAccStableFlag() == 1))
	{
		float pressureTmp;

		pressureTmp = (1.0f - powf((GetPressureVal()) / 101325.0f, 0.190295f)) * 4433000.0f;
		pressureTmp -= groundAltitude;

		pressureAlt = pressureAlt * 0.5f + pressureTmp * 0.5f;

		static float sonicAlt_last = 0;
		//获得超声波高度,并检查阶跃
		SonicHeightInfo = GetSonicDistance();
		if(SonicHeightInfo.distance_valid)
		{
			snoicBuff[SnoicFliter_Cnt] = constrain_float( SonicHeightInfo.sonar_distance_raw * 100,0, 600 );
			SnoicFliter_Cnt ++;
			if(SnoicFliter_Cnt==SnoicFliter_NUM)SnoicFliter_Cnt=0;

			SnoicAVG = 0;
			for(uint16_t i=0;i<SnoicFliter_NUM;i++)	SnoicAVG+=snoicBuff[i];
			SnoicAVG/=SnoicFliter_NUM;

			sonicAlt = (SnoicAVG)*0.1f+sonicAlt*0.9f;
			Sonic_Speed = (sonicAlt-sonicAlt_last) / 0.01f;
			sonicAlt_last = sonicAlt;

			float Step = 50;
			linermap(300, 150, 300, 100, sonicAlt, &Step);
			if((fabs(Sonic_Speed) > Step * 2 || (((fabsf(Sonic_Speed - veldelayed) > Step) && fabsf(Sonic_Speed) > Step))) && GET_Sonic_STEP == 0)
			GET_Sonic_STEP = 1;
		}

		if(flyEnable == 1 && GPS_IsReady() && GPS_Can_Used == 0)//飞行状态下GPS就绪后10s启用GPS
		{
			if(Use_GPSCnt < 1000)
			{
				Use_GPSCnt ++;
				GPS_HgtErrConstTime = 200;//GPS高度融合放到很小
				GPS_GroundHeight = GPS_Height - EstAlt;
			}
			else
			{
				Use_GPSCnt = 0;
				GPS_Can_Used = 1;
			}
		}
		if(GPS_IsReady())//有GPS速度参考时,使用GPS速度补偿
		{
			if(SonicHeightInfo.distance_valid)
			{
				step_change(&time_const_z_baro, 20, 0.1f, 0.1f);
				step_change(&time_const_z_GPS, 20, 0.1f, 0.1f);
				step_change(&GPS_HgtErrConstTime, 20, 0.1f, 0.1f);
			}
			else
			{
				step_change(&time_const_z_baro, 6, 0.1f, 0.1f);
				step_change(&time_const_z_GPS, 12, 0.1f, 0.1f);
				step_change(&GPS_HgtErrConstTime, 8, 0.1f, 0.1f);
			}
		}
		else //非GPS 室内用的气压融合系数
		{
			time_const_z_GPS = 200;//GPS速度融合放到很小
			if(BaroFusion_OFF == 1) step_change(&time_const_z_baro, 20, 0.1, 0.1);//关闭气压融合后,融合时间渐变到很慢
			else
			{
				if(AutoTakeOff_Sta == SUCCEED)//起飞成功
				{
					if(GET_Sonic_STEP == 1) step_change(&time_const_z_baro, 5, 0.1, 0.1);//检测到跳变,加强融合
					if(GET_Sonic_STEP == 0) step_change(&time_const_z_baro, 20, 0.1, 0.1);//无跳变,降低气压融合
				}
				else if(AutoTakeOff_Sta == WAIT_SONIC)//起飞中
				{
					if(Bad_Sonic == 0)
					{
						if(SonicHeightInfo.distance_valid)
							step_change(&time_const_z_baro, 8, 0.2f, 0.2f);//离地有一定高度了
						else
							step_change(&time_const_z_baro, 20, 0.2f, 0.2f);//离地面比较近
					}
				}
				else if(AutoTakeOff_Sta == 1 || AutoTakeOff_Sta == 2)
				{
					step_change(&time_const_z_baro, 20, 0.2f, 0.2f);//立即削弱气压效果
				}
				else if(AutoTakeOff_Sta == FAILED)//起飞失败
				{
					if(Bad_Sonic == 1)//红外坏,加强气压融合
						step_change(&time_const_z_baro, 8, 0.2f, 0.2f);//加强气压融合,防止降落时高度估计出错
				}
				else if(AutoTakeOff_Sta == ONGROUND)//地面上加强气压融合
					step_change(&time_const_z_baro, 1, 0.2, 0.2);
			}
		}

	  //降落时接近近地面判断,降落过程中红外
		static uint16_t NearSide_CNT = 0;
		if(AutoLand_Flag == 1)
		{
			if(SonicHeightInfo.distance_valid && SonicHeightInfo.UnStable == 0)
			{
				if(NearSide_CNT < 100) NearSide_CNT ++;
				else NearSide_flag = 1;
			}
//			if(NearSide_CNT>=100)NearSide_flag=1;
		}
		else
		{
			NearSide_CNT = 0;
			NearSide_flag = 0;
		}

		//-------------------气压修正----------------------
		//起飞的过程中不可用
		//起飞失败时,超声波盲区内不可用
		//自动降落时,超声波盲区内不可用,但降落是由于超声波失效引起的除外
		/*
			1,在地面上
			2,起飞成功且不在自动降落
			3,起飞失败,但超声波有效
			4,起飞过程中且超声波有效
			5,当高度估计只有加速度参与时,不会影响到自动降落的过程,但高度值容易出现偏差.
		*/
		if(AutoTakeOff_Sta == ONGROUND || \
			(AutoTakeOff_Sta == SUCCEED && AutoLand_Flag == 0) || \
			(AutoTakeOff_Sta == FAILED && SonicHeightInfo.distance_valid) || \
			(AutoLand_Flag == 1 ) || \
			((AutoTakeOff_Sta == WAIT_SONIC || AutoTakeOff_Sta == UP) && SonicHeightInfo.distance_valid))//气压参与融合的条件
		{
			BaroFusion_OFF = 0;

			//自动降落时,红外进入死区,接近地面,红外坏了,引导气压进入-3m气垫.
			if(AutoLand_Flag == 1  && !(SonicHeightInfo.distance_valid || (SonicHeightInfo.UnStable == 1 && NearSide_flag == 0 && Bad_Sonic == 0)) )
			{
				if(pos_baro_airpillow<300)pos_baro_airpillow+=3;      
			}

			//没有在降落状态,取消引导气垫
			if(AutoLand_Flag ==0) step_change(&pos_baro_airpillow,0,3,3);

			// 气压高度修正= (气压实际高度-气压偏移-气垫修正值)-估计高度
			pos_err_z_baro = (pressureAlt - pos_err_baro + pos_baro_airpillow) - EstAlt;

			if(AutoTakeOff_Sta == ONGROUND) pos_err_z_baro = 0 - EstAlt;

			acc_correction_z_baro = pos_err_z_baro*(1.0f/(time_const_z_baro*time_const_z_baro*time_const_z_baro)) * Alt_DT;
			vel_correction_z_baro = pos_err_z_baro*(1.0f/(time_const_z_baro*time_const_z_baro)) * Alt_DT;
			pos_correction_z_baro = pos_err_z_baro*(3.0f/(time_const_z_baro)) * Alt_DT;
		}
		else
		{
			step_change(&pos_correction_z_baro, 0, 0.05f, 0.05f);//不使用气压后会突然上窜的问题
			step_change(&acc_correction_z_baro, 0, 0.05f, 0.05f);
			step_change(&vel_correction_z_baro, 0, 0.05f, 0.05f);
			BaroFusion_OFF = 1;
		}

		if(GPS_IsReady())//GPS高度修正
		{
			GPS_HgtErr = (GPS_Height - GPS_GroundHeight) - EstAlt;//高度误差
			GPS_HgtErr_CorrPos = GPS_HgtErr * (3.0f / (GPS_HgtErrConstTime)) * Alt_DT;
			GPS_HgtErr_CorrVel = GPS_HgtErr * (1.0f / (GPS_HgtErrConstTime * GPS_HgtErrConstTime)) * Alt_DT;
			GPS_HgtErr_CorrAcc = GPS_HgtErr * (1.0f / (GPS_HgtErrConstTime * GPS_HgtErrConstTime * GPS_HgtErrConstTime)) * Alt_DT;
		}
		else
		{
			step_change(&GPS_HgtErr_CorrPos, 0, 0.05f, 0.05f);
			step_change(&GPS_HgtErr_CorrVel, 0, 0.05f, 0.05f);
			step_change(&GPS_HgtErr_CorrAcc, 0, 0.05f, 0.05f);
			step_change(&GPS_HgtErr_CorrAcc_I, 0, 0.05f, 0.05f);
		}
		if(GPS_IsReady())//GPS垂直速度修正
		{
			vle_err_z_GPS = -GPS_Velocity - velRateCorr;
			vel_correction_z_GPS = vle_err_z_GPS * (3.0f/time_const_z_GPS) * Alt_DT;
			acc_correction_z_GPS = vle_err_z_GPS * (1.0f/(time_const_z_GPS * time_const_z_GPS)) * Alt_DT;
		}
		else
		{
			step_change(&vel_correction_z_GPS, 0, 0.05f, 0.05f);
			step_change(&acc_correction_z_GPS, 0, 0.05f, 0.05f);
			step_change(&acc_correction_z_GPS_I, 0, 0.05f, 0.05f);
		}

	//-------------------超声波修正----------------------
		      vel_correction_z_sonic = 0;
		float pos_correction_z_sonic = 0;
		float acc_correction_z_sonic = 0;
		static uint16_t Wait_STEP = 0;

		//超声波在可用范围内 开启超声波融合
		if(SonicHeightInfo.distance_valid)
		{
			if(GET_Sonic_STEP == 0)//超声波没有发生跳变
			{   				
				//pos_err_baro = pressureAlt - EstAlt ;
				
				if(GPS_IsReady())// 室外
				{	
					pos_err_baro = pos_err_baro * 0.99f + (pressureAlt - (SnoicAVG + SonicOffsetAlt)) * 0.01f;			
					GPS_GroundHeight = GPS_GroundHeight * 0.99f + (GPS_Height - (sonicAlt + SonicOffsetAlt)) * 0.01f;		
					if(sonicAlt < 200.0f)
						step_change(&time_const_sonic, 1.5f, 0.01f, 0.01f);
					else
					if(sonicAlt < 300.0f)
						step_change(&time_const_sonic, 5.0f, 0.01f, 0.01f);
					else
					if(sonicAlt < 400.0f)
						step_change(&time_const_sonic, 5.0f, 0.01f, 0.01f);
					else
						step_change(&time_const_sonic, 5.0f, 0.01f, 0.01f);
			  }
				
				if(!GPS_IsReady())// 室内
				{
					pos_err_baro = pos_err_baro * 0.95f + (pressureAlt - (SnoicAVG + SonicOffsetAlt)) * 0.05f;			
					GPS_GroundHeight = GPS_GroundHeight * 0.95f + (GPS_Height - (sonicAlt + SonicOffsetAlt)) * 0.05f;		
					if(sonicAlt < 200.0f)
						step_change(&time_const_sonic, 1.5f, 0.01f, 0.01f);
					else
					if(sonicAlt < 300.0f)
						step_change(&time_const_sonic, 5.0f, 0.02f, 0.02f);
					else
					if(sonicAlt < 400.0f)
						step_change(&time_const_sonic, 5.0f, 0.02f, 0.02f);
					else
						step_change(&time_const_sonic, 5.0f, 0.02f, 0.02f);
				}
				

				pos_err_z_sonic = (SnoicAVG + SonicOffsetAlt) - EstAlt;
				
				acc_correction_z_sonic = pos_err_z_sonic * (1.0f /100) * Alt_DT;
				vel_correction_z_sonic = pos_err_z_sonic * (1.0f / (time_const_sonic * time_const_sonic)) * Alt_DT;
				pos_correction_z_sonic = pos_err_z_sonic * (1.0f / (time_const_sonic)) * Alt_DT;

				acc_correction_z_sonic_I += acc_correction_z_sonic;
				acc_correction_z_sonic_I = constrain_float(acc_correction_z_sonic_I, -10.0f, 10.0f);			
			}

			if(GET_Sonic_STEP == 1)
			{
				
				float Step = 50;
			  linermap(300, 150, 300, 100, sonicAlt, &Step);
								
				acc_correction_z_sonic_I = 0.0f;
				if(fabs(Sonic_Speed) < Step && fabs(curEurtemp.Pitch) < 15 && fabs(curEurtemp.Rool) < 15) {if(Wait_STEP < 100)Wait_STEP ++;} else Wait_STEP = 0;

				if( Wait_STEP >= 100)
				{
					SonicOffsetAlt = EstAlt - (sonicAlt);
					GET_Sonic_STEP = 0;
					Wait_STEP = 0;
				}
			}
		}
		else
		{
			if(SonicHeightInfo.UnStable == 1 && AutoTakeOff_Sta==SUCCEED) time_const_sonic = 20.0f;
			GET_Sonic_STEP = 0;
		}

		//融合结果
		velAccCorr = (vel_acc - acc_OFFSET);
		EstAlt += (velRateCorr * Alt_DT) + (0.5f*velAccCorr * Alt_DT * Alt_DT) + pos_correction_z_baro + pos_correction_z_sonic + GPS_HgtErr_CorrPos;
		velRateCorr += (velAccCorr * Alt_DT) + vel_correction_z_baro+ vel_correction_z_sonic + vel_correction_z_GPS  + GPS_HgtErr_CorrVel;

		veldelay_buff[veldelay_count] = velRateCorr;
		veldelay_count ++;
		if(veldelay_count == VELDELAY)veldelay_count = 0;
		veldelayed = veldelay_buff[veldelay_count];
	}
}

float HoverLevel = 400.0f;  //初始评估悬停油门为38%油门转速
float DroneHoverVal = 400.0f;

float ALTDesired = 0;
float VelDesired = 0;
float ACCDesired = 0;

PID AltBar, AltVel, AltAcc;

float HeightExpVel = 0;
float ThrCtrl;    //油门补偿量

void AltPID_init(void)
{

	AltBar.kp = 8.0f;
	AltBar.ki = 0.0f;
	AltBar.kd = 0.0f;
	AltBar.I_max = 20;
	AltBar.Dt = Alt_DT;

	AltVel.kp = 14.0f;
	AltVel.ki = 1.0f;
	AltVel.kd = 0.0;
	AltVel.I_max = 60;

	AltAcc.kp = 0.22f;
	AltAcc.ki = 0.05f;
	AltAcc.I_max = 100;

	AltVel.Dt = Alt_DT;
	AltAcc.Dt = Alt_DT;

}

//垂直高度P 得到垂直速度期望
void PID_AltBarLoop(PID* pid,float AltDesir,float measure,float* Output)
{
	float Err, Diff;
	Err = measure - AltDesir;//得到误差
	Diff = (Err - pid->PreErr) / pid->Dt;     //D 为垂直速度

	pid->PreErr = Err;      //更新前次误差

	pid->Pout = pid->kp * Err;
	pid->Dout = pid->kd * Diff;

	*Output = pid->Pout + pid->Iout + pid->Dout;
}

////根据期望Z轴速度 计算期望的加速度  rate_to_accel
//void AltVelLoop(float z_target,float z_vel_ff)
//{
//	float z_err;
//	float z_target_delta;       //期望速度的变化率
//	static float last_z_target;

//	z_target_delta = (z_target - last_z_target) / Alt_DT;
//	last_z_target = z_target;

//	z_err = (z_target + z_vel_ff) - velRateCorr; //期望速度和实际速度的误差

//	ACCDesired = z_target_delta + (z_err * AltVel.kp);
//}

//根据期望Z轴速度 计算期望的加速度  rate_to_accel
void AltVelLoop(float z_target,float z_vel_ff)
{
	float z_err;	
	float z_target_delta;       //期望速度的变化率
	static float last_z_target;

	z_target_delta = (z_target - last_z_target) / Alt_DT;
	last_z_target = z_target;

	z_err = (z_target + z_vel_ff) - velRateCorr; //期望速度和实际速度的误差	
	AltVel.PreErr= z_target-velRateCorr;
	
  AltVel.I_sum += (z_err*Alt_DT);
	if(AltVel.I_sum >  AltVel.I_max) AltVel.I_sum = AltVel.I_max;
	if(AltVel.I_sum < -AltVel.I_max) AltVel.I_sum =-AltVel.I_max;//抗饱和
	if(!flyEnable) AltVel.I_sum  = 0;
		
	ACCDesired = z_target_delta + (z_err * AltVel.kp) + (AltVel.ki*AltVel.I_sum);
}


//垂直加速度PID 得到垂直油门修正量
void PID_AltAccLoop(PID* pid, float AccDesir, float measure, float* Output)
{
	float Err,Diff;
	Err = measure - AccDesir; //得到误差
	Diff = (Err-pid->PreErr)/pid->Dt;

	pid->PreErr = Err;       //更新前次误差

	pid->I_sum += (Err*pid->Dt); //积分 带死区30mg
	if(pid->I_sum >  pid->I_max) pid->I_sum = pid->I_max;
	if(pid->I_sum < -pid->I_max) pid->I_sum =-pid->I_max;//抗饱和
	if(!flyEnable) pid->I_sum = 0;

	pid->Pout = pid->kp * Err; //比例计算，P*误差
	pid->Iout = pid->ki * pid->I_sum;
	pid->Dout = pid->kd * Diff;

	*Output = pid->Pout + pid->Iout;
}
float RC_z_vel = 0;
//根据水平速度评估悬停油门
void Update_HoverThr(void)
{
	static uint32_t HoverLevelUpdateTimeCnt = 0;
	if((AutoTakeOff_Sta == SUCCEED) && SonicWarningFlag == 0 && AutoLand_Flag == 0 && fabs(RC_z_vel)<1.0f)
		if((pressureOffsetFlag == 1) && fabs(velRateCorr) < 8 && fabs(GetCurEuler()->Pitch) < 5 && fabs(GetCurEuler()->Rool) < 5)//气压初始化完毕+垂直速度<15cm/s
		{
			if(HoverLevelUpdateTimeCnt < 100) HoverLevelUpdateTimeCnt ++;//保持1s后学习
			else
				DroneHoverVal = HoverLevel = (HoverLevel * 0.998f) + (thrAltOut * 0.002f);
		}
		else HoverLevelUpdateTimeCnt = 0;
	else
		HoverLevelUpdateTimeCnt = 0;
}

#define LAND_DELAY 100
#define AltVel_RFdeadband 100

//function prototype
void AutoLandProg(void);
void RCExp_Vel_Pos(float RC_Thr, Sonar *InfoSonar);

float TakeOffAlt = 0;
extern float thr;
uint8_t AltHoldInit = 0, MotorUpFlag = 0;
static uint8_t TakeOffFailedCode = 0;
uint8_t GetALTDesir_Flag = 0;

void Alt_VelHoldLoop_10ms_task(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

	float curThr = thr;
	FLOAT_RPY curEurTemp = *GetCurEuler();

	OS_EXIT_CRITICAL();

	if(AltHoldInit == 0)
	{
		AltPID_init();
		AltHoldInit = 1;
	}

	SonicHeightInfo = GetSonicDistance();//get sonic info.

	//---------------自动起飞----------------
	static uint16_t SonicDetect = 0;
	static uint16_t TakeOffTime = 0;
	static uint16_t TakeOffDelay = 0;

	switch(AutoTakeOff_Sta)
	{
		case ONGROUND:
			AutoTakeOff_Sta = ONGROUND;
		break;
		case TRIGGER: //--------------------------------
			Bad_Sonic = 0;//红外损坏标志量,允许用户重新起飞,清除标志量
			TakeOffTime = 0;
			SonicDetect = 0;
			VelDesired = 0;
			ALTDesired = EstAlt;
			AltVel.I_sum = 0; AltAcc.I_sum = 0;
			TakeOffAlt = EstAlt;
			AutoTakeOff_Sta = UP;
			flyEnable = 1; //启动
			MotorUpFlag = 1;
			TakeOffDelay = 0;
		break;
		case UP: //--------------------------------
			if(TakeOffDelay <= 100)
			{
				MotorUpFlag = 1;
				velRateCorr = 0;
				EstAlt = 0;
				HoverLevel = (DroneHoverVal / 100.0f) * TakeOffDelay;//1s 悬停油门缓变,马达缓慢提速
				VelDesired = 0.0f;
				TakeOffDelay ++;
			}
			else
			{
				MotorUpFlag = 0;
				if(VelDesired < 26) VelDesired += 0.2f;//1s, up to 26cm/s
				else AutoTakeOff_Sta = WAIT_SONIC;
			}
      //速度环前馈 加力
			HeightExpVel = VelDesired;
		break;
		case WAIT_SONIC://正常情况下,进入这一步时飞机已经应离地有一定距离了.
			ALTDesired = EstAlt;

			TakeOffTime ++;

			if(SonicHeightInfo.distance_valid && SonicDetect < 50)//0.5s 探测超声波
				SonicDetect ++;
			if(SonicDetect >= 50 && SonicHeightInfo.sonar_distance_raw >= (GetDroneSysParam()->Height / 10.0f - 0.2f))//一键起降高度,需要提前到位.
				step_change(&VelDesired, 0, 0.4, 0.4);//0.5s
			HeightExpVel = VelDesired;

			if(VelDesired < 0.4f)//尽量减小起飞成功后的马达异音
			{
				VelDesired = 0.0f;
				AutoTakeOff_Sta = SUCCEED;
				GetALTDesir_Flag = 100;
				break;
			}

			if(TakeOffTime > 1100)
			{
				AutoTakeOff_Sta = FAILED;//超时失败
				TakeOffFailedCode = 0x03;
			}
			if(fabsf(curEurTemp.Pitch) > 60 || fabsf(curEurTemp.Rool) > 60)
			{
				AutoTakeOff_Sta = FAILED;//起飞过程中角度过大
				TakeOffFailedCode = 0x05;
			}
			if(SonicDetect < 50)//红外一直没有检测到有效的距离(可能过高/过低)
			{
				if(TakeOffTime > 200)//2s内红外高度未就绪
				{
					AutoTakeOff_Sta = FAILED;
					if(DroneHoverVal < 900)
					{
						Bad_Sonic = 1;//悬停油门值小,说明不是超重导致的
						TakeOffFailedCode = 0x01;
					}
					else
						TakeOffFailedCode = 0x02;
				}
				if(pressureAlt - groundAltitude > 160)
				{
					Bad_Sonic = 1;
					AutoTakeOff_Sta = FAILED;
					TakeOffFailedCode = 0x04;
				}//气压高度过高仍未检测到红外
			}
//			if(EstAlt - TakeOffAlt > 140 && SonicDetect < 50) {AutoTakeOff_Sta = FAILED; Bad_Sonic = 1;}//高度过高仍未检测到红外
		break;
		case SUCCEED://--------------------------------
			AutoTakeOff_Sta = SUCCEED;
			if(GetCurMode() != RFMODE_JOURNEY && GetCurMode() != RFMODE_GOHOME)//仅JOURNEY及GOHOME模式下的高度是自行给定的
			{
				RCExp_Vel_Pos(curThr, &SonicHeightInfo);
				HeightExpVel = 0;
			}
			else
				RC_z_vel = 0;
		break;
		case FAILED:
			AutoLand_Flag = 1;
		break;
		default:
			AutoTakeOff_Sta = ONGROUND;
		break;
	}

	AutoLandProg();//auto land.
	ThrOutLoop(ALTDesired, curEurTemp, HeightExpVel);//ctrl loop.

	//更新悬停油门学习
	Update_HoverThr();
}

void RCExp_Vel_Pos(float RC_Thr, Sonar *InfoSonar)
{
	static float Z_ExpVel = 0;
	static float Z_ExpVelLPF = 0;
	float thrMidOffValue = (float)RC_Thr - 1200;
	uint8_t OutBoundFlag = 0;

	if(thrMidOffValue >= -AltVel_RFdeadband && \
	(IsOverrangeAltLimit() || \
	(ALTDesired >= 4000 && (GetLowPowerFlag() >= 1)) || \
	((GetNFZInfo() & NFZ_LEVEL_BIT_2) == NFZ_LEVEL_BIT_2 && ALTDesired >= 1000) || \
	((GetNFZInfo() & NFZ_LEVEL_BIT_1) == NFZ_LEVEL_BIT_1 && ALTDesired >= 2000) || \
	(InfoSonar->sonar_distance_filtered > UpperRegion && GetCurMode() == RFMODE_HEIGHT))
	)
		OutBoundFlag = 1;//过高
	if(InfoSonar->sonar_distance_filtered < LowerRegion && thrMidOffValue <= AltVel_RFdeadband)
		OutBoundFlag = 2;//过低

	if(AutoLand_Flag == 0 && AutoTakeOff_Sta == SUCCEED)
	{
		if(fabs(thrMidOffValue) < AltVel_RFdeadband || OutBoundFlag != 0)//摇杆在中点,或出了禁飞区,没有期望速度
		{
			if(OutBoundFlag == 0) Z_ExpVel = 0.0f;
			else if(OutBoundFlag == 1)
			{
				if(GetCurMode() == RFMODE_HEIGHT)
				{
					float MaxVel = -60.0f;
					if(EstAlt < 600.0f)
						MaxVel = -60.0f;
					else if(EstAlt < 1000.0f)
						MaxVel = -120.0f;
					else
						MaxVel = -160.0f;
					step_change(&Z_ExpVel, MaxVel, 0.5f, 0.5f);//室内过高自动下降
				}
				else
					Z_ExpVel = 0.0f;
			}
			else if(OutBoundFlag == 2) step_change(&Z_ExpVel, +30, 0.5f, 0.5f);//过低自动上升

//			if(GetALTDesir_Flag >= 100){AltVel.I_sum = 0; AltAcc.I_sum = 0;}//清除积分加快响应
			//-1s-高度期望过度到当前位置，减少超调
			if(GetALTDesir_Flag > 0 && OutBoundFlag == 0)
			{
				GetALTDesir_Flag --;
				ALTDesired += (EstAlt - ALTDesired) * 0.01f;
				step_change(&AltVel.I_sum, 0, 1, 1);
				step_change(&AltAcc.I_sum, 0, 1, 1);
			}
		}
		else//摇杆量不在中点,且没有离开电子围栏,允许用户打杆
		{
			 GetALTDesir_Flag = 100;
			 float speed_scal;

			 if(thrMidOffValue < 0)//向下
			 {
				if(EstAlt < 400.0f)//4m以下
					speed_scal = 0.15f;
				else if(EstAlt < 800.0f)//8m以下
					linermap( 800.0f , 400.0f , 0.25f, 0.15f , EstAlt,&speed_scal);
				else //8m以上
					speed_scal = 0.2f;
				if(InfoSonar->distance_valid && InfoSonar->sonar_distance_filtered < 0.7f)
					linermap(0.7f, 0.5f, 0.04f, 0.0f, InfoSonar->sonar_distance_filtered, &speed_scal);
				else if(InfoSonar->distance_valid && InfoSonar->sonar_distance_filtered < 2.0f)
					linermap(2.0f, 0.7f, 0.15f, 0.04f, InfoSonar->sonar_distance_filtered, &speed_scal);

				Z_ExpVel = thrMidOffValue * speed_scal;
			}
			else if(thrMidOffValue > 0)
			{
				if(EstAlt < 400.0f)//4m以下
					speed_scal = 0.1f;
				else if(EstAlt < 800.0f)//8m以下
					linermap(800.0f, 400.0f, 0.2f, 0.1f, EstAlt, &speed_scal);
				else  //8m以上
					speed_scal = 0.2f;
				Z_ExpVel = thrMidOffValue * speed_scal;

				Z_ExpVel = apply_deadband(Z_ExpVel, AltVel_RFdeadband * speed_scal);
			}
		}

		//----------更新高度期望------------
		if(GetCurMode() == RFMODE_HEIGHT)
			Z_ExpVel *= 0.6f;//室内油门舵量为室外的60%
		step_change(&Z_ExpVelLPF, Z_ExpVel, 4, 4);

		RC_z_vel = RC_z_vel * 0.8f + Z_ExpVelLPF * 0.2f;
		ALTDesired += RC_z_vel * Alt_DT;// dt = 0.01s

		//高度期望限制
		ALTDesired = constrain_float(ALTDesired, EstAlt - 30, EstAlt + 30);
	}
	else
	{
		RC_z_vel = 0;
		SonicWarningFlag = 0;
	}
}

static uint32_t RealNearGroundTimeCnt = 0;
static float AltVelRemnant = 0.0f;

static float LandSpeed = 0.0f, LandMaxSpeed = 0.0f;
void AutoLandProg(void)
{
    static uint16_t start_autoland = 0;
	static uint16_t end_autoland = 0;
	if(flyEnable == 0 && AutoLand_Flag == 1)
	{
		UnLockAutoLand();
		ClrAutoLandFlag();
		ALTDesired = EstAlt - 50;
		RealNearGroundTimeCnt = 0;
		AutoTakeOff_Sta = ONGROUND;
	}
/* ----------------------- AutoLanding ----------------------- */
	if(AutoLand_Flag == 0)
	{
		start_autoland = 0; end_autoland = 0;
		if(LandSpeed > 0)//exit autoland.
		{
			LandSpeed -= 0.01f;
			ALTDesired -= LandSpeed;
			if(ALTDesired < EstAlt - 100) ALTDesired = EstAlt - 100;
		}
		else
			LandSpeed = 0;
	}
	else if(AutoLand_Flag == 1 && start_autoland < LAND_DELAY)
	{
		if(start_autoland == 0)
			AltVelRemnant = JourneyModeExpAltVel() * 0.01f;//仅在Journey模式会产生速度残留(与gohome之间的迅速切换也会有残留)
		GET_Sonic_STEP = 0;
		start_autoland ++;//开始降落
		if(fabsf(AltVelRemnant) > 0.01f)
		{
			if(start_autoland >= LAND_DELAY)
				start_autoland = LAND_DELAY - 1;
			AltVelRemnant = SGN(AltVelRemnant) * (fabsf(AltVelRemnant) - 0.01f);
			ALTDesired += AltVelRemnant;
		}
		else
			AltVelRemnant = 0.0f;
	}
	else if(AutoLand_Flag == 1 && start_autoland >= LAND_DELAY)
	{
		if(EstAlt > 1500)
			LandMaxSpeed = 3.0f;
		else if(EstAlt > 800)
			linermap(1500, 800, 3.0f, 1.5f, EstAlt, &LandMaxSpeed);
		else
			linermap(800, 30, 1.5f, 0.3f, EstAlt, &LandMaxSpeed);

		step_change(&LandSpeed, LandMaxSpeed, 0.01f, 0.01f);

		ALTDesired -= LandSpeed;
		if(ALTDesired < EstAlt - 100) ALTDesired = EstAlt - 100;

		if(thrAltOut < HoverLevel * 0.2f && end_autoland < LAND_DELAY)
			end_autoland ++;
		else
			end_autoland *= 0.9f;  //判断降落到底
		if(end_autoland == LAND_DELAY)
		{
//			flyEnable = 0;
			CutOff();
			UnLockAutoLand();
			ClrAutoLandFlag();
			ALTDesired = EstAlt - 50;
			RealNearGroundTimeCnt = 0;
			if(AutoTakeOff_Sta == FAILED)
				HoverLevel = DroneHoverVal = 400;

			AutoTakeOff_Sta = ONGROUND;
		}//自动降落完成
	}

	/* ------------- LockAutoLand Condition (2016/12/09) ------------- */
	if(AutoLand_Flag == 1 && flyEnable == 1 && AutoLandLock == 0)
	{
		if(SonicHeightInfo.sonar_distance_filtered < 0.5f)
		{
			if(RealNearGroundTimeCnt < 100)
				RealNearGroundTimeCnt ++;
			else
			{
				RealNearGroundTimeCnt = 0;
				AutoLandLock = 1;//Lock AutoLand operation.
			}
		}
		else
			RealNearGroundTimeCnt = 0;
	}
}

void ThrOutLoop(float ExpAlt, FLOAT_RPY curEurTemp, float ExpVel)
{
	static uint32_t OverWeightCnt = 0;
	//计算角度补偿系数
	float thr_boost_tri = 1.0f/constrain_float(cosf(curEurTemp.Pitch * (float)DEG_TO_RAD) * cosf(curEurTemp.Rool * (float)DEG_TO_RAD), 0.8f, 1.0f);
	//ALTDesired -> VelDesir -> ACCDesir -> ThrCtrl -> AltOut
	//正常飞行时使用气压高度误差控制垂直速度
	if(AutoTakeOff_Sta == SUCCEED || AutoLand_Flag == 1)
	{
		PID_AltBarLoop(&AltBar, EstAlt, ExpAlt, &VelDesired);//height->vel
	}

	VelDesired = constrain_float(VelDesired, -500, 500);//vel constrain

	//速度环控制,给定前馈
	AltVelLoop(VelDesired, ExpVel);//vel->acc

	//加速度内环
	PID_AltAccLoop(&AltAcc, ACCDesired, vel_acc_lowPass, &ThrCtrl);//acc->thr

	ThrCtrl = -ThrCtrl;

	//控制量是在HoverLevel(机体悬停油门)的基础上给定的 HoverLevel值在高度估计部分会有实时更新
	if((AutoTakeOff_Sta == UP || AutoTakeOff_Sta == WAIT_SONIC) && AutoLand_Flag == 0 && MotorUpFlag == 0)
	{
		HoverLevel += ThrCtrl * 0.010f;
		DroneHoverVal = HoverLevel;
		thrAltOut = HoverLevel + ThrCtrl;// * 0.6f;

		if(DroneHoverVal >= 900)//超重保护/起飞时受到向上的压力
		{
			if(OverWeightCnt < 100)
				OverWeightCnt ++;
			else
			{
				AutoTakeOff_Sta = FAILED;
				TakeOffFailedCode = 0x02;
			}
		}
		else
			OverWeightCnt = 0;
	}
	else
		thrAltOut = (HoverLevel + ThrCtrl);

	//高度控制实际输出油门 输出0-1000
	thrAltOut = constrain_float(thrAltOut * thr_boost_tri, 0, 1000);
}

uint8_t IsOverrangeAltLimit(void)
{
	if(ALTDesired >= GetDroneSysParam()->OutDoorHeight * 10.0f)
		return 1;
	else
		return 0;
}

inline void EntryAutoLand(void)
{
	AutoLand_Flag = 1;
}

inline void ExitAutoLand(void)
{
	if(SonicHeightInfo.sonar_distance_filtered >= 0.5f && AutoLandLock == 0)
		AutoLand_Flag = 0;
}

inline void LockAutoLand(void)
{
	AutoLandLock = 1;
}

inline void UnLockAutoLand(void)
{
	AutoLandLock = 0;
}

inline void ClrAutoLandFlag(void)
{
	AutoLand_Flag = 0;
}

inline uint8_t GetAutoLandSta(void)
{
	return AutoLand_Flag;
}

inline void SetExp_Alt_Vel(float ExpAlt, float ExpVel)
{
	ALTDesired = ExpAlt;
	HeightExpVel = ExpVel;
}

inline float CurExpAlt(void)
{
	return ALTDesired;
}

inline uint8_t GetTakeOffFailed(void)
{
	return TakeOffFailedCode;
}
