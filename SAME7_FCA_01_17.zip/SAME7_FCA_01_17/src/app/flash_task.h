#ifndef _FLASH_TASK_H_
#define _FLASH_TASK_H_

#include "middleware.h"

typedef union
{
    float			Cal_F[7];
    unsigned char	data[28];
}MAG_PARAM_FLASH;

typedef union
{
	float fData[2];
	unsigned char Data[8];
}VOL_PARAM_FLASH;

typedef union
{
    float OffsetAng[2];
    unsigned char Data[8];
} AssembleOffset;

void flash_10ms_task(void);
uint8_t MagCalDataValid(void);

#endif
