/*************************************************
PID整定算法(模糊自适应法)
*************************************************/
#include "fuzzyPID.h"

/***采用调整因子的规则表，大误差时偏重误差，小误差时偏重误差变化率***/
//偏差率   -3,-2,-1, 0, 1, 2, 3     // 偏差e
int8_t kp_rule[7][7]= {
    { 3, 3, 3, 3, 2, 2, 1},//   -3
    { 3, 3, 2, 2, 1, 1, 1},//   -2
    { 2, 2, 1, 1, 1, 0, 1},//   -1
    { 1, 1, 0, 0, 0, 1, 1},//   0
    { 1, 0, 1, 1, 1, 2, 2},//   1
    { 1, 1, 1, 2, 2, 3, 3},//   2
    { 1, 2, 2, 3 ,3 ,3, 3}
};//  3


//偏差率   -3,-2,-1, 0, 1, 2, 3     // 偏差e
int8_t kd_rule[7][7]= {
    { 3, 1, 0, 0, 0, 0, 0},
    { 2, 3, 1, 1, 1, 0, 0},
    { 2, 2, 3, 2, 2, 1, 1},
    { 1, 2, 2, 3, 2, 2, 1},
    { 1, 1, 2, 2, 3, 2, 2},
    { 0, 0, 1, 1, 1, 3, 2},
    { 0, 0, 0, 0 ,0 ,1, 3}
};

//偏差率   -3,-2,-1, 0, 1, 2, 3     // 偏差e
int8_t ki_rule[7][7]= {
    { 3, 2, 2, 1, 1, 0, 0},
    { 3, 3, 2, 2, 1, 1, 0},
    { 3, 3, 3, 2, 2, 1, 1},
    { 3, 3, 3, 3, 3, 3, 3},
    { 1, 1, 2, 2, 3, 3, 3},
    { 0, 1, 1, 2, 2, 3, 3},
    { 0, 0, 1, 1 ,2 ,2, 3}
};

float E_DataSet[4] = {0,1,2.5,4};  // Pitch偏差的论域    可调整
float Ec_DataSet[4] = {0,60,120,200};   //Pitch偏差变化率的论域

float Kp_DataSet[4] = {0,0.05,0.1,0.2};  // Pitch轴输出量Kp的论域
float Ki_DataSet[4] = {0,0.000001,0.000003,0.000005};   // 输出量Ki的论域
float Kd_DataSet[4] = {0,0.005,0.01,0.02};    // 输出量Kd的论域

/*
*   function:Fuzzy
*   input:      E 偏差
*               EC 偏差变化率
*               pid_ref pid基础值
*               *fuzpid 自适应pid增值
*/
void Fuzzy(float E, float EC, PID pid_ref, PID *fuzpid)
{
    fuzpid->kp = fabsf(fuzzyout(E,EC,(float *)E_DataSet,(float *)Ec_DataSet,&kp_rule[0][0],(float *)Kp_DataSet,3)) * pid_ref.kp_temp;
    fuzpid->kd = fuzzyout(E,EC,(float *)E_DataSet,(float *)Ec_DataSet,&kd_rule[0][0],(float *)Kd_DataSet,3) * pid_ref.kd;
    fuzpid->ki = fuzzyout(E,EC,(float *)E_DataSet,(float *)Ec_DataSet,&ki_rule[0][0],(float *)Ki_DataSet,3) * pid_ref.ki;
}

float E_DataSet_Rollrate[4] = {0,1.3,3.5,5};  // Roll偏差的论域    可调整
float Ec_DataSet_Rollrate[4] = {0,80,120,180};   //Roll偏差变化率的论域

float Kp_DataSet_Rollrate[4] = {0,0.08,0.15,0.24};  // Roll轴输出量Kp的论域
float Ki_DataSet_Rollrate[4] = {0,0.000001,0.000003,0.000005};   // 输出量Ki的论域
float Kd_DataSet_Rollrate[4] = {0,0.005,0.01,0.02};    // 输出量Kd的论域
/*
*   function:Fuzzy
*   input:      E 偏差
*               EC 偏差变化率
*               pid_ref pid基础值
*               *fuzpid 自适应pid增值
*/
void Fuzzy_Rollrate(float E, float EC, PID pid_ref, PID *fuzpid)
{
    fuzpid->kp = fabsf(fuzzyout(E,EC,(float *)E_DataSet_Rollrate,(float *)Ec_DataSet_Rollrate,&kp_rule[0][0],(float *)Kp_DataSet_Rollrate,3)) * pid_ref.kp_temp;
    fuzpid->kd = fuzzyout(E,EC,(float *)E_DataSet_Rollrate,(float *)Ec_DataSet_Rollrate,&kd_rule[0][0],(float *)Kd_DataSet_Rollrate,3) * pid_ref.kd;
    fuzpid->ki = fuzzyout(E,EC,(float *)E_DataSet_Rollrate,(float *)Ec_DataSet_Rollrate,&ki_rule[0][0],(float *)Ki_DataSet_Rollrate,3) * pid_ref.ki;
}


/*
*   function:fuzzyout
*   input:      E 偏差
*               EC 偏差变化率
*               pE_DataSet 偏差论域
*               pEc_DataSet 偏差变化论域
*               pRule 模糊规则库
*               pU_DataSet 输出论域
*               n 单维度值
*   output：   输出
*/
float fuzzyout(float E, float EC, float *pE_DataSet, float *pEc_DataSet, int8_t *pRule, float *pU_DataSet, int8_t n)
{
    int8_t  En,Ecn,Un[4];    /*偏差，偏差变化率，输出值的标号值*/
    float   EF[2],EcF[2],UF[4];   /*偏差，偏差变化率，输出值的隶属度*/
    float   temp1,temp2;
    float   U_Out[4];
    float     out;
    /*********根据E/EC值确定论域值和隶属度(采用trim函数)**********/
    fuzzyDomain(E,EF,&En,pE_DataSet,n);
    fuzzyDomain(EC,EcF,&Ecn,pEc_DataSet,n);


    /*输出值使用了13个隶属函数,且一般都是四个规则有效*/

    /*Un[]为所隶属的隶属函数标号*/
    Un[0] = *(pRule+    (En-1+n)*(2*n+1)    +   Ecn-1+n);
    Un[1] = *(pRule+    (En+n)  *(2*n+1)    +   Ecn-1+n);
    Un[2] = *(pRule+    (En-1+n)*(2*n+1)    +   Ecn+n);
    Un[3] = *(pRule+    (En+n)  *(2*n+1)    +   Ecn+n);

    /********模糊推理(Mamdani法)，合成运算，求出输出隶属度*********/

    /**输入量向量乘法，输出论域极小值**/
    UF[0] = EF[0] <= EcF[0] ? EF[0] : EcF[0];
    UF[1] = EF[1] <= EcF[0] ? EF[1] : EcF[0];
    UF[2] = EF[0] <= EcF[1] ? EF[0] : EcF[1];
    UF[3] = EF[1] <= EcF[1] ? EF[1] : EcF[1];

    /**相同隶属函数的，输出论域值极大值**/

    if(Un[0]==Un[1])    UF[0]>UF[1]?(UF[1]=0):(UF[0]=0);

    if(Un[0]==Un[2])    UF[0]>UF[2]?(UF[2]=0):(UF[0]=0);

    if(Un[0]==Un[3])    UF[0]>UF[3]?(UF[3]=0):(UF[0]=0);

    if(Un[1]==Un[2])    UF[1]>UF[2]?(UF[2]=0):(UF[1]=0);

    if(Un[1]==Un[3])    UF[1]>UF[3]?(UF[3]=0):(UF[1]=0);

    if(Un[2]==Un[3])    UF[2]>UF[3]?(UF[3]=0):(UF[2]=0);

    /**********重心法反模糊计算kp***********/  //符号
    U_Out[0]= Un[0]>=0?pU_DataSet[Un[0]]:-pU_DataSet[-Un[0]];
    U_Out[1]= Un[1]>=0?pU_DataSet[Un[1]]:-pU_DataSet[-Un[1]];
    U_Out[2]= Un[2]>=0?pU_DataSet[Un[2]]:-pU_DataSet[-Un[2]];
    U_Out[3]= Un[3]>=0?pU_DataSet[Un[3]]:-pU_DataSet[-Un[3]];

    temp1 = UF[0]*UF[0]*U_Out[0]+UF[1]*UF[1]*U_Out[1]+UF[2]*UF[2]*U_Out[2]+UF[3]*UF[3]*U_Out[3];
    temp2 = (UF[0]*UF[0]+UF[1]*UF[1]+UF[2]*UF[2]+UF[3]*UF[3]);
    out = temp1/temp2;

    return out;
}

void fuzzyDomain(float E, float *pEF, int8_t *pEn, float *pE_DataSet, int8_t n)
{
    int8_t i;
    int8_t t;
    if(E>-*(pE_DataSet+n)&&E<*(pE_DataSet+n))
    {
        for(i = 1; i<2*n+1; i++)
        {
            t = i-n;
            if(t>0)
            {
                if(E<=*(pE_DataSet+t))
                {
                    *pEn = t;
                    pEF[0] = P_level*(*(pE_DataSet+t)-E)/(*(pE_DataSet+t) - *(pE_DataSet+t-1));
                    break;
                } else
                    continue;
            } else
            {
                if(E<=-*(pE_DataSet-t))
                {
                    *pEn = t;
                    pEF[0] = P_level*(-*(pE_DataSet-t)-E)/(*(pE_DataSet-t+1) - *(pE_DataSet-t));
                    break;
                } else
                    continue;
            }
        }
    } else if(E <= -*(pE_DataSet+n))
    {
        *pEn = -(n-1);
        pEF[0] = F_max;
    }
    else if(E >= *(pE_DataSet+n))
    {
        *pEn = n;
        pEF[0] = 0;
    }
    pEF[1]=F_max-pEF[0];    // 函数对称性
}
