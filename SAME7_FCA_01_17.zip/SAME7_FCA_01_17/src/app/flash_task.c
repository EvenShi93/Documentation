#include "flash_task.h"
#include "math.h"

//#define ACC_PARAM_OFFSET 0
#define FCA_PARAM_OFFSET 0
#define ESC_PARAM_OFFSET 2
#define MAG_PARAM_OFFSET 5
#define DSN_PARAM_OFFSET 34
#define VOL_PARAM_OFFSET 51
#define AssembleOffset_OFFSET 64

//extern float AccM[7];
float *MagM;
uint8_t MagCaliDataIsValid = 0;

//extern unsigned char accParamDirty;
extern uint8_t WriteVoltParamFlag;
extern unsigned char magParamDirty;
//extern unsigned char AngOffNeedCorrect;
extern uint8_t DroneSN[16];
extern uint16_t ESC_Version;
extern uint8_t VoltParamValid;
//extern float Flow_OffsetAngPit, Flow_OffsetAngRol;
#if MOT_PREBURNING_ENABLE && defined(CTRL_A9)
extern uint8_t SN_WriteCnt;
extern uint8_t DroneSN_WriteFlag;
#else
uint8_t SN_WriteCnt = 0;
uint8_t DroneSN_WriteFlag = 0;
#endif
unsigned char paramBuffer[100] = {0};
//PARAM_FLASH accParam;
MAG_PARAM_FLASH magParam;
VOL_PARAM_FLASH volParam;
//AssembleOffset AngOff;
unsigned char flashUpdateFlag = 0;
static uint8_t Index = 0;
void flash_10ms_task(void)
{
    static unsigned char flashReadFlag = 0;
    if(flashReadFlag == 0)
    {
        flashReadFlag = 1;
///* <! ----------------------------Get ESC Version ---------------------- */
//		open(flash_getID());
//		ioctrl(flash_getID(), FLASH_RWE_SECTOR_ADDR_SETTING, (void *)0x43FF00);//set addr.
//		read(flash_getID(), &ESC_Version, 2);//read data.
//		close(flash_getID());
///* <! ---------------------------- Get ESC Version ---------------------- */
        flashM_read(paramBuffer, 100);

		//Get ESC Version.
		ESC_Version = (uint16_t)paramBuffer[ESC_PARAM_OFFSET + 1] << 8 | paramBuffer[ESC_PARAM_OFFSET];
		//Get Mag calibration data.
        for(uint8_t i = 0; i < 28; i++)
            magParam.data[i] = paramBuffer[i + MAG_PARAM_OFFSET];
		for(uint8_t i = 0; i < 8; i ++)
			volParam.Data[i] = paramBuffer[i + VOL_PARAM_OFFSET];
		if(paramBuffer[0 + DSN_PARAM_OFFSET] == 'Y' && paramBuffer[1 + DSN_PARAM_OFFSET] == 'U')
		{
			//Get Drone S/N
			for(uint8_t i = 0; i < 16; i ++)
				DroneSN[i] = paramBuffer[i + DSN_PARAM_OFFSET];
		}
		else
		{
			DroneSN_WriteFlag = 1;
		}
		for(Index = 0; Index < 7; Index ++)
		{
			if(__ARM_isnanf(magParam.Cal_F[Index]))
				break;
		}
		if(Index >= 7)
		{
			if((fabs(magParam.Cal_F[4] - 1.0f) < 0.3f && fabs(magParam.Cal_F[5] - 1.0f) < 0.3f && fabs(magParam.Cal_F[6] - 1.0f) < 0.3f) && \
				fabsf(magParam.Cal_F[0]) < 70 && fabsf(magParam.Cal_F[1]) < 70 && fabsf(magParam.Cal_F[2]) < 70)
			{
				MagM = GetCalMatrix();
				for(unsigned short i = 0; i < 7; i ++)
				{
					OS_ALLOC_SR();
					OS_ENTER_CRITICAL();
					MagM[i] = magParam.Cal_F[i];
					OS_EXIT_CRITICAL();
				}
				MagCaliDataIsValid = 1;
			}
		}
		if(!__ARM_isnanf(volParam.fData[0]) && !__ARM_isnanf(volParam.fData[1]))
		{
			if(volParam.fData[0] < 0.1f && volParam.fData[0] > 0.0f)
				SetVoltCalParam(volParam.fData[0], volParam.fData[1]);
			else
			{
				SetVoltCalParam(0.00969f, -3.186785f);//默认值适用老电阻
				VoltParamValid = 1;
				WriteVoltParamFlag = 1;//写入FLASH
			}
		}
		else
		{
			SetVoltCalParam(0.00969f, -3.186785f);//默认值适用老电阻
			VoltParamValid = 1;
			WriteVoltParamFlag = 1;//写入FLASH
		}

//        for(unsigned char i = 0; i < 8; i ++)
//            AngOff.Data[i] = paramBuffer[i + AssembleOffset_OFFSET];

//        if(__ARM_isnanf(AngOff.OffsetAng[0]) || __ARM_isnanf(AngOff.OffsetAng[1]))//get assemble offset.
//        {
//            AngOff.OffsetAng[0] = 0;
//            AngOff.OffsetAng[1] = 0;
//            Flow_OffsetAngPit = 0;
//            Flow_OffsetAngRol = 0;
//        }
//        else
//        {
//            Flow_OffsetAngPit = AngOff.OffsetAng[0];
//            Flow_OffsetAngRol = AngOff.OffsetAng[1];
//        }
    }
    if(magParamDirty == 1)
    {
        OS_ALLOC_SR();
        OS_ENTER_CRITICAL();
		MagM = GetCalMatrix();
        for(unsigned short i = 0; i < 7; i ++)
        {
            //写入flash
            magParam.Cal_F[i] = MagM[i];
        }
        OS_EXIT_CRITICAL();

        for(unsigned short i = 0; i < 28; i ++)
        {
            paramBuffer[MAG_PARAM_OFFSET + i] = magParam.data[i];
        }
        magParamDirty = 0;
        flashUpdateFlag = 1;
    }
	if(DroneSN_WriteFlag == 1 && SN_WriteCnt == 0)
	{
		for(uint8_t i = 0; i < 16; i ++)
			paramBuffer[i + DSN_PARAM_OFFSET] = DroneSN[i];
		SN_WriteCnt ++;
		DroneSN_WriteFlag = 0;
		flashUpdateFlag = 1;
	}
	if(WriteVoltParamFlag == 1)
	{
		GetVoltCalParam(volParam.fData);
		for(uint8_t i = 0; i < 8; i ++)
			paramBuffer[i + VOL_PARAM_OFFSET] = volParam.Data[i];
		WriteVoltParamFlag = 0;
		flashUpdateFlag = 1;
	}

//    if(AngOffNeedCorrect == 1)
//    {
//        OS_ALLOC_SR();
//        OS_ENTER_CRITICAL();
//        AngOff.OffsetAng[0] = Flow_OffsetAngPit;
//        AngOff.OffsetAng[1] = Flow_OffsetAngRol;
//        OS_EXIT_CRITICAL();

//        for(unsigned char i = 0; i < 8; i ++)
//        {
//            paramBuffer[AssembleOffset_OFFSET + i] = AngOff.Data[i];
//        }

//        AngOffNeedCorrect = 0;
//        flashUpdateFlag = 1;
//    }

    if(flashUpdateFlag == 1)
    {
        flashUpdateFlag = 0;
        flashM_earse();
        flashM_write(paramBuffer, 100);
    }
}

inline uint8_t MagCalDataValid(void)
{
	return MagCaliDataIsValid;
}
