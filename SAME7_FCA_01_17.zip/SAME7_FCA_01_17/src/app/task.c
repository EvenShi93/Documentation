#include "task.h"
#include "maths.h"
#include "fuzzyPID.h"

OS_EVENT* task_1ms;
OS_EVENT* task_5ms;
OS_EVENT* task_10ms;
OS_EVENT* task_10ms2;
OS_EVENT* Flow_Task_8ms;

unsigned int task2_1_s_count = 0;
unsigned int task3_1_s_count = 0;
unsigned int task4_1_s_count = 0;
unsigned int task5_1_s_count = 0;

uint32_t task1_InvokedTime_us = 0;
uint32_t task2_InvokedTime_us = 0;
uint32_t task3_InvokedTime_us = 0;
uint32_t task4_InvokedTime_us = 0;

uint32_t task1_OccupyTime_us = 0;
uint32_t task2_OccupyTime_us = 0;
uint32_t task3_OccupyTime_us = 0;
uint32_t task4_OccupyTime_us = 0;

uint32_t Gry_OccupyUS = 0;
uint32_t Mag_OccupyUS = 0;
uint32_t Press_OccupyUS = 0;
//������ʼ�����
uint8_t DeviceInit = 0;

volatile uint8_t IIC_busy_flag = 0;

unsigned char taskStartFlag = 0;
void task_1ms_int(void)
{
    static unsigned int timerTaskCount = 0;

    if(taskStartFlag == 1)//1ms task
    {
        timerTaskCount ++;

        OSSemPost(task_1ms);
        if((timerTaskCount % 5) == 1)//5ms task
        {
            OSSemPost(task_5ms);
        }
		else if((timerTaskCount % 5) == 2)
		{
			if((timerTaskCount % 10) == 2)
			{
				OSSemPost(task_10ms);
			}
			else if((timerTaskCount % 10) == 7)
			{
				OSSemPost(task_10ms2);
			}
		}

        if(timerTaskCount >= 60000)
        {
            timerTaskCount = 0;
        }
    }
}

extern Nav_struct_PosHold PH;

void AppTask1(void *p_arg)
{
	DeviceInit = DroneSystemParamInit(middleware_init());//ϵͳ��ʼ��
//����
	if((DeviceInit & DEV_ERR_AT24CXX) != 0 || (DeviceInit & DEV_ERR_DATAGET) != 0)
		SetToneCmd(EEPROMErr);
	if((DeviceInit & DEV_ERR_MPU6500) != 0)
		SetToneCmd(MPU6500Err);
	if((DeviceInit & DEV_ERR_IST8307) != 0)
		SetToneCmd(IST8307Err);
	if((DeviceInit & DEV_ERR_BMS56XX) != 0)
		SetToneCmd(MS56xxErr);
	if((DeviceInit & DEV_ERR_FLOWCAM) != 0)
		SetToneCmd(FlowCamera);
	if((DeviceInit & DEV_ERR_UBLOXM8) != 0)
		SetToneCmd(UBLOXM8Err);
	if((DeviceInit & DEV_ERR_ALLMASK) == 0)
		SetToneCmd(Startup);

	pid_init();
	memset(&PH, 0, sizeof(PH));

    task_1ms = OSSemCreate(0);
    task_5ms = OSSemCreate(0);
    task_10ms = OSSemCreate(0);
    task_10ms2 = OSSemCreate(0);
#if USE_CAM_FLOW
    Flow_Task_8ms = OSSemCreate(0);
#endif

    taskStartFlag = 1;

    OSTaskDel(OS_PRIO_SELF);

    while(1);
}

uint32_t flow_us = 0;
uint32_t flow_us5 = 0;
uint32_t flow_us10 = 0;
uint32_t flowcpy_us = 0;

uint16_t Gry_OccupyUS_err = 0;

uint16_t FlowCopy = 0;

void AppTask2(void *p_arg)
{
    INT8U error = 0;
    while(1)
    {
        OSSemPend(task_1ms, 0xffff, &error);
        if(error == OS_ERR_NONE)
        {
            static uint32_t flow_usT = 0;
            task1_InvokedTime_us = _Get_Micros() - flow_usT;
            flow_usT = _Get_Micros();

            static unsigned int task2_count = 0;
            task2_count ++;
            if(task2_count >= 1000)
            {
                task2_count = 0;
                task2_1_s_count ++;
            }
if((DeviceInit & DEV_ERR_MPU6500) == 0)//MPU6500��ʼ������
{
            acc_gyro_1ms_task();
			MagCalGyrIntegTask();
}

            Gry_OccupyUS = _Get_Micros() - flow_usT;

            if(Gry_OccupyUS > 300) Gry_OccupyUS_err ++;

#if USE_CAM_FLOW

            uint32_t usT = _Get_Micros();
if((DeviceInit & DEV_ERR_FLOWCAM) == 0)//������ʼ������
            FlowTask_1ms();
            flowcpy_us= _Get_Micros() - usT;

#endif
            volt_switch_1ms_task();
            attitude_quat_1ms_task();
            attitude_pid_1ms_task();
            attitude_accEF_1ms_task();
            fly_switch_1ms_task();
            moto_1ms_task();

            task1_OccupyTime_us = _Get_Micros() - flow_usT;

            if(task1_OccupyTime_us > 250) FlowCopy ++;
        }
    }
}

uint32_t press_us = 0;

uint16_t pressTimeOut = 0;
uint16_t pressTimeMax = 0;
void AppTask3(void *p_arg)
{
    INT8U error = 0;

    while(1)
    {
        OSSemPend(task_5ms, 0xffff, &error);
        if(error == OS_ERR_NONE)
        {
            static uint32_t flow_usT = 0;
            task2_InvokedTime_us = _Get_Micros() - flow_usT;
            flow_usT = _Get_Micros();

            static unsigned int task3_count = 0;
            task3_count ++;
            if(task3_count >= 200)
            {
                task3_count = 0;
                task3_1_s_count ++;

                if(task3_1_s_count % 2 == 0) close(led_getID());
                else open(led_getID());
            }

            Mag_OccupyUS = _Get_Micros() - flow_usT;

            rfM_task();
            rf_5ms_task();
            LedTask();

#if USE_CAM_FLOW
            FlowComp_5msTask();
            FlowHold_Task();
#endif
			if((task3_count % 20) == 0)
if((DeviceInit & DEV_ERR_FLOWCAM) == 0)//������ʼ������
			GetCamLumValue();

					if((task3_count % 2) == 0)
					{
							IIC_busy_flag = 1;
							if((DeviceInit & DEV_ERR_IST8307) == 0)//�شų�ʼ������
							mag_5ms_task();

							IIC_busy_flag = 0;

							if((DeviceInit & DEV_ERR_UBLOXM8) == 0)//GPS��ʼ������
							gps_10ms_task();

							height_10ms_task();
							PosEst_task();
							PosHold_task();
							GoHomeTask();
							JourneyTask();
							Selfie_Task();
							FollowMeTask();
							Alt_VelHoldLoop_10ms_task();
					}
          else
          {
							uint32_t press_usT = _Get_Micros();

							IIC_busy_flag = 1;
							if((DeviceInit & DEV_ERR_BMS56XX) == 0)//��ѹ�Ƴ�ʼ������
							pressure_10ms_task();
							IIC_busy_flag = 0;

							Press_OccupyUS = _Get_Micros() - press_usT;
							if(press_us > 300)
							{
							  pressTimeMax = press_us;
							  pressTimeOut ++;
							}
           }

			attitude_quat_5ms_loop();
            attitude_pid_5ms_task();
			rfSend_Task();
            task2_OccupyTime_us = _Get_Micros() - flow_usT;
        }
    }
}

//10ms
void AppTask4(void *p_arg)
{
    INT8U error = 0;
    while(1)
    {
        OSSemPend(task_10ms, 0xffff, &error);
        if(error == OS_ERR_NONE)
        {
            static uint32_t flow_usT = 0;
            task3_InvokedTime_us = _Get_Micros() - flow_usT;
            flow_usT = _Get_Micros();

            static unsigned int task4_count = 0;
            task4_count ++;
            if(task4_count >= 100)
            {
                task4_count = 0;
                task4_1_s_count ++;
            }

            flash_10ms_task();
if((DeviceInit & DEV_ERR_MPU6500) == 0 && (GetPowerStat() == POWER_ON))//MPU6500��ʼ������,���ڿ���״̬��
            gyro_calibration_10ms_task();

			MagCalCmdDetect();

            if((task4_count % 10) == 0)//100ms
            {
#if defined(USE_E2PROM_CAL_DATA)
				//EEPROM��ʼ���Լ���ȡ���ݳɹ�,���ڿ���״̬��
if((DeviceInit & DEV_ERR_AT24CXX) == 0 && (DeviceInit & DEV_ERR_DATAGET) == 0 && (GetPowerStat() == POWER_ON))
                IMUCaliTask();
#endif /* defined(USE_E2PROM_CAL_DATA) */

				mag_calibration_100ms_task();
            }

            task3_OccupyTime_us = _Get_Micros() - flow_usT;
        }
    }
}

#if USE_CAM_FLOW
void FlowTaskLoop(void *p_arg)
{
    INT8U error = 0;
    while(1)
    {
        OSSemPend(Flow_Task_8ms, 0xffff, &error);
        if(error == OS_ERR_NONE)
        {
            Flow_Main();
        }
    }
}
#endif

void AppTask5(void *p_arg)
{
    INT8U error = 0;
    while(1)
    {
        OSSemPend(task_10ms2, 0xffff, &error);
        if(error == OS_ERR_NONE)
        {
            static uint32_t flow_usT = 0;
            task4_InvokedTime_us = _Get_Micros() - flow_usT;
            flow_usT = _Get_Micros();

            static unsigned int task5_count = 0;
            task5_count ++;
            if(task5_count >= 100)
            {
                task5_count = 0;
                task5_1_s_count ++;
            }

#if USE_DATA_TRANSFER
            monitor_10ms_task();
#endif

            AutoShutDown_Task();
			ShutDownTask();

			EngineModeTask();

            task4_OccupyTime_us = _Get_Micros() - flow_usT;
        }
    }
}
