#ifndef _GLOBAL_TYPE_H_
#define _GLOBAL_TYPE_H_

#include "platform.h"

typedef struct
{
    float qw;
    float qx;
    float qy;
    float qz;
} Quat;

typedef struct
{
    float kp,ki,kd,PreErr,Pout,Iout,Dout,Output,I_max,I_sum,Dt,DLPF, EC,kp_temp;

} PID; //PID

typedef struct
{
    float Rool;
    float Pitch;
    float Yaw;
} FLOAT_RPY;

typedef struct
{
    float X;
    float Y;
    float Z;
} FLOAT_XYZ;

typedef struct
{
    float accX;
    float accY;
    float accZ;
} FLOAT_ACC;

typedef struct
{
    float gyroX;
    float gyroY;
    float gyroZ;

} FLOAT_GYRO;

typedef struct
{
    float magX;
    float magY;
    float magZ;

} FLOAT_MAG;

typedef struct
{
    short gyroX;
    short gyroY;
    short gyroZ;
} GYRO_RAW_SHORT;

typedef struct
{
    short accX;
    short accY;
    short accZ;
} ACC_RAW_SHORT;

typedef struct
{
    short value;
} TEMP_RAW_SHORT;

typedef struct
{
    int16_t magX;
    int16_t magY;
    int16_t magZ;
} MAGNET_RAW_SHORT;

typedef struct
{
	float X;
	float Y;
}_2AxisFloat;

typedef struct
{
	double X;
	double Y;
}_2AxisDouble;

typedef struct
{
	float X;
	float Y;
	float Z;
}_3AxisFloat;

typedef struct
{
	uint16_t X;
	uint16_t Y;
}_2AxisRaw;

typedef struct
{
	uint16_t X;
	uint16_t Y;
	uint16_t Z;
}_3AxisRaw;

typedef enum
{
	ERR_OK = 0,
	ERR_WARNING = 1,
	ERR_BAD = 2
}ErrCode;

typedef struct
{
    GYRO_RAW_SHORT* gyro_raw_short;
    ACC_RAW_SHORT* acc_raw_short;
    MAGNET_RAW_SHORT* magnet_raw_short;
} _9AXIE; //������xyz

typedef struct
{
    int temperature;
    int pressure;
    unsigned char check_flag;

} PRESSURE_RAW;

typedef struct
{
    float pos_exp_x, pos_exp_y;//Ŀ��λ��
    float pos_target_x, pos_target_y;//Ŀ��λ��
    float pos_error_x, pos_error_y;//��ǰλ�ú�Ŀ��λ�õ�λ�����

    float vel_exp_x, vel_exp_y;//�����ٶ�
    float vel_target_x, vel_target_y;//�����ٶ�

    float accel_target_x, accel_target_y;//Ŀ����ٶ�
	float acc_exp_x, acc_exp_y;
} Nav_struct_PosHold;

typedef struct
{
    float r1,r1_pre;
    float r2,r2_pre;
    float delta,h0,dt;
} ADRC_str;

typedef struct
{
		float B1,B2,B3;
		float dt;		
		float z1,z2,z3;	
}ESO;

typedef struct
{
	float Acc, Vel, velMax, Pos, LastPos, expPos, dt;
}QuadCurve;//element Acc,velMax should be > 0, all element has the same unit.





#endif
