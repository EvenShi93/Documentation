#include "GoHome.h"

#define GOHOME_DT 0.01f
#define GOHOME_ALT_VEL 150  /* 1.5m/s */
#define GOHOME_ALT_ACC 1.0f /* 1.0m/s^2 */
#define GOHOME_POS_VEL 300  /* 3.0m/s */
#define GOHOME_POS_ACC 1.5f /* 1.5m/s^2 */

static void GoHome_Exp_pos(void);
static void GoHome_Exp_alt(void);

uint8_t GoHomeRet = 0;
QuadCurve GoHomeCurve = {0};
_2AxisFloat GoHomeStartPoint = {0};

uint32_t rfLostHoverTime = 0;

uint8_t GetAltFlag = 0, GoHomeStart = 0, GetPoint = 0;
uint32_t GetAltTimeCnt = 0, GetPntTimeCnt = 0;

float AccInit_x = 0.0f, AccInit_y = 0.0f;
float VelInit_x = 0.0f, VelInit_y = 0.0f;

float GoHomeExpAlt = 20.0f;
float GoHomeExpAltVel = 0.0f;
static float AltVelRemnant = 0.0f;
void GoHomeTask(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

	unsigned char curRFMode = RFMode;
	static unsigned char oldRFMode = RFMODE_9AXIE;

	OS_EXIT_CRITICAL();

	if((oldRFMode != curRFMode) && (curRFMode == RFMODE_GOHOME))
	{
		GetPoint = 0;
		GoHomeRet = 0;
		GetAltFlag = 0;
		GoHomeStart = 0;
		GetAltTimeCnt = 0;
		GetPntTimeCnt = 0;
		rfLostHoverTime = 0;

		GoHomeExpAltVel = 0.0f;
		GoHomeExpAlt = GetDroneSysParam()->GoHomeHeight * 10.0f;
		if(IsEntryNFZ_1())
			GoHomeExpAlt = Min(2000, GoHomeExpAlt);
		if(IsEntryNFZ_2())
			GoHomeExpAlt = Min(1000, GoHomeExpAlt);

		AltVelRemnant = JourneyModeExpAltVel() * 0.01f;

		PH.pos_exp_x = PH.pos_target_x;
		PH.pos_exp_y = PH.pos_target_y;

		VelInit_x = PH.vel_exp_x;//��ȡ��ʼ�����ٶ�
		VelInit_y = PH.vel_exp_y;
		AccInit_x = PH.acc_exp_x;//��ȡ��ʼ���ٶ�ǰ��
		AccInit_y = PH.acc_exp_y;
	}
	if((oldRFMode == RFMODE_GOHOME) && (curRFMode != RFMODE_GOHOME))//�˳�GoHome��ȡ������
	{
		if(GetAutoLandSta() == 1)
			ExitAutoLand();
	}

	oldRFMode = curRFMode;

	if(curRFMode == RFMODE_GOHOME)
	{
		GoHome_Exp_pos();
		if(GetAltFlag == 0)
			GoHome_Exp_alt();
		Pos_to_rate_xy(PH.vel_exp_x, PH.vel_exp_y);
		Rate_to_accel_xy(PH.acc_exp_x, PH.acc_exp_y);
		ComputePositionQuat();
	}
}

float GoHomeExpVel = 0.0f;
float cosGoHomeAng = 0.0f, sinGoHomeAng = 0.0f;
static void GoHome_Exp_pos(void)
{
	Sonar SonarInfo = GetSonicDistance();

	if(GoHomeStart == 0)
	{
		if((fabs(PH.vel_exp_x) + fabs(PH.vel_exp_y) < 1.0f) && (fabs(PH.acc_exp_x) + fabs(PH.acc_exp_y) < 1.0f))
		{
			PH.vel_exp_x = PH.vel_exp_y = 0;
			PH.acc_exp_x = PH.acc_exp_y = 0;
			if(GetAltFlag == 1)
			{
				GoHomeStart = 1;
				GoHomeExpVel = 0.0f;

				float dx = GetHomePoint()->X - PH.pos_exp_x;
				float dy = GetHomePoint()->Y - PH.pos_exp_y;
				float dis_home = sqrtf(dx * dx + dy * dy);

				if(dis_home != 0)
				{
					GetPoint = 0;
					GoHomeRet = 0;

					GoHomeCurve.Acc = GOHOME_POS_ACC * 100;
					GoHomeCurve.dt = GOHOME_DT;
					GoHomeCurve.expPos = dis_home;
					GoHomeCurve.velMax = GOHOME_POS_VEL;
					GoHomeCurve.Vel = 0;
					GoHomeCurve.LastPos = 0;
					GoHomeCurve.Pos = 0;
					GoHomeStartPoint.X = PH.pos_exp_x;
					GoHomeStartPoint.Y = PH.pos_exp_y;

					cosGoHomeAng = dx / dis_home;
					sinGoHomeAng = dy / dis_home;
				}
				else
				{
					GetPoint = 1;
				}
			}
		}
		else
		{
			//һ��ɲ������,�����ж�������ʱʹ��  //�Կ�
			PH.vel_exp_x = PH.vel_exp_x * 0.93f;
			PH.vel_exp_y = PH.vel_exp_y * 0.93f;
			PH.acc_exp_x = PH.acc_exp_x * 0.93f;
			PH.acc_exp_y = PH.acc_exp_y * 0.93f;
			PH.pos_exp_x += PH.vel_exp_x * GOHOME_DT + 0.5f * PH.acc_exp_x * GOHOME_DT * GOHOME_DT;
			PH.pos_exp_y += PH.vel_exp_y * GOHOME_DT + 0.5f * PH.acc_exp_y * GOHOME_DT * GOHOME_DT;
		}
    }
    else if(GetPoint == 0)
    {
		GoHomeRet = QuadCurveCtrl(&GoHomeCurve, (GetLowPowerFlag() != 2));
		PH.pos_exp_x = GoHomeStartPoint.X + GoHomeCurve.Pos * cosGoHomeAng;
		PH.pos_exp_y = GoHomeStartPoint.Y + GoHomeCurve.Pos * sinGoHomeAng;

		if(GoHomeRet == 0)
		{
			GetPoint = 1;
		}
    }
	else if(GetPoint == 1)
	{
//		Sonar SonarInfo = GetSonicDistance();
		//define -3
		if(rfIsLost() == 0 && GetAutoLandSta() == 0)
			EntryAutoLand();
		else if(rfIsLost())
		{
			if(rfLostHoverTime < 3000 && UserExpMode != 8)
				rfLostHoverTime ++;
			else
				EntryAutoLand();
		}
		//define -2
//		if(rfIsLost() == 0 && GetAutoLandSta() == 0)
//			EntryAutoLand();
//		else if(rfIsLost())
//		{
//			if(SonarInfo.sonar_distance_filtered > 1.6f && GetAutoLandSta() == 0)
//				EntryAutoLand();
//			else if(SonarInfo.distance_valid && SonarInfo.sonar_distance_filtered <= 1.6f && rfLostHoverTime < 3000)
//			{
//				ExitAutoLand();
//				rfLostHoverTime ++;
//			}
//			else if(rfLostHoverTime >= 3000)
//				EntryAutoLand();
//		}
		//define -1
//		if((rfIsLost() == 0 || CurExpAlt() > 160.0f) && GetAutoLandSta() == 0)
//			EntryAutoLand();
//		else if(rfIsLost() && SonarInfo.distance_valid && SonarInfo.sonar_distance_filtered <= 1.6f && GetAutoLandSta() == 1)//ֹͣ�ڳ�����1.6m�߶�
//			ExitAutoLand();

		desired_vel_to_pos();
	}
}

static void GoHome_Exp_alt(void)//���߶ȴ���GoHomeҪ��ĸ߶�,���½�,ֱ��gohome
{
	if(fabsf(AltVelRemnant) > 0.01f)//��JOURNEY������ٶ�
	{
		AltVelRemnant = SGN(AltVelRemnant) * (fabsf(AltVelRemnant) - 0.01f);
		SetExp_Alt_Vel(CurExpAlt() + AltVelRemnant, 0);
		return;
	}
	float ExpAltErr = CurExpAlt() - GoHomeExpAlt;//GetDroneSysParam()->GoHomeHeight * 10.0f;//ALTDesired
	if(ExpAltErr < 0.0f && GetAutoLandSta() != 1)
	{
		if(GoHomeExpAltVel * GoHomeExpAltVel / (GOHOME_ALT_ACC * 200) + ExpAltErr >= 0)
		{
			if(GoHomeExpAltVel > GOHOME_ALT_ACC) GoHomeExpAltVel -= GOHOME_ALT_ACC;
			else GoHomeExpAltVel = 0;
		}
		else if(GoHomeExpAltVel < GOHOME_ALT_VEL)
			GoHomeExpAltVel += GOHOME_ALT_ACC;
		else
			GoHomeExpAltVel = GOHOME_ALT_VEL;

		SetExp_Alt_Vel(CurExpAlt() + GoHomeExpAltVel * GOHOME_DT, 0);//���������߶�
	}
	else if(ExpAltErr >= 0.0f && GetAutoLandSta() != 1)//��Home��ܽ������ѵ�ָ���߶� && GoHomeExpAltVel == 0
	{
		GoHomeExpAltVel = 0;
		if(GetAltTimeCnt < 10)
			GetAltTimeCnt ++;
		else
			GetAltFlag = 1;
	}
}

uint8_t GoHomeModeExit(void)
{
	if(GoHomeExpAltVel > GOHOME_ALT_ACC || GoHomeRet == 1)//GoHomeExpVel > GOHOME_POS_ACC
	{
		if(GoHomeExpAltVel > GOHOME_ALT_ACC)
		{
			GoHomeExpAltVel -= GOHOME_ALT_ACC;
			SetExp_Alt_Vel(CurExpAlt() + GoHomeExpAltVel * GOHOME_DT, 0);//���������߶�
		}

		if(GoHomeRet == 1)
		{
			GoHomeRet = QuadCurveCtrl(&GoHomeCurve, 0);
			PH.pos_exp_x = GoHomeStartPoint.X + GoHomeCurve.Pos * cosGoHomeAng;
			PH.pos_exp_y = GoHomeStartPoint.Y + GoHomeCurve.Pos * sinGoHomeAng;

		}
		return 1;
	}
	else
	{
		return 0;
	}
}
