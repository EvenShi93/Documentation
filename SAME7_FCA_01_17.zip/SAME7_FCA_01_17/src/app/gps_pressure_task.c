#include "gps_pressure_task.h"

GPS_DATA* gpsData;
unsigned char gps_set_flag = 0;
unsigned char gps_update_1time = 0;

void gps_10ms_task(void)
{
	gpsM_task();
	gpsData = get_gps_data();
	gps_set_flag = get_gps_set_flag();
	gps_update_1time = get_gps_update_flag();
}

static float pressure = 0;
void pressure_10ms_task(void)
{
	pressureM_task();
	pressure = get_pressure();
}

inline float GetPressureVal(void)
{
	return pressure;
}
