#ifndef __JOURNEY_H
#define __JOURNEY_H

#include "GoHome.h"

typedef struct
{
	float Length;
	float Angle;
//	float Exp_X, Exp_Y;
	float StartX, StartY, StartZ;
//	float EndP_X, EndP_Y, EndP_Z;
}JourneyParam;

typedef enum
{
	JourneyStop = 0,
	JourneyStart = 1,
	JourneyPause = 2,
	JourneyResum = 3
}JourneyCmdSta;

typedef enum
{
	AtPoint_A = 0,
	StartFrom_A = 1,
	AtPoint_B = 2,
	StartFrom_B = 3,
}JourneyRunSta;

void JourneyTask(void);
float JourneyModeExpAltVel(void);
JourneyCmdSta JourneyRunGet(void);
void JourneyRunSet(JourneyCmdSta JourneySta);
void JourneySetParam(float Length, float Angle);

#endif /* __JOURNEY_H */
