#include "attitude_task.h"
#include "maths.h"
#include "rf_task.h"
#include "fuzzyPID.h"

//extern float  Debug_Param[15];
extern FLOAT_ACC* accUnit;
extern FLOAT_GYRO* gyroUnit;
extern FLOAT_MAG* magUnit;
Quat imuQ = {1, 0, 0, 0};
Quat imuQ_9Axie = {1, 0, 0, 0};

extern unsigned char magErrorFlag;
FLOAT_RPY curEur = {0};
extern FLOAT_RPY expEur;
extern unsigned char flyEnable;
FLOAT_RPY rotateEur = {0};
Quat expQ = {0};
Quat rotateQ = {0};
FLOAT_XYZ  rotateAngleEF = {0};
FLOAT_XYZ  rotateAngleBF = {0};
extern float IMU_P,IMU_I;
unsigned int imuStableFlag = 0;
uint8_t accStain = 0; //加速度异常标记，当冲刺时

FLOAT_RPY magErrorEur = {0};
Quat magError_Q = {1, 0, 0, 0};

//1ms 四元数更新
void attitude_quat_1ms_task(void)
{
	FLOAT_ACC curAccUnit;
	FLOAT_GYRO curGyroUnit;
	FLOAT_MAG curMag;
	unsigned char curFlyEnable;

	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

	curAccUnit = *accUnit;
	curGyroUnit = *gyroUnit;
	curMag = *magUnit;
	curFlyEnable = flyEnable;
	OS_EXIT_CRITICAL();

	//根据飞机状态更改互补滤波系数
	if(curFlyEnable == 0)
	{
		if(imuStableFlag == 0)
		{
			IMU_P = 8.0f;
			IMU_I = 0;
		}
		else
		{
			 IMU_P = 5.0f;
			 IMU_I = 0.0f;
		}
	}
	else // flying
	{
		 IMU_P = 0.5f;
	}

	//等待IMU 角度解算稳定
	static unsigned int imuStableCount = 0;
	if(imuStableCount < 5000)
	{
		imuStableCount ++;
		imuStableFlag = 0;
	}
	else
	{
		imuStableFlag = 1;
	}

	//用 9Axie IMU更新四元数
	sensfusion9UpdateQ(&curGyroUnit, &curAccUnit, &curMag, 0.001f, &imuQ_9Axie);

	//旋转磁偏角到四元数内
	if(magErrorFlag == 1)
	{
		step_change(&(magErrorEur.Yaw), GetMagDecline(), 0.004f, 0.004f);
		EulerAngleToQuaternion1(&magErrorEur, &magError_Q);
		QuaternionMultiplicationCross(&imuQ_9Axie, &magError_Q, &imuQ);
	}
	else
	{
		imuQ = imuQ_9Axie;
	}
	//四元数到欧拉角
	Quat2Euler(&imuQ, &curEur);
}

FLOAT_RPY *GetCurEuler(void)
{
	return &curEur;
}

extern unsigned char RFMode;

FLOAT_RPY errEur = {0};
extern FLOAT_RPY expEurRate;
extern float Flow_ExpAngPit, Flow_ExpAngRol;
extern float Flow_OffsetAngPit, Flow_OffsetAngRol;
extern float SELFIE_ExpYaw;
static float yaw_targe = 0;
extern ModeReadyAct ReadyAct;
extern ModeOrbitAct OrbitAct;

inline float YawTarVal(void)
{
	return yaw_targe;
}

//姿态四元数控制环 5ms



ADRC_str Pitch_RC, Roll_RC;

ADRC_str Pitch_RC, Roll_RC;
extern FLOAT_RPY PositionXY_EUR;

FLOAT_RPY ExpEur_targe = {0,0,0};

void attitude_quat_5ms_loop(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

	Quat curImuQ;
	FLOAT_RPY curExpEur = {0,0,0};
	unsigned char curFlyEnable;
	unsigned char curRFMode = RFMode;
	Quat temp_Q;
	curImuQ = imuQ;
	curFlyEnable = flyEnable;

	OS_EXIT_CRITICAL();

	static float yaw_rate = 0;

	if(curFlyEnable == 0)
	{
		yaw_targe = curEur.Yaw;
		InitSelfieYaw(yaw_targe);
		InitFollowExpYaw(yaw_targe);
	}
	else
	{
		if(curRFMode == RFMODE_HEIGHT)
			step_change(&yaw_rate, apply_deadband(expEur.Yaw * 1.5f, 15) * 0.005f, 5, 5);
		else
			step_change(&yaw_rate, apply_deadband(expEur.Yaw * 2, 3) * 0.005f, 10, 10);

		if(curRFMode == RFMODE_SELFIE || (curRFMode == RFMODE_ORBIT && OrbitAct == OrbitAct_ME)) yaw_targe = SELFIE_ExpYaw;
		else if(curRFMode == RFMODE_FOLLOWME) yaw_targe = GetFollowExpYaw();
		else
		{
			yaw_targe += yaw_rate;
			if(yaw_targe > 180) yaw_targe -= 360;
			if(yaw_targe < -180) yaw_targe += 360;
			InitFollowExpYaw(yaw_targe);
			InitSelfieYaw(yaw_targe);
		}
	}

	//高度模式使或READY模式下用光流输出的欧拉角
	if(curRFMode == RFMODE_HEIGHT || (curRFMode == RFMODE_READY && ReadyAct == ReadyHoldFlow))
	{
		if(fabsf(Flow_ExpAngPit-curEur.Pitch)>5)
		{
			if(Flow_ExpAngPit>curEur.Pitch)
				curExpEur.Pitch = curEur.Pitch+5;
			else
				curExpEur.Pitch =curEur.Pitch-5;
			curExpEur.Pitch = constrain_float(curExpEur.Pitch, -10, 10);
		}
		else
			curExpEur.Pitch = constrain_float(Flow_ExpAngPit, -10, 10);

		if(fabsf(Flow_ExpAngRol-curEur.Rool)>5)
		{
			if(Flow_ExpAngRol>curEur.Rool)
				curExpEur.Rool =curEur.Rool+5;
			else
				curExpEur.Rool =curEur.Rool-5;
			curExpEur.Rool = constrain_float(curExpEur.Rool, -10, 10);
		}
		else
			curExpEur.Rool = constrain_float(Flow_ExpAngRol, -10, 10);
		curExpEur.Yaw = yaw_targe;
	}
	else if(curRFMode == RFMODE_9AXIE)//手动模式使用的遥控器欧拉角
	{
		curExpEur.Pitch = expEur.Pitch;
		curExpEur.Rool  = expEur.Rool;
		curExpEur.Yaw = yaw_targe;
	}
	else if( curRFMode == RFMODE_POSITION || curRFMode == RFMODE_GOHOME || curRFMode == RFMODE_SMART || curRFMode == RFMODE_SELFIE || \
			(curRFMode == RFMODE_READY && ReadyAct == ReadyHoldGPS) || curRFMode == RFMODE_ORBIT || curRFMode == RFMODE_JOURNEY || curRFMode == RFMODE_FOLLOWME)
	{
		curExpEur.Pitch = 0;//PositionXY_EUR.Pitch;
		curExpEur.Rool  = 0;//PositionXY_EUR.Rool;
		curExpEur.Yaw = yaw_targe;//yaw_Ctrl_targe
	}
	//最终输出到 ExpEur_targe 

	ExpEur_targe.Pitch=curExpEur.Pitch;
	ExpEur_targe.Rool= curExpEur.Rool;

	if(fabsf(curExpEur.Yaw-ExpEur_targe.Yaw) >= 180)
	{
		if(curExpEur.Yaw<=ExpEur_targe.Yaw)
			ExpEur_targe.Yaw-= 360;
		else if(curExpEur.Yaw>ExpEur_targe.Yaw)
			ExpEur_targe.Yaw+= 360;			
	}
	if(curRFMode == RFMODE_FOLLOWME)
	{
		ExpEur_targe.Yaw = ExpEur_targe.Yaw * 0.8f + curExpEur.Yaw * 0.2f;
		step_change(&ExpEur_targe.Yaw, curExpEur.Yaw, 0.8f, 0.8f);
	}
	else
	{
		ExpEur_targe.Yaw = ExpEur_targe.Yaw * 0.92f + curExpEur.Yaw * 0.08f;
		step_change(&ExpEur_targe.Yaw, curExpEur.Yaw, 0.4f, 0.4f);
	}

	//期望欧拉角转期望四元数
	EulerAngleToQuaternion1(&ExpEur_targe, &expQ);
	//实际四元数与期望四元数误差大
	if(fabs(expQ.qw - curImuQ.qw) > 1 || fabs(expQ.qz - curImuQ.qz) > 1)
	{
		expQ.qw = -expQ.qw;
		expQ.qx = -expQ.qx;
		expQ.qy = -expQ.qy;
		expQ.qz = -expQ.qz;
	}

	//室外定位模式叠加位置环四元数
	if(curRFMode == RFMODE_POSITION || \
		curRFMode == RFMODE_GOHOME   || \
		curRFMode == RFMODE_SMART    || \
		curRFMode == RFMODE_SELFIE   || \
		(curRFMode == RFMODE_READY && ReadyAct == ReadyHoldGPS) || 
		curRFMode == RFMODE_ORBIT    || \
		curRFMode == RFMODE_JOURNEY  || \
		curRFMode == RFMODE_FOLLOWME)
	{
		QuaternionMultiplicationCross(GetPositionQuat(), &expQ, &temp_Q);
		expQ=temp_Q;
	}
	//得到误差四元数
	QuaternionDiviCross(&curImuQ, &expQ, &rotateQ);

	// rotateQ 为误差四元数，得到旋转角
	Quat2Euler(&rotateQ, &errEur);

	rotateAngleEF.X = constrain_float(errEur.Rool, -35, 35);
	rotateAngleEF.Y = constrain_float(errEur.Pitch, -35, 35);
	rotateAngleEF.Z = constrain_float(errEur.Yaw, -35, 35);

	//将旋转角转到机体 rotateAngleEF -> rotateAngleBF
	quaternion_rotateVector(&curImuQ, &rotateAngleEF, &rotateAngleBF, 1);
}


PID pidPitch, pidRoll, pidPitchRate, pidRollRate, pidYawRate;
PID fuzzy_Pitch, fuzzy_Roll;

PID fPitch_LPF, fRoll_LPF;

float PitchPreErrLPF = 0.0f, PitchEC_LPF = 0.0f;
float RollPreErrLPF = 0.0f, RollEC_LPF = 0.0f;

ADRC_str Gz_adrc;

float LPF_PAR = 0.5f;
void pid_init(void)
{
	pidPitch.kp = 13.0f;
	pidPitch.kd = 0.0f;
	pidPitch.ki = 0.0f;
	pidPitch.I_max = 100;
	pidPitch.Dt = 0.005f;

	pidRoll.kp = 13.0f;
	pidRoll.kd = 0.0f;
	pidRoll.ki = 0.0f;
	pidRoll.I_max = 100;
	pidRoll.Dt = pidPitch.Dt;

	pidPitchRate.kp_temp = pidPitchRate.kp = 1.0f;
	pidPitchRate.kd = 0.0f;
	pidPitchRate.ki = 0.2f;
	pidPitchRate.I_max = 200;
	pidPitchRate.Dt = 0.001f;

	pidRollRate.kp = pidRollRate.kp_temp = 1.0f;
	pidRollRate.kd = 0.0f;
	pidRollRate.ki = 0.2f;
	pidRollRate.I_max = pidPitchRate.I_max;
	pidRollRate.Dt = pidPitchRate.Dt;

	pidYawRate.kp = 8.0f;
	pidYawRate.kd = 0.0f;
	pidYawRate.ki = 0.5f;
	pidYawRate.I_max = 50.0f;
	pidYawRate.Dt = 0.001f;

	//TD跟踪微分
	Pitch_RC.dt=Roll_RC.dt=0.005;
	Pitch_RC.h0=Roll_RC.h0=0.05;
	Pitch_RC.delta=Roll_RC.delta=6000;

	Gz_adrc.dt=0.001;
	Gz_adrc.h0=0.02;
	Gz_adrc.delta=50000;
}

#define Yaw_P_Gain 8.0f

float GxLPF = 0, GyLPF = 0, GzLPF = 0;

//1ms 角速度内环控制
void attitude_pid_1ms_task(void)
{
	FLOAT_GYRO curGyroUnit;
	unsigned char curFlyEnable;
	unsigned char curRFMode = RFMode;

	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();

	curGyroUnit = *gyroUnit;
	curFlyEnable = flyEnable;

	OS_EXIT_CRITICAL();

	GyLPF = curGyroUnit.gyroY;
	GxLPF = curGyroUnit.gyroX;

	//GxLPF = GxLPF * 0.9f + curGyroUnit.gyroX * 0.1f;

	ADRC_td(curGyroUnit.gyroZ,&Gz_adrc);
	GzLPF = Gz_adrc.r1;

	pidPitchRate.kp = pidPitchRate.kp_temp;//+ fPitch_LPF.kp;
	pidRollRate.kp = pidRollRate.kp_temp;//+ fRoll_LPF.kp;

	if(curRFMode == RFMODE_9AXIE)
	{
		pid_loop(&pidPitchRate, pidPitch.Output +(Pitch_RC.r2)/4, GyLPF);
		pid_loop(&pidRollRate, pidRoll.Output   +(Roll_RC.r2)/4,  GxLPF);
	}
	else
	{
		pidPitchRate.kp= 0.8f+0.3f*(1-PID_sech((pidPitch.Output-GyLPF),0.08f));
		pidRollRate.kp= 0.8f+0.3f*(1-PID_sech((pidRoll.Output-GxLPF),0.08f));
		
		pid_loop(&pidPitchRate, pidPitch.Output, GyLPF);
		pid_loop(&pidRollRate, pidRoll.Output  , GxLPF);
	}

	pid_loop(&pidYawRate, rotateAngleBF.Z * Yaw_P_Gain, GzLPF);

	pidRollRate.Output = constrain_float(pidRollRate.Output,  -350, 350);   //50%
	pidPitchRate.Output = constrain_float(pidPitchRate.Output,-350, 350);   //50%
	pidYawRate.Output = constrain_float(pidYawRate.Output,    -300, 300);   //20%

	if(curFlyEnable == 0)
	{
		pidPitchRate.I_sum = 0;
		pidRollRate.I_sum = 0;
		pidYawRate.I_sum = 0;
	}
}

//5ms角度外环PID
void attitude_pid_5ms_task(void)
{
	FLOAT_XYZ curRotateAngleBF = rotateAngleBF;
	unsigned char curFlyEnable = flyEnable;

	pid_loop(&pidPitch, curRotateAngleBF.Y, 0);
	pid_loop(&pidRoll, curRotateAngleBF.X, 0);

    //飞机物理性能只有250度秒,不加的话外扰过大会翻机
	pidPitch.Output = constrain_float(pidPitch.Output, -250, 250);
	pidRoll.Output = constrain_float(pidRoll.Output, -250, 250);

	if(curFlyEnable == 0)
	{
		pidPitch.I_sum = 0;
		pidRoll.I_sum = 0;
	}
}

FLOAT_XYZ accEF = {0};
float accZOffset = 9.8f;
float vel_acc = 0;
FLOAT_XYZ accLowPass;
extern unsigned char gyroCalibrationFlag;
extern unsigned char IMU_TempStableFlag;

float vel_acc_lowPass = 0;
void get_accEF(void)
{
	accLowPass.Z = accEF.Z * 0.1f + accLowPass.Z * 0.9f;
	accLowPass.X = accEF.X;
	accLowPass.Y = accEF.Y;

	vel_acc = (accLowPass.Z - accZOffset) * 100;

	vel_acc_lowPass = vel_acc * 0.5f + vel_acc_lowPass * 0.5f;
}

void attitude_accEF_1ms_task(void)
{
	OS_ALLOC_SR();
	OS_ENTER_CRITICAL();
	FLOAT_XYZ accBF = *(FLOAT_XYZ *)accUnit;
	static uint16_t AccEF_Cnt = 0;
	OS_EXIT_CRITICAL();

	quaternion_rotateVector(&imuQ, &accBF, &accEF, 0);

	AccEF_Cnt ++;

	if(AccEF_Cnt % 5 == 0)// && (GetAccStableFlag() == 1))
		get_accEF();

	if(GetAccStableFlag() == 1)
		accZOffset = GetGravity();

	if(AccEF_Cnt >= 60000)
		AccEF_Cnt = 0;
}
