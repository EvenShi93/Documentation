#ifndef __FOLLOWME_H
#define __FOLLOWME_H

#include "position_task.h"

void FollowMeTask(void);
float GetWatchAng(void);
float GetFollowExpYaw(void);
void InitFollowExpYaw(float Yaw);
void SetImgFollowData(uint16_t rfDataH, uint16_t rfDataV);

#endif /* __FOLLOWME_H */
