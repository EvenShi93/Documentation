#ifndef _MPU6500_H_
#define _MPU6500_H_

#include "platform.h"
#include "i2c.h"

#define MPU6500_ID    0x70
#define	MPU6500_ADDR  0x68    

#define	MPU6500_SMPLRT_DIV		0x19	
#define	MPU6500_CONFIG			  0x1A	
#define	MPU6500_ACCEL_CONFIG2 0x1D  
#define	MPU6500_GYRO_CONFIG		0x1B	
#define	MPU6500_ACCEL_CONFIG	0x1C
#define	MPU6500_INT_PIN_CFG	  0x37
#define MPU6500_INT_ENABLE    0x38

#define	MPU6500_GYRO_XOUT_H		0x43
#define	MPU6500_GYRO_XOUT_L		0x44
#define	MPU6500_GYRO_YOUT_H		0x45
#define	MPU6500_GYRO_YOUT_L		0x46
#define	MPU6500_GYRO_ZOUT_H		0x47
#define	MPU6500_GYRO_ZOUT_L		0x48
#define MPU6500_GYRO_OUT_LEN  6

#define	MPU6500_ACCEL_XOUT_H	0x3B
#define	MPU6500_ACCEL_XOUT_L	0x3C
#define	MPU6500_ACCEL_YOUT_H	0x3D
#define	MPU6500_ACCEL_YOUT_L	0x3E
#define	MPU6500_ACCEL_ZOUT_H	0x3F
#define	MPU6500_ACCEL_ZOUT_L	0x40
#define MPU6500_ACCEL_OUT_LEN 6

#define	MPU6500_TEMP_OUT_H		0x41
#define	MPU6500_TEMP_OUT_L		0x42
#define MPU6500_TEMP_OUT_LEN  2

#define MPU6500_SIGNAL_PATH_RESET 0x68
#define	MPU6500_PWR_MGMT_1		0x6B	
#define	MPU6500_WHO_AM_I   		0x75

#define MPU6500_DLPF_GRY_250         0x00
#define MPU6500_DLPF_GRY_184         0x01
#define MPU6500_DLPF_GRY_92          0x02
#define MPU6500_DLPF_GRY_41          0x03
#define MPU6500_DLPF_GRY_20          0x04
#define MPU6500_DLPF_GRY_10          0x05
#define MPU6500_DLPF_GRY_5           0x06
#define MPU6500_DLPF_GRY_3600        0x07

#define MPU6500_DLPF_ACC_460         0x00
#define MPU6500_DLPF_ACC_184         0x01
#define MPU6500_DLPF_ACC_92          0x02
#define MPU6500_DLPF_ACC_41          0x03
#define MPU6500_DLPF_ACC_20          0x04
#define MPU6500_DLPF_ACC_10          0x05
#define MPU6500_DLPF_ACC_5           0x06

#define MPU6500_GRY_SELFTEST         0x07
#define MPU6500_ACC_SELFTEST         0x07

#define MPU6500_GYRO_SCALE250  0  //+/- 250?s
#define MPU6500_GYRO_SCALE500  8  //+/- 500?s
#define MPU6500_GYRO_SCALE1000 16  //+/- 1000?s
#define MPU6500_GYRO_SCALE2000 24  //+/- 2000?s


#define MPU6500_ACCEL_SCALE2G 0  //+/- 2g
#define MPU6500_ACCEL_SCALE4G 8  //+/- 4g
#define MPU6500_ACCEL_SCALE8G 16  //+/- 8g
#define MPU6500_ACCEL_SCALE16G 24  //+/- 16g


typedef enum
{
	MPU6500_IOCTRL_ACCEL_READ = 0,
	MPU6500_IOCTRL_GYRO_READ = 1,
	MPU6500_IOCTRL_TEMP_READ = 2,
	MPU6500_IOCTRL_ACCEL_SET = 3,
	MPU6500_IOCTRL_GYRO_SET = 4,
	MPU6500_IOCTRL_ACC_COEFF_READ = 5,
	MPU6500_IOCTRL_GYRO_COEFF_READ = 6,
	MPU6500_IOCTRL_IMU_READ = 7,
	MPU6500_IOCTRL_REBOOT =8 
}MPU6500_IOCTRL;

unsigned int mpu6500_getID(void);
unsigned int mpu6500_register(void);
static void mpu6500_set_acc(unsigned char accel);
static void mpu6500_set_gyro(unsigned char gyro);
static int mpu6500_init(void);
static int mpu6500_read(void* buffer,unsigned int len);
static int  mpu6500_ioctrl(unsigned char cmd,void* arg);

#endif
