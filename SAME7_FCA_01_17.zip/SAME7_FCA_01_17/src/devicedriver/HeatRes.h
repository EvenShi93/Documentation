#ifndef __HEATRES_H
#define __HEATRES_H

#include "platform.h"

unsigned int Heat_getID(void);
unsigned int Heat_register(void);

#endif /* __HEATRES */
