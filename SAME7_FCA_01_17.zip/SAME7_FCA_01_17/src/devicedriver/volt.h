#ifndef _VOLT_H_
#define _VOLT_H_

#include "platform.h"

static int volt_init(void);
static int volt_read(void* buffer,unsigned int len);
unsigned int volt_getID(void);
unsigned int volt_register(void);

#endif 
