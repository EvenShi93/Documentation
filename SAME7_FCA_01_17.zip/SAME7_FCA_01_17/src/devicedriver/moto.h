#ifndef _MOTO_H_
#define _MOTO_H_

#include "platform.h"

/*
 * This is the data format of ESCBus message.
 * ESCBus begins with a specific start sign which is 0xFE, follow that is one ID number for specifying type of message.
 * Then comes the length of data field which can be used to locate the CRC byte easily. CRC is calculated for the whole
 * message except the start sign. It is recommended that hardware CRC unit should be used instead of software if it's
 * supported by your MCU.
 *
 * Here is the graph of ESCBus protocol:
 *  -----------------------------------------------------------------------
 *  | START(0XFE) |   LENTH   |   MSG ID   | --- DATA FIELD --- |   CRC   |
 *  -----------------------------------------------------------------------
 *
 * Note: We should check the length of data field according to its ID number, or you can't get the right position of CRC byte
 * if the length byte was corrupted.
 */

/*
 * ESCBUS Message ID definition
 */
typedef enum {
	// messages or command to ESC
	ESCBUS_MSG_ID_CONFIG_BASIC = 0,
	ESCBUS_MSG_ID_CONFIG_FULL,
	ESCBUS_MSG_ID_RUN,
	ESCBUS_MSG_ID_TUNE,
	ESCBUS_MSG_ID_DO_CMD,
	ESCBUS_MSG_ID_REQUEST_INFO,
	// messages from ESC
	ESCBUS_MSG_ID_CONFIG_INFO_BASIC,	// simple configuration info for request from flight controller
	ESCBUS_MSG_ID_CONFIG_INFO_FULL,		// full configuration info for request from host such as computer
	ESCBUS_MSG_ID_RUN_INFO,				// feedback message in RUN mode
	ESCBUS_MSG_ID_STUDY_INFO,			// studied parameters in STUDY mode
	ESCBUS_MSG_ID_COMM_INFO,			// communication method info
	ESCBUS_MSG_ID_DEVICE_INFO,			// ESC device info
	ESCBUS_MSG_ID_ASSIGNED_ID,
	ESCBUS_MSG_ID_BOOT_SYNC=0x21,
	// never touch ESCBUS_MSG_ID_MAX_NUM
	ESCBUS_MSG_ID_MAX_NUM
} ESCBUS_ENUM_MESSAGE_ID;

/******************************************************************************************
 * ESCBUS_MSG_ID_RUN_INFO packet
 *
 * Monitor message of ESCs while motor is running
 *
 * channelID: assigned channel number
 *
 * ESCStatus: status of ESC
 * 	Num		Health status
 * 	0		HEALTHY
 * 	1		WARNING_LOW_VOLTAGE
 * 	2		WARNING_OVER_CURRENT
 * 	3		WARNING_OVER_HEAT
 *	4		ERROR_MOTOR_LOW_SPEED_LOSE_STEP
 *  5		ERROR_MOTOR_STALL
 *
 * speed: -32767 - 32767 rpm
 *
 * temperature: 0 - 256 celsius degree (if available)
 * voltage: 0.00 - 100.00 V (if available)
 * current: 0.0 - 200.0 A (if available)
 */

typedef enum {
	ESC_STATUS_HEALTHY,
	ESC_STATUS_WARNING_LOW_VOLTAGE,
	ESC_STATUS_WARNING_OVER_HEAT,
	ESC_STATUS_ERROR_MOTOR_LOW_SPEED_LOSE_STEP,
	ESC_STATUS_ERROR_MOTOR_STALL,
	ESC_STATUS_ERROR_HARDWARE,
	ESC_STATUS_ERROR_LOSE_PROPELLER,
	ESC_STATUS_ERROR_OVER_CURRENT,
} ESCBUS_ENUM_ESC_STATUS;

typedef struct
{
	uint8_t Len;
	uint8_t msgid;
	uint8_t channelID;
	uint8_t ESCStatus;
	int16_t speed; // -32767 - 32768 rpm
	uint16_t current; // 0.0 - 200.0 A
}EscbusRunInfoPacket;

typedef union
{
	EscbusRunInfoPacket EscBuf;
	uint8_t Array[8];
}EscBufUnion;

static int moto_init(void);

static int moto_write(void* buffer,unsigned int len);

static int  moto_ioctrl(unsigned char cmd,void* arg);

unsigned int moto_getID(void);

unsigned int moto_register(void); 

typedef enum
{
	MOTO_IOCTRL_DIRECT_WTIRE = 0,
	MOTO_IOCTRL_GET_ESC_STAT = 1
}MOTO_IOCTRL;

#endif
