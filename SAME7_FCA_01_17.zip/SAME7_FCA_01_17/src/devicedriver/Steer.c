#include "Steer.h"
#include "delay.h"
#include "device.h"
#include "driver.h"

/** PWM frequency in Hz. */
#define PWM_FREQUENCY				50

/** Maximum duty cycle value. */
#define MAX_DUTY_CYCLE				3200
/** Minimum duty cycle value. */
#define MIN_DUTY_CYCLE				0
/** Duty cycle length */
#define DUTY_CYCLE_LENGTH			(MAX_DUTY_CYCLE - MIN_DUTY_CYCLE)

#define CHANNEL_PWM_STEER			1

static unsigned int SteerID = 0;
static const Pin pinPWM = {PIO_PD20A_PWMC0_PWMH0, PIOD, ID_PIOD, PIO_PERIPH_A, PIO_PULLUP}; //  PIO_DEFAULT

static int Steer_Init(void);
static int Steer_Write(void* buffer, unsigned int len);

static DEV STEER = {
	.name = "STEER",
	.devDrv = {
		.init = Steer_Init,
		.write = Steer_Write,
//		.ioctrl = Steer_ioctrl
	}
};

unsigned int Steer_getID(void)
{
	return SteerID;
}

unsigned int Steer_register(void)
{
	SteerID = register_driver(&STEER.devDrv);
	return SteerID;
}

static int Steer_Init(void)
{
	/* PIO configuration */
	PIO_Configure(&pinPWM, 1);

	/* Enable PWMC peripheral clock */
	PMC_EnablePeripheral(ID_PWM0);
//	/* Configure interrupt for PWM transfer */
//	NVIC_DisableIRQ(PWM0_IRQn);
//	NVIC_ClearPendingIRQ(PWM0_IRQn);
//	NVIC_SetPriority(PWM0_IRQn, 0);
	/* Set clock A to run at PWM_FREQUENCY * MAX_DUTY_CYCLE (clock B is not used) */
	PWMC_ConfigureClocks(PWM0, PWM_FREQUENCY * MAX_DUTY_CYCLE, 0, MCK);

	/* Configure PWMC channel for Steer (left-aligned, enable dead time generator) */
	PWMC_ConfigureChannel(PWM0,
			0,  /* channel */
			PWM_CMR_CPRE_CLKA,  /* prescaler, CLKA  */
			0,                  /* alignment */
			0                   /* polarity */
			);

	/* Configure channel 0 period */
	PWMC_SetPeriod(PWM0, 0, DUTY_CYCLE_LENGTH);
	/* Configure channel 0 duty cycle */
	PWMC_SetDutyCycle(PWM0, 0, 160);
	/* Enable the synchronous channels by writing CHID0 in the PWM_ENA register */
	PWMC_EnableChannel(PWM0, 0);
	return 1;
}

static int Steer_Write(void* buffer, unsigned int len)
{
	uint16_t SteerDeg = *(uint16_t *)buffer;
	/* constraint condition: [160, 320] */
	if(SteerDeg > 320) SteerDeg = 320;
	if(SteerDeg < 160) SteerDeg = 160;
    /* New duty-cycle and dead-time values for the synchronous channels can be written. */
	/* Configure channel 0 duty cycle */
	PWMC_SetDutyCycle(PWM0, 0, SteerDeg);
	return 1;
}
