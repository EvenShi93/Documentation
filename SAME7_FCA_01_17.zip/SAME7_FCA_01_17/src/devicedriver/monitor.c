#include "monitor.h"
#include "delay.h"
#include "device.h"
#include "driver.h"

static unsigned int  monitorID = 0;
unsigned char monitorUartDmaChannel = 4;

#if defined(TRANS_RX_ENABLE)

static RecPackTypeDef RecPack_Par = {0};
static RecCommTypeDef RecPack_Comm = {0};

uint8_t DataReceivedFlag = 0;

#endif

#if USE_DATA_TRANSFER
static unsigned char monitorUartDmaTxFlag = 1;

static void monitor_uart_init(void);
static void monitor_send_nbyte(unsigned char* pBuffer, unsigned int len);
#endif

static int monitor_init(void);
static int monitor_write(void* buffer, unsigned int len);
static int monitor_ioctrl(unsigned char cmd, void* arg);
#if defined(TRANS_RX_ENABLE)
static int monitor_read(void* buffer, unsigned int len);
#endif

static DEV monitor = {
	.name = "MONITOR",
	.devDrv = {
		.init =  monitor_init,
		.write = monitor_write,
#if defined(TRANS_RX_ENABLE)
		.read = monitor_read,
#endif
		.ioctrl = monitor_ioctrl
	}
};

unsigned int monitor_getID(void)
{
	return monitorID;
}

unsigned int monitor_register(void)
{
	monitorID = register_driver(&monitor.devDrv);
	return monitorID;
}

static int monitor_init(void)
{
#if USE_DATA_TRANSFER
	monitor_uart_init();
#endif
	return 1;
}

static int monitor_write(void* buffer, unsigned int len)
{
#if USE_DATA_TRANSFER
	unsigned char* pBuffer = buffer;
	monitor_send_nbyte(pBuffer, len);
#endif
	return 1;
}

#if defined(TRANS_RX_ENABLE)

static int monitor_read(void* buffer, unsigned int type)
{
   switch(type)
	 {	 
		 case ParPack:			 
	        if( DataReceivedFlag & ParPack ) {*((RecPackTypeDef *)buffer) = RecPack_Par; DataReceivedFlag &=~(ParPack);  return 1;}
     break;
	   
		 case CommPack:			 
	        if( DataReceivedFlag & CommPack ) {*((RecCommTypeDef *)buffer) = RecPack_Comm; DataReceivedFlag &=~(CommPack);  return 1;}
     break;
	
	 }
		return 0;
}
#endif

static int monitor_ioctrl(unsigned char cmd, void* arg)
{
#if USE_DATA_TRANSFER
	switch(cmd)
	{
		case MONITOR_IOCTRL_COMM_DATA_WRITE:
		{
			COMM_DATA* pBuffer = arg;
			monitor_send_nbyte((unsigned char*)pBuffer, sizeof(COMM_DATA));
		}
		break;
		case MONITOR_IOCTRL_COMM_STR_WRITE:
		{
			COMM_STR* pBuffer = arg;
			monitor_send_nbyte((unsigned char*)pBuffer, sizeof(COMM_STR));
		}
		break;
		default: break;
	}
#endif
	return 1;
}

#if USE_DATA_TRANSFER
static void monitor_uart_init(void)
{
#if defined(USE_A9_SERIAL_PORT)
	Pin PIN_USART2_RX = {PIO_PD15B_RXD2, PIOD, ID_PIOD, PIO_PERIPH_B, PIO_DEFAULT};
	Pin PIN_USART2_TX = {PIO_PD16B_TXD2, PIOD, ID_PIOD, PIO_PERIPH_B, PIO_DEFAULT};

	PMC_EnablePeripheral(ID_USART2);

	PIO_Configure(&PIN_USART2_RX, 1);
	PIO_Configure(&PIN_USART2_TX, 1);

	USART_Configure(USART2, US_MR_USART_MODE_NORMAL|US_MR_CHRL_8_BIT|US_MR_PAR_NO|US_MR_NBSTOP_1_BIT, 115200, MCK);

	USART_SetReceiverEnabled(USART2, 1);
	USART_SetTransmitterEnabled(USART2, 1);

	NVIC_ClearPendingIRQ(USART2_IRQn);
	NVIC_SetPriority(USART2_IRQn, 12);

	USART_EnableIt(USART2, US_IER_RXRDY);
	NVIC_EnableIRQ(USART2_IRQn);
#elif defined(USE_RF_SERIAL_PORT)
	Pin PIN_POWER_CONT = {PIO_PA26, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};
	Pin PIN_UART3_RX = {PIO_PD28A_URXD3, PIOD, ID_PIOD, PIO_PERIPH_A, PIO_DEFAULT};
	Pin PIN_UART3_TX = {PIO_PD30A_UTXD3, PIOD, ID_PIOD, PIO_PERIPH_A, PIO_DEFAULT};

	PIO_Configure(&PIN_POWER_CONT, 1);
	PIO_Clear(&PIN_POWER_CONT);

	PMC_EnablePeripheral(ID_UART3);

	PIO_Configure(&PIN_UART3_TX, 1);
	PIO_Configure(&PIN_UART3_RX, 1);

	UART_Configure(UART3, ( UART_MR_PAR_NO | UART_MR_BRSRCCK_PERIPH_CLK | UART_MR_CHMODE_NORMAL ), 115200, MCK);

	UART_SetReceiverEnabled (UART3, 1);
	UART_SetTransmitterEnabled (UART3, 1);

	NVIC_ClearPendingIRQ(UART3_IRQn);
	NVIC_SetPriority(UART3_IRQn, 12);

	UART_EnableIt(UART3, UART_IER_RXRDY);
	NVIC_EnableIRQ(UART3_IRQn);
#endif /* defined(USE_A9_SERIAL_PORT) */

	PMC_EnablePeripheral( ID_XDMAC );

	/* Clear dummy status */
	XDMAC_GetChannelIsr( XDMAC, monitorUartDmaChannel);
	/* Disables XDMAC interrupt for the given channel. */
	XDMAC_DisableGIt (XDMAC, monitorUartDmaChannel);
	XDMAC_DisableChannelIt (XDMAC, monitorUartDmaChannel, 0xFF);
	/* Disable the given dma channel. */
	XDMAC_DisableChannel( XDMAC, monitorUartDmaChannel );

	XDMAC_SetChannelConfig(XDMAC, monitorUartDmaChannel, XDMAC_CC_TYPE_PER_TRAN      |
														 XDMAC_CC_DSYNC_MEM2PER      |
														 XDMAC_CC_MBSIZE_SINGLE      |
														 XDMAC_CC_PROT_SEC           |
														 XDMAC_CC_MEMSET_NORMAL_MODE |
														 XDMAC_CC_CSIZE_CHK_1        |
														 XDMAC_CC_DWIDTH_BYTE        |
														 XDMAC_CC_SIF_AHB_IF0        |
														 XDMAC_CC_DIF_AHB_IF1        |
														 XDMAC_CC_SAM_INCREMENTED_AM |
														 XDMAC_CC_DAM_FIXED_AM       |
#if defined(USE_A9_SERIAL_PORT)
														 XDMAC_CC_PERID(11)          );
#elif defined(USE_RF_SERIAL_PORT)
														 XDMAC_CC_PERID(26)          );
#endif /* defined(USE_A9_SERIAL_PORT) */

	XDMAC_SetMicroblockControl(XDMAC, monitorUartDmaChannel, 12);
	XDMAC_SetSourceAddr(XDMAC, monitorUartDmaChannel, (unsigned int)0);
#if defined(USE_A9_SERIAL_PORT)
	XDMAC_SetDestinationAddr(XDMAC, monitorUartDmaChannel, (unsigned int)&(USART2->US_THR));
#elif defined(USE_RF_SERIAL_PORT)
	XDMAC_SetDestinationAddr(XDMAC, monitorUartDmaChannel, (unsigned int)&(UART3->UART_THR));
#endif /* defined(USE_A9_SERIAL_PORT) */
	XDMAC_SetDescriptorControl(XDMAC, monitorUartDmaChannel, 0);
	XDMAC_SetBlockControl(XDMAC, monitorUartDmaChannel, 0);
	XDMAC_SetDataStride_MemPattern(XDMAC, monitorUartDmaChannel, 0);
	XDMAC_SetSourceMicroBlockStride(XDMAC, monitorUartDmaChannel, 0);
	XDMAC_SetDestinationMicroBlockStride(XDMAC, monitorUartDmaChannel, 0);

	/*Enable xDMA interrupt */ 
	NVIC_ClearPendingIRQ(XDMAC_IRQn);
	NVIC_SetPriority( XDMAC_IRQn, 9);
	NVIC_EnableIRQ(XDMAC_IRQn);

	XDMAC_EnableChannelIt (XDMAC, monitorUartDmaChannel, XDMAC_CIE_BIE);
	XDMAC_EnableGIt (XDMAC, monitorUartDmaChannel);
}

static void monitor_send_nbyte(unsigned char* pBuffer, unsigned int len)
{
	while(monitorUartDmaTxFlag == 0){}
	monitorUartDmaTxFlag = 0;
	XDMAC_SetMicroblockControl(XDMAC, monitorUartDmaChannel, len);
	XDMAC_SetSourceAddr(XDMAC, monitorUartDmaChannel, (unsigned int)pBuffer);
#if defined(USE_A9_SERIAL_PORT)
	XDMAC_SetDestinationAddr(XDMAC, monitorUartDmaChannel, (unsigned int)&(USART2->US_THR));
#elif defined(USE_RF_SERIAL_PORT)
	XDMAC_SetDestinationAddr(XDMAC, monitorUartDmaChannel, (unsigned int)&(UART3->UART_THR));
#endif /* defined(USE_A9_SERIAL_PORT) */
	SCB_CleanInvalidateDCache();
	XDMAC_EnableChannel(XDMAC, monitorUartDmaChannel);
}

#if defined(TRANS_RX_ENABLE)

void monitor_uart_rx_irq(unsigned char data)
{
	static uint8_t RecDataStep = 0;
	static uint8_t DataIndexCnt = 0;
	static uint8_t DataCheck = 0;
	static uint8_t DataLen = 0;
	static uint8_t* DataBuf=NULL;

	switch(RecDataStep)
	{
		case 0:
			if(data == 0x55) RecDataStep ++;
			else RecDataStep = 0;
		break;
		case 1:
			if(data == 0xAA) RecDataStep ++; //参数设置包
			else if(data == 0xAB) RecDataStep ++; //按钮命令包
			else RecDataStep = 0;
		break;
		case 2:
			if(data == 5){RecDataStep ++; DataIndexCnt = 0; DataCheck = 0;DataLen=5;DataBuf=NULL;}
			else if(data == 2){RecDataStep ++; DataIndexCnt = 0; DataCheck = 0;DataLen=2;DataBuf=NULL;}
			else RecDataStep = 0;
		break;
		case 3:
			if(DataLen==5) DataBuf= RecPack_Par.rData;
			if(DataLen==2) DataBuf= RecPack_Comm.rData;
			if(DataIndexCnt < DataLen) DataBuf[DataIndexCnt ++] = data;
			if(DataIndexCnt == DataLen) RecDataStep ++;
		break;
		case 4: //和校验
			for(uint8_t i = 0; i < DataLen; i ++)  DataCheck += DataBuf[i];
			if(data == DataCheck) //校验通过,接收完毕
			{
				if(DataLen==5)DataReceivedFlag |= ParPack;
				if(DataLen==2)DataReceivedFlag |= CommPack;
			}
			RecDataStep = 0;
		break;
		default :
			RecDataStep = 0;
		break;
	}
}
#endif /* defined(TRANS_RX_ENABLE) */

void monitorUartDmaIrq(void)
{
	monitorUartDmaTxFlag = 1;
}
#endif /* USE_DATA_TRANSFER */

/*
//应用
unsigned char buffer[10] = {0};
for(int i = 0; i < 10; i ++)
{
  buffer[i] = i + 1;
}
write(monitor_getID(), buffer, 10);

void comm_data_send(COMM_DATA* pcomm)
{
	unsigned char checksum = 0;
	pcomm->head = 0x55;
	pcomm->cmd = 0xDD;
	pcomm->length = 36;
	for(unsigned char kk = 0; kk < 36; kk ++)
	{
		checksum += pcomm->data[kk/4].c_data[kk%4];
	}
	pcomm->checksum = checksum;
	ioctrl(monitor_getID(), MONITOR_IOCTRL_COMM_DATA_WRITE, pcomm);
}

void comm_str_send(unsigned char* buffer, unsigned int size)
{
	unsigned char checksum = 0;
	unsigned char data = 0; 
	data = 0x55;
	write(monitor_getID(), &data, 1);
	data = 0xCC;
	write(monitor_getID(), &data, 1);
	data = size;
	write(monitor_getID(), &data, 1);
	for(unsigned char kk = 0; kk < size; kk ++)
	{
		checksum += buffer[i];	
	}
	write(monitor_getID(), buffer, size);
	write(monitor_getID(), &checksum, 1);
}
*/
