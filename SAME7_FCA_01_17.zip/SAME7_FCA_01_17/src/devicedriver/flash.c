﻿#include "flash.h"
#include "delay.h"	
#include "device.h"
#include "driver.h"

static unsigned int  flashID = 0;

static DEV flash={
	.name = "FLASH",
	.devDrv={
		.init =  flash_init,
		.open =  flash_open,
		.close = flash_close,
		.read =  flash_read,
		.write = flash_write,		
		.ioctrl = flash_ioctrl
	}
};


static unsigned char* flashAddr = 0;

unsigned int flash_getID(void)
{
	return flashID;
}
unsigned int flash_register(void)
{
	flashID = register_driver(&flash.devDrv);
	return  flashID;
}


static int flash_init(void)
{
	/* Set 6 WS for internal Flash writing (refer to errata) */
	EFC_SetWaitState(EFC, 6);
	
	/* Initialize flash driver */
	FLASHD_Initialize(MCK, 0);
	
	return 1;
}

static int flash_open(void)
{
	/* Update internal flash Region to Full Access*/
	MPU_UpdateRegions(MPU_DEFAULT_IFLASH_REGION, IFLASH_START_ADDRESS, \
		MPU_AP_FULL_ACCESS |
		INNER_NORMAL_WB_NWA_TYPE( NON_SHAREABLE ) |
		MPU_REGION_ENABLE);
	return 1;
}

static int flash_close(void)
{
	MPU_UpdateRegions(MPU_DEFAULT_IFLASH_REGION, IFLASH_START_ADDRESS, \
		MPU_AP_READONLY |
		INNER_NORMAL_WB_NWA_TYPE( NON_SHAREABLE ) |
		MPU_CalMPURegionSize(IFLASH_END_ADDRESS - IFLASH_START_ADDRESS) |
		MPU_REGION_ENABLE);
	return 1;
}


static int flash_read(void* buffer,unsigned int len)
{
	 unsigned char* pBuffer = buffer;
	 for(unsigned int i=0;i<len;i++)
	 {
		 pBuffer[i] =  flashAddr[i];
	 }
	 return 1;
}

static int flash_write(void* buffer,unsigned int len)
{
	 int ret = 1;
	 FLASHD_Unlock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
	 if(FLASHD_Write((unsigned int)flashAddr, buffer,len) != 0)
	 {
		 ret = 0;
	 }
	 FLASHD_Lock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
	 return ret;
}

static int  flash_ioctrl(unsigned char cmd,void* arg)
{
	int ret = 1;
	switch(cmd)
	{
		case FLASH_EARSE: 
		{
			unsigned int pBuffer = (unsigned int)arg;
			switch(pBuffer)
			{
				case FLASH_EARSE_4_PAGES:
					FLASHD_Unlock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					if(FLASHD_ErasePages((unsigned int)flashAddr,4) != 0 )
					{
						ret = 0;
					}
					FLASHD_Lock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					break;
				case FLASH_EARSE_8_PAGES:
					FLASHD_Unlock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					if(FLASHD_ErasePages((unsigned int)flashAddr,8) != 0)
					{
						ret = 0;
					}
					FLASHD_Lock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					break;
				case FLASH_EARSE_16_PAGES:
					FLASHD_Unlock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					if(FLASHD_ErasePages((unsigned int)flashAddr,16) != 0) 
					{
						ret = 0;
					}
					FLASHD_Lock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					break;
				case FLASH_EARSE_32_PAGES:
					FLASHD_Unlock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					if(FLASHD_ErasePages((unsigned int)flashAddr,32)!= 0)
					{
						ret = 0;
					}
					FLASHD_Lock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					break;
				case FLASH_EARSE_SECTOR:
					FLASHD_Unlock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					if(FLASHD_EraseSector((unsigned int)flashAddr)!= 0)
					{
						ret = 0;
					}
					FLASHD_Lock((unsigned int)flashAddr&~(FLASH_SECTOR_0_START_LEN-1),(unsigned int)flashAddr + FLASH_SECTOR_0_START_LEN, 0, 0);
					break;
				default:
					break;
			}
		}
		break;
		case FLASH_RWE_OFFSET_ADDR_SETTING:
		{
			flashAddr += (unsigned int)arg;
		}
		break;
		case FLASH_RWE_SECTOR_ADDR_SETTING:
		{
			flashAddr = (unsigned char*)arg;
		}
		break;
		default:
		break;
	}
	return ret;
}



/*
flash 应用

unsigned int kk = 0;
unsigned char buffer[121] ={0};
unsigned char buffer1[121] ={0};

for(int i=0;i<121;i++)
	{
		buffer[i] = i;
	}
if(kk == 1)
			{
				OS_ALLOC_SR();
				OS_ENTER_CRITICAL();
				open(flash_getID());
				ioctrl(flash_getID(),FLASH_RWE_SECTOR_ADDR_SETTING,(void*)FLASH_SECTOR_15_START_ADDR);
				ioctrl(flash_getID(),FLASH_EARSE,(void*)FLASH_EARSE_SECTOR);
				
				ioctrl(flash_getID(),FLASH_RWE_SECTOR_ADDR_SETTING,(void*)FLASH_SECTOR_15_START_ADDR);
				write(flash_getID(),buffer,121);
				read(flash_getID(),buffer1,121);
				close(flash_getID());
				OS_EXIT_CRITICAL();
				kk = 0 ;
			}
*/
