#include "volt.h"
#include "delay.h"
#include "device.h"
#include "driver.h"

#define AFEC AFEC0
#define AFEC_CHANNEL_VLT 6 //PA17
#define AFEC_CHANNEL_GND 7 //PA18
 
static unsigned int  voltID = 0;

static DEV volt={
	.name = "VOLT",
	.devDrv={
		.init =  volt_init,
		.read =  volt_read,
	}
};


unsigned int volt_getID(void)
{
	return voltID;
}
unsigned int volt_register(void)
{
	voltID = register_driver(&volt.devDrv);
	return  voltID;
}

static int volt_init(void)
{
	AFEC_Initialize( AFEC, ID_AFEC0 );//注意修改
	AFEC_SetModeReg(AFEC,AFEC_MR_FREERUN_ON|AFEC_EMR_RES_NO_AVERAGE|(1 << AFEC_MR_TRANSFER_Pos)|(2 << AFEC_MR_TRACKTIM_Pos) | AFEC_MR_ONE| AFEC_MR_SETTLING_AST3| AFEC_MR_STARTUP_SUT64);
	AFEC_SetClock( AFEC, 2200000, MCK ) ;
	AFEC_SetExtModeReg(AFEC, 0| AFEC_EMR_RES_NO_AVERAGE| AFEC_EMR_TAG| AFEC_EMR_STM );			
	AFEC_SetAnalogOffset(AFEC, AFEC_CHANNEL_GND, 0x200);
	AFEC_SetAnalogOffset(AFEC, AFEC_CHANNEL_VLT, 0x200);
	AFEC_SetAnalogControl(AFEC, AFEC_ACR_IBCTL(1) | AFEC_ACR_PGA0_ON | AFEC_ACR_PGA1_ON | 1<<4); 
	AFEC_SetChannelGain(AFEC, 0<<(AFEC_CHANNEL_GND*2)); 
	AFEC_SetChannelGain(AFEC, 0<<(AFEC_CHANNEL_VLT*2)); 
	AFEC_EnableChannel(AFEC,AFEC_CHANNEL_GND);
	AFEC_EnableChannel(AFEC,AFEC_CHANNEL_VLT);
	AFEC_StartConversion(AFEC);
	return 1;
}

static int volt_read(void* buffer,unsigned int len)
{
	short* pBuffer = buffer;
	*pBuffer = AFEC_GetConvertedData(AFEC, AFEC_CHANNEL_VLT) - AFEC_GetConvertedData(AFEC, AFEC_CHANNEL_GND);
//	volt_gnd = AFEC_GetConvertedData(AFEC,AFEC_CHANNEL_GND);
	return 1;
}

/*
 volt使用 
short voltValue = 0;
read(volt_getID(),&voltValue,2);
*/
