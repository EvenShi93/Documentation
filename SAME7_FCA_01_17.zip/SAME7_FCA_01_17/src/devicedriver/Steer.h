#ifndef __STEER_H
#define __STEER_H

#include "platform.h"

unsigned int Steer_getID(void);
unsigned int Steer_register(void);

#endif /* __STEER_H */
