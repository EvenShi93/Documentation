#include "HeatRes.h"
#include "device.h"
#include "driver.h"

static Pin PIN_Heat = {PIO_PA12, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};

static unsigned int HeatID = 0;

static int Heat_init(void);
static int Heat_open(void);
static int Heat_close(void);

static DEV Heat = {
	.name = "Heat",
	.devDrv = {
	.init = Heat_init,
	.open = Heat_open,
	.close = Heat_close
	}
};

unsigned int Heat_getID(void)
{
	return HeatID;
}

unsigned int Heat_register(void)
{
	HeatID = register_driver(&Heat.devDrv);
	return HeatID;
}

static int Heat_init(void)
{
	PIO_Configure(&PIN_Heat, 1);
	return 1;
}

static int Heat_open(void)
{
	PIO_Set(&PIN_Heat); 
	return 1;
}

static int Heat_close(void)
{
	PIO_Clear(&PIN_Heat);
	return 1;
}
