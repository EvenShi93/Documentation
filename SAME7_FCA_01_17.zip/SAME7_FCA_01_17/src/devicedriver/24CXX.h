#ifndef __24C0XX_H
#define __24C0XX_H

#include "platform.h"

#define AT24CXX_ADDR 0x50  //8bit=0xA0 , 7bit=0x50

typedef enum
{
	AT24_WRITE_1Byte = 0,
	AT24_WRITE_1Page,
	AT24_READ_DATA
}AT24CXX_CMD;

typedef struct
{
	uint16_t DataAddr;
	uint8_t len;
	uint8_t* pData;
}AT24CXX_RW_struct;

unsigned int AT24CXX_getID(void);
unsigned int AT24CXX_register(void);

#endif
