﻿#include "usbdriver.h"
#include "delay.h"
#include "device.h"
#include "driver.h"

#include <USBDescriptors.h>
#include <USBRequests.h>
#include "USBD.h"
#include <USBD_HAL.h>
#include <USBDDriver.h>
#include <VIDEODescriptors.h>
#include <USBVideo.h>

#include "CDCDSerialDriver.h"

//extern const USBDDriverDescriptors usbdDriverDescriptors;
extern const USBDDriverDescriptors cdcdSerialDriverDescriptors;

static unsigned int usbID = 0;
///** Alternate interfaces */
//static uint8_t bAlternateInterfaces[4];

static int USB_Init(void);
static void _ConfigureUotghs(void);

static DEV usb_drv = {
	.name = "USB",
	.devDrv = {
		.init = USB_Init
	}
};

unsigned int usb_getID(void)
{
	return usbID;
}

unsigned int usb_register(void)
{
	usbID = register_driver(&usb_drv.devDrv);
	return  usbID;
}

/*
set usb initializes
*/
static int USB_Init(void)
{
	/* Get usb device driver pointer */
	USBDDriver *pUsbd = USBD_GetDriver();
	/* Set interrupt priority */
	NVIC_SetPriority(USBHS_IRQn, 2);
	/* Initialize all USB power (off) */
	_ConfigureUotghs();
//	/* USB Driver Initialize */
//	USBDDriver_Initialize(pUsbd, &usbdDriverDescriptors, bAlternateInterfaces);
//	USBD_Init();

	/* CDC serial driver initialization */
	CDCDSerialDriver_Initialize(&cdcdSerialDriverDescriptors);

	/* Start USB stack to authorize VBus monitoring */
	USBD_Connect();

	return 1;
}

/**
 * Configure USB settings for USB device
 */
static void _ConfigureUotghs(void)
{
	/* UTMI parallel mode, High/Full/Low Speed */
	/* UUSBCK not used in this configuration (High Speed) */
	PMC->PMC_SCDR = PMC_SCDR_USBCLK;
	/* USB clock register: USB Clock Input is UTMI PLL */
	PMC->PMC_USB = PMC_USB_USBS;
	/* Enable peripheral clock for USBHS */
	PMC_EnablePeripheral(ID_USBHS);
	USBHS->USBHS_CTRL = USBHS_CTRL_UIMOD_DEVICE;
	/* Enable PLL 480 MHz */
	PMC->CKGR_UCKR = CKGR_UCKR_UPLLEN | CKGR_UCKR_UPLLCOUNT(0xF);

	/* Wait that PLL is considered locked by the PMC */
	while (!(PMC->PMC_SR & PMC_SR_LOCKU));

	/* IRQ */
	NVIC_EnableIRQ(USBHS_IRQn);
}

/*-----------------------------------------------------------------------------
 *                      Callback re-implementation
 *-----------------------------------------------------------------------------*/
/**
 * Invoked when the configuration of the device changes. Parse used endpoints.
 * \param cfgnum New configuration number.
 */
void USBDDriverCallbacks_ConfigurationChanged(unsigned char cfgnum)
{
	CDCDSerialDriver_ConfigurationChangedHandler(cfgnum);
}

/**
 * Invoked when a new SETUP request is received from the host. Forwards the
 * request to the Mass Storage device driver handler function.
 * \param request  Pointer to a USBGenericRequest instance.
 */
void USBDCallbacks_RequestReceived(const USBGenericRequest *request)
{
	CDCDSerialDriver_RequestHandler(request);
}

/*----------------------------------------------------------------------------
 * Callback invoked when data has been received on the USB.
 *----------------------------------------------------------------------------*/
 void _UsbDataReceived(uint32_t unused,
							uint8_t status,
							uint32_t received,
							uint32_t remaining)
{
	(void)unused;
	/* Check that data has been received successfully */
	if (status == USBD_STATUS_SUCCESS)
	{
	}
}
