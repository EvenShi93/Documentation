#include "Ultrasonic.h"
#include "delay.h"
#include "device.h"
#include "driver.h"
#include "TimeCounter.h"

static unsigned int UltrasonicID = 0;
static unsigned char EdgeDet = 0, DistanceGetFlag = 0;
static uint32_t Time_Cur = 0, Time_Last = 0, Time_Ticks = 0;
#if defined(USE_SONIC)
float HalfSoundSpeed = 170.0f;
#elif defined(USE_INFRA)
float HalfSoundSpeed = 1000.0f;
#endif /* defined(USE_SONIC) */
static const Pin pinUltraRx = {PIO_PA30, PIOA, ID_PIOA, PIO_INPUT, PIO_PULLUP | PIO_IT_RISE_EDGE};

static int SonicInterfaceInit(void);
static int SonicInterfaceRead(void* buffer, unsigned int len);
static void UltraRx_Handler(const Pin* pPin);

static DEV Ultrasonic = {
	.name = "Ultrasonic",
	.devDrv={
		.init = SonicInterfaceInit,
		.read = SonicInterfaceRead,
//		.ioctrl = SonicInterfaceioctrl
	}
};

unsigned int Ultrasonic_getID(void)
{
	return UltrasonicID;
}

unsigned int Ultrasonic_register(void)
{
	UltrasonicID = register_driver(&Ultrasonic.devDrv);
	return  UltrasonicID;
}

static int SonicInterfaceInit(void)
{
	/* ---------------------- I/O Interrupt Configuration ---------------------- */
	/* Configure PIO as inputs. */
	PIO_Configure(&pinUltraRx, 1);
	/* Initialize PIO interrupt handlers */
	PIO_ConfigureIt(&pinUltraRx, UltraRx_Handler);
	/* Enable PIO controller IRQs. */
	NVIC_EnableIRQ((IRQn_Type)pinUltraRx.id);
	/* Enable PIO line interrupts. */
	PIO_EnableIt(&pinUltraRx);

	return 1;
}


//read 直接返回定时器值
static int SonicInterfaceRead(void* buffer, unsigned int len)
{
	if(DistanceGetFlag == 1)
	{
		float *p = (float *)buffer;
		*p = HalfSoundSpeed * Time_Ticks * 0.000001f;/* Tick frequency:1M, Soundspeed * Time */
		DistanceGetFlag = 0;
		return 1;
	}
	return 0;
}

/**
  *  \brief Handler for Rx rising/falling edge interrupt.
  *
  *  Handle process Ultrasonic time.
  */
static void UltraRx_Handler(const Pin* pPin)
{
	if(pPin == &pinUltraRx)
	{
		if(EdgeDet == 0)//rising edge.
		{
			pinUltraRx.pio->PIO_FELLSR = pinUltraRx.mask; //Detect the falling edge
			Time_Last = _Get_Micros();//_Ticks_us & 0xFFFF; //Start count.
			EdgeDet = 1;
		}
		else if(EdgeDet == 1)//falling edge.
		{
			pinUltraRx.pio->PIO_REHLSR = pinUltraRx.mask; //rising edge
			EdgeDet = 0;
			Time_Cur = _Get_Micros();//_Ticks_us & 0xFFFF;

//			if(Time_Cur < Time_Last) Time_Ticks = (Time_Cur + (0xFFFF - Time_Last));
//			else Time_Ticks = (Time_Cur - Time_Last);
			Time_Ticks = (Time_Cur - Time_Last);

			DistanceGetFlag = 1;
		}
	}
}
