#ifndef _LED_H_
#define _LED_H_

#include "platform.h"

#define R_Msk 0x01
#define G_Msk 0x02
#define B_Msk 0x04

typedef enum 
{
	BLACK = 0,
	RED   = 1,
	GREEN = 2,
	BLUE  = 4,
	WHITE = RED|GREEN|BLUE
}LED_COLOR;

typedef enum
{
	LED_Board = 0,
	LED_Indep
}LED_NUM;

static int  led_ioctrl(unsigned char cmd,void* arg);
static int led_init(void);
static int led_open(void);
static int led_close(void);
unsigned int led_getID(void);
unsigned int led_register(void);
	
#endif
