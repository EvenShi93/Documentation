#include "AppsA9Ctrl.h"
#include "delay.h"
#include "device.h"
#include "driver.h"
#include "maths.h"

static unsigned int AppsA9_ID = 0;

unsigned char AppsA9_UartDmaChannel = 5;

#if defined(CTRL_A9)
static unsigned char AppsA9_UartDmaTxFlag = 1;
static unsigned char AppsA9_data_rec_flag = 0;
static unsigned char AppsA9_Rec_Pack_Type = 0;
static unsigned char AppsA9_Rec_Data_Buff[100] = {0};

static void AppsA9_uart_init(void);
static void AppsA9_uart_send_nbyte(unsigned char* pBuffer, unsigned int len);
#endif

static int AppsA9_init(void);
static int AppsA9_read(void* buffer, unsigned int len);
static int AppsA9_write(void* buffer, unsigned int len);
static int AppsA9_ioctrl(unsigned char cmd, void* arg);

static DEV AppsA9 = {
	.name = "AppsA9",
	.devDrv = {
		.init = AppsA9_init,
		.read = AppsA9_read,
		.write = AppsA9_write,
		.ioctrl = AppsA9_ioctrl
	}
};

unsigned int AppsA9_getID(void)
{
	return AppsA9_ID;
}

unsigned int AppsA9_register(void)
{
	AppsA9_ID = register_driver(&AppsA9.devDrv);
	return AppsA9_ID;
}

static int AppsA9_init(void)
{
#if defined(CTRL_A9)
	AppsA9_uart_init();
#endif

	return 1;
}

static int AppsA9_read(void* buffer, unsigned int len)
{
#if defined(CTRL_A9)
	if(AppsA9_data_rec_flag == 1)
	{
		switch(AppsA9_Rec_Pack_Type)
		{
			case PACKET_TYPE_CHANNELDATA12:
			{
				YUNEEC_A9_STR* pBuffer = buffer;
				*pBuffer = *(YUNEEC_A9_STR *)AppsA9_Rec_Data_Buff;
				AppsA9_data_rec_flag = 0;
				return 1;
			}
			case PACKET_TYPE_Calibration_Set:
			{
				*(Calibration_Type *)buffer = *(Calibration_Type *)AppsA9_Rec_Data_Buff;
				AppsA9_data_rec_flag = 0;
				return 1;
			}
			default :
				AppsA9_Rec_Pack_Type = 0;
				AppsA9_data_rec_flag = 0;
			return 0;
		}
	}
	else
#endif
	{
		return 0;
	}
}

static int AppsA9_write(void* buffer, unsigned int len)
{
#if defined(CTRL_A9)
	unsigned char* pBuffer = buffer;
	AppsA9_uart_send_nbyte((unsigned char*)pBuffer, len);
#endif
	return 1;
}

static int AppsA9_ioctrl(unsigned char cmd, void* arg)
{
#if defined(CTRL_A9)
	switch(cmd)
	{
		case CMD_GET_REC_FLAG:
		{
			unsigned char* pBuffer = arg;
			*pBuffer = AppsA9_data_rec_flag;
		}
		break;
		case CMD_GET_PKG_TYPE:
		{
			unsigned char* pBuffer = arg;
			*pBuffer = AppsA9_Rec_Pack_Type;
		}
		break;
		case CMD_GET_PKG_DATA:
		{
			switch(AppsA9_Rec_Pack_Type)
			{
				case PACKET_TYPE_CHANNELDATA12:
					*(YUNEEC_A9_STR *)arg = *(YUNEEC_A9_STR *)AppsA9_Rec_Data_Buff;
					AppsA9_data_rec_flag = 0;
				break;
				case PACKET_TYPE_Calibration_Set:
					*(Calibration_Type *)arg = *(Calibration_Type *)AppsA9_Rec_Data_Buff;
					AppsA9_data_rec_flag = 0;
				break;
				case PACKET_TYPE_Parameter_Set:
					*(FCA_SysParamSet *)arg = *(FCA_SysParamSet *)AppsA9_Rec_Data_Buff;
					AppsA9_data_rec_flag = 0;
				break;
				case PACKET_TYPE_CHANNELDATA12_GPS:
					*(RF_GPS_DATA *)arg = *(RF_GPS_DATA *)AppsA9_Rec_Data_Buff;
					AppsA9_data_rec_flag = 0;
				break;
				default :
					AppsA9_data_rec_flag = 0;
				break;
			}
		}
		break;
	}

#endif
	return 1;
}

#if defined(CTRL_A9)
static void AppsA9_uart_init(void)
{
#if defined(A9_RX_ENABLE)
	Pin PIN_USART2_RX = {PIO_PD15B_RXD2, PIOD, ID_PIOD, PIO_PERIPH_B, PIO_DEFAULT};
#endif
	Pin PIN_USART2_TX = {PIO_PD16B_TXD2, PIOD, ID_PIOD, PIO_PERIPH_B, PIO_DEFAULT};

	PMC_EnablePeripheral(ID_USART2);

#if defined(A9_RX_ENABLE)
	PIO_Configure(&PIN_USART2_RX, 1);
#endif
	PIO_Configure(&PIN_USART2_TX, 1);

	USART_Configure (USART2, US_MR_USART_MODE_NORMAL|US_MR_CHRL_8_BIT|US_MR_PAR_NO|US_MR_NBSTOP_1_BIT, 115200, MCK);

#if defined(A9_RX_ENABLE)
	USART_SetReceiverEnabled (USART2, 1);
#endif
	USART_SetTransmitterEnabled (USART2, 1);

#if defined(A9_RX_ENABLE)
	NVIC_ClearPendingIRQ(USART2_IRQn);
	NVIC_SetPriority(USART2_IRQn, 3);

	USART_EnableIt(USART2, US_IER_RXRDY);
	NVIC_EnableIRQ(USART2_IRQn);
#endif

	PMC_EnablePeripheral( ID_XDMAC );

	/* Clear dummy status */
	XDMAC_GetChannelIsr( XDMAC, AppsA9_UartDmaChannel );
	/* Disables XDMAC interrupt for the given channel. */
	XDMAC_DisableGIt (XDMAC, AppsA9_UartDmaChannel);
	XDMAC_DisableChannelIt (XDMAC, AppsA9_UartDmaChannel, 0xFF);
	/* Disable the given dma channel. */
	XDMAC_DisableChannel( XDMAC, AppsA9_UartDmaChannel );

	XDMAC_SetChannelConfig( XDMAC, AppsA9_UartDmaChannel, XDMAC_CC_TYPE_PER_TRAN
														|XDMAC_CC_DSYNC_MEM2PER
														|XDMAC_CC_MBSIZE_SINGLE
														|XDMAC_CC_PROT_SEC
														|XDMAC_CC_MEMSET_NORMAL_MODE
														|XDMAC_CC_CSIZE_CHK_1
														|XDMAC_CC_DWIDTH_BYTE
														|XDMAC_CC_SIF_AHB_IF0
														|XDMAC_CC_DIF_AHB_IF1
														|XDMAC_CC_SAM_INCREMENTED_AM
														|XDMAC_CC_DAM_FIXED_AM
														|XDMAC_CC_PERID(11)
														);

	XDMAC_SetMicroblockControl(XDMAC, AppsA9_UartDmaChannel, 12);
	XDMAC_SetSourceAddr(XDMAC, AppsA9_UartDmaChannel, (unsigned int)0);
	XDMAC_SetDestinationAddr(XDMAC, AppsA9_UartDmaChannel, (unsigned int)&(USART2->US_THR));
	XDMAC_SetDescriptorControl(XDMAC, AppsA9_UartDmaChannel,0);
	XDMAC_SetBlockControl(XDMAC, AppsA9_UartDmaChannel,0);
	XDMAC_SetDataStride_MemPattern(XDMAC, AppsA9_UartDmaChannel,0);
	XDMAC_SetSourceMicroBlockStride(XDMAC, AppsA9_UartDmaChannel,0);
	XDMAC_SetDestinationMicroBlockStride(XDMAC, AppsA9_UartDmaChannel,0);

	/*Enable xDMA interrupt */
	NVIC_ClearPendingIRQ(XDMAC_IRQn);
	NVIC_SetPriority( XDMAC_IRQn, 9);
	NVIC_EnableIRQ(XDMAC_IRQn);

	XDMAC_EnableChannelIt(XDMAC, AppsA9_UartDmaChannel,XDMAC_CIE_BIE);
	XDMAC_EnableGIt(XDMAC, AppsA9_UartDmaChannel);
}

//发送DMA中断
void AppsA9_UartDmaIrq(void)
{
	AppsA9_UartDmaTxFlag = 1;
}

static void AppsA9_uart_send_nbyte(unsigned char* pBuffer, unsigned int len)
{
	while(AppsA9_UartDmaTxFlag == 0) {}
	AppsA9_UartDmaTxFlag = 0;
	XDMAC_SetMicroblockControl(XDMAC, AppsA9_UartDmaChannel, len);
	XDMAC_SetSourceAddr(XDMAC, AppsA9_UartDmaChannel, (unsigned int)pBuffer);
	XDMAC_SetDestinationAddr(XDMAC, AppsA9_UartDmaChannel, (unsigned int)&(USART2->US_THR));
	SCB_CleanInvalidateDCache();
	XDMAC_EnableChannel(XDMAC, AppsA9_UartDmaChannel);
}
#endif
#if defined(A9_RX_ENABLE)
YUNEEC_REC_STR AppsA9_rec_package = {0};
void AppsA9_uart_rx_irq(unsigned char data)
{
	static unsigned char AppsA9_step = 0;
	static unsigned short App_count = 0;
	switch(AppsA9_step)
	{
		case 0:
			AppsA9_rec_package.h1 = data;
			if(data == 0x55)
				AppsA9_step = 1;
		break;
		case 1:
			AppsA9_rec_package.h2 = data;
			if(data == 0x55)
				AppsA9_step = 2;
			else
				AppsA9_step = 0;
		break;
		case 2:
			AppsA9_rec_package.length = data;
			if((data > 0) && (data <= 100))
				AppsA9_step = 3;
			else
				AppsA9_step = 0;
		break;
		case 3:
			AppsA9_rec_package.type = data;
			App_count = 0;
			AppsA9_step = 4;
		break;
		case 4:
		{
			AppsA9_rec_package.buffer[App_count] = data;
			App_count ++;
			if(App_count == AppsA9_rec_package.length - 1)
			{
				if(crcRfCal(&AppsA9_rec_package.length, AppsA9_rec_package.length) == AppsA9_rec_package.buffer[AppsA9_rec_package.length - 2])//check
				{
					AppsA9_Rec_Pack_Type = AppsA9_rec_package.type;//type
					for(uint8_t len = 0; len < AppsA9_rec_package.length - 1; len ++)
					{
						AppsA9_Rec_Data_Buff[len] = AppsA9_rec_package.buffer[len];//data
					}
					AppsA9_data_rec_flag = 1;//flag
				}
				App_count = 0;
				AppsA9_step = 0;
			}
		}
		break;
		default:
			AppsA9_step = 0;
		break;
	}
}
#endif
