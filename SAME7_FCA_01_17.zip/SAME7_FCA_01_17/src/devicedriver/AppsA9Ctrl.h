#ifndef __APPSA9CTRL_H
#define __APPSA9CTRL_H

#include "platform.h"

#define CMD_GET_REC_FLAG 0x01
#define CMD_GET_PKG_TYPE 0x02
#define CMD_GET_PKG_DATA 0x03

__packed typedef struct
{
	unsigned char h1;	//0x55
	unsigned char h2;	//0x55
	unsigned char length;
	unsigned char type;
	unsigned char buffer[44];
}YUNEEC_SND_STR;

__packed typedef struct
{
	unsigned short t;
	unsigned char status[2];
	unsigned char channel[24];
}YUNEEC_A9_STR;

unsigned int AppsA9_getID(void);
unsigned int AppsA9_register(void);

#endif /* __APPSA9CTRL_H */
