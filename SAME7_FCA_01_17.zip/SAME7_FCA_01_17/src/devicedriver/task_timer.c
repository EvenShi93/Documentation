﻿#include "task_timer.h"
#include "delay.h"	
#include "device.h"
#include "driver.h"


static unsigned int  taskTimerID = 0;

static DEV taskTimer={
	.name = "TASK_TIMER",
	.devDrv={
		.init =  task_timer_init,
		.open =  task_timer_open
	}
};


unsigned int task_timer_getID(void)
{
	return taskTimerID;
}
unsigned int task_timer_register(void)
{
	taskTimerID = register_driver(&taskTimer.devDrv);
	return  taskTimerID;
}



static int task_timer_init(void)
{
	TC0_init(1000);//1s中断1000次，T=1ms
	
	return 1;
}

static int task_timer_open(void)
{
		TC0_enable();
	 return 1;
}

/*
  应用
	task_timer_register();
	init(task_timer_getID());
	open(task_timer_getID());
*/
