#include "switch.h"
#include "delay.h"	
#include "device.h"
#include "driver.h"

static Pin PIN_POWER_AD = {PIO_PD0, PIOD, ID_PIOD, PIO_INPUT, PIO_DEFAULT};
static Pin PIN_POWER = {PIO_PB13, PIOB, ID_PIOB, PIO_OUTPUT_0, PIO_DEFAULT};

static unsigned int switchID = 0;

static DEV SWITCH = {
	.name = "SWITCH",
	.devDrv = {
		.init = switch_init,
		.read = switch_read,
		.open = switch_open,
		.close = switch_close,
		.ioctrl = switch_ioctrl,
	}
};

unsigned int switch_getID(void)
{
	return switchID;
}

unsigned int switch_register(void)
{
	switchID = register_driver(&SWITCH.devDrv);
	return  switchID;
}

static int switch_init(void)
{
	PIO_Configure(&PIN_POWER_AD, 1);
	PIO_Configure(&PIN_POWER, 1);
	return 1;
}

static int switch_open(void)
{
	PIO_Set(&PIN_POWER);
	return 1;
}

static int switch_close(void)
{
	PIO_Clear(&PIN_POWER);
	return 1;
}

static int switch_read(void* buffer,unsigned int len)
{	
	unsigned char* pBuffer = buffer;
	*pBuffer = PIO_Get(&PIN_POWER_AD);
	return 1;
}

static int switch_ioctrl(unsigned char cmd, void* arg)
{
	switch(cmd)
	{
		case SWITCH_IOCTRL_POWER_DETECT:
			switch_read(arg, 1);
		break;
	}
	return 1;
}
