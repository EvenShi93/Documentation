#include "bsp.h"

uint8_t bsp_init(void)
{
	uint8_t COLOR = 0;
	uint8_t Mpu6500Tries = 0;
	uint8_t DeviceInitSta = 0;
	delay_ms(300);

	init(switch_register());
	open(switch_getID());
delay_ms(1);
	init(led_register());
#if defined(CTRL_RF)
	COLOR = RED | GREEN;
	ioctrl(led_getID(), LED_Indep, &COLOR);
#elif defined(CTRL_A9)
	COLOR = GREEN | BLUE;
	ioctrl(led_getID(), LED_Indep, &COLOR);
#endif
delay_ms(1);
	init(Heat_register());
	close(Heat_getID());
delay_ms(1);
	init(flash_register());
delay_ms(1);
	init(moto_register());
delay_ms(1);
	init(volt_register());
delay_ms(1);

	mpu6500_register();
	while(Mpu6500Tries < 20)
	{
		if(!init(mpu6500_getID()))
			Mpu6500Tries ++;
		else break;
		if(Mpu6500Tries >= 20)
			DeviceInitSta |= DEV_ERR_MPU6500;//MPU6500��ʼ��ʧ��
		delay_ms(1);
	}
#if USE_EEPROM_DATA
	AT24CXX_register();
	open(AT24CXX_getID());
	if(!init(AT24CXX_getID()))
		DeviceInitSta |= DEV_ERR_AT24CXX;//EEPROM��ʼ������
	close(AT24CXX_getID());
delay_ms(1);
#endif /* USE_EEPROM_DATA */

	if(!init(IST8307_register())) DeviceInitSta |= DEV_ERR_IST8307;//IST8307��ʼ��ʧ��
delay_ms(1);
	if(!init(ms56xx_register())) DeviceInitSta |= DEV_ERR_BMS56XX;//��ѹ�Ƴ�ʼ��ʧ��
delay_ms(1);

	init(rf_st10_register());
delay_ms(1);
	init(Ultrasonic_register());
delay_ms(1);
	init(AppsA9_register());
delay_ms(1);
	init(monitor_register());
delay_ms(1);
	init(Steer_register());
delay_ms(1);

	if(!init(ublox_m8q_register())) DeviceInitSta |= DEV_ERR_UBLOXM8;
delay_ms(1);

#if USE_CAM_FLOW
	if(!init(camera_register())) DeviceInitSta |= DEV_ERR_FLOWCAM;//������ͷ��ʼ������
#endif /* USE_CAM_FLOW */
delay_ms(2);

	init(task_timer_register());
	open(task_timer_getID());

	return DeviceInitSta;
}
