﻿#include "led.h"
#include "device.h"
#include "driver.h"
#include "delay.h"

static Pin PIN_LED = {PIO_PD9, PIOD, ID_PIOD, PIO_OUTPUT_1, PIO_DEFAULT};

static Pin PIN_Ind_R = {PIO_PA1, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};
static Pin PIN_Ind_G = {PIO_PA0, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};
static Pin PIN_Ind_B = {PIO_PA2, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};

static unsigned int LedID = 0;

static DEV Led = {
	.name = "LED",
	.devDrv = {
	.init = led_init,
	.open = led_open,
	.close = led_close,
	.ioctrl = led_ioctrl
	}
};

unsigned int led_getID(void)
{
	return LedID;
}
unsigned int led_register(void)
{
	LedID = register_driver(&Led.devDrv);
	return LedID;
}

static int led_ioctrl(unsigned char cmd, void* arg)
{
	uint8_t Color = *(uint8_t *)arg;
	switch(cmd)
	{
		case LED_Board:
			if(Color != 0) PIO_Set(&PIN_LED);
			else PIO_Clear(&PIN_LED);
		break;
		case LED_Indep:
			if((Color & R_Msk) == R_Msk) PIO_Set(&PIN_Ind_R);
			else PIO_Clear(&PIN_Ind_R);
			if((Color & G_Msk) == G_Msk) PIO_Set(&PIN_Ind_G);
			else PIO_Clear(&PIN_Ind_G);
			if((Color & B_Msk) == B_Msk) PIO_Set(&PIN_Ind_B);
			else PIO_Clear(&PIN_Ind_B);
		break;
		default : break;
	}
	return 1;
}

static int led_init(void)
{
	PIO_Configure(&PIN_LED, 1);

	PIO_Configure(&PIN_Ind_R, 1);
	PIO_Configure(&PIN_Ind_G, 1);
	PIO_Configure(&PIN_Ind_B, 1);

	return 1;
}

static int led_open(void)
{
	PIO_Clear(&PIN_LED);

//	PIO_Clear(&PIN_Ind_R);
//	PIO_Clear(&PIN_Ind_G);
//	PIO_Clear(&PIN_Ind_B);

	return 1;
}

static int led_close(void)
{
	PIO_Set(&PIN_LED);

//	PIO_Set(&PIN_Ind_R);
//	PIO_Set(&PIN_Ind_G);
//	PIO_Set(&PIN_Ind_B);

	return 1;
}

/*
	led应用示例
  static unsigned int count = 0;
			count++;
			if(count >= 1000)
			{
				static unsigned char  flag = 0;
				unsigned char ledbuffer[3]={0};
				if(flag == 0)
				{
					flag = 1;
				   ledbuffer[0] = WHITE;
				}
				else
				{
					flag = 0;
					ledbuffer[0] = BLACK;
				}
				ioctrl(led_getID(),0,ledbuffer);
				 count = 0;
			}	

*/
