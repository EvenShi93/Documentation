#ifndef _DEVICE_H_
#define _DEVICE_H_

#include "driver.h"
#include "cfg.h"

typedef struct
{
  char name[DEV_NAME_LEN];
  unsigned int devID;
  DEV_DRV devDrv;
  void* private;
}DEV;


#endif 
