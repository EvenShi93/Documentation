﻿#include "hmc5883.h"
#include "delay.h"	
#include "device.h"
#include "driver.h"


static unsigned int  hmc5883ID = 0;

static DEV hmc5883={
	.name = "HMC5883",
	.devDrv={
		.init =  hmc5883_init,
		.read =  hmc5883_read,
		.ioctrl = hmc5883_ioctrl
	}
};

unsigned int hmc5883_getID(void)
{
	return hmc5883ID;
}
unsigned int hmc5883_register(void)
{
	hmc5883ID = register_driver(&hmc5883.devDrv);
	return  hmc5883ID;
}

static void  hmc5883_i2c_init(void)
{
	REG_CCFG_SYSIO = (1<<5) | (1<<4);
	Pin PIN_I2C1_SDA ={PIO_PB4A_TWD1, PIOB, ID_PIOB, PIO_PERIPH_A, PIO_DEFAULT}; 
	Pin PIN_I2C1_SCL ={PIO_PB5A_TWCK1, PIOB, ID_PIOB, PIO_PERIPH_A, PIO_DEFAULT}; 
	
	PMC_EnablePeripheral(ID_TWIHS1);
	PIO_Configure(&PIN_I2C1_SDA,1);
	PIO_Configure(&PIN_I2C1_SCL,1);
	i2c_init(TWIHS1,400000,MCK);
	delay_ms(10);
}

static void hmc5883_i2c_write_byte(unsigned char deviceAddr, unsigned char regAddr,unsigned char data)
{
	unsigned char temp[2] = {0};
	temp[0] = regAddr;
	temp[1] = data;
	i2c_write(TWIHS1,deviceAddr,temp,2);	
}

static void hmc5883_i2c_read(unsigned char slaveAddr,unsigned char regAddr,unsigned int readNumber,unsigned char* readBuffer)
{
	i2c_write_read(TWIHS1,slaveAddr,&regAddr,1,readBuffer,readNumber);
}

static int hmc5883_init(void)
{
		hmc5883_i2c_init();
		hmc5883_set_mode(0);//连续测量模式
		hmc5883_set_ms(0);//正常测量配置
		hmc5883_set_dor(6);//数据输出速率75HZ
		hmc5883_set_ma(3);//采样平均数8
		hmc5883_set_gn(1);//增益为1，+/-1.3Ga (-2048--2047 )
		delay_ms(2);
		return 1;
}

static int hmc5883_read(void* buffer,unsigned int len)
{
	unsigned char* pBuffer = buffer;
	hmc5883_i2c_read(HMC58X3_ADDR,HMC58X3_R_XM,6,pBuffer);
	return 1;
}
	

static int  hmc5883_ioctrl(unsigned char cmd,void* arg)
{
	unsigned int ret = 1;
	switch(cmd)
	{
		case HMC5883_IOCTRL_SET_DOR:
			{
				 unsigned char* pBuffer =  arg;
				 hmc5883_set_dor(*pBuffer);
			}
			 break;
		case HMC5883_IOCTRL_SET_MA:  
			{
				 unsigned char* pBuffer =  arg;
				 hmc5883_set_ma(*pBuffer);
			}
			 break;
		case HMC5883_IOCTRL_SET_MS:
			{
				 unsigned char* pBuffer =  arg;
				 hmc5883_set_ms(*pBuffer);
			}
			 break;
		case HMC5883_IOCTRL_SET_GN:
			{
				 unsigned char* pBuffer =  arg;
				 hmc5883_set_gn(*pBuffer);
			}
			 break;
		case HMC5883_IOCTRL_SET_MODE:
			{
				 unsigned char* pBuffer =  arg;
				 hmc5883_set_mode(*pBuffer);
			}
			 break;
		case HMC5883_IOCTRL_CHECK:
			{
				 ret = hmc5883_check();
			}
			 break;
		default:
			break;
		 
	}
	return ret;
}



static unsigned char hmc5883_check(void)
{
	unsigned char temp = 0;
	hmc5883_i2c_read(HMC58X3_ADDR,10,1,&temp);
	if(temp != 0x48)
	{
		return 0;
	}
	delay_ms(2);
	hmc5883_i2c_read(HMC58X3_ADDR,11,1,&temp);
	if(temp != 0x34)
	{
		return 0;
	}
	delay_ms(2);
	hmc5883_i2c_read(HMC58X3_ADDR,12,1,&temp);
	if(temp != 0x33)
	{
		return 0;
	}
	delay_ms(2);
	return 1;
}	
/*----------------------------------------------------------------------------
设置输出速率
0 -> 0.75Hz  |   1 -> 1.5Hz
2 -> 3Hz     |   3 -> 7.5Hz
4 -> 15Hz    |   5 -> 30Hz
6 -> 75Hz  
------------------------------------------------------------------------------*/
static void hmc5883_set_dor(unsigned char rate)
{
	if(rate>6)
	{
		return ;
	}
	else
	{
		unsigned char temp;
		hmc5883_i2c_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
		temp &= ~0x1C;
		temp |= rate<<2;
		delay_ms(2);
		hmc5883_i2c_write_byte(HMC58X3_ADDR,HMC58X3_R_CONFA,temp);
		delay_ms(2);
		//i2c1_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
	}
}

//设置采样平均数
static void hmc5883_set_ma(unsigned char ma)
{
	if(ma>3)
	{
		return ;
	}
	else
	{
		unsigned char temp;
		hmc5883_i2c_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
		temp &= ~0x60;
		temp |= ma<<5;
		delay_ms(2);
		hmc5883_i2c_write_byte(HMC58X3_ADDR,HMC58X3_R_CONFA,temp);
		delay_ms(2);
		//i2c1_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
	}
}
//设置测量配置
static void hmc5883_set_ms(unsigned char ms)
{
	if(ms>3)
	{
		return ;
	}
	else
	{
		unsigned char temp;
		hmc5883_i2c_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
		temp &= ~0x3;
		temp |= ms;
		delay_ms(2);
		hmc5883_i2c_write_byte(HMC58X3_ADDR,HMC58X3_R_CONFA,temp);
		delay_ms(2);
		//i2c1_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
	}
}


//设置增益
static void hmc5883_set_gn(unsigned char gn)
{
	if(gn>7)
	{
		return ;
	}
	else
	{
		unsigned char temp;
		hmc5883_i2c_read(HMC58X3_ADDR,HMC58X3_R_CONFB,1,&temp);
		temp &= ~0xE0;
		temp |= gn<<5;
		delay_ms(2);
		hmc5883_i2c_write_byte(HMC58X3_ADDR,HMC58X3_R_CONFB,temp);
		delay_ms(2);
		//i2c1_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
	}
}
//设置模式
static void hmc5883_set_mode(unsigned char mode)
{
	if(mode>3)
	{
		return ;
	}
	else
	{
		unsigned char temp;
		hmc5883_i2c_read(HMC58X3_ADDR,HMC58X3_R_MODE,1,&temp);
		temp &= ~0x03;
		temp |= mode;
		delay_ms(2);
		hmc5883_i2c_write_byte(HMC58X3_ADDR,HMC58X3_R_MODE,temp);
		delay_ms(2);
		//i2c1_read(HMC58X3_ADDR,HMC58X3_R_CONFA,1,&temp);
	}
}


/*
  //应用
	unsigned char buffer[6] ={0};
	MAGNET_RAW_SHORT magnetRawShort={0};
	read(hmc5883_getID(),buffer,6);
	magnetRawShort.magX=((short)buffer[0] << 8) | buffer[1];
	magnetRawShort.magY=((short)buffer[4] << 8) | buffer[5];
	magnetRawShort.magZ=((short)buffer[2] << 8) | buffer[3];
*/

//void hmc5883_get_raw(void)
//{
//	unsigned char temp[6]={0};
//	
//	i2c1_read(HMC58X3_ADDR,HMC58X3_R_XM,6,temp);
//	
//	magnetRawShort.X=((short)temp[0] << 8) | temp[1];
//	magnetRawShort.Y=((short)temp[4] << 8) | temp[5];
//	magnetRawShort.Z=((short)temp[2] << 8) | temp[3];
//	
//}
