#ifndef __FUNCCONFIG_H
#define __FUNCCONFIG_H

/* ------------------------------ UART ------------------------------ */

#define MOT_PREBURNING_ENABLE 1

#if MOT_PREBURNING_ENABLE
#define USE_DATA_TRANSFER 0
#else
#define USE_DATA_TRANSFER 1
#endif

#if USE_DATA_TRANSFER
//#define USE_A9_SERIAL_PORT
#define USE_RF_SERIAL_PORT

#define TRANS_RX_ENABLE
#endif

#if !defined(USE_RF_SERIAL_PORT) && !MOT_PREBURNING_ENABLE
//#define CTRL_RF
#endif
#if !defined(USE_A9_SERIAL_PORT)
#define CTRL_A9
#endif

#if defined(CTRL_A9)
#define A9_RX_ENABLE
#endif

#if MOT_PREBURNING_ENABLE && defined(CTRL_RF)
#error "RF UART MULTIPLEX ERROR."
#endif

#if defined(USE_RF_SERIAL_PORT) && defined(CTRL_RF)
#error "RF UART MULTIPLEX ERROR."
#endif

#if defined(USE_A9_SERIAL_PORT) && defined(CTRL_A9)
#error "A9 UART MULTIPLEX ERROR."
#endif
/* ------------------------------ UART ------------------------------ */

/* ------------------------------ FLOW ------------------------------ */
#define USE_CAM_FLOW 1
/* ------------------------------ FLOW ------------------------------ */

/* ----------------------------- E2PROM ----------------------------- */

#define USE_EEPROM_DATA 1

#if USE_EEPROM_DATA

#define USE_E2PROM_CAL_DATA

#if defined(USE_E2PROM_CAL_DATA)
#define USE_PEACE_DATA
#define USE_ELLIP_DATA
#endif /* defined(USE_E2PROM_CAL_DATA) */

#endif /* USE_EEPROM_DATA */
/* ----------------------------- E2PROM ----------------------------- */

/* ----------------------------- HEIGHT ----------------------------- */
#define USE_INFRA
//#define USE_SONIC
/* ----------------------------- HEIGHT ----------------------------- */

#endif /* __FUNCCONFIG_H */
