#ifndef __USBDRIVER_H
#define __USBDRIVER_H

#include "platform.h"

unsigned int usb_getID(void);
unsigned int usb_register(void);

#endif /* __USBDRIVER_H */
