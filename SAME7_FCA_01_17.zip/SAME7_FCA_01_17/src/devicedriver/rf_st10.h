#ifndef _RF_ST10_H_
#define _RF_ST10_H_

#include "platform.h"

__packed typedef struct
{
	unsigned char h1;	//0x55
	unsigned char h2;	//0x55
	unsigned char length;
	unsigned char type;
	unsigned char buffer[100];
}YUNEEC_REC_STR;

__packed typedef struct
{
	unsigned short t;
	unsigned char status[2];
	unsigned char channel[18];
//	RF_GPS_RAW GPSInfo;
}YUNEEC_RF_STR;

typedef enum
{
	RF_ST10_IOCTRL_BIND_PACKAGE_SEND = 0,
	RF_ST10_IOCTRL_REMOTE_PACKAGE_REC_FLAG = 1
}RF_ST10_IOCTRL;

unsigned int rf_st10_getID(void);
unsigned int rf_st10_register(void);

#endif
