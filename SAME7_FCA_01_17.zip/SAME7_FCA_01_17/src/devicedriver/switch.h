#ifndef _SWITCH_H_
#define _SWITCH_H_

#include "platform.h"

typedef enum
{
	POWER_LOW = 0,
	POWER_HIGH = 1
}POWER_AD_LEVEL;

typedef enum
{
	POWER_OFF = 0,
	POWER_ON = 1
}POWER_STATUE;


typedef enum
{
	SWITCH_IOCTRL_POWER_STATUS = 0,
	SWITCH_IOCTRL_POWER_DETECT = 1
}SWITCH_IOCTRL;

unsigned int switch_getID(void);
unsigned int switch_register(void);
static int switch_init(void);
static int switch_open(void);
static int switch_close(void);
static int switch_read(void* buffer,unsigned int len);
static int  switch_ioctrl(unsigned char cmd,void* arg);
static void  switch_detect(void);

#endif 
