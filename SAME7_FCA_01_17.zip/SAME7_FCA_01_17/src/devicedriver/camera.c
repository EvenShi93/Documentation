#include "camera.h"
#include "delay.h"
#include "device.h"
#include "driver.h"
#include "OV7740Config.h"

/** TWI1 data pin */
#define PIN_TWI_TWD1  {PIO_PB4A_TWD1, PIOB, ID_PIOB, PIO_PERIPH_A, PIO_OPENDRAIN}
/** TWI1 clock pin */
#define PIN_TWI_TWCK1 {PIO_PB5A_TWCK1, PIOB, ID_PIOB, PIO_PERIPH_A, PIO_OPENDRAIN}
/** TWI1 pins */
#define PINS_TWI_ISI  {PIN_TWI_TWD1, PIN_TWI_TWCK1}
/** TWI peripheral ID for Sensor configuration */
#define ID_TWI_ISI    ID_TWIHS1
/** TWI base address for Sensor configuration */
#define BASE_TWI_ISI  TWIHS1
/** TWI clock frequency in Hz. */
#define TWCK          400000

static unsigned int cameraID = 0;
static unsigned char FrameGetFlag = 0;
static uint32_t Time_Cur = 0, Time_Last = 0, Time_Ticks = 0;
OVCamera_IDTypeDef OVC_ID = {0};

COMPILER_WORD_ALIGNED static ISI_FrameBufferDescriptors preBufDesc;
COMPILER_WORD_ALIGNED static unsigned char FrameBuffer[FRAME_BUFFER_SIZEC(FrameWidth, FrameHeight)];//COMPILER_WORD_ALIGNED static 
//static unsigned char FrameBufferCopy[FRAME_BUFFER_SIZEC(FrameWidth, FrameHeight)/2];
COMPILER_WORD_ALIGNED unsigned char FrameBuffer_cpy[FRAME_BUFFER_SIZEC(FrameWidth, FrameHeight)];//COMPILER_WORD_ALIGNED static 

/** TWI Pins definition */
const Pin pinsTWI[] = PINS_TWI_ISI;

static int Camera_Open(void);
static int Camera_Close(void);
static int CAMERA_Init(void);
static int FrameBufferRead(void* buffer,unsigned int len);
static int Camera_ioctrl(unsigned char cmd, void* arg);
static void SCCB_Init(void);
static uint8_t SCCB_WriteSingleData(uint8_t Device, uint8_t Addr, uint8_t Data);
static uint8_t SCCB_ReadSingleData(uint8_t Device, uint8_t Addr, uint8_t *Data);
static void _isi_AllocateFBD(void);
static void _isiInit(void);

static DEV camera = {
	.name = "CAMERA",
	.devDrv = {
		.init = CAMERA_Init,
		.open = Camera_Open,
		.close = Camera_Close,
		.read = FrameBufferRead,
		.ioctrl = Camera_ioctrl
	}
};

unsigned int camera_getID(void)
{
	return cameraID;
}

unsigned int camera_register(void)
{
	cameraID = register_driver(&camera.devDrv);
	return cameraID;
}

static int Camera_Open(void)
{
	ISI_DmaChannelEnable(ISI_DMA_CHER_P_CH_EN);
	ISI_EnableInterrupt(ISI_IER_PXFR_DONE);
	/* Configure ISI interrupts */
	NVIC_ClearPendingIRQ(ISI_IRQn);
	NVIC_EnableIRQ(ISI_IRQn);
	ISI_Enable();
	return 1;
}

static int Camera_Close(void)
{
	ISI_DisableInterrupt(0xFFFFFFFF);
	ISI_DmaChannelDisable(ISI_DMA_CHDR_C_CH_DIS);
	ISI_Disable();
	return 1;
}

static int CAMERA_Init(void)
{
	uint16_t Index = 0;
	uint8_t Temp = 0;
	//init sccb interface.
	SCCB_Init();
	delay_ms(2);
	//camera configuration.
	while(ov7740_qvga_yuv[Index].reg != 0xFF)
	{
		delay_ms(1);
		if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, ov7740_qvga_yuv[Index].reg, ov7740_qvga_yuv[Index].val)) return 0;
		Index ++;
	}
	#if (FRAMESIZE==FRAMESIZE_80X80)
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x31, 0x14)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x32, 0x28)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x82, 0x3f)) return 0;
	#endif
	
	#if (FRAMESIZE==FRAMESIZE_160X160)
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x31, 0x28)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x32, 0x50)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x82, 0x3f)) return 0;
	#endif

	#if (FRAMESIZE==FRAMESIZE_84X84)
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x31, 0x15)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x32, 0x2A)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x82, 0x3f)) return 0;
	#endif
	
	#if (FRAMESIZE==FRAMESIZE_100X100)
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x31, 0x19)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x32, 0x32)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x82, 0x3f)) return 0;
	#endif
	
	#if (FRAMESIZE==FRAMESIZE_132X132)
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x31, 0x21)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x32, 0x42)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x82, 0x3f)) return 0;
	#endif
	
	#if (FRAMESIZE==FRAMESIZE_164X164)
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x31, 0x29)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x32, 0x52)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x82, 0x3f)) return 0;
	#endif



	// gray pixels
	if(!SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0x81, (uint8_t*)&Temp)) return 0;
	Temp |= 0x20;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x81, Temp)) return 0;

	if(!SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0xDA, (uint8_t*)&Temp)) return 0;
	Temp |= 0x18;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xDA, Temp)) return 0;

	Temp = 0x80;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xDF, Temp)) return 0;
	if(!SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xE0, Temp)) return 0;

	/* Get Product ID & Manufacturer ID */
	if(!SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, OV7740_PIDH_ADDRESS, &(OVC_ID.Product_ID_H))) return 0;
	if(!SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, OV7740_PIDL_ADDRESS, &(OVC_ID.Product_ID_L))) return 0;

	if(!SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, OV7740_MIDH_ADDRESS, &(OVC_ID.Manufacturer_IDH))) return 0;
	if(!SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, OV7740_MIDL_ADDRESS, &(OVC_ID.Manufacturer_IDL))) return 0;

	_isiInit();
	return 1;
}

void camera_set_bright(int8_t bright)
{
	uint8_t Temp = 0;

	SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0x81, (uint8_t*)&Temp);
	Temp |= 0x20;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x81, Temp);

	SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0xDA, (uint8_t*)&Temp);
	Temp |= 0x04;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xDA, Temp);

	if(bright>=0) Temp = 0x0e;
	else Temp = 0x06;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xE4, Temp);

	Temp = (uint8_t)(0x10*fabs(bright));
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xE3, Temp);
}

void camera_set_contrast(int8_t contrast)
{
	uint8_t Temp = 0;

	SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0x81, (uint8_t*)&Temp);
	Temp |= 0x20;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x81, Temp);

	SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0xDA, (uint8_t*)&Temp);
	Temp |= 0x04;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xDA, Temp);

	Temp = 0x20;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xE1, Temp);

	if(contrast>0) Temp = 0x30-4*contrast;
	else Temp = 0x20+4*contrast;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xE2, Temp);

	if(contrast > 0) Temp = 0x00;
	else Temp = 0x20;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xE3, Temp);

	SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0xE4, (uint8_t*)&Temp);
	Temp |= 0xFB;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0xE4, Temp);
}

void camera_set_exposure(uint8_t exposure)
{
	uint8_t Temp = 0;
	Temp = 0xff;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x13, Temp);
	Temp = 0x00;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x15, Temp);
	Temp = 0x00;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x2d, Temp);
	Temp = 0x00;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x2e, Temp);
	Temp = (8 + exposure) << 4;
	SCCB_WriteSingleData(OV7740_SLAVE_ADDRESS, 0x15, Temp);
}

uint8_t camera_get_LumValue(uint8_t* value)
{
	return SCCB_ReadSingleData(OV7740_SLAVE_ADDRESS, 0x2f, value);
}

static int FrameBufferRead(void* buffer, unsigned int len)
{
//	uint8_t *pBuf = (uint8_t *)buffer;
	if(FrameGetFlag == 1)
	{
		FrameGetFlag = 0;
		
		memcpy(FrameBuffer_cpy,FrameBuffer,IMAGE_BUFF_SIZE);
		
		//for(uint32_t Index = 0; Index < IMAGE_SIZE * 2; Index += 2) *pBuf ++ = FrameBuffer[Index];
		
		return 1;
	}
	return 0;
}

static int Camera_ioctrl(unsigned char cmd, void* arg)
{
	uint8_t *pBuf = (uint8_t *)arg;
	switch(cmd)
	{
		case GetFrameBuffer:
			if(FrameGetFlag == 1)
			{
				FrameGetFlag = 0;
				for(uint32_t Index = 0; Index < IMAGE_SIZE * 2; Index += 2) *pBuf ++ = FrameBuffer[Index];
//				buffer = FrameBufferCopy;
				return 1;
			}
			return 0;
		case GetImageT:
			*((uint32_t *)arg) = Time_Ticks;
		return 1;
		case GetLumValue:
			return camera_get_LumValue((uint8_t *)arg);
		default : return 0;
	}
}

/**
 * \brief TWI initialization.
 */
static void SCCB_Init(void)
{
//	REG_CCFG_SYSIO = (1<<5) | (1<<4);

//    /* Enable TWI peripheral clock */
//	PMC_EnablePeripheral(ID_TWI_ISI);
//	/* Configure TWI pins. */
//	PIO_Configure(pinsTWI, PIO_LISTSIZE(pinsTWI));
//	/* Configure TWI */
//	TWI_ConfigureMaster(BASE_TWI_ISI, TWCK, MCK);
}

/**
  * @brief  Writes a byte at a specific Camera register
  * @param  Device: Image Sensor write address.
  * @param  Addr: Image Sensor register address.
  * @param  Data: data to be written to the specific register.
  * @retval None
  */
static uint8_t SCCB_WriteSingleData(uint8_t Device, uint8_t Addr, uint8_t Data)
{
	uint8_t temp[2];
	temp[0] = Addr;
	temp[1] = Data;
	return i2c_write(BASE_TWI_ISI, Device, temp, 2);
}

/**
  * @brief  Reads a byte from a specific Camera register.
  * @param  Device: Image Sensor write address.
  * @param  Addr: Image Sensor register address.
  * @retval data read from the specific register or 0xFF if 
  *         timeout condition occured.
  */
static uint8_t SCCB_ReadSingleData(uint8_t Device, uint8_t Addr, uint8_t *Data)
{
	return i2c_write_read(BASE_TWI_ISI, Device, &Addr, 1, Data, 1);
}

/**
 * \brief Set up Frame Buffer Descriptors(FBD) for preview path.
 */
static void _isi_AllocateFBD(void)
{
	preBufDesc.Current = (uint32_t)FrameBuffer;
	preBufDesc.Control = ISI_DMA_P_CTRL_P_FETCH;
	preBufDesc.Next    = (uint32_t)&preBufDesc;
    //clear D cache before used by DMA
	SCB_CleanDCache_by_Addr((uint32_t *)&preBufDesc, sizeof(preBufDesc));
}

/**
 * \brief ISI  initialization.
 */
static void _isiInit(void)
{
	/* Enable ISI peripheral clock */
	PMC_EnablePeripheral(ID_ISI);
	/* Set up Frame Buffer Descriptors(FBD) for preview path. */
	_isi_AllocateFBD();
	/* Reset ISI peripheral */
	ISI_Reset();
	/* Set the windows blank */
	ISI_SetBlank(0, 0);
	/* Set vertical and horizontal Size of the Image Sensor for preview path*/
	ISI_SetSensorSize(FrameWidth, FrameHeight);
	/*  Set data stream in RGB format.*/
	ISI_setInputStream(RGB_INPUT);

	/* Set preview size to fit memory */
	ISI_setPreviewSize(FrameWidth, FrameHeight);
	/* calculate scaler factor automatically. */
	ISI_calcScalerFactor();
	/* Configure DMA for preview path. */
	ISI_setDmaInPreviewPath((uint32_t)&preBufDesc, ISI_DMA_P_CTRL_P_FETCH, ((uint32_t)(FrameBuffer) << 2));
	ISI_RgbPixelMapping(ISI_CFG2_RGB_CFG_MODE3);

	/* Interrupt priority */
	NVIC_SetPriority(ISI_IRQn, 10);

	ISI_DisableInterrupt(0xFFFFFFFF);
	ISI_DmaChannelDisable(ISI_DMA_CHDR_C_CH_DIS);
	ISI_DmaChannelEnable(ISI_DMA_CHER_P_CH_EN);
	ISI_EnableInterrupt(ISI_IER_PXFR_DONE);
	/* Configure ISI interrupts */
	NVIC_ClearPendingIRQ(ISI_IRQn);
	NVIC_EnableIRQ(ISI_IRQn);
	ISI_Enable();
}

/* ---------------------------------------------------------------------------------------- */
/* ------------------------------- camera interrupt handler ------------------------------- */
/* ---------------------------------------------------------------------------------------- */
/**
 * \brief ISI interrupt handler.
 */
void ISI_Handler(void)
{
	/* If Preview DMA Transfer has Terminated */
	if(ISI_StatusRegister() & ISI_SR_PXFR_DONE)
	{
		Time_Cur = _Get_Micros();
		Time_Ticks = Time_Cur - Time_Last;
		Time_Last = Time_Cur;
		FrameGetFlag = 1;
	}
}
