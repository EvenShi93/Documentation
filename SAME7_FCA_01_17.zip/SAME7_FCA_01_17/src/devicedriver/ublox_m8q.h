#ifndef _GPS_H_
#define _GPS_H_

#include "platform.h"

typedef struct
{
	unsigned char SYNCHAR1, SYNCHAR2;
	unsigned char CLASS, ID;
	unsigned short LENGTH;
	unsigned char* pPayload;
	unsigned char CK_A, CK_B;
}UBXStrcutureDef;

typedef struct
{
	unsigned char  numSV;//������Ŀ
	int lon;      //���� 1e-7
	int lat;      //γ�� 1e-7
	int height;      //�������߶� mm
	int hMSL;     //��ƽ��߶� mm
	unsigned short year;
	unsigned char month;
	unsigned char day;
	unsigned char hour;
	unsigned char min;
	unsigned char sec;
	unsigned char fixType;//ȫ�����ǵ���ϵͳ 0x00 = No Fix 0x01 = Dead Reckoning only 0x02 = 2D-Fix 0x03 = 3D-Fix 0x04 = GNSS + dead reckoning combined 0x05 = Time only fix
	unsigned int hAcc;//ˮƽ���ȹ��� mm
	unsigned int vAcc;//��ֱ���ȹ��� mm
	int velN;//���ٶ� mm/s
	int velE;//���ٶ� mm/s
	int velD;//�����ٶ� mm/s
	unsigned int sAcc;//�ٶȾ��ȹ��� mm/s
}GPS_DATA_RAW;

typedef struct
{
//	unsigned char svId;  //��������
	unsigned char cno;   //�����
//	int flags;           //��־
}SATELLITE_DATA;

typedef struct
{
	unsigned char  numSV;		//������Ŀ
	SATELLITE_DATA slmsg[32];
}GPS_DATA_NAV;

typedef enum
{
	portable =  0,
	stationary = 2,
	pedestrian = 3,
	automotive = 4,
	sea        = 5,
	lessThan1G = 6,
	lessThan2G = 7,
	lessThan4G = 8
}DYN_MODEL;

typedef enum
{
	GPS_UART_INTERRUPT_DISABLE = 0,
	GPS_UART_INTERRUPT_ENABLE =  1
}GPS_INTERRUPT;

typedef enum
{
	GPS_UART_TX_DISABLE = 0,
	GPS_UART_TX_ENABLE =  1
}GPS_UART_TX;

typedef enum
{
	GPS_UART_RX_DISABLE = 0,
	GPS_UART_RX_ENABLE =  1
}GPS_UART_RX;

typedef enum
{
	UBLOX_M8Q_IOCTRL_UBX_REC_FLAG_READ = 0,
	UBLOX_M8Q_IOCTRL_GPS_INIT_FLAG_READ = 1,
	UBLOX_M8Q_IOCTRL_GPS_INIT_NAV_WRITE =2,
	UBLOX_M8Q_IOCTRL_GPS_NAV_FLAG_READ = 3,
	UBLOX_M8Q_IOCTRL_GPS_NAV_DATA_GET = 4
}GPS_IOCTRL;

unsigned int ublox_m8q_getID(void);
unsigned int ublox_m8q_register(void);

#endif
