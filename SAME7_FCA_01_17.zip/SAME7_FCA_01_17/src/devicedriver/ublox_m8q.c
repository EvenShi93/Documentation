#include "ublox_m8q.h"
#include "delay.h"
#include "device.h"
#include "driver.h"

unsigned char ubloxM8UartDmaChannel = 6;
static unsigned char ubloxM8UartDmaTxFlag = 1;

static UBXStrcutureDef gps_send;
static UBXStrcutureDef gps_rec;
static GPS_DATA_RAW gpsDataRaw;
static GPS_DATA_NAV gpsDataNav;
static unsigned char gps_set_flag = 0;
static unsigned char gps_ubx_nav_flag = 0;
static unsigned char ublox_m8q_ubx_set_flag = 0;
static unsigned char ublox_m8q_gps_data_rec_flag = 0;
static unsigned char sendBuffer[48] = {0};
static unsigned char recBuffer[410] = {0};

static unsigned int  ubloxM8qID = 0;

static int ublox_m8q_read(void* buffer,unsigned int len);
static int ublox_m8q_ioctrl(unsigned char cmd,void* arg);
static void ublox_m8q_uart_port_init(void);
static void ublox_m8q_uart_set_baudrate(unsigned int baudrate);
static void ublox_m8q_uart_interrupt(unsigned char interruptEnable);
static void ublox_m8q_uart_tx_enable(unsigned char enable);
static void ublox_m8q_uart_rx_enable(unsigned char enable);
static void ublox_m8q_uart_send_byte(unsigned char data);
static int ublox_m8q_init(void);
static void ubloxM8qUartDMAInit(void);
static void ublox_m8q_uart_send(UBXStrcutureDef* pgsp);
static unsigned char ublox_m8q_ubx_set(void);
static void ublox_m8q_ubx_send(void);
//static void ublox_m8q_ubx_get_cfg_SBAS(void);
static unsigned char  ublox_m8q_ubx_nav_engine_set(unsigned char dynModel);
static unsigned char  ublox_m8q_ubx_pvt_set(void);
static unsigned char  ublox_m8q_ubx_Rate_set(unsigned char freq,unsigned char navRate,unsigned char timeRef);
//static unsigned char ublox_m8q_PMS_send_1(void);
//static unsigned char ublox_m8q_PMS_send_2(void);
static void ublox_m8q_chksum(UBXStrcutureDef* pgsp);
static unsigned char ublox_m8q_chkSumVerify(UBXStrcutureDef* UBXStructure);
static unsigned char gps_ubx_nav_send(void);

static DEV ubloxM8q={
	.name = "UBLOX_M8Q",
	.devDrv={
		.init =  ublox_m8q_init,
		.read =  ublox_m8q_read,
		.ioctrl = ublox_m8q_ioctrl
	}
};

unsigned int ublox_m8q_getID(void)
{
	return ubloxM8qID;
}
unsigned int ublox_m8q_register(void)
{
	ubloxM8qID = register_driver(&ubloxM8q.devDrv);
	return  ubloxM8qID;
}

static int ublox_m8q_init(void)
{
	ublox_m8q_uart_port_init();
	gps_send.pPayload = sendBuffer;
	gps_rec.pPayload = recBuffer;

	if(ublox_m8q_ubx_set()==1)
	{
		if(ublox_m8q_ubx_Rate_set(10,1,0) == 1)
		{
			gps_set_flag = ublox_m8q_ubx_nav_engine_set(lessThan2G) && ublox_m8q_ubx_pvt_set();
//			ublox_m8q_PMS_send_1();
//			ublox_m8q_PMS_send_2();
			ubloxM8qUartDMAInit();
		}
		else
		{
			gps_set_flag = 0;
		}
	}
	else
	{
		gps_set_flag = 0;
	}
	return  gps_set_flag;
}

static int ublox_m8q_read(void* buffer,unsigned int len)
{
	 if(ublox_m8q_gps_data_rec_flag == 1)//&&len==0&&gps_rec.ID == 0x07
	 {
		  GPS_DATA_RAW* pBuffer = buffer;
		 *pBuffer = gpsDataRaw;
		  ublox_m8q_gps_data_rec_flag = 0;
		  return 1;
	 }
//	 else if(ublox_m8q_gps_data_rec_flag == 1)//&&len==1&&gps_rec.ID == 0x35
//	 {
//		  GPS_DATA_NAV* pBuffer = buffer;
//		 *pBuffer = gpsDataNav;
//		  ublox_m8q_gps_data_rec_flag = 0;
//		  return 1;
//	 }
	 else
	 {
		  return 0;
	 }
}

static int ublox_m8q_ioctrl(unsigned char cmd, void* arg)
{
	switch(cmd)
	{
		case UBLOX_M8Q_IOCTRL_UBX_REC_FLAG_READ:
		{
			unsigned char* pBuffer = arg;
		   *pBuffer = ublox_m8q_gps_data_rec_flag;
		}
		break;
		case UBLOX_M8Q_IOCTRL_GPS_INIT_FLAG_READ:
		{
			unsigned char* pBuffer = arg;
		   *pBuffer = gps_set_flag;
		}
		break;
		case UBLOX_M8Q_IOCTRL_GPS_NAV_FLAG_READ:
		{
			unsigned char* pBuffer = arg;
		   *pBuffer = gps_ubx_nav_flag;
		}
		break;
		case UBLOX_M8Q_IOCTRL_GPS_INIT_NAV_WRITE:
			gps_ubx_nav_send();
		break;
		case UBLOX_M8Q_IOCTRL_GPS_NAV_DATA_GET:
			*(GPS_DATA_NAV *)arg = gpsDataNav;
		break;
		default:
		break;	
	}
	return 1;
}

// ublox_m8q_uart 设置函数
static void ublox_m8q_uart_port_init(void)
{
	Pin PIN_UART4_TX = {PIO_PD19C_UTXD4, PIOD, ID_PIOD, PIO_PERIPH_C, PIO_DEFAULT}; 
	Pin PIN_UART4_RX = {PIO_PD18C_URXD4, PIOD, ID_PIOD, PIO_PERIPH_C, PIO_DEFAULT}; 

	PMC_EnablePeripheral(ID_UART4);
	PIO_Configure(&PIN_UART4_TX,1);
	PIO_Configure(&PIN_UART4_RX,1);
}

static void ubloxM8qUartDMAInit(void)
{
//	UART_Configure(UART4, (UART_MR_PAR_NO | UART_MR_BRSRCCK_PERIPH_CLK | UART_MR_CHMODE_NORMAL), 115200, MCK);

//	UART_SetReceiverEnabled(UART4, 1);
//	UART_SetTransmitterEnabled(UART4, 1);

//	NVIC_ClearPendingIRQ(UART4_IRQn);
//	NVIC_SetPriority(UART4_IRQn, 12);

//	UART_EnableIt(UART4, UART_IER_RXRDY);
//	NVIC_EnableIRQ(UART4_IRQn);

	PMC_EnablePeripheral(ID_XDMAC);

	/* Clear dummy status */
	XDMAC_GetChannelIsr(XDMAC, ubloxM8UartDmaChannel);
	/* Disables XDMAC interrupt for the given channel. */
	XDMAC_DisableGIt (XDMAC, ubloxM8UartDmaChannel);
	XDMAC_DisableChannelIt (XDMAC, ubloxM8UartDmaChannel, 0xFF);
	/* Disable the given dma channel. */
	XDMAC_DisableChannel(XDMAC, ubloxM8UartDmaChannel);

	XDMAC_SetChannelConfig(XDMAC, ubloxM8UartDmaChannel, XDMAC_CC_TYPE_PER_TRAN		|
														XDMAC_CC_DSYNC_MEM2PER		|
														XDMAC_CC_MBSIZE_SINGLE		|
														XDMAC_CC_PROT_SEC			|
														XDMAC_CC_MEMSET_NORMAL_MODE	|
														XDMAC_CC_CSIZE_CHK_1		|
														XDMAC_CC_DWIDTH_BYTE		|
														XDMAC_CC_SIF_AHB_IF0		|
														XDMAC_CC_DIF_AHB_IF1		|
														XDMAC_CC_SAM_INCREMENTED_AM	|
														XDMAC_CC_DAM_FIXED_AM		|
														XDMAC_CC_PERID(28)			);

	XDMAC_SetMicroblockControl(XDMAC, ubloxM8UartDmaChannel, 12);
	XDMAC_SetSourceAddr(XDMAC, ubloxM8UartDmaChannel, (unsigned int)0);
	XDMAC_SetDestinationAddr(XDMAC, ubloxM8UartDmaChannel, (unsigned int)&(UART4->UART_THR));
	XDMAC_SetDescriptorControl(XDMAC, ubloxM8UartDmaChannel, 0);
	XDMAC_SetBlockControl(XDMAC, ubloxM8UartDmaChannel, 0);
	XDMAC_SetDataStride_MemPattern(XDMAC, ubloxM8UartDmaChannel, 0);
	XDMAC_SetSourceMicroBlockStride(XDMAC, ubloxM8UartDmaChannel, 0);
	XDMAC_SetDestinationMicroBlockStride(XDMAC, ubloxM8UartDmaChannel, 0);

	/*Enable xDMA interrupt */ 
	NVIC_ClearPendingIRQ(XDMAC_IRQn);
	NVIC_SetPriority(XDMAC_IRQn, 9);
	NVIC_EnableIRQ(XDMAC_IRQn);

	XDMAC_EnableChannelIt (XDMAC, ubloxM8UartDmaChannel, XDMAC_CIE_BIE);
	XDMAC_EnableGIt (XDMAC, ubloxM8UartDmaChannel);
}

void ubloxM8_UartDmaIrq(void)
{
	ubloxM8UartDmaTxFlag = 1;
}

static void ubloxM8_uart_send_nbyte(unsigned char *pBuffer, unsigned int len)
{
	while(ubloxM8UartDmaTxFlag == 0){}
	ubloxM8UartDmaTxFlag = 0;
	XDMAC_SetMicroblockControl(XDMAC, ubloxM8UartDmaChannel, len);
	XDMAC_SetSourceAddr(XDMAC, ubloxM8UartDmaChannel, (unsigned int)pBuffer);
	XDMAC_SetDestinationAddr(XDMAC, ubloxM8UartDmaChannel, (unsigned int)&(UART4->UART_THR));
	SCB_CleanInvalidateDCache();
	XDMAC_EnableChannel(XDMAC, ubloxM8UartDmaChannel);
}

static void ublox_m8q_uart_set_baudrate(unsigned int baudrate)
{
	UART_Configure(UART4, ( UART_MR_PAR_NO | UART_MR_BRSRCCK_PERIPH_CLK | UART_MR_CHMODE_NORMAL ),baudrate, MCK);
}

static void ublox_m8q_uart_interrupt(unsigned char interruptEnable)
{
	if(interruptEnable == GPS_UART_INTERRUPT_ENABLE)
	{
		NVIC_ClearPendingIRQ(UART4_IRQn);
		NVIC_SetPriority(UART4_IRQn, 4);

		UART_EnableIt(UART4,UART_IER_RXRDY);

		NVIC_EnableIRQ(UART4_IRQn);
	}
	else
	{
		NVIC_ClearPendingIRQ(UART4_IRQn);
		NVIC_SetPriority(UART4_IRQn,4);	
		UART_DisableIt(UART4,UART_IER_RXRDY);
		NVIC_DisableIRQ(UART4_IRQn);
	}
}

static void ublox_m8q_uart_tx_enable(unsigned char enable)
{
	UART_SetTransmitterEnabled (UART4,enable);
}

static void ublox_m8q_uart_rx_enable(unsigned char enable)
{
	UART_SetReceiverEnabled (UART4,enable);
}

static void ublox_m8q_uart_send_byte(unsigned char data)
{
	UART_PutChar(UART4,data);
}

//static uint8_t ublox_m8q_PMS_flag_1 = 0;
//static unsigned char ublox_m8q_PMS_send_1(void)//PMS
//{
//	uint8_t MaxTrial = 5;
//	gps_send.SYNCHAR1 = 0xb5;
//	gps_send.SYNCHAR2 = 0x62;
//	gps_send.CLASS   = 0x06;
//	gps_send.ID      = 0x86;
//	gps_send.LENGTH  = 0x08;

//	gps_send.pPayload[0] = 0x00;
//	gps_send.pPayload[1] = 0x00;
//	gps_send.pPayload[2] = 0x00;
//	gps_send.pPayload[3] = 0x00;
//	gps_send.pPayload[4] = 0x00;
//	gps_send.pPayload[5] = 0x00;
//	gps_send.pPayload[6] = 0x00;
//	gps_send.pPayload[7] = 0x00;
//	ublox_m8q_chksum(&gps_send);
////	ublox_m8q_uart_send(&gps_send);
//	while(MaxTrial --)
//	{
//		ublox_m8q_uart_send(&gps_send);
//		delay_ms(2);
//		if(ublox_m8q_PMS_flag_1 == 1)
//			return 1;
//		else if(MaxTrial == 0)
//			return 0;
//	}
//	return 0;
//}

//static uint8_t ublox_m8q_PMS_flag_2 = 0;
//static unsigned char ublox_m8q_PMS_send_2(void)
//{
//	uint8_t MaxTrial = 5;
//	gps_send.SYNCHAR1 = 0xb5;
//	gps_send.SYNCHAR2 = 0x62;
//	gps_send.CLASS   = 0x06;
//	gps_send.ID      = 0x09;
//	gps_send.LENGTH  = 0x0D;

//	gps_send.pPayload[0] = 0x00;
//	gps_send.pPayload[1] = 0x00;
//	gps_send.pPayload[2] = 0x00;
//	gps_send.pPayload[3] = 0x00;
//	gps_send.pPayload[4] = 0xFF;
//	gps_send.pPayload[5] = 0xFF;
//	gps_send.pPayload[6] = 0x00;
//	gps_send.pPayload[7] = 0x00;
//	gps_send.pPayload[8] = 0x00;
//	gps_send.pPayload[9] = 0x00;
//	gps_send.pPayload[10] = 0x00;
//	gps_send.pPayload[11] = 0x00;
//	gps_send.pPayload[12] = 0x07;
//	ublox_m8q_chksum(&gps_send);
////	ublox_m8q_uart_send(&gps_send);

//	while(MaxTrial --)
//	{
//		ublox_m8q_uart_send(&gps_send);
//		delay_ms(2);
//		if(ublox_m8q_PMS_flag_2 == 1)
//			return 1;
//		else if(MaxTrial == 0)
//			return 0;
//	}
//	return 0;
//}

static void ublox_m8q_ubx_send(void)
{
	gps_send.SYNCHAR1 = 0xb5;
	gps_send.SYNCHAR2 = 0x62;
	gps_send.CLASS   = 0x06;
	gps_send.ID      = 0x00;
	gps_send.LENGTH  = 0x14;

	gps_send.pPayload[0] = 0x01;
	gps_send.pPayload[1] = 0x00;
	gps_send.pPayload[2] = 0x00;
	gps_send.pPayload[3] = 0x00;
	gps_send.pPayload[4] = 0xD0;
	gps_send.pPayload[5] = 0x08;
	gps_send.pPayload[6] = 0x00;
	gps_send.pPayload[7] = 0x00;
	gps_send.pPayload[8] = 0x00;
	gps_send.pPayload[9] = 0xc2;
	gps_send.pPayload[10] = 0x01;
	gps_send.pPayload[11] = 0x00;
	gps_send.pPayload[12] = 0x01;
	gps_send.pPayload[13] = 0x00;
	gps_send.pPayload[14] = 0x01;
	gps_send.pPayload[15] = 0x00;
	gps_send.pPayload[16] = 0x00;
	gps_send.pPayload[17] = 0x00;
	gps_send.pPayload[18] = 0x00;
	gps_send.pPayload[19] = 0x00;
	
	ublox_m8q_chksum(&gps_send);
	ublox_m8q_uart_send(&gps_send);
}

static unsigned char ublox_m8q_ubx_set(void)
{
	uint8_t MaxTrial = 5;
	while(MaxTrial --)
	{
		ublox_m8q_uart_set_baudrate(9600);
		ublox_m8q_uart_tx_enable(GPS_UART_TX_ENABLE);
		ublox_m8q_uart_rx_enable(GPS_UART_RX_DISABLE);
		ublox_m8q_uart_interrupt(GPS_UART_INTERRUPT_DISABLE);
		delay_ms(2);
		ublox_m8q_ubx_send();
		delay_ms(2);
		ublox_m8q_uart_tx_enable(GPS_UART_TX_DISABLE);
		ublox_m8q_uart_set_baudrate(115200);
		ublox_m8q_uart_tx_enable(GPS_UART_TX_ENABLE);
		ublox_m8q_uart_rx_enable(GPS_UART_RX_ENABLE);
		ublox_m8q_uart_interrupt(GPS_UART_INTERRUPT_ENABLE);

		ublox_m8q_ubx_send();
		delay_ms(2);
		if(ublox_m8q_ubx_set_flag)
			return 1;
		else
		{
			ublox_m8q_ubx_send();
			delay_ms(2);
			if(ublox_m8q_ubx_set_flag)
				return 1;
			else if(MaxTrial != 0)
			{
				ublox_m8q_uart_tx_enable(GPS_UART_TX_DISABLE);
				ublox_m8q_uart_rx_enable(GPS_UART_RX_DISABLE);
				ublox_m8q_uart_interrupt(GPS_UART_INTERRUPT_DISABLE);
			}
		}
	}
	return 0;
}
//	unsigned char test_count = 0;
//	while(1)
//	{
//		ublox_m8q_uart_set_baudrate(9600);
//		ublox_m8q_uart_tx_enable(GPS_UART_TX_ENABLE);
//		ublox_m8q_uart_rx_enable(GPS_UART_RX_DISABLE);
//		ublox_m8q_uart_interrupt(GPS_UART_INTERRUPT_DISABLE);
//		delay_ms(2);
//		ublox_m8q_ubx_send();
//		delay_ms(2);
//		ublox_m8q_ubx_send();
//		delay_ms(2);
//		ublox_m8q_ubx_send();
//		delay_ms(2);
//		ublox_m8q_uart_tx_enable(GPS_UART_TX_DISABLE);
//		ublox_m8q_uart_rx_enable(GPS_UART_RX_DISABLE);
//		delay_ms(2);
//		ublox_m8q_uart_set_baudrate(115200);
//		ublox_m8q_uart_tx_enable(GPS_UART_TX_ENABLE);
//		ublox_m8q_uart_rx_enable(GPS_UART_RX_ENABLE);
//		ublox_m8q_uart_interrupt(GPS_UART_INTERRUPT_ENABLE);
//		delay_ms(2);
//		ublox_m8q_ubx_send();
//		delay_ms(2);
//		ublox_m8q_ubx_send();
//		delay_ms(2);
//		if(ublox_m8q_ubx_set_flag)
//		{
//			return 1;
//		}
//		else
//		{
////			ublox_m8q_uart_tx_enable(GPS_UART_TX_DISABLE);
////			ublox_m8q_uart_rx_enable(GPS_UART_RX_DISABLE);
////			delay_ms(2);
////			ublox_m8q_uart_interrupt(GPS_UART_INTERRUPT_DISABLE);
////			test_count++;
////			if(test_count == 20)
////			{
//				return 0;
////			}
//		}
//	}


//static void ublox_m8q_ubx_get_cfg_SBAS(void)
//{
//	gps_send.SYNCHAR1 = 0xb5;
//	gps_send.SYNCHAR2 = 0x62;
//	gps_send.CLASS   = 0x06;
//	gps_send.ID      = 0x16;
//	gps_send.LENGTH  = 0x00;
//	
//	ublox_m8q_chksum(&gps_send);
//	ublox_m8q_uart_send(&gps_send);
//}

static unsigned char ublox_m8q_ubx_set_nav_engine_flag = 0;
static unsigned char ublox_m8q_ubx_nav_engine_set(unsigned char dynModel)
{
	unsigned char MaxTrial = 5;
	ublox_m8q_ubx_set_nav_engine_flag = 0;
	gps_send.SYNCHAR1 = 0xb5;
	gps_send.SYNCHAR2 = 0x62;
	gps_send.CLASS   = 0x06;
	gps_send.ID      = 0x24;
	gps_send.LENGTH  = 0x24;

	gps_send.pPayload[0] = 0xff;
	gps_send.pPayload[1] = 0xff;
	gps_send.pPayload[2] = dynModel;
	gps_send.pPayload[3] = 0x02; //3d only
	gps_send.pPayload[4] = 0x00;
	gps_send.pPayload[5] = 0x00;
	gps_send.pPayload[6] = 0x00;
	gps_send.pPayload[7] = 0x00;
	gps_send.pPayload[8] = 0x10;
	gps_send.pPayload[9] = 0x27;
	gps_send.pPayload[10] = 0x00;
	gps_send.pPayload[11] = 0x00;
	gps_send.pPayload[12] = 0x05;
	gps_send.pPayload[13] = 0x00;
	gps_send.pPayload[14] = 0xfa;
	gps_send.pPayload[15] = 0x00;
	gps_send.pPayload[16] = 0xfa;
	gps_send.pPayload[17] = 0x00;
	gps_send.pPayload[18] = 0x64;
	gps_send.pPayload[19] = 0x00;
	gps_send.pPayload[20] = 0x2c;
	gps_send.pPayload[21] = 0x01;
	gps_send.pPayload[22] = 0x00;
	gps_send.pPayload[23] = 0x3c;
	gps_send.pPayload[24] = 0x00;
	gps_send.pPayload[25] = 0x00;
	gps_send.pPayload[26] = 0x00;
	gps_send.pPayload[27] = 0x00;
	gps_send.pPayload[28] = 0xc8;
	gps_send.pPayload[29] = 0x00;
	gps_send.pPayload[30] = 0x00;
	gps_send.pPayload[31] = 0x00;
	gps_send.pPayload[32] = 0x00;
	gps_send.pPayload[33] = 0x00;
	gps_send.pPayload[34] = 0x00;
	gps_send.pPayload[35] = 0x00;

	ublox_m8q_chksum(&gps_send);

	while(MaxTrial --)
	{
		ublox_m8q_uart_send(&gps_send);
		delay_ms(2);
		if(ublox_m8q_ubx_set_nav_engine_flag == 1)
			return 1;
		else if(MaxTrial == 0)
			return 0;
	}
	return 0;
}

static unsigned char ublox_m8q_ubx_pvt_flag = 0;
static unsigned char ublox_m8q_ubx_pvt_set(void)
{
	unsigned char MaxTrial = 5;
	gps_send.SYNCHAR1 = 0xb5;
	gps_send.SYNCHAR2 = 0x62;
	gps_send.CLASS   = 0x06;
	gps_send.ID      = 0x01;
	gps_send.LENGTH  = 0x03;

	gps_send.pPayload[0] = 0x01;
	gps_send.pPayload[1] = 0x07;
	gps_send.pPayload[2] = 0x01;

	ublox_m8q_chksum(&gps_send);
	while(MaxTrial --)
	{
		ublox_m8q_uart_send(&gps_send);
		delay_ms(2);
		if(ublox_m8q_ubx_pvt_flag == 1)
			return 1;
		else if(MaxTrial == 0)
			return 0;
	}
	return 0;
}

static unsigned char gps_ubx_nav_send(void)
{
	uint8_t Temp[11];
	Temp[0] = gps_send.SYNCHAR1 = 0xb5;
	Temp[1] = gps_send.SYNCHAR2 = 0x62;
	Temp[2] = gps_send.CLASS    = 0x06;
	Temp[3] = gps_send.ID       = 0x01;
	Temp[4] = gps_send.LENGTH   = 0x03;
	Temp[5] = 0;

	Temp[6] = gps_send.pPayload[0] = 0x01;
	Temp[7] = gps_send.pPayload[1] = 0x35;
	Temp[8] = gps_send.pPayload[2] = 0x0A;

	ublox_m8q_chksum(&gps_send);
	Temp[9] = gps_send.CK_A;
	Temp[10] = gps_send.CK_B;

	ubloxM8_uart_send_nbyte(Temp, 11);
//	ublox_m8q_uart_send(&gps_send);

	return 0;
}

static unsigned char ublox_m8q_ubx_Rate_flag = 0;
static unsigned char ublox_m8q_ubx_Rate_set(unsigned char freq, unsigned char navRate, unsigned char timeRef)
{
	unsigned char MaxTrial = 5;
	unsigned int time_interval = 1000/freq;
	gps_send.SYNCHAR1 = 0xb5;
	gps_send.SYNCHAR2 = 0x62;
	gps_send.CLASS   = 0x06;
	gps_send.ID      = 0x08;
	gps_send.LENGTH  = 0x06;

	gps_send.pPayload[0] = time_interval&0xff;
	gps_send.pPayload[1] = (time_interval>>8)&0xff;
	gps_send.pPayload[2] = navRate&0xff;
	gps_send.pPayload[3] = (navRate>>8)&0xff;
	gps_send.pPayload[4] = timeRef&0xff;
	gps_send.pPayload[5] = (timeRef>>8)&0xff;

	ublox_m8q_chksum(&gps_send);
	while(MaxTrial --)
	{
		ublox_m8q_uart_send(&gps_send);
		delay_ms(2);
		if(ublox_m8q_ubx_Rate_flag == 1)
			return 1;
		else if(MaxTrial == 0)
			return 0;
	}
	return 0;
}

static void ublox_m8q_uart_send(UBXStrcutureDef* pgsp)
{
	unsigned short count = 0;
	ublox_m8q_uart_send_byte(pgsp->SYNCHAR1);
	ublox_m8q_uart_send_byte(pgsp->SYNCHAR2);
	ublox_m8q_uart_send_byte(pgsp->CLASS);
	ublox_m8q_uart_send_byte(pgsp->ID);
	ublox_m8q_uart_send_byte(pgsp->LENGTH&0xff);
	ublox_m8q_uart_send_byte(pgsp->LENGTH>>8);
	for(count = 0; count < (pgsp->LENGTH); count ++)
	{
		ublox_m8q_uart_send_byte(pgsp->pPayload[count]);
	}
	ublox_m8q_uart_send_byte(pgsp->CK_A);
	ublox_m8q_uart_send_byte(pgsp->CK_B);
}

//static void ublox_m8q_uart_send(UBXStrcutureDef* pgsp)
//{
////	unsigned char *Temp = (unsigned char *)pgsp;
////	ubloxM8_uart_send_nbyte((unsigned char *)pgsp, 6);
////	ubloxM8_uart_send_nbyte(sendBuffer, pgsp->LENGTH);
//	unsigned char Temp[56];
//	unsigned short count = 0;
//	Temp[0] = pgsp->SYNCHAR1;
//	Temp[1] = (pgsp->SYNCHAR2);
//	Temp[2] = (pgsp->CLASS);
//	Temp[3] = (pgsp->ID);
//	Temp[4] = (pgsp->LENGTH&0xff);
//	Temp[5] = (pgsp->LENGTH>>8);
//	for(count = 0; count < (pgsp->LENGTH); count ++)
//	{
//		Temp[6 + count] = (pgsp->pPayload[count]);
//	}
//	Temp[6 + count] = (pgsp->CK_A);
//	Temp[7 + count] = (pgsp->CK_B);
//	ubloxM8_uart_send_nbyte(Temp, pgsp->LENGTH + 8);

////	ubloxM8_uart_send_nbyte((unsigned char *)&(pgsp->CK_A), 2);
//}

static void ublox_m8q_chksum(UBXStrcutureDef* pgsp)
{
	unsigned short count = 0;
	pgsp->CK_A = 0;
	pgsp->CK_B = 0;
	pgsp->CK_A += pgsp->CLASS; pgsp->CK_B += pgsp->CK_A;
	pgsp->CK_A += pgsp->ID; pgsp->CK_B += pgsp->CK_A;
	pgsp->CK_A += pgsp->LENGTH & 0xFF; pgsp->CK_B += pgsp->CK_A;
	pgsp->CK_A += (pgsp->LENGTH >> 8) & 0xFF; pgsp->CK_B += pgsp->CK_A;

	for(count = 0; count < (pgsp->LENGTH); count ++)
	{
		pgsp->CK_A += (pgsp->pPayload)[count];
		pgsp->CK_B += pgsp->CK_A;
	}
}

static unsigned char ublox_m8q_chkSumVerify(UBXStrcutureDef* UBXStructure)
{
	unsigned char Chk_A = 0, Chk_B = 0;
	uint16_t Cnt = 0;
	uint16_t Leng = UBXStructure->LENGTH;

	Chk_A += UBXStructure->CLASS; Chk_B += Chk_A;
	Chk_A += UBXStructure->ID; Chk_B += Chk_A;
	Chk_A += Leng & 0xFF; Chk_B += Chk_A;
	Chk_A += (Leng >> 8) & 0xFF; Chk_B += Chk_A;

	for(Cnt = 0; Cnt < (UBXStructure->LENGTH); Cnt ++)
	{
		Chk_A += (UBXStructure->pPayload)[Cnt];
		Chk_B += Chk_A;
	}
	if((Chk_A == UBXStructure->CK_A) && (Chk_B == UBXStructure->CK_B))
		return 1;
	else
		return 0;
}

void ublox_m8q_uart_rx_irq(unsigned char data)
{
	static unsigned char gps_step = 0;
	static unsigned short count = 0;

	switch(gps_step)
	{
		case 0:
			if(data == 0xb5)
			{
				gps_rec.SYNCHAR1 = data;
				gps_step ++;
			}
		break;
		case 1:
			if(data == 0x62)
			{
				gps_rec.SYNCHAR2 = data;
				gps_step ++;
			}
			else
				gps_step = 0;
		break;
		case 2:
			gps_rec.CLASS = data;
			gps_step = 3;
		break;
		case 3:
			gps_rec.ID = data;
			gps_step = 4;
		break;
		case 4:
			gps_rec.LENGTH = data;
			gps_step = 5;
		break;
		case 5:
			gps_rec.LENGTH += ((unsigned short)data) << 8;
			if(gps_rec.LENGTH > 400)
				gps_step = 0;
			else
				gps_step = 6;
			count = 0;
		break;
		case 6:
			gps_rec.pPayload[count] = data;
			count ++;
			if(count == gps_rec.LENGTH)
			{
				count = 0;
				gps_step = 7;
			}
		break;
		case 7:
			gps_rec.CK_A = data;
			gps_step = 8;
		break;
		case 8:
			gps_rec.CK_B = data;
			if(ublox_m8q_chkSumVerify(&gps_rec))
			{
				if((gps_rec.CLASS == 0x05) &&(gps_rec.ID == 0x01)&&(gps_rec.pPayload[0] == 0x06)&&(gps_rec.pPayload[1] == 0x00))
				{
					ublox_m8q_ubx_set_flag = 1;
				}
				else if((gps_rec.CLASS == 0x05) &&(gps_rec.ID == 0x01)&&(gps_rec.pPayload[0] == 0x06)&&(gps_rec.pPayload[1] == 0x01))
				{
					ublox_m8q_ubx_pvt_flag = 1;
				}
				else if((gps_rec.CLASS == 0x05) &&(gps_rec.ID == 0x01)&&(gps_rec.pPayload[0] == 0x06)&&(gps_rec.pPayload[1] == 0x08))
				{
					ublox_m8q_ubx_Rate_flag = 1;
				}
				else if((gps_rec.CLASS == 0x05) &&(gps_rec.ID == 0x01)&&(gps_rec.pPayload[0] == 0x06)&&(gps_rec.pPayload[1] == 0x24))
				{
					ublox_m8q_ubx_set_nav_engine_flag = 1;
				}
//				else if((gps_rec.CLASS == 0x05) &&(gps_rec.ID == 0x01)&&(gps_rec.pPayload[0] == 0x06)&&(gps_rec.pPayload[1] == 0x86))
//				{
//					ublox_m8q_PMS_flag_1 = 1;
//				}
//				else if((gps_rec.CLASS == 0x05) &&(gps_rec.ID == 0x01)&&(gps_rec.pPayload[0] == 0x06)&&(gps_rec.pPayload[1] == 0x09))
//				{
//					ublox_m8q_PMS_flag_2 = 1;
//				}
				else if(gps_rec.ID == 0x35 && gps_rec.CLASS == 0x01)
				{
					gps_ubx_nav_flag = 1;
					gpsDataNav.numSV = gps_rec.pPayload[5];//获取卫星数量
					if(gpsDataNav.numSV > 32) gpsDataNav.numSV = 32;//限制卫星数目
					for(uint8_t SVCnt = 0; SVCnt < gpsDataNav.numSV; SVCnt ++)//记录每颗卫星的dB值
						gpsDataNav.slmsg[SVCnt].cno = gps_rec.pPayload[10 + 12 * SVCnt];
				}
				else if((gps_rec.CLASS == 0x01) &&(gps_rec.ID == 0x07))
				{
					int temp = 0;
					unsigned int temp1 = 0;

					gpsDataRaw.numSV = gps_rec.pPayload[23];

					temp = gps_rec.pPayload[27]; temp <<= 8;
					temp |= gps_rec.pPayload[26]; temp <<= 8;
					temp |= gps_rec.pPayload[25]; temp <<= 8;
					temp |= gps_rec.pPayload[24];
					gpsDataRaw.lon = temp;

					temp = gps_rec.pPayload[31]; temp <<= 8;
					temp |= gps_rec.pPayload[30]; temp <<= 8;
					temp |= gps_rec.pPayload[29]; temp <<= 8;
					temp |= gps_rec.pPayload[28];
					gpsDataRaw.lat = temp;

					temp = gps_rec.pPayload[35]; temp <<= 8;
					temp |= gps_rec.pPayload[34]; temp <<= 8;
					temp |= gps_rec.pPayload[33]; temp <<= 8;
					temp |= gps_rec.pPayload[32];
					gpsDataRaw.height = temp;

					temp = gps_rec.pPayload[39]; temp <<= 8;
					temp |= gps_rec.pPayload[38]; temp <<= 8;
					temp |= gps_rec.pPayload[37]; temp <<= 8;
					temp |= gps_rec.pPayload[36];
					gpsDataRaw.hMSL = temp;

					temp = gps_rec.pPayload[5]; temp <<= 8;
					temp |= gps_rec.pPayload[4];
					gpsDataRaw.year = temp;

					gpsDataRaw.month = gps_rec.pPayload[6];
					gpsDataRaw.day = gps_rec.pPayload[7];
					gpsDataRaw.hour = gps_rec.pPayload[8];
					gpsDataRaw.min = gps_rec.pPayload[9];
					gpsDataRaw.sec = gps_rec.pPayload[10];
					gpsDataRaw.fixType = gps_rec.pPayload[20];

					temp1 = gps_rec.pPayload[43]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[42]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[41]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[40];
					gpsDataRaw.hAcc = temp1;

					temp1 = gps_rec.pPayload[47]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[46]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[45]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[44];
					gpsDataRaw.vAcc = temp1;

					temp = gps_rec.pPayload[51]; temp <<= 8;
					temp |= gps_rec.pPayload[50]; temp <<= 8;
					temp |= gps_rec.pPayload[49]; temp <<= 8;
					temp |= gps_rec.pPayload[48];
					gpsDataRaw.velN = temp;

					temp = gps_rec.pPayload[55]; temp <<= 8;
					temp |= gps_rec.pPayload[54]; temp <<= 8;
					temp |= gps_rec.pPayload[53]; temp <<= 8;
					temp |= gps_rec.pPayload[52];
					gpsDataRaw.velE = temp;

					temp = gps_rec.pPayload[59]; temp <<= 8;
					temp |= gps_rec.pPayload[58]; temp <<= 8;
					temp |= gps_rec.pPayload[57]; temp <<= 8;
					temp |= gps_rec.pPayload[56];
					gpsDataRaw.velD = temp;

					temp1 = gps_rec.pPayload[71]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[70]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[69]; temp1 <<= 8;
					temp1 |= gps_rec.pPayload[68];
					gpsDataRaw.sAcc = temp1;
					ublox_m8q_gps_data_rec_flag = 1;
				}
			}
			gps_step = 0;
		break;
		default:
			gps_step = 0;
		break;
	}
}

/*
 //应用

unsigned char gps_set_flag = 0;
GPS_DATA_RAW gpsData;
unsigned char gps_read_ret = 0;
 ioctrl(ublox_m8q_getID(),UBLOX_M8Q_IOCTRL_GPS_INIT_FLAG_READ,&gps_set_flag);
 if(gps_set_flag == 1)
 {
		OS_ALLOC_SR();
		OS_ENTER_CRITICAL();
		gps_read_ret= read(ublox_m8q_getID(),&gpsData,0);
		OS_EXIT_CRITICAL();

		if(gps_read_ret == 1)
		{
			//使用最新数据
		}
		else
		{
			//使用原先数据	
		}
 }
 
*/
