#include "moto.h"
#include "delay.h"
#include "device.h"
#include "driver.h"
#include "maths.h"

unsigned char motoUsartTxDmaChannel = 2;
static volatile unsigned char motoUsartDmaTx_Done = 1;
static unsigned int  motoID = 0;

ESCBUS_ENUM_ESC_STATUS ESC_Sta[4] = {ESC_STATUS_HEALTHY, ESC_STATUS_HEALTHY, ESC_STATUS_HEALTHY, ESC_STATUS_HEALTHY};

static DEV moto={
	.name = "MOTO",
	.devDrv = {
		.init =  moto_init,
		.write =  moto_write,
		.ioctrl = moto_ioctrl
	}
};

unsigned int moto_getID(void)
{
	return motoID;
}

unsigned int moto_register(void)
{
	motoID = register_driver(&moto.devDrv);
	return  motoID;
}

static void moto_uart_init(void)
{
	Pin PIN_USART0_RXD = {PIO_PB0C_RXD0, PIOB, ID_PIOB, PIO_PERIPH_C, PIO_DEFAULT};
	Pin PIN_USART0_TXD = {PIO_PB1C_TXD0, PIOB, ID_PIOB, PIO_PERIPH_C, PIO_DEFAULT};

	PIO_Configure(&PIN_USART0_RXD, 1);
	PIO_Configure(&PIN_USART0_TXD, 1);

	PMC_EnablePeripheral(ID_USART0);

	//USART_Configure (USART0, US_MR_USART_MODE_NORMAL|US_MR_CHRL_8_BIT|US_MR_PAR_NO|US_MR_NBSTOP_1_BIT, 256000, MCK);
	USART_Configure (USART0, US_MR_USART_MODE_NORMAL|US_MR_CHRL_8_BIT|US_MR_PAR_NO|US_MR_NBSTOP_1_BIT, 250000, MCK);

	USART_SetReceiverEnabled(USART0, ENABLE);
	USART_SetTransmitterEnabled(USART0, ENABLE);

	NVIC_ClearPendingIRQ(USART0_IRQn);
	NVIC_SetPriority(USART0_IRQn, 2);

	USART_EnableIt(USART0, US_IER_RXRDY);
	NVIC_EnableIRQ(USART0_IRQn);

	PMC_EnablePeripheral( ID_XDMAC );

	/* Clear dummy status */
	XDMAC_GetChannelIsr( XDMAC,motoUsartTxDmaChannel );
	/* Disables XDMAC interrupt for the given channel. */
	XDMAC_DisableGIt (XDMAC, motoUsartTxDmaChannel);
	XDMAC_DisableChannelIt (XDMAC, motoUsartTxDmaChannel, 0xFF);
	/* Disable the given dma channel. */
	XDMAC_DisableChannel( XDMAC, motoUsartTxDmaChannel );

	XDMAC_SetChannelConfig( XDMAC, motoUsartTxDmaChannel, XDMAC_CC_TYPE_PER_TRAN
														|XDMAC_CC_DSYNC_MEM2PER
														|XDMAC_CC_MBSIZE_SINGLE
														|XDMAC_CC_PROT_SEC
														|XDMAC_CC_MEMSET_NORMAL_MODE
														|XDMAC_CC_CSIZE_CHK_1
														|XDMAC_CC_DWIDTH_BYTE
														|XDMAC_CC_SIF_AHB_IF0
														|XDMAC_CC_DIF_AHB_IF1
														|XDMAC_CC_SAM_INCREMENTED_AM
														|XDMAC_CC_DAM_FIXED_AM
														|XDMAC_CC_PERID(7)
														);

	XDMAC_SetMicroblockControl(XDMAC, motoUsartTxDmaChannel, 12);
	XDMAC_SetSourceAddr(XDMAC, motoUsartTxDmaChannel, (unsigned int)0);
	XDMAC_SetDestinationAddr(XDMAC, motoUsartTxDmaChannel, (unsigned int)&(USART0->US_THR));
	XDMAC_SetDescriptorControl(XDMAC, motoUsartTxDmaChannel,0);
	XDMAC_SetBlockControl(XDMAC, motoUsartTxDmaChannel,0);
	XDMAC_SetDataStride_MemPattern(XDMAC, motoUsartTxDmaChannel,0);
	XDMAC_SetSourceMicroBlockStride(XDMAC, motoUsartTxDmaChannel,0);
	XDMAC_SetDestinationMicroBlockStride(XDMAC, motoUsartTxDmaChannel,0);

	/*Enable xDMA interrupt */ 
	NVIC_ClearPendingIRQ(XDMAC_IRQn);
	NVIC_SetPriority( XDMAC_IRQn, 8);
	NVIC_EnableIRQ(XDMAC_IRQn);

	XDMAC_EnableChannelIt (XDMAC, motoUsartTxDmaChannel, XDMAC_CIE_BIE);
	XDMAC_EnableGIt (XDMAC, motoUsartTxDmaChannel);
}

void motoUsartTxDmaIrq(void)
{
	motoUsartDmaTx_Done = 1;
}

static void moto_usart_send_nbyte(unsigned char* pBuffer,unsigned int len)
{
	while(motoUsartDmaTx_Done == 0) {}
	motoUsartDmaTx_Done = 0;
	XDMAC_SetMicroblockControl(XDMAC, motoUsartTxDmaChannel, len);
	XDMAC_SetSourceAddr(XDMAC, motoUsartTxDmaChannel, (unsigned int)pBuffer);
	XDMAC_SetDestinationAddr(XDMAC, motoUsartTxDmaChannel, (unsigned int)&(USART0->US_THR));
	SCB_CleanInvalidateDCache();
	XDMAC_EnableChannel(XDMAC,motoUsartTxDmaChannel);
}

static int moto_init(void)
{
	moto_uart_init();
	delay_ms(5);
	return 1;
}

static int moto_write(void* buffer, unsigned int len)
{
	unsigned char* pBuffer = buffer;
	moto_usart_send_nbyte(pBuffer, len);
	return 1;
}

static int moto_ioctrl(unsigned char cmd, void* arg)
{
	switch(cmd)
	{
//		case MOTO_IOCTRL_DIRECT_WTIRE:
//		{
//			//pBuffer[0]写的长度 pBuffer[1]~ pBuffer[n]为数据
//			unsigned char *pBuffer = arg;
//			moto_usart_send_nbyte(pBuffer + 1, pBuffer[0]);
//		}
//		break;
		case MOTO_IOCTRL_GET_ESC_STAT:
			*(uint32_t *)arg = *(uint32_t *)ESC_Sta;
		break;
		default:break;
	}
	return 1;
}

EscBufUnion GetPackage = {0};
void moto_uart_rx_irq(unsigned char Data)
{
	static uint8_t RecDataStep = 0;
	switch(RecDataStep)
	{
		case 0:
			if(Data == 0xFE) RecDataStep ++;
		break;
		case 1:
			if(Data == 0x06)
			{
				RecDataStep ++;
				GetPackage.Array[0] = Data;
			}
			else RecDataStep = 0;
		break;
		case 2:
			if(Data == 0x08)
			{
				RecDataStep ++;
				GetPackage.Array[1] = Data;
			}
			else RecDataStep = 0;
		break;
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
			GetPackage.Array[RecDataStep - 1] = Data;
			RecDataStep ++;
		break;
		case 9:
			if(Data == crcMotoCal(GetPackage.Array, GetPackage.Array[0] + 2))
			{
				if(GetPackage.Array[2] <= 3)
					ESC_Sta[GetPackage.Array[2]] = (ESCBUS_ENUM_ESC_STATUS)GetPackage.Array[3];
			}
			RecDataStep = 0;
		break;
		default :
			RecDataStep = 0;
		break;
	}
}
