//IST8307 driver
#include "IST8307_driver.h"
#include <stdint.h>
#include "delay.h"
#include "device.h"
#include "driver.h"

static int IST8307_Init(void);
static int IST8307_GetXYZ(int16_t *xyz);
static int IST8307_Read(void* buffer, unsigned int len);
static int IST8307_ioctrl(unsigned char cmd, void* arg);

static unsigned int IST8307ID = 0;

static DEV IST8307 = {
	.name = "IST8307",
	.devDrv = {
		.init = IST8307_Init,
		.read = IST8307_Read,
		.ioctrl = IST8307_ioctrl
	}
};

unsigned int IST8307_getID(void)
{
	return IST8307ID;
}

unsigned int IST8307_register(void)
{
	IST8307ID = register_driver(&IST8307.devDrv);
	return  IST8307ID;
}

static void IST8307_i2c_init(void)
{
	//Reset IIC Clock
	Pin PIN_SCL = {PIO_PB4, PIOB, ID_PIOB, PIO_OUTPUT_1, PIO_DEFAULT};	
	PIO_Configure(&PIN_SCL, 1);	
	PIO_Set(&PIN_SCL);
	for(uint8_t i = 0; i < 8; i ++)
	{
		delay_ms(1);
		PIO_Clear(&PIN_SCL);
		delay_ms(1);
		PIO_Set(&PIN_SCL);
	}

	REG_CCFG_SYSIO = (1 << 5) | (1 << 4);
	Pin PIN_I2C1_SDA = {PIO_PB4A_TWD1, PIOB, ID_PIOB, PIO_PERIPH_A, PIO_OPENDRAIN};
	Pin PIN_I2C1_SCL = {PIO_PB5A_TWCK1, PIOB, ID_PIOB, PIO_PERIPH_A, PIO_OPENDRAIN};

	PMC_EnablePeripheral(ID_TWIHS1);
	PIO_Configure(&PIN_I2C1_SDA, 1);
	PIO_Configure(&PIN_I2C1_SCL, 1);
	i2c_init(TWIHS1, 400000, MCK);
	delay_ms(10);
}

static uint8_t IST8307_i2c_write_byte(unsigned char deviceAddr, unsigned char regAddr,unsigned char data)
{
	unsigned char temp[2] = {0};
	temp[0] = regAddr;
	temp[1] = data;
	return i2c_write(TWIHS1, deviceAddr, temp, 2);	
}

static uint8_t IST8307_i2c_read(unsigned char slaveAddr, unsigned char regAddr, unsigned int readNumber, unsigned char* readBuffer)
{
	return i2c_write_read(TWIHS1, slaveAddr, &regAddr, 1, readBuffer, readNumber);
}

static int IST8307_Read(void* buffer, unsigned int len)
{
	int16_t* pBuffer = buffer;

	return IST8307_GetXYZ(pBuffer);
}

static int IST8307_ioctrl(unsigned char cmd, void* arg)
{
	int16_t* pBuffer = arg;
	switch(cmd)
	{
		case WRITE_REG:
			if(!IST8307_i2c_write_byte(IST8307_SLA, IST8307_REG_CNTRL1, IST8307_ODR_MODE)) return 0;
		break;
		case READ_DATA:
			return IST8307_GetXYZ(pBuffer);
		default : return 0;
	}
	return 0;
}

#ifdef IST_CROSS_AXIS_CALI
#ifdef SUPPORT_FLOAT_TYPE
float crossaxis_inv[3][3];
#define OTPsensitivity (330)
#else
int64_t crossaxis_inv[9];
int32_t crossaxis_det[1];
//crossaxis cali_sensitivity and bit shift setting
#define OTPsensitivity (330)
#define crossaxisinv_bitshift (16)
#endif
#endif

int I_InvertMatrix3by3(float *invIn, float *invOut)
{
    float largest;					// largest element used for pivoting
	float scaling;					// scaling factor in pivoting
	float recippiv;					// reciprocal of pivot element
	float ftmp;						// temporary variable used in swaps
	int i, j, k, l, m;				// index counters
	int iPivotRow, iPivotCol;		// row and column of pivot element
	int iPivot[3]={0};
	int isize=3;
	int iRowInd[3] = {0};
	int	iColInd[3] = {0};
	float A[3][3]={0};
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
		{
			A[i][j]= invIn[i+j*3];
		}
	//printf("%f %f %f %f",A[0][0],A[1][1],A[2][2],A[3][3]);
	// to avoid compiler warnings
	iPivotRow = iPivotCol = 0;

	// main loop i over the dimensions of the square matrix A
	for (i = 0; i < isize; i++)
	{
		// zero the largest element found for pivoting
		largest = 0.0F;
		// loop over candidate rows j
		for (j = 0; j < isize; j++)
		{
			// check if row j has been previously pivoted
			if (iPivot[j] != 1)
			{
				// loop over candidate columns k
				for (k = 0; k < isize; k++)
				{
					// check if column k has previously been pivoted
					if (iPivot[k] == 0)
					{
						// check if the pivot element is the largest found so far
						if (fabs(A[j][k]) >= largest)
						{
							// and store this location as the current best candidate for pivoting
							iPivotRow = j;
							iPivotCol = k;
							largest = (float) fabs(A[iPivotRow][iPivotCol]);
						}
					}
					else if (iPivot[k] > 1)
					{
						// zero determinant situation: exit with identity matrix
						//fmatrixAeqI(A, isize);
					 return -1;
					}
				}
			}
		}
		// increment the entry in iPivot to denote it has been selected for pivoting
		iPivot[iPivotCol]++;

		// check the pivot rows iPivotRow and iPivotCol are not the same before swapping
		if (iPivotRow != iPivotCol)
		{
			// loop over columns l
			for (l = 0; l < isize; l++)
			{
				// and swap all elements of rows iPivotRow and iPivotCol
				ftmp = A[iPivotRow][l];
				A[iPivotRow][l] = A[iPivotCol][l];
				A[iPivotCol][l] = ftmp;
			}
		}

		// record that on the i-th iteration rows iPivotRow and iPivotCol were swapped
		iRowInd[i] = iPivotRow;
		iColInd[i] = iPivotCol;

		// check for zero on-diagonal element (singular matrix) and return with identity matrix if detected
		if (A[iPivotCol][iPivotCol] == 0.0F)
		{
			// zero determinant situation: exit with identity matrix
			//fmatrixAeqI(A, isize);
			 return -1;
		}

		// calculate the reciprocal of the pivot element knowing it's non-zero
		recippiv = 1.0F / A[iPivotCol][iPivotCol];
		// by definition, the diagonal element normalizes to 1
		A[iPivotCol][iPivotCol] = 1.0F;
		// multiply all of row iPivotCol by the reciprocal of the pivot element including the diagonal element
		// the diagonal element A[iPivotCol][iPivotCol] now has value equal to the reciprocal of its previous value
		for (l = 0; l < isize; l++)
		{
			A[iPivotCol][l] *= recippiv;
		}
		// loop over all rows m of A
		for (m = 0; m < isize; m++)
		{
			if (m != iPivotCol)
			{
				// scaling factor for this row m is in column iPivotCol
				scaling = A[m][iPivotCol];
				// zero this element
				A[m][iPivotCol] = 0.0F;
				// loop over all columns l of A and perform elimination
				for (l = 0; l < isize; l++)
				{
					A[m][l] -= A[iPivotCol][l] * scaling;
				}
			}
		}
	} // end of loop i over the matrix dimensions

	// finally, loop in inverse order to apply the missing column swaps
	for (l = isize - 1; l >= 0; l--)
	{
		// set i and j to the two columns to be swapped
		i = iRowInd[l];
		j = iColInd[l];

		// check that the two columns i and j to be swapped are not the same
		if (i != j)
		{
			// loop over all rows k to swap columns i and j of A
			for (k = 0; k < isize; k++)
			{
				ftmp = A[k][i];
				A[k][i] = A[k][j];
				A[k][j] = ftmp;
			}
		}
	}
//		printf("%f %f %f %f",A[0][0],A[1][1],A[2][2],A[3][3]);
		for(i=0;i<3;i++)
		for(j=0;j<3;j++)
		{
			 invOut[i+j*3]=A[i][j];
		}
   return 0;

}

void IST8307_MergeHighLowData(uint8_t *raw, int16_t *xyz){
    xyz[0] = (((int16_t)raw[1]) << 8) | raw[0];
    xyz[1] = (((int16_t)raw[3]) << 8) | raw[2];
    xyz[2] = (((int16_t)raw[5]) << 8) | raw[4];
}

#ifdef IST_CROSS_AXIS_CALI
void IST8307_CrossaxisTransformation(int16_t *xyz){
    int i = 0;
#ifdef SUPPORT_FLOAT_TYPE
    int16_t outputtmp[3];
    outputtmp[0] = (*xyz) * crossaxis_inv[0][0] +
                   (*(xyz+1)) * crossaxis_inv[1][0] +
                   (*(xyz+2)) * crossaxis_inv[2][0];

    outputtmp[1] = (*xyz) * crossaxis_inv[0][1] +
                   (*(xyz+1)) * crossaxis_inv[1][1] +
                   (*(xyz+2)) * crossaxis_inv[2][1];

    outputtmp[2] = (*xyz) * crossaxis_inv[0][2] +
                   (*(xyz+1)) * crossaxis_inv[1][2] +
                   (*(xyz+2)) * crossaxis_inv[2][2];

    for (i=0; i<IST8307_AXES_NUM; i++)
        *(xyz+i) = (short)outputtmp[i];
#else
	int64_t outputtmp[3];
    for( i = 0; i < 9; i++){
        if(crossaxis_inv[i]!=0)
          break;
        if(i == 8)
          IST8307_Init();
    }
    outputtmp[0] = xyz[0] * crossaxis_inv[0] +
                   xyz[1] * crossaxis_inv[1] +
                   xyz[2] * crossaxis_inv[2];

    outputtmp[1] = xyz[0] * crossaxis_inv[3] +
                   xyz[1] * crossaxis_inv[4] +
                   xyz[2] * crossaxis_inv[5];
    
    outputtmp[2] = xyz[0] * crossaxis_inv[6] +
                   xyz[1] * crossaxis_inv[7] +
                   xyz[2] * crossaxis_inv[8];

    for (i=0; i<IST8307_AXES_NUM; i++)
    {
        outputtmp[i] = outputtmp[i] / (*crossaxis_det);
    }
    xyz[0]= (short)(outputtmp[0] >> crossaxisinv_bitshift);
    xyz[1]= (short)(outputtmp[1] >> crossaxisinv_bitshift);
    xyz[2]= (short)(outputtmp[2] >> crossaxisinv_bitshift);
#endif
}
#endif

static int IST8307_GetXYZ(int16_t *xyz)
{
	uint8_t Stat = 1;
    uint8_t raw[IST8307_DATA_NUM];
    //Write ODR to force mode
    Stat &= IST8307_i2c_write_byte(IST8307_SLA, IST8307_REG_CNTRL1, IST8307_ODR_MODE);
    //Read 6 reg data from x high&low to z
	Stat &= IST8307_i2c_read(IST8307_SLA, IST8307_REG_DATAX, 1, raw);
    Stat &= IST8307_i2c_read(IST8307_SLA, IST8307_REG_DATAX, IST8307_DATA_NUM, raw);
    //Combine High Low byte
    IST8307_MergeHighLowData(raw, xyz);
#ifdef IST_CROSS_AXIS_CALI
    IST8307_CrossaxisTransformation(xyz);
#endif
	return Stat;
}

#ifdef IST_CROSS_AXIS_CALI
#ifdef SUPPORT_FLOAT_TYPE
int IST8307_Crossaxis_Matrix(int enable)
{
    int ret = 1;
    int i = 0, j;
    char crossxbuf[6];
    char crossybuf[6];
    char crosszbuf[6];
    float OTPcrossaxis[3][3];   
    
    if (enable == 0)
    {
//    DET_eql_0:
    memset(crossaxis_inv, 0 ,9);
    crossaxis_inv[0][0] = crossaxis_inv[1][1] = crossaxis_inv[2][2] = 1;
        return 1;
    }    
    else
    {
        ret &= IST8307_i2c_read(IST8307_SLA, IST8307_REG_XX_CROSS_L, 6, (uint8_t *)crossxbuf);
        ret &= IST8307_i2c_read(IST8307_SLA, IST8307_REG_YX_CROSS_L, 6, (uint8_t *)crossybuf);
        ret &= IST8307_i2c_read(IST8307_SLA, IST8307_REG_ZX_CROSS_L, 6, (uint8_t *)crosszbuf);

        OTPcrossaxis[0][0] = (float)(short)(((crossxbuf[1] << 8) | (crossxbuf[0]))); //328
        OTPcrossaxis[0][1] = (float)(short)(((crossxbuf[3] << 8) | (crossxbuf[2]))); //9
        OTPcrossaxis[0][2] = (float)(short)(((crossxbuf[5] << 8) | (crossxbuf[4]))); //19
        OTPcrossaxis[1][0] = (float)(short)(((crossybuf[1] << 8) | (crossybuf[0]))); //-7
        OTPcrossaxis[1][1] = (float)(short)(((crossybuf[3] << 8) | (crossybuf[2]))); //326
        OTPcrossaxis[1][2] = (float)(short)(((crossybuf[5] << 8) | (crossybuf[4]))); //2
        OTPcrossaxis[2][0] = (float)(short)(((crosszbuf[1] << 8) | (crosszbuf[0])));    //36
        OTPcrossaxis[2][1] = (float)(short)(((crosszbuf[3] << 8) | (crosszbuf[2])));    //27
        OTPcrossaxis[2][2] = (float)(short)(((crosszbuf[5] << 8) | (crosszbuf[4])));   //335
        I_InvertMatrix3by3(&OTPcrossaxis[0][0], &crossaxis_inv[0][0]);
        for(i=0;i<3;i++)
            for(j=0;j<3;j++)
                crossaxis_inv[i][j] = crossaxis_inv[i][j]*OTPsensitivity;
    }
    return ret;
}
#else
void IST8307_Crossaxis_Matrix(int bitshift, int enable)
{
//    int ret;
    int i = 0;
    uint8_t crossxbuf[6];
    uint8_t crossybuf[6];
    uint8_t crosszbuf[6];
    short OTPcrossaxis[9] = {0}; 
    int64_t inv[9] = {0};
    
    if (enable == 0)
    {
DET_eql_0:
        *crossaxis_inv = (1<<bitshift);
        *(crossaxis_inv+1) = 0;
        *(crossaxis_inv+2) = 0;
        *(crossaxis_inv+3) = 0;
        *(crossaxis_inv+4) = (1<<bitshift);
        *(crossaxis_inv+5) = 0;
        *(crossaxis_inv+6) = 0;
        *(crossaxis_inv+7) = 0;
        *(crossaxis_inv+8) = (1<<bitshift); 
        *crossaxis_det = 1;

//        for (i=0; i<9; i++)
//        {
//            printf("*(crossaxis_inv + %d) = %lld\n", i, *(crossaxis_inv+i));
//        }
//        printf("det = %d\n",*crossaxis_det);
        return;
    }    
    else
    {
        i2c_read(IST8307_SLA, IST8307_REG_XX_CROSS_L, 6, crossxbuf);

        i2c_read(IST8307_SLA, IST8307_REG_YX_CROSS_L, 6, crossybuf);

        i2c_read(IST8307_SLA, IST8307_REG_ZX_CROSS_L, 6, crosszbuf);

        OTPcrossaxis[0] = ((int) crossxbuf[1]) << 8 | ((int) crossxbuf[0]);
        OTPcrossaxis[3] = ((int) crossxbuf[3]) << 8 | ((int) crossxbuf[2]);
        OTPcrossaxis[6] = ((int) crossxbuf[5]) << 8 | ((int) crossxbuf[4]);
        OTPcrossaxis[1] = ((int) crossybuf[1]) << 8 | ((int) crossybuf[0]);
        OTPcrossaxis[4] = ((int) crossybuf[3]) << 8 | ((int) crossybuf[2]);
        OTPcrossaxis[7] = ((int) crossybuf[5]) << 8 | ((int) crossybuf[4]);
        OTPcrossaxis[2] = ((int) crosszbuf[1]) << 8 | ((int) crosszbuf[0]);
        OTPcrossaxis[5] = ((int) crosszbuf[3]) << 8 | ((int) crosszbuf[2]);
        OTPcrossaxis[8] = ((int) crosszbuf[5]) << 8 | ((int) crosszbuf[4]);
        *crossaxis_det = ((int32_t)OTPcrossaxis[0])*OTPcrossaxis[4]*OTPcrossaxis[8] +
               ((int32_t)OTPcrossaxis[1])*OTPcrossaxis[5]*OTPcrossaxis[6] +
               ((int32_t)OTPcrossaxis[2])*OTPcrossaxis[3]*OTPcrossaxis[7] -
               ((int32_t)OTPcrossaxis[0])*OTPcrossaxis[5]*OTPcrossaxis[7] -
               ((int32_t)OTPcrossaxis[2])*OTPcrossaxis[4]*OTPcrossaxis[6] -
               ((int32_t)OTPcrossaxis[1])*OTPcrossaxis[3]*OTPcrossaxis[8];
        
        if (*crossaxis_det == 0) {
            goto DET_eql_0;
        }
        
        inv[0] = (int64_t)OTPcrossaxis[4] * OTPcrossaxis[8] - (int64_t)OTPcrossaxis[5] * OTPcrossaxis[7];
        inv[1] = (int64_t)OTPcrossaxis[2] * OTPcrossaxis[7] - (int64_t)OTPcrossaxis[1] * OTPcrossaxis[8];
        inv[2] = (int64_t)OTPcrossaxis[1] * OTPcrossaxis[5] - (int64_t)OTPcrossaxis[2] * OTPcrossaxis[4];
        inv[3] = (int64_t)OTPcrossaxis[5] * OTPcrossaxis[6] - (int64_t)OTPcrossaxis[3] * OTPcrossaxis[8];
        inv[4] = (int64_t)OTPcrossaxis[0] * OTPcrossaxis[8] - (int64_t)OTPcrossaxis[2] * OTPcrossaxis[6];
        inv[5] = (int64_t)OTPcrossaxis[2] * OTPcrossaxis[3] - (int64_t)OTPcrossaxis[0] * OTPcrossaxis[5];
        inv[6] = (int64_t)OTPcrossaxis[3] * OTPcrossaxis[7] - (int64_t)OTPcrossaxis[4] * OTPcrossaxis[6];
        inv[7] = (int64_t)OTPcrossaxis[1] * OTPcrossaxis[6] - (int64_t)OTPcrossaxis[0] * OTPcrossaxis[7];
        inv[8] = (int64_t)OTPcrossaxis[0] * OTPcrossaxis[4] - (int64_t)OTPcrossaxis[1] * OTPcrossaxis[3];
        
        for (i=0; i<9; i++) {
            crossaxis_inv[i] = (inv[i] << bitshift) * OTPsensitivity;
        }
    }
    
    return;
}
#endif
#endif

static int IST8307_Init(void)
{
	uint8_t Stat = 1;
	IST8307_i2c_init();
    Stat &= IST8307_i2c_write_byte(IST8307_SLA, IST8307_REG_CNTRL1, 0x0);
    Stat &= IST8307_i2c_write_byte(IST8307_SLA, IST8307_REG_TEST_REG, 0x1);
    Stat &= IST8307_i2c_write_byte(IST8307_SLA, IST8307_REG_SELECTION_REG, 0x0);

#ifdef IST_CROSS_AXIS_CALI
    int crossaxis_enable = 0;
    char cross_mask[1];
    uint8_t wbuffer[2];

    cross_mask[0]= 0xFF;
    Stat &= IST8307_i2c_read(IST8307_SLA, IST8307_REG_XX_CROSS_L, 2, wbuffer);

    if((wbuffer[0] == cross_mask[0]) && (wbuffer[1] == cross_mask[0]))
        crossaxis_enable = 0;
    else
        crossaxis_enable = 1;
#ifdef SUPPORT_FLOAT_TYPE
    Stat &= IST8307_Crossaxis_Matrix(crossaxis_enable);
#else
    IST8307_Crossaxis_Matrix(crossaxisinv_bitshift, crossaxis_enable);
#endif
#endif
	return Stat;
}
