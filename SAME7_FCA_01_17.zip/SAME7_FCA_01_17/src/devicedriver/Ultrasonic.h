#ifndef __ULTRASONIC_H
#define __ULTRASONIC_H

#include "platform.h"

unsigned int Ultrasonic_getID(void);
unsigned int Ultrasonic_register(void);

#endif /* __ULTRASONIC_H */
