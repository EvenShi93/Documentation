#include "24cXX.h"
#include "delay.h"
#include "device.h"
#include "driver.h"

static unsigned int  AT24CXXID = 0;


static int AT24CXX_Init(void);
static int AT24CXX_OPEN(void);
static int AT24CXX_CLOSE(void);
static void AT24CXX_i2c_init(void);

static int AT24CXX_Read(uint16_t DataAddr,uint16_t len,uint8_t* pData_out);

static int AT24CXX_write_1Byte(uint16_t DataAddr,  uint8_t* pData_in);

static int AT24CXX_write_1Page32Byte(uint16_t PageAddr, uint8_t len,  uint8_t* pData_in);

static int AT24CXX_ioctrl(unsigned char cmd, void* arg);

static DEV AT24CXX = {
	.name = "AT24CXX",
	.devDrv={
		.init =  AT24CXX_Init,
		.open = AT24CXX_OPEN,
		.close = AT24CXX_CLOSE,
		.ioctrl = AT24CXX_ioctrl
	}
};

unsigned int AT24CXX_getID(void)
{
	return AT24CXXID;
}

unsigned int AT24CXX_register(void)
{
	AT24CXXID = register_driver(&AT24CXX.devDrv);
	return AT24CXXID;
}

static void AT24CXX_i2c_init(void)
{
	return;
//	Pin PIN_I2C0_SDA = {PIO_PA3A_TWD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_OPENDRAIN};
//	Pin PIN_I2C0_SCL = {PIO_PA4A_TWCK0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_OPENDRAIN};

//	PMC_EnablePeripheral(ID_TWIHS0);
//	PIO_Configure(&PIN_I2C0_SDA, 1);
//	PIO_Configure(&PIN_I2C0_SCL, 1);
//	i2c_init(TWIHS0, 900000, MCK);
//	delay_ms(10);
}

static int AT24CXX_Init(void)
{
	uint8_t wData = 0, rData = 0;

	AT24CXX_i2c_init();
	if(AT24CXX_Read(8189, 1, &rData))
	{
		if(rData != 0x55)
		{
			rData = 0x55;
			if(AT24CXX_write_1Byte(8189, &rData))
			{
				rData = 0;
				delay_ms(5);
				if(AT24CXX_Read(8189, 1, &rData))
				{
					if(rData != 0x55)
						return 0;
				}
				else
					return 0;
			}
			else
				return 0;
		}
	}
	else
		return 0;

	wData = 0;
	rData = 0;
	if(AT24CXX_Read(8190, 1, &wData))
	{
		wData ++;
		if(AT24CXX_write_1Byte(8190, &wData))
		{
			delay_ms(5);
			if(AT24CXX_Read(8190, 1, &rData))
			{
				if(rData == wData)
					return 1;
				else
					return 0;
			}
			else
				return 0;
		}
		else
			return 0;
	}
	else
		return 0;
}

static int AT24CXX_OPEN(void)
{
	unsigned char temp[2] = {0};
	temp[0] = 0x37;
	temp[1] = 0xA0;//Low
	return i2c_write(TWIHS0, 0x68, temp, 2);
}

static int AT24CXX_CLOSE(void)
{
	unsigned char temp[2] = {0};
	temp[0] = 0x37;
	temp[1] = 0x20;//High
	return i2c_write(TWIHS0, 0x68, temp, 2);
}

static int AT24CXX_Read(uint16_t DataAddr, uint16_t len, uint8_t* pData_out)
{
	uint8_t temp[2] = {0};

	temp[0] = DataAddr >> 8;
	temp[1] = DataAddr & 0x00FF;

	//先写两字节地址,再读取多字节
	i2c_write(TWIHS0, AT24CXX_ADDR, temp, 2);

	return i2c_read(TWIHS0, AT24CXX_ADDR, pData_out, len);
}

static int AT24CXX_write_1Page32Byte(uint16_t PageAddr, uint8_t plen, uint8_t* pData_in)
{
	if(plen > 32) plen = 32;
	if(PageAddr % 32 != 0 || PageAddr > 8160) return 0; //非页起始地址

	uint8_t temp[32+2]={0};

	temp[0]=PageAddr>>8;
	temp[1]=PageAddr&0x00FF;
	for(uint8_t i=0;i<plen;i++) temp[i+2]= *(pData_in+i);

	//先写两字节地址,再写32字节
	return i2c_write(TWIHS0,AT24CXX_ADDR,temp, plen+2);
}

static int AT24CXX_write_1Byte(uint16_t DataAddr, uint8_t* pData_out)
{
	uint8_t temp[3] = {0};

	temp[0] = DataAddr >> 8;
	temp[1] = DataAddr & 0x00FF;
	temp[2] = *pData_out;

	//先写两字节地址,再写一字节
	return i2c_write(TWIHS0, AT24CXX_ADDR, temp, 3);
}

static int AT24CXX_ioctrl(unsigned char cmd, void* arg)
{
  //拿到读写信息结构体
	AT24CXX_RW_struct* pRW_struct = arg;
	
	switch(cmd)
	{
		//写一个字节
		case AT24_WRITE_1Byte:
			if(!AT24CXX_write_1Byte(pRW_struct->DataAddr,pRW_struct->pData)) return 0;
		break;
		
		//写一页32Byte
		case AT24_WRITE_1Page:
			if(!AT24CXX_write_1Page32Byte(pRW_struct->DataAddr,pRW_struct->len,pRW_struct->pData)) return 0;
		break;
		
		//读任意地址任意字节		
		case AT24_READ_DATA:
			if(!AT24CXX_Read(pRW_struct->DataAddr,pRW_struct->len,pRW_struct->pData)) return 0;
		break;
		
		
		default : break;
	}
	return 1;
}
