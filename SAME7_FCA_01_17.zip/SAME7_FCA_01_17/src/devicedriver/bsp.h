#ifndef _BSP_H_
#define _BSP_H_

#include "platform.h"
#include "cfg.h"

#include "SystemTypes.h"

#include "driver.h"
#include "device.h"

#include "ucos_ii.h"

#include "mpu6500.h"
#include "flash.h"
#include "led.h"
#include "moto.h"
#include "volt.h"
#include "task_timer.h"
#include "ms56xx.h"
//#include "hmc5883.h"
#include "ublox_m8q.h"
#include "rf_st10.h"
#include "monitor.h"
#include "switch.h"
//#include "IST8307.h"
#include "IST8307_driver.h"
#include "Steer.h"
#include "Ultrasonic.h"
#include "AppsA9Ctrl.h"
#include "HeatRes.h"

#if USE_CAM_FLOW
#include "camera.h"
#endif /* USE_CAM_FLOW */

#if USE_EEPROM_DATA
#include "24cXX.h"
#endif /* USE_EEPROM_DATA */

/* ��������λ */
#define DEV_ERR_AT24CXX 0x01
#define DEV_ERR_DATAGET 0x02
#define DEV_ERR_IST8307 0x04
#define DEV_ERR_BMS56XX 0x08
#define DEV_ERR_MPU6500 0x10
#define DEV_ERR_FLOWCAM 0x20
#define DEV_ERR_UBLOXM8 0x40

#define DEV_ERR_ALLMASK 0x7F

uint8_t bsp_init(void);

#if OS_CRITICAL_METHOD == 3u

#define OS_ALLOC_SR() 	OS_CPU_SR  cpu_sr = 0u

#else

#define OS_ALLOC_SR()

#endif

#endif
