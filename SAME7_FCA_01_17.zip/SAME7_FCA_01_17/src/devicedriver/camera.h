#ifndef __CAMERA_H
#define __CAMERA_H

#include "platform.h"

/** Frame size: Width, Height */
#define FRAMESIZE_80X80 0
#define FRAMESIZE_84X84 1
#define FRAMESIZE_160X160 2
#define FRAMESIZE_100X100 3
#define FRAMESIZE_132X132 4
#define FRAMESIZE_164X164 5

#define FRAMESIZE FRAMESIZE_132X132

#if (FRAMESIZE==FRAMESIZE_80X80)
	#define FrameWidth 80
	#define FrameHeight 80
	#define IMAGE_BUFF_SIZE (FrameWidth*FrameHeight*2)   //80*80*4/3//for klt sub sample pyramid
#endif

#if (FRAMESIZE==FRAMESIZE_160X160)
	#define FrameWidth 160
	#define FrameHeight 160
	#define IMAGE_BUFF_SIZE (FrameWidth*FrameHeight*2)   //160*160*4/3//for klt sub sample pyramid
#endif

#if (FRAMESIZE==FRAMESIZE_84X84)
	#define FrameWidth 84
	#define FrameHeight 84
	#define IMAGE_BUFF_SIZE (FrameWidth*FrameHeight*2)   //120*120*4/3//for klt sub sample pyramid
#endif

#if (FRAMESIZE==FRAMESIZE_100X100)
	#define FrameWidth 100
	#define FrameHeight 100
	#define IMAGE_BUFF_SIZE (FrameWidth*FrameHeight*2)   //120*120*4/3//for klt sub sample pyramid
#endif

#if (FRAMESIZE==FRAMESIZE_132X132)
	#define FrameWidth 132
	#define FrameHeight 132
	#define IMAGE_BUFF_SIZE (FrameWidth*FrameHeight*2)   //120*120*4/3//for klt sub sample pyramid
#endif

#if (FRAMESIZE==FRAMESIZE_164X164)
	#define FrameWidth 164
	#define FrameHeight 164
	#define IMAGE_BUFF_SIZE (FrameWidth*FrameHeight*2)   //160*160*4/3//for klt sub sample pyramid
#endif


#define IMAGE_SIZE (FrameWidth * FrameHeight)


/** Video frame BitsPerPixel */
#define FRAME_BPP         (16)
/** Video frame buffer size calculation */
#define FRAME_BUFFER_SIZEC(W,H)  ((W)*(H)*FRAME_BPP/8)

typedef enum
{
	GetFrameBuffer = 0,
	GetImageT,
	GetLumValue,
}Camera_IOCTRL_CMD;

unsigned int camera_getID(void);
unsigned int camera_register(void);

extern void camera_set_bright(int8_t bright);
extern void camera_set_contrast(int8_t contrast);
extern void camera_set_exposure(uint8_t exposure);

#endif /* __CAMERA_H */
