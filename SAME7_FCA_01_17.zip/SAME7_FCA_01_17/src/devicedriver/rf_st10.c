#include "rf_st10.h"
#include "delay.h"
#include "device.h"
#include "driver.h"
#include "maths.h"

static unsigned int rfSt10ID = 0;
unsigned char rfSt10UartDmaChannel = 3;

//#if defined(CTRL_RF)
static void rf_st10_power_init(void);
static void rf_st10_power_on(void);
//static void rf_st10_power_off(void);
//#endif

#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
static unsigned char rfSt10UartDmaTxFlag = 1;
static unsigned char rf_st10_data_rec_flag = 0;
static YUNEEC_REC_STR rf_st10_rec_package = {0};
static YUNEEC_RF_STR rf_st10_remote_rec_package = {0};
static void rf_st10_uart_send_nbyte(unsigned char* pBuffer, unsigned int len);
static void rf_st10_uart_init(void);
#endif

static int rf_st10_init(void);
static int rf_st10_read(void* buffer, unsigned int len);
static int rf_st10_write(void* buffer, unsigned int len);
static int rf_st10_open(void);
static int rf_st10_close(void);
static int rf_st10_ioctrl(unsigned char cmd, void* arg);

static DEV rfSt10 = {
	.name = "RF_ST10",
	.devDrv = {
		.init = rf_st10_init,
		.read = rf_st10_read,
		.write = rf_st10_write,
		.open = rf_st10_open,
		.close = rf_st10_close,
		.ioctrl = rf_st10_ioctrl
	}
};

unsigned int rf_st10_getID(void)
{
	return rfSt10ID;
}

unsigned int rf_st10_register(void)
{
	rfSt10ID = register_driver(&rfSt10.devDrv);
	return rfSt10ID;
}

static int rf_st10_init(void)
{
//#if defined(CTRL_RF)
	rf_st10_power_init();
	rf_st10_power_on();
	delay_ms(100);
//#endif
#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
	rf_st10_uart_init();
#endif
	return 1;
}

static int rf_st10_read(void* buffer, unsigned int len)
{
#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
	if(rf_st10_data_rec_flag == 1)
	{
#if MOT_PREBURNING_ENABLE
		if(rf_st10_rec_package.type == 0 && len == 0)
		{
#endif /* MOT_PREBURNING_ENABLE */
			YUNEEC_RF_STR* pBuffer = buffer;
			*pBuffer = rf_st10_remote_rec_package;
			rf_st10_data_rec_flag = 0;
#if MOT_PREBURNING_ENABLE
			return 1;
		}
		else if(rf_st10_rec_package.type == 1 && len == 1)
			return 1;
		else if(rf_st10_rec_package.type == 7 && len == 7)
		{
			*(uint8_t *)buffer = *((uint8_t *)&rf_st10_remote_rec_package);
			rf_st10_data_rec_flag = 0;
			return 1;
		}
		else if(rf_st10_rec_package.type == 8 && len == 8)
		{
			*((YUNEEC_RF_STR *)buffer) = rf_st10_remote_rec_package;
			rf_st10_data_rec_flag = 0;
			return 1;
		}
		else
			return 0;
#endif /* MOT_PREBURNING_ENABLE */
	}
#endif
	return 0;
}

static int rf_st10_write(void* buffer, unsigned int len)
{
#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
	unsigned char* pBuffer = buffer;
	rf_st10_uart_send_nbyte((unsigned char *)pBuffer, len);
#endif
	return 1;
}

static int rf_st10_open(void)
{
#if defined(CTRL_RF)
	rf_st10_power_on();
#endif
	return 1;
}

static int rf_st10_close(void)
{
#if defined(CTRL_RF)
	rf_st10_power_off();
#endif
	return 1;
}

static int rf_st10_ioctrl(unsigned char cmd, void* arg)
{
#if defined(CTRL_RF)
	switch(cmd)
	{
		case RF_ST10_IOCTRL_REMOTE_PACKAGE_REC_FLAG:
		{
			unsigned char* pBuffer = arg;
			*pBuffer = rf_st10_data_rec_flag;
		}
		break;
		default: break;
	}
#endif
	return 1;
}

static Pin PIN_RADIO_CONT = {PIO_PA26, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};

//#if defined(CTRL_RF)
static void rf_st10_power_init(void)
{
	PIO_Configure(&PIN_RADIO_CONT, 1);
}

static void rf_st10_power_on(void)
{
	PIO_Clear(&PIN_RADIO_CONT);
}

//static void rf_st10_power_off(void)
//{
//	PIO_Set(&PIN_RADIO_CONT);
//}
//#endif

#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
//#if defined(CTRL_RF)
//#endif
static void rf_st10_uart_init(void)
{
	Pin PIN_UART3_RX = {PIO_PD28A_URXD3, PIOD, ID_PIOD, PIO_PERIPH_A, PIO_DEFAULT};
	Pin PIN_UART3_TX = {PIO_PD30A_UTXD3, PIOD, ID_PIOD, PIO_PERIPH_A, PIO_DEFAULT};

	PMC_EnablePeripheral(ID_UART3);

	PIO_Configure(&PIN_UART3_TX, 1);
	PIO_Configure(&PIN_UART3_RX, 1);

	UART_Configure(UART3, (UART_MR_PAR_NO | UART_MR_BRSRCCK_PERIPH_CLK | UART_MR_CHMODE_NORMAL), 115200, MCK);

	UART_SetReceiverEnabled(UART3, 1);
	UART_SetTransmitterEnabled(UART3, 1);

	NVIC_ClearPendingIRQ(UART3_IRQn);
	NVIC_SetPriority(UART3_IRQn, 12);

	UART_EnableIt(UART3, UART_IER_RXRDY);
	NVIC_EnableIRQ(UART3_IRQn);

	PMC_EnablePeripheral(ID_XDMAC);

	/* Clear dummy status */
	XDMAC_GetChannelIsr(XDMAC, rfSt10UartDmaChannel);
	/* Disables XDMAC interrupt for the given channel. */
	XDMAC_DisableGIt (XDMAC, rfSt10UartDmaChannel);
	XDMAC_DisableChannelIt (XDMAC, rfSt10UartDmaChannel, 0xFF);
	/* Disable the given dma channel. */
	XDMAC_DisableChannel(XDMAC, rfSt10UartDmaChannel);

	XDMAC_SetChannelConfig(XDMAC, rfSt10UartDmaChannel, XDMAC_CC_TYPE_PER_TRAN		|
														XDMAC_CC_DSYNC_MEM2PER		|
														XDMAC_CC_MBSIZE_SINGLE		|
														XDMAC_CC_PROT_SEC			|
														XDMAC_CC_MEMSET_NORMAL_MODE	|
														XDMAC_CC_CSIZE_CHK_1		|
														XDMAC_CC_DWIDTH_BYTE		|
														XDMAC_CC_SIF_AHB_IF0		|
														XDMAC_CC_DIF_AHB_IF1		|
														XDMAC_CC_SAM_INCREMENTED_AM	|
														XDMAC_CC_DAM_FIXED_AM		|
														XDMAC_CC_PERID(26)			);

	XDMAC_SetMicroblockControl(XDMAC, rfSt10UartDmaChannel, 12);
	XDMAC_SetSourceAddr(XDMAC, rfSt10UartDmaChannel, (unsigned int)0);
	XDMAC_SetDestinationAddr(XDMAC, rfSt10UartDmaChannel, (unsigned int)&(UART3->UART_THR));
	XDMAC_SetDescriptorControl(XDMAC, rfSt10UartDmaChannel, 0);
	XDMAC_SetBlockControl(XDMAC, rfSt10UartDmaChannel, 0);
	XDMAC_SetDataStride_MemPattern(XDMAC, rfSt10UartDmaChannel, 0);
	XDMAC_SetSourceMicroBlockStride(XDMAC, rfSt10UartDmaChannel, 0);
	XDMAC_SetDestinationMicroBlockStride(XDMAC, rfSt10UartDmaChannel, 0);

	/*Enable xDMA interrupt */ 
	NVIC_ClearPendingIRQ(XDMAC_IRQn);
	NVIC_SetPriority(XDMAC_IRQn, 9);
	NVIC_EnableIRQ(XDMAC_IRQn);

	XDMAC_EnableChannelIt (XDMAC, rfSt10UartDmaChannel, XDMAC_CIE_BIE);
	XDMAC_EnableGIt (XDMAC, rfSt10UartDmaChannel);
}

#if defined(CTRL_RF) || MOT_PREBURNING_ENABLE
//发送DMA中断
void rfSt10UartDmaIrq(void)
{
	rfSt10UartDmaTxFlag = 1;
}

static void rf_st10_uart_send_nbyte(unsigned char *pBuffer, unsigned int len)
{
	while(rfSt10UartDmaTxFlag == 0){}
	rfSt10UartDmaTxFlag = 0;
	XDMAC_SetMicroblockControl(XDMAC, rfSt10UartDmaChannel, len);
	XDMAC_SetSourceAddr(XDMAC, rfSt10UartDmaChannel, (unsigned int)pBuffer);
	XDMAC_SetDestinationAddr(XDMAC, rfSt10UartDmaChannel, (unsigned int)&(UART3->UART_THR));
	SCB_CleanInvalidateDCache();
	XDMAC_EnableChannel(XDMAC, rfSt10UartDmaChannel);
}
#endif

void rf_st10_uart_rx_irq(unsigned char data)
{
	static unsigned char rf_st10_step = 0;
	static unsigned short rfcount = 0;
	switch(rf_st10_step)
	{
		case 0:
			rf_st10_rec_package.h1 = data;
			if(data == 0x55)
				rf_st10_step = 1;
			else
				rf_st10_step = 0;
		break;
		case 1:
			rf_st10_rec_package.h2 = data;
			if(data == 0x55)
				rf_st10_step = 2;
			else
				rf_st10_step = 0;
		break;
		case 2:
			rf_st10_rec_package.length = data;
			if((data > 0) && (data <= 100))
				rf_st10_step = 3;
			else
				rf_st10_step = 0;
		break;
		case 3:
			rf_st10_rec_package.type = data;
			rfcount = 0;
			rf_st10_step = 4;
		break;
		case 4:
		{
			rf_st10_rec_package.buffer[rfcount] = data;
			rfcount ++;
			if(rfcount > 100)
			{
				rf_st10_step = 0;
			}
			if(rfcount == rf_st10_rec_package.length - 1)
			{
				if(crcRfCal(&rf_st10_rec_package.length, rf_st10_rec_package.length) == rf_st10_rec_package.buffer[rf_st10_rec_package.length - 2])
				{
					rf_st10_remote_rec_package = *(YUNEEC_RF_STR *)(rf_st10_rec_package.buffer);
					rf_st10_data_rec_flag = 1;
				}
				rfcount = 0;
				rf_st10_step = 0;
			}
		}
		break;
		default:
			rf_st10_step = 0;
		break;
	}
}
#endif
