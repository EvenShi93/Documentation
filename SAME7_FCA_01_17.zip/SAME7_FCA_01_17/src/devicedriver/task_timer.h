#ifndef _TASK_TIMER_H_
#define _TASK_TIMER_H_

#include "platform.h"

unsigned int task_timer_getID(void);
unsigned int task_timer_register(void);
static int task_timer_init(void);
static int task_timer_open(void);

#endif
