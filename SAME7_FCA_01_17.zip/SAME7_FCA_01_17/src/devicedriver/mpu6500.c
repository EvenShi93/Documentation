#include "mpu6500.h"
#include "delay.h"	
#include "device.h"
#include "driver.h"

static float  accCoefficient = 0;
static float  gyroCoefficient = 0;
static unsigned int  mpu6500ID = 0;
static uint8_t MPU_ID = 0;

static DEV mpu6500={
	.name = "MPU6500",
	.devDrv = {
		.init = mpu6500_init,
		.read = mpu6500_read,
		.ioctrl = mpu6500_ioctrl
	}
};

unsigned int mpu6500_getID(void)
{
	return mpu6500ID;
}
unsigned int mpu6500_register(void)
{
	mpu6500ID = register_driver(&mpu6500.devDrv);
	return  mpu6500ID;
}

static void mpu6500_i2c_init(void)
{
	//Reset IIC Clock
	Pin PIN_SCL = {PIO_PA4, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};
	Pin PIN_I2C0_SDA = {PIO_PA3A_TWD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_OPENDRAIN};
	Pin PIN_I2C0_SCL = {PIO_PA4A_TWCK0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_OPENDRAIN};

	PIO_Configure(&PIN_SCL, 1);
	PIO_Set(&PIN_SCL);
	for(uint8_t i = 0; i < 8; i ++)
	{
		delay_ms(1);
		PIO_Clear(&PIN_SCL);
		delay_ms(1);
		PIO_Set(&PIN_SCL);
	}

	PMC_EnablePeripheral(ID_TWIHS0);
	PIO_Configure(&PIN_I2C0_SDA, 1);
	PIO_Configure(&PIN_I2C0_SCL, 1);
	i2c_init(TWIHS0, 900000, MCK);
	delay_ms(5);
}

static uint8_t mpu6500_i2c_write_byte(unsigned char deviceAddr, unsigned char regAddr, unsigned char buffer)
{
	unsigned char temp[2] = {0};
	temp[0] = regAddr;
	temp[1] = buffer;
	return i2c_write(TWIHS0, deviceAddr, temp, 2);
}


static uint8_t mpu6500_i2c_read(unsigned char deviceAddr,unsigned char regAddr,unsigned char numByteToRead,unsigned char *pBuffer)
{
	return i2c_write_read(TWIHS0, deviceAddr, &regAddr, 1, pBuffer, numByteToRead);
}

static void mpu6500_set_acc(unsigned char accel)
{
	switch(accel)
	{
		case MPU6500_ACCEL_SCALE2G:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_ACCEL_CONFIG,MPU6500_ACCEL_SCALE2G);
			accCoefficient = 0.00059814453125f; //2*9.8/32768
			break;
		case MPU6500_ACCEL_SCALE4G:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_ACCEL_CONFIG,MPU6500_ACCEL_SCALE4G);
			accCoefficient = 0.0011962890625f; //4*9.8/32768
			break;
		case MPU6500_ACCEL_SCALE8G:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_ACCEL_CONFIG,MPU6500_ACCEL_SCALE8G);
			accCoefficient = 0.002392578125f; //8*9.8/32768
			break;
		case MPU6500_ACCEL_SCALE16G:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_ACCEL_CONFIG,MPU6500_ACCEL_SCALE16G);
			accCoefficient = 0.00478515625f; //16*9.8/32768
			break;
		default:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_ACCEL_CONFIG,MPU6500_ACCEL_SCALE8G);
			accCoefficient = 0.002392578125f; //8*9.8/32768
			break;
	}
}

static void mpu6500_set_gyro(unsigned char gyro)
{
	switch(gyro)
	{
		case MPU6500_GYRO_SCALE250:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_GYRO_CONFIG,MPU6500_GYRO_SCALE250);
			gyroCoefficient = 0.00762939453125f;// 250/32768
			break;
		case MPU6500_GYRO_SCALE500:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_GYRO_CONFIG,MPU6500_GYRO_SCALE500);
			gyroCoefficient = 0.0152587890625f;// 500/32768
			break;
		case MPU6500_GYRO_SCALE1000:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_GYRO_CONFIG,MPU6500_GYRO_SCALE1000);
			gyroCoefficient = 0.030517578125f;// 1000/32768
			break;
		case MPU6500_GYRO_SCALE2000:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_GYRO_CONFIG,MPU6500_GYRO_SCALE2000);
			gyroCoefficient = 0.06103515625f;// 2000/32768
			break;
		default:
			mpu6500_i2c_write_byte(MPU6500_ADDR,MPU6500_GYRO_CONFIG,MPU6500_GYRO_SCALE2000);
			gyroCoefficient = 0.06103515625f;// 2000/32768
			break;
	}
}

static int mpu6500_init(void)
{
	uint8_t Sta = 1;
	mpu6500_i2c_init();
	delay_ms(10);
	Sta &= mpu6500_i2c_read(MPU6500_ADDR, MPU6500_WHO_AM_I, 1, &MPU_ID);
	if(MPU_ID != MPU6500_ID) return 0;
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_PWR_MGMT_1, 0x80);
	delay_ms(100);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_SIGNAL_PATH_RESET, 0x07);

	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_PWR_MGMT_1, 0x0);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_SMPLRT_DIV, 0);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_CONFIG, MPU6500_DLPF_GRY_41);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_ACCEL_CONFIG2, MPU6500_DLPF_ACC_5);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_INT_PIN_CFG, 0x20);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_INT_ENABLE, 0x01);

	if(!Sta) return 0;

	mpu6500_set_acc(MPU6500_ACCEL_SCALE8G);
	mpu6500_set_gyro(MPU6500_GYRO_SCALE2000);
	delay_ms(5);

	return Sta;
}

static int mpu6500_reboot(void)
{
  uint8_t MPU_ID=0;
  uint8_t Sta = 1; 

	Pin PIN_SCL = {PIO_PA4, PIOA, ID_PIOA, PIO_OUTPUT_1, PIO_DEFAULT};
	Pin PIN_I2C0_SDA = {PIO_PA3A_TWD0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_OPENDRAIN};
	Pin PIN_I2C0_SCL = {PIO_PA4A_TWCK0, PIOA, ID_PIOA, PIO_PERIPH_A, PIO_OPENDRAIN};
	PIO_Configure(&PIN_SCL, 1);
	PIO_Set(&PIN_SCL);
	for(uint8_t i = 0; i < 8; i ++)
	{
		PIO_Clear(&PIN_SCL);
		delay_us(1);
		PIO_Set(&PIN_SCL);
		delay_us(1);
	}
	PMC_EnablePeripheral(ID_TWIHS0);
	PIO_Configure(&PIN_I2C0_SDA, 1);
	PIO_Configure(&PIN_I2C0_SCL, 1);
	i2c_init(TWIHS0, 900000, MCK);
	
	
	Sta &= mpu6500_i2c_read(MPU6500_ADDR, MPU6500_WHO_AM_I, 1, &MPU_ID);
  if(MPU_ID != MPU6500_ID || Sta==0 ) return 0;
	
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_SMPLRT_DIV, 0);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_CONFIG, MPU6500_DLPF_GRY_41);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_ACCEL_CONFIG2, MPU6500_DLPF_ACC_5);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_INT_PIN_CFG, 0x20);
	Sta &= mpu6500_i2c_write_byte(MPU6500_ADDR, MPU6500_INT_ENABLE, 0x01);
	mpu6500_set_acc(MPU6500_ACCEL_SCALE8G);
	mpu6500_set_gyro(MPU6500_GYRO_SCALE2000);
	
	return Sta;
}

static int mpu6500_read(void* buffer,unsigned int len)
{
	 unsigned char* pBuffer = buffer;
	 return mpu6500_i2c_read(MPU6500_ADDR, MPU6500_ACCEL_XOUT_H, MPU6500_GYRO_OUT_LEN + MPU6500_TEMP_OUT_LEN + MPU6500_ACCEL_OUT_LEN, pBuffer);
}

static int mpu6500_ioctrl(unsigned char cmd,void* arg)
{
	switch(cmd)
	{
		case MPU6500_IOCTRL_ACCEL_READ: 
		{
			unsigned char* pBuffer = arg;
			if(!mpu6500_i2c_read(MPU6500_ADDR,MPU6500_ACCEL_XOUT_H,MPU6500_ACCEL_OUT_LEN,pBuffer)) return 0;
		}
		break;
		case MPU6500_IOCTRL_GYRO_READ:
		{
			unsigned char* pBuffer = arg;
			if(!mpu6500_i2c_read(MPU6500_ADDR,MPU6500_GYRO_XOUT_H,MPU6500_GYRO_OUT_LEN,pBuffer)) return 0;
		}
		break;
		case MPU6500_IOCTRL_TEMP_READ:
		{
			unsigned char* pBuffer = arg;			
			if(!mpu6500_i2c_read(MPU6500_ADDR,MPU6500_TEMP_OUT_H,MPU6500_TEMP_OUT_LEN,pBuffer)) return 0;
		}
		break;
		case MPU6500_IOCTRL_ACCEL_SET:
		{
			unsigned char* pBuffer = arg;	
			mpu6500_set_acc(*pBuffer);
		}
		break;
		case MPU6500_IOCTRL_GYRO_SET:
		{
			unsigned char* pBuffer = arg;	
			mpu6500_set_gyro(*pBuffer);
		}
		break;
		case MPU6500_IOCTRL_ACC_COEFF_READ:
		{
			float* pBuffer = arg;	
			*pBuffer = accCoefficient;
		}
		break;
		case MPU6500_IOCTRL_GYRO_COEFF_READ:
		{
			float* pBuffer = arg;	
			*pBuffer = gyroCoefficient;
		}
		break;
		case MPU6500_IOCTRL_IMU_READ:
		{
			unsigned char* pBuffer = arg;
			if(!mpu6500_i2c_read(MPU6500_ADDR,MPU6500_ACCEL_XOUT_H, 14, pBuffer)) return 0;
		}
		break;
		case MPU6500_IOCTRL_REBOOT:
		{
			//����������
		  	if(!mpu6500_reboot())
				return 0;
			else
				return 1;
		}
		default:
		break;
	}
	return 1;
}
